#include<fstream>
#include<iostream>
#include<algorithm>
using namespace std;

        ifstream f("z.in");
        ofstream g("z.out");
int get_number(int x, int y, int putere,long int numb)
{
    if(putere==1)
    {
        if(x==1)
        {
            numb+=3+y;
        }
        else
        {
            numb+=1+y;
        }
        return numb;
    }
    else
    {
    int line,col;
    line=x/putere; //cout<<line<<"\n\n\n";
    col=y/putere;   //cout<<y<<"\n\n\n";
    if(line==0&&col==0)
    {   cout<<"0 0\n";
        x=x%putere;
        y=y%putere;
        putere=(putere>>1);
        return get_number(x,y,putere,numb);
    }
    if(line==0&&col==1)
    {
        cout<<"0 1\n";
        x=x%putere;
        y=y%putere;
        numb+=(putere*putere);
        putere=(putere>>1);
        return get_number(x,y,putere,numb);
    }
    if(line==1&&col==0)
    {
        cout<<"1 0\n";
        x=x%putere;
        y=y%putere;
        numb+=2*(putere*putere);
        putere=(putere>>1);
        return get_number(x,y,putere,numb);
    }
    if(line==1&&col==1)
    {
        cout<<"1 1\n";
        x=x%putere;
        y=y%putere;
        numb+=3*(putere*putere); cout<<3*putere<<"\n\n";
        putere=(putere>>1);
        return get_number(x,y,putere,numb);
    }

    }

    return -1;
}
int main()
{


        int n,k;
        f>>n>>k;
        int putere=1;
        putere=(putere<<(n-1));
        int x,y;
        for(int i=0;i<k;++i)
        {
            long int numb=0;
            f>>x>>y;
            g<<get_number(x-1,y-1,putere,numb)<<"\n";
        }
        return 0;
}
