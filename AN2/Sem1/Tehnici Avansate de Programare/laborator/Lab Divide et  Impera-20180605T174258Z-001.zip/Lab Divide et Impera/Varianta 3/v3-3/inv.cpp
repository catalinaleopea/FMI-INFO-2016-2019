#include<fstream>
#include<algorithm>
#include<iostream>
#include<queue>
using namespace std;
ifstream f("inv.in");
ofstream g("inv.out");

int m;

int determina_inversiuni(int *vect,int st,int dr)
{
    if(dr-st==0)
    {        return 0;}
    else
    {
        int nr_inv=0;
        int mid=(st+dr)/2;
        nr_inv+=determina_inversiuni(vect,st,mid);
        nr_inv+=determina_inversiuni(vect,mid+1,dr);
        int *vect_nou=new int[dr-st+1];
        queue <int> q;
        int i=st,j=mid+1,k=0;
        while(i<=mid&&j<=dr)
        if(vect[i]<vect[j])
        {
            while((!(q.empty()))&&(q.front()<vect[i]))
            {
                vect_nou[k]=q.front(); //cout<<"A adaugat: "<<q.front()<<"\n";
                //g<<q.front()<<"\n";
                q.pop();
                ++k;
            }
            {vect_nou[k]=vect[i];// cout<<"A adaugat: "<<vect[i]<<"\n";
            ++i;
            ++k;}

        }
        else
        {
            while((vect[i]<=2*vect[j])&&(i<=mid))
            {
                q.push(vect[i]);
                ++i;
            }
            if(i<=mid&&(vect[i]>2*vect[j]))
            {nr_inv+=mid-i+1;}
            vect_nou[k]=vect[j]; //cout<<"A adaugat: "<<vect[j]<<"\n";
            ++j;
            ++k;
        }
        //g<<i<<" "<<dr<<" "<<mid<<"\n";
         while(i<=mid)
        {
            while((!(q.empty()))&&(q.front()<vect[i]))
            {
                vect_nou[k]=q.front();
                q.pop();
                ++k;
            }
            vect_nou[k]=vect[i]; //cout<<"A adaugat: "<<vect[i]<<"\n";
            ++i;
            ++k;
        }
       // g<<i<<" "<<dr<<" "<<mid<<"\n\n\n\n";
        while(j<=dr)
        {
                while((!(q.empty()))&&(q.front()<vect[j]))
            {
                vect_nou[k]=q.front();
                q.pop();
                ++k;
            }
            vect_nou[k]=vect[j]; //cout<<"A adaugat: "<<vect[j]<<"\n";
            ++j;
            ++k;
        }
        while(!q.empty())
        {
            vect_nou[k]=q.front();
            q.pop();
            ++k;
        }
        j=0;
        for(int i=st;i<=dr;++i,++j)
        vect[i]=vect_nou[j];
        return nr_inv;
    }

}

int main()
{
    int n;
    f>>n;
    m=n;
    int *vect;
    vect=new int[n];
    for(int i=0;i<n;++i)
    f>>vect[i];
    g<<determina_inversiuni(vect,0,n-1);

    return 0;
}
