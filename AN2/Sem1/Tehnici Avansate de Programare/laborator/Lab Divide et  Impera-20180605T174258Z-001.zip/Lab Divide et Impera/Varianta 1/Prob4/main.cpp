#include <iostream>
#include <float.h>
#include <cmath>
#include <algorithm>
#include <fstream>
using namespace std;
struct punct
{
    int x, y;
};
struct distanta
{
    float dist;
    punct start,dest;
};
int cmpX(const void* a, const void* b)
{
    punct *p1 = (punct *)a,  *p2 = (punct *)b;
    return (p1->x - p2->x);
}
int cmpY(const void* a, const void* b)
{
    punct *p1 = (punct *)a,   *p2 = (punct *)b;
    return (p1->y - p2->y);
}
float dist(punct p1, punct p2)
{
    return sqrt( (p1.x - p2.x)*(p1.x - p2.x) + (p1.y - p2.y)*(p1.y - p2.y) );
}
distanta PeBanda(punct banda[], int nr, distanta d)
{
    distanta min = d;
    for (int i = 0; i < nr; ++i)
        for (int j = i+1; j < nr && (banda[j].y - banda[i].y) < min.dist; ++j)
            if (dist(banda[i],banda[j]) < min.dist)
                {
                min.dist = dist(banda[i], banda[j]);
                min.start=banda[i];
                min.dest=banda[j];
                }

    return min;
}
distanta CeaMaiApropiata(punct Px[], punct Py[], int n)
{
    if (n <= 3)
    {
        distanta min;
        min.dist = FLT_MAX;
        for (int i = 0; i < n; ++i)
            for (int j = i+1; j < n; ++j)
                if (dist(Px[i], Px[j]) < min.dist)
                    {
                        min.dist = dist(Px[i], Px[j]);
                        min.start= Px[i];
                        min.dest = Px[j];
                    }
        return min;
    }
    int mid = n/2;
    punct midpunct = Px[mid];
    punct Pyl[mid+1];
    punct Pyr[n-mid-1];
    int li = 0, ri = 0;
    for (int i = 0; i < n; i++)
    {
        if (Py[i].x <= midpunct.x)
            Pyl[li++] = Py[i];
        else
            Pyr[ri++] = Py[i];
    }
    distanta dl = CeaMaiApropiata(Px, Pyl, mid);
    distanta dr = CeaMaiApropiata(Px + mid, Pyr, n-mid);

    distanta d = (dl.dist< dr.dist) ? dl : dr;

    punct banda[n];
    int nr = 0;
    for (int i = 0; i < n; i++)
        if ( abs(Py[i].x - midpunct.x) < d.dist)
            banda[nr++] = Py[i];

    if(d.dist < PeBanda(banda, nr, d).dist)
        return d;
    else
        return PeBanda(banda, nr, d);
}
int main()
{
    ifstream fin("date.in");
    ofstream fout("date.out");
    int n;
    fin>>n;
    punct *P = new punct[n];
    for(int i=0; i<n; i++)
        fin>>P[i].x>>P[i].y;

    punct Px[n];
    punct Py[n];
    for (int i = 0; i < n; i++)
    {
        Px[i] = P[i];
        Py[i] = P[i];
    }

    qsort(Px, n, sizeof(punct), cmpX);
    qsort(Py, n, sizeof(punct), cmpY);

    distanta rezultat=CeaMaiApropiata(Px, Py, n);
    cout<< rezultat.dist<<" { ("<<rezultat.start.x<<","<<rezultat.start.y<<") , ("<<rezultat.dest.x<<","<<rezultat.dest.y<<") }";
    return 0;
}
