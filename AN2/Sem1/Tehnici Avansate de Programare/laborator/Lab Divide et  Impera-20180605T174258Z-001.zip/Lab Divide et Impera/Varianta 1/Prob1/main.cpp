#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("date.in");
ofstream fout("date.out");
void val_eq_pos(int* &v,int s, int f)
{
    int m=(s+f)/2;
    if(s-f==0)
        return ;
    if(v[m]==m)
    {
        fout<<m<<" ";
        val_eq_pos(v,s,m-1);
        val_eq_pos(v,m+1,f);
    }
    else
        if(v[m]<m)
            val_eq_pos(v,m+1,f);
        else ///v[m]>m
            val_eq_pos(v,s,m-1);
}
int main()
{
    int n;
    fin>>n;
    int* v=new int[n];
    for(int i=0;i<n;i++)
        fin>>v[i];
    val_eq_pos(v,0,n-1);
    return 0;
}
