#include <iostream>
#include <fstream>
#include <assert.h>
using namespace std;
ifstream fin("date.in");
ofstream fout("date.out");
struct Node
{
    int val;
    Node* left;
    Node* right;
};
int *map;
void mapIndex(int inordine[], int n)
{
    for (int i = 0; i < n; i++)
        map[inordine[i]] = i;

}
void RSD(Node* aux)  ///Preordine
{
    if(aux!=NULL)
    {
        fout<<aux->val<<" ";
        RSD(aux->left);
        RSD(aux->right);
    }
}
void SRD(Node* aux)
{
    if(aux!=NULL)
    {
        SRD(aux->left);
        fout<<aux->val<<" ";
        SRD(aux->right);
    }
}
void SDR(Node* aux)
{
    if(aux!=NULL)
    {
        SDR(aux->left);
        SDR(aux->right);
        fout<<aux->val<<" ";
    }
}
int valid=0,ul=-1;
Node* buildInordinePostordine(int inordine[], int postordine[], int n, int offset)
{
    if(valid)
        return NULL; ///Daca s-au gasit elemente ce se repeta, atunci constructia arborelui se opreste
    if(n >= 0)
    {
        if (n == 0) return NULL;
        int radVal = postordine[n-1];
        int i = map[radVal]-offset; ///i=Pozitia radacinei actuale in parcurgerea Inordine

        Node *rad = new Node;
        rad->val=radVal;

     if(radVal==ul) ///Valoarea curenta a mai fost adaugata
        valid=1;

    ul=radVal;///Actualizez ultima val din arbore

        rad->left  = buildInordinePostordine (inordine, postordine, i, offset);
        rad->right = buildInordinePostordine (inordine+i+1, postordine+i, n-i-1, offset+i+1);

    return rad;
    }
}
void afisare_arbore(Node* arb)
{
    if(arb!=NULL)
    {cout<<endl;
    if(arb->left==NULL)
        if(arb->right==NULL)
            cout<<arb->val<<"(-,-)"<<endl;
        else
            cout<<arb->val<<"(-,"<<arb->right->val<<")"<<endl;
    else
        if(arb->right==NULL)
            cout<<arb->val<<"("<<arb->left->val<<",-)"<<endl;
        else
            cout<<arb->val<<"("<<arb->left->val<<","<<arb->right->val<<")"<<endl;
    afisare_arbore(arb->left);
    afisare_arbore(arb->right);}

}
int main()
{

    int n;
    fin>>n;
    int *inordine=new int[n];
    int *postordine=new int[n];

    for(int i=0; i<n; i++)
        fin>>postordine[i];

    for(int i=0; i<n; i++)
        fin>>inordine[i];
    map=new int[n+1]; ///Asta impune ca nodurile sa fie etichetate de la 1 la n
    mapIndex(inordine,n);

    Node* arbore=buildInordinePostordine(inordine,postordine,n,0);

    afisare_arbore(arbore);
    if(!valid)  ///Daca constructia nu a fost oprita validatorul ramane 0 si parcurgem arborele
    {
    fout<<"RSD:";
    RSD(arbore);
    fout<<endl;

    fout<<"SRD:";
    SRD(arbore);
    fout<<endl;

    fout<<"SDR:";
    SDR(arbore);
    fout<<endl;
    }
    else
        fout<<"Nu se poate.";
    return 0;
}
