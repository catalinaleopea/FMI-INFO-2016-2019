#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
double Mediana(vector<int> A, vector<int> B)
{
    int m = A.size();
    int n = B.size();
    if (m > n)   // to ensure m<=n
    {
        vector<int> temp = A;
        A = B;
        B = temp;
        int tmp = m;
        m = n;
        n = tmp;
    }
    int iMin = 0, iMax = m, lungTot = (m + n + 1) / 2;
    while (iMin <= iMax)
    {
        int i = (iMin + iMax) / 2;
        int j = lungTot - i;
        if (i < iMax && B[j-1] > A[i])
        {
            iMin = i + 1;
        }
        else if (i > iMin && A[i-1] > B[j])
        {
            iMax = i - 1;
        }
        else
        {
            int maxS = 0;
            if (i == 0)
            {
                maxS = B[j-1];
            }
            else if (j == 0)
            {
                maxS = A[i-1];
            }
            else
            {
                maxS =max(A[i-1], B[j-1]);
            }
            if ( (m + n) % 2 == 1 )
            {
                return maxS;
            }

            int minD = 0;
            if (i == m)
            {
                minD = B[j];
            }
            else if (j == n)
            {
                minD = A[i];
            }
            else
            {
                minD = min(B[j], A[i]);
            }

            return (maxS + minD) / 2.0;
        }
    }
    return 0.0;
}
int main()
{
    ifstream fin("date.in");
    vector<int> A,B;
    int n,m,aux;
    fin>>n;
    for(int i=0; i<n; i++)
    {
        fin>>aux;
        A.push_back(aux);
    }
    fin>>m;
    for(int i=0; i<m; i++)
    {
        fin>>aux;
        B.push_back(aux);
    }
    cout<<"Mediana vectorilor A si B este "<<Mediana(A,B);
    return 0;
}
