#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
#include <stdlib.h>
#include <algorithm>
#include <iomanip>
#include <float.h>
using namespace std;

struct punct
{
    long long int x,y;
} p,q;

bool comp1(punct a,punct b)
{
    return (a.x < b.x);
}

bool comp2(punct a,punct b)
{
    return (a.y < b.y);
}
double d(punct a,punct b)
{
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
double Distanta(vector<punct> Px,vector<punct> Py,long int st,long int dr)
{
    /// Daca am doar doua puncte,distanta minima este dinstanta dintre cele doua puncte.
    if (dr-st == 1)
    {
        return d(Px[st],Px[dr]);
    }
    /// Daca am trei puncte,distanta minima este minimul dintre distantele perechilor de puncte.
    if (dr-st == 2)
    {
         return min(min(d(Px[st],Px[st+1]),d(Px[st+1],Px[dr])),d(Px[st],Px[dr]));

    }

    double dist;

    long long int m = (st+dr)/2;
    /// Calculez distanta minima pentru multimea de puncte din stanga dreptei si pentru multimea de puncte din dreapta acesteia.
    double d1 = Distanta(Px,Py,st,m);
    double d2 = Distanta(Px,Py,m+1,dr);
    dist = min(d1,d2);
    /// Iau intr-un vector toate punctele care se afla la distanta cel mult dist de dreapta verticala,din vectorul sortat dupa y.
    vector <punct> aux;
    for (long long int i=st; i<dr; i++)
        if (llabs(Py[i].x - Py[m].x) <= dist)
            aux.push_back(Py[i]);
    double d3 = DBL_MAX;
    /// Pentru fiecare punct din acest vector,iau urmatoarele cel mult 7 puncte.
    for (long long int i=0; i<aux.size(); i++)
    {
        long long int j = i+1;
        /// Fac distantele dintre ele doua cate doua si in d3 pun distanta minima.
        while ((j <= i+7) && (j < aux.size()))
        {
            d3 = min(d3,d(Py[i],Py[j]));
            j++;
        }
    }

    dist = min(dist,d3);
    return dist;
}
int main()
{
    ifstream fin("cmap.in");
    vector <punct> punctex,punctey;
    /// Citesc primul vector din fisier.
    long long int n;
    fin >> n;
    for(long long int i=0; i<n; i++)
    {
        punct a;
        fin >> a.x >> a.y;
        punctex.push_back(a);
    }
    fin.close();

    punctey = punctex; /// Ii fac o copie primului vector si o pun in al doilea.
    sort(punctex.begin(),punctex.end(),comp1);  /// Sortez primul vector dupa abscisa.
    sort(punctey.begin(),punctey.end(),comp2); /// Sortez primul vector dupa ordonata.


    cout <<"Distanta este "<< fixed << setprecision(6) << Distanta(punctex,punctey,0,n-1) << endl;


    return 0;
}
