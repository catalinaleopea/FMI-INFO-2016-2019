#include <iostream>
#include <string.h>
#include <fstream>
#include <cstdlib>
using namespace std;

ifstream f("date.in");

struct node
{
    node* st;
    node* dr;
    int info;
};
void vsd(node *c)

{
    if(c)

    {
        cout<<c->info<<" ";

        vsd(c->st);

        vsd(c->dr);

    }

}

node* citire()
{

    int x;
    f>>x;

    node*  c;
    if(x!=0)
    {
        if(x!=-1)
        {
            c=new node;
            c->info=x;
            c->st=citire();
            c->dr=citire();
            return c;
        }
        else
            return NULL;
    }
    else
        return 0;

}
bool verifica(node* nod)
{
    int x,y;

    if(nod!=NULL)
    {
        if(nod->st!=NULL && nod->dr!=NULL)
        {
            x=nod->st->info;
            y=nod->dr->info;
            if(x> nod->info || nod->info > y)
            {
                cout<<"da"<<x<<" "<<nod->info<<" "<<y;
                return 0;
            }
        }
        verifica(nod->st);
        verifica(nod->dr);
    }
    return 1;
}
int main()
{
    node* r;
    r=citire();
    vsd(r);
    if(verifica(r))
        cout<<"Arbore binar de cautare.";
    else
        cout<<"Nu.";
    return 0;
}
