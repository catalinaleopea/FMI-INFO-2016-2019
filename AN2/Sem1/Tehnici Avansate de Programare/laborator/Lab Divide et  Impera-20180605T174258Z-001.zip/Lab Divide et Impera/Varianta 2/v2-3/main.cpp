#include <iostream>
#include <fstream>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

    int n;
struct pereche
{
    int x;
    float w;
};
int sum_weight(pereche a[], int p, int r)
{
    int i;
    int suma=0;
    for(i = p; i <=r; i++)
        {suma+=a[i].w;}
        cout<<" "<<suma<<"+"<<endl;
    return suma;
}
int PARTITION(pereche a[],int p,int r)
{
    pereche temp,temp1;
    int y=a[r].x;
    int i=p-1;
    for(int j=p; j<=r; j++)
    {
        if(a[j].x < y)
        {cout<"saddsafag";

            i=i+1;
            temp=a[i];
            a[i]=a[j];
            a[j]=temp;
        }
    }
    temp1=a[i+1];
    a[i+1]=a[r];
    a[r]=temp1;
    return i+1;
}
int R_PARTITION(pereche a[],int p,int r)
{
    srand(time(NULL));
    int i=p+rand()%(r-p+1);
    cout<<i<<"-PIVOT->";
    pereche temp;
    temp=a[r];
    a[r]=a[i];
    a[i]=temp;
    return PARTITION(a,p,r);
}


int weighted_median(pereche a[], int p, int r)
{
    if(r == p)
        return a[p].x;
    int q;
    q=R_PARTITION(a,p,r);
    cout<<"\nq="<<q;

    int ws=sum_weight(a,p,q-1);
    int wr=sum_weight(a,q+1,r);
    if(ws < 50 && wr <= 50)
        return a[q].x;
    else if (ws > wr )
    {
        a[q].w += wr;
        weighted_median(a,p ,q);
    }
    else
    {
        a[q].w +=ws;
        weighted_median(a,q,r);
    }
}
int main()
{
    pereche a[100];
    ifstream f("date.in");
    f>>n;
    int i;
    for(i = 1; i <= n; i++)
    {
        int val;
        float pond;
        f>>val>>pond;
        a[i].x = val;
        a[i].w = pond*100;
    }

    cout<<weighted_median(a,1,n);
    return 0;

}
