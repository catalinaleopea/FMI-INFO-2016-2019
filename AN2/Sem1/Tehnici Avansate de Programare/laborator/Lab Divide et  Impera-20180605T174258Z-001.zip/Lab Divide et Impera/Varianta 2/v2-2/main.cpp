#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;
int piesa;
void fillmatrix(int smatrix_size,int x_missing,int y_missing,int x_matrix,int y_matrix,int sizee,int matrix[100][100])
{    int z=piesa;
    if(smatrix_size == 2)
    {cout<<"DA "<<endl;
        int i,j;
        piesa++;
        z=piesa;
        for(i = x_matrix; i < (x_matrix + smatrix_size); i++)
            for(j = y_matrix; j < (y_matrix + smatrix_size); j++)
            {

                if(!(i == x_missing && j == y_missing))
                    matrix[i][j]=piesa;
            }
        return;
    }
    piesa++;
    z=piesa;

    int half_size=smatrix_size/2,x_center,y_center;
    int x_up_left,y_up_left,x_up_right,y_up_right,x_do_left,y_do_left,x_do_right,y_do_right;
    x_center = x_matrix + half_size;
    y_center = y_matrix + half_size;

    if(x_missing < x_center && y_missing < y_center ) ///Daca sunt in cadranul stanga sus `
    {
        matrix[x_center][y_center] = piesa;
        matrix[x_center-1][y_center] = piesa;
        matrix[x_center][y_center-1] = piesa;
        x_up_left=x_missing;
        y_up_left=y_missing;
        x_up_right=x_center-1;
        y_up_right=y_center;
        x_do_left=x_center;
        y_do_left=y_center-1;
        x_do_right=x_center;
        y_do_right=y_center;
    }
    else if(x_missing < x_center && y_missing >= y_center)   ///Daca sunt in cadranul dreapta sus
    {
        matrix[x_center][y_center] = piesa;
        matrix[x_center-1][y_center-1] = piesa;
        matrix[x_center][y_center-1] = piesa;
        x_up_right = x_missing;
        y_up_right = y_missing;
        x_up_left = x_center-1;
        y_up_left = y_center-1;
        x_do_left = x_center;
        y_do_left = y_center-1;
        x_do_right = x_center;
        y_do_right = y_center;

    }
    else if(x_missing >= x_center && y_missing < y_center) ///Daca sunt in cadranul stanga jos
    {
        matrix[x_center][y_center] = piesa;
        matrix[x_center-1][y_center-1] = piesa;
        matrix[x_center-1][y_center] = piesa;
        x_up_left = x_center-1;
        y_up_left = y_center-1;
        x_up_right = x_center-1;
        y_up_right = y_center;
        x_do_left = x_missing;
        y_do_left = y_missing;
        x_do_right = x_center;
        y_do_right = y_center;
    }
    else if(x_missing >= x_center && y_missing >= y_center) ///Daca sunt in cadranul dreapta jos
    {
        matrix[x_center-1][y_center-1] = piesa;
        matrix[x_center-1][y_center] = piesa;
        matrix[x_center][y_center-1] = piesa;
        x_up_left = x_center-1;
        y_up_left = y_center-1;
        x_up_right = x_center-1;
        y_up_right = y_center;
        x_do_left = x_center;
        y_do_left = y_center-1;
        x_do_right = x_missing;
        y_do_right = y_missing;
    }
    fillmatrix(half_size,x_up_left,y_up_left,x_matrix,y_matrix,sizee,matrix);///Apelez pt cadranul stanga sus
    fillmatrix(half_size,x_up_right,y_up_right,x_matrix,y_matrix + half_size,sizee,matrix); ///dreapta sus
    fillmatrix(half_size,x_do_left,y_do_left,x_matrix + half_size,y_matrix,sizee,matrix);///stanga jos
    fillmatrix(half_size,x_do_right,y_do_right,x_matrix + half_size,y_matrix + half_size,sizee,matrix);///dreapta jos

}
int main()
{
    ifstream f("date.in");
    int i,j,n,x,y;
    f>>n>>x>>y;
    int matrice[100][100];
    n=pow(2,n);
    for(i = 0 ; i < n ; i++ )
        for(j = 0 ; j < n ; j++)
            matrice[i][j] = -1;
    cout<<x<<y<<endl;
    matrice[x-1][y-1] = 0;

    fillmatrix(n,x-1,y-1,0,0,n,matrice);
    for(i = 0 ; i < n ; i++ )
    {
        for(j = 0 ; j < n ; j++)
            cout<<matrice[i][j]<<" ";
        cout<<endl;
    }
    return 0;
}
