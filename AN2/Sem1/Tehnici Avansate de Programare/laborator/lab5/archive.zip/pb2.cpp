#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

void solve(vector<vector<int>> &matrix,int dim,int x,int y,int &k,int lx, int ly) {
    if(dim<=1) {
        return;
    }
    k++;
    cout<<x<<" "<<y<<endl;
    if(lx<dim/2+x&&ly<dim/2+y) { ///okay
        matrix[x+dim/2][y+dim/2]=k;
        matrix[x+dim/2-1][y+dim/2]=k;
        matrix[x+dim/2][y+dim/2-1]=k;
        solve(matrix,dim/2,x,y,k,lx,ly);
        solve(matrix,dim/2,x,y+dim/2,k,x+dim/2-1,y+dim/2);
        solve(matrix,dim/2,x+dim/2,y+dim/2,k,x+dim/2,y+dim/2);
        solve(matrix,dim/2,x+dim/2,y,k,x+dim/2,y+dim/2-1);
    }
    if(lx<dim/2+x&&ly>=dim/2+y) { ///okay
        matrix[x+dim/2-1][y+dim/2-1]=k;
        matrix[x+dim/2][y+dim/2-1]=k;
        matrix[x+dim/2][y+dim/2]=k;
        solve(matrix,dim/2,x,y,k,x+dim/2-1,y+dim/2-1);
        solve(matrix,dim/2,x,y+dim/2,k,lx,ly);
        solve(matrix,dim/2,x+dim/2,y,k,x+dim/2,y+dim/2-1);
        solve(matrix,dim/2,x+dim/2,y+dim/2,k,x+dim/2,y+dim/2);
    }
    if(lx>=dim/2+x&&ly<dim/2+y) { ///okay
        matrix[x+dim/2-1][y+dim/2]=k;
        matrix[x+dim/2-1][y+dim/2-1]=k;
        matrix[x+dim/2][y+dim/2]=k;
        solve(matrix,dim/2,x,y,k,x+dim/2-1,y+dim/2-1);
        solve(matrix,dim/2,x,y+dim/2,k,x+dim/2-1,y+dim/2);
        solve(matrix,dim/2,x+dim/2,y+dim/2,k,x+dim/2,y+dim/2);
        solve(matrix,dim/2,x+dim/2,y,k,lx,ly);
    }
    if(lx>=dim/2+x&&ly>=dim/2+y) { ///okay
        matrix[x+dim/2-1][y+dim/2-1]=k;
        matrix[x+dim/2-1][y+dim/2]=k;
        matrix[x+dim/2][y+dim/2-1]=k;
        solve(matrix,dim/2,x,y,k,x+dim/2-1,y+dim/2-1);
        solve(matrix,dim/2,x,y+dim/2,k,x+dim/2-1,y+dim/2);
        solve(matrix,dim/2,x+dim/2,y+dim/2,k,lx,ly);
        solve(matrix,dim/2,x+dim/2,y,k,x+dim/2,y+dim/2-1);
    }
}

int main()
{
    int n;
    cin>>n;
    int m=pow(2,n);
    int x,y;
    cin>>x>>y;
    vector<vector<int>> matrix(m+1);
    for(int i=1;i<=m;i++)
        matrix[i].resize(m+1);
    matrix[x][y]=0;
    int k=0;
    for(int i=1;i<=m;i++) {
        for(int j=1;j<=m;j++)
            cout<<matrix[i][j];
        cout<<endl;
    }
    cout<<endl<<endl<<endl;
    solve(matrix,m,1,1,k,x,y);
    for(int i=1;i<=m;i++) {
        for(int j=1;j<=m;j++)
            cout<<matrix[i][j]<<" ";
        cout<<endl;
    }
    return 0;
}
