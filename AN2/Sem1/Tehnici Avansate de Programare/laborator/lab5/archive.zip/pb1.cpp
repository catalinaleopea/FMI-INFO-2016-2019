#include <iostream>
#include <limits>
#include <fstream>

using namespace std;

ifstream f("date.in");
ofstream g("date.out");
struct node
{
    int val;
    node* rad;
    node* left;
    node* right;
};

node* newNode(int val)
{
    node* nod=new node;
    nod->val=val;
    nod->rad=NULL;
    nod->left=NULL;
    nod->right=NULL;
    return(nod);
}

void adaugareRSD(node* rad, int &k, int n, int &ok)
{
    int x;
    int i=0;
    while(++i<n)
    {
        f>>x;
        if(rad->left==NULL)
        {
            rad->left=newNode(x);
            rad->left->rad=rad;
            if(x!=0)
            {
                rad=rad->left;
                if(x>rad->rad->val)
                    ok=0;
            }
        }
        else if(rad->right==NULL)
        {
            rad->right=newNode(x);
            rad->right->rad=rad;
            if(x!=0)
            {
                rad=rad->right;
                if(x<rad->rad->val)
                    ok=0;
            }
        }
        if(x!=0) k=0;
        else k++;
        if(k==2)
        {
            while(rad->left!=NULL&&rad->right!=NULL)
                rad=rad->rad;
        }
    }
}

int main()
{
    int n;
    cin>>n;
    int x;
    f>>x;
    node* rad=newNode(x);
    int k=0;
    int ok=1;
    adaugareRSD(rad,k,n,ok);
    if(ok)
        g<<"da";
    else
        g<<"nu";
    return 0;
}
