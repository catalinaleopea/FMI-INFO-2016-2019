package com.mkyong;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class ExtragereDinText {

    private static final String FILENAME = "C:\\Users\\Student\\Desktop\\file.txt";

    public static void main(String[] args) {
        try (BufferedReader br = new BufferedReader(new FileReader(FILENAME))) {

            String sCurrentLine;

            while ((sCurrentLine = br.readLine()) != null) {
                String aux[] = sCurrentLine.split("[^0-9]+");
                System.out.println(Arrays.asList(aux));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}








