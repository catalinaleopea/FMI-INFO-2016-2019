package com.company;

public class ClasaNonThreadSafe {
    private int c = 0;

    public void increment(){
        c++;
    }
    public int getC(){
        return c;
    }
}
