package com.company;

import java.util.Arrays;

public class Vector extends Lista{
    public static void main(String[] args) {
        Vector vector = new Vector();
        vector.add(5);
        vector.add(60);
        System.out.println(vector);
        vector.remove(5);
        System.out.println(vector);
        vector.add(7);
        System.out.println(vector);
        System.out.println(vector.indexOf(6));
        vector.clear();
        System.out.println(vector);
    }
}
