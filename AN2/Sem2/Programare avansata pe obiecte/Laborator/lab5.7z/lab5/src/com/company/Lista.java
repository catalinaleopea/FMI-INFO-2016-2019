package com.company;

abstract class Lista {
    protected int lastIndex = -1;
    Object[] elems = new Object[100];
    public boolean add(Object obj){
        if(elems.length == lastIndex) {
            Object newElems[] = new Object[elems.length + 100];
            for (int i = 0; i < elems.length; i++) {
                newElems[i] = elems[i];
            }
            elems = newElems;
            elems[++lastIndex] = obj;
        }else{
            elems[++lastIndex] = obj;
        }
        return true;
    }

    public boolean remove(Object obj) {
        for(int i = 0;i < elems.length ;i++){
            if(obj.equals(elems[i])){
                for(int j = i;j < elems.length - 1;j++){
                    elems[j] = elems[j+1];
                }
                lastIndex--;
                return true;
            }
        }
        return false;
    }

    int indexOf(Object obj) {
        for(int i = 0;i < elems.length ;i++){
            if(obj.equals(elems[i])){
                return i;
            }
        }
        return -1;
    }

    public String toString() {
        if(lastIndex > -1) {
            String ret = "[";
            for (int i = 0; i < lastIndex; i++) {
                ret = ret + elems[i] + ",";
            }
            ret = ret + elems[lastIndex] + "]";
            return ret;
        }
       return "Lista vida";

    }
    public void clear(){
        lastIndex = -1;
    }
}