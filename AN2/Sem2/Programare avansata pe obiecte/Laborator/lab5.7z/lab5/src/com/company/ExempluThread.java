package  com.company;
public class ExempluThread implements Runnable{
    public static int idCounter = 1;

    private ClasaNonThreadSafe clasaNonThreadSafe;
    private int id;

    public ExempluThread(ClasaNonThreadSafe clasaNonThreadSafe) {
        this.clasaNonThreadSafe = clasaNonThreadSafe;
        this.id = idCounter++;
    }

    @Override
    public void run() {
        System.out.println("Tread "+id+" started!");
        for(int i = 0; i < 1000 * 1000; i++){
            clasaNonThreadSafe.increment();
        }
        System.out.println("Thread "+id+" ended. Value of c = "
                +clasaNonThreadSafe.getC());
    }
    public static void main(String[] args) {
        ExempluThread[] exempluThreads = new ExempluThread[5];
        ClasaNonThreadSafe clasaNonThreadSafe = new ClasaNonThreadSafe();

        for(int i =0; i<exempluThreads.length; i++){
            exempluThreads[i] = new ExempluThread(clasaNonThreadSafe);
            new Thread(exempluThreads[i]).start();
        }
    }

}
