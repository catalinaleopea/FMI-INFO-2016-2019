package com.company;

public class VectorOrdonat extends Vector {
    @Override
    public boolean add(Object obj){
        //insereaza ordonat
        System.out.println("a");
        return true;
    }
}
