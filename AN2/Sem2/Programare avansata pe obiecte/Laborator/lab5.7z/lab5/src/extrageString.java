//impartire din sir
package com.company;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

public class extrageString {
    public static void main(String[] args) {
    /*    String str = "as123dgd4";
        Pattern p = Pattern.compile("[0-9]+");
        Matcher m = p.matcher(str);
        int beginIndex, endIndex;
        while(m.find()) {
            beginIndex = m.start();
            endIndex = m.end();
            String nrVal = str.substring(beginIndex, endIndex);
            System.out.println(nrVal);
        }
        */
        String str ="str1" + "str2";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("str1");
        stringBuilder.append("str2");
        System.out.println(stringBuilder.toString());

        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("str1");
        stringBuffer.append("str2");
        stringBuffer.append("str3");
        System.out.println(stringBuffer.toString());
    }
}