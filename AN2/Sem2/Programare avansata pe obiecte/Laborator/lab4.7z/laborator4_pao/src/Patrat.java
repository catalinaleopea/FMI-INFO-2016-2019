public class Patrat extends Dreptunghi {
    public Patrat(){

    }

    public Patrat(Punct p1, Punct p2, Punct p3, Punct p4) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.p4 = p4;
    }
    @Override
    public double aria(){
        double lungime = Math.sqrt(Math.pow(p2.getX()-p1.getX(), 2) + Math.pow(p2.getY()-p1.getY(),2));
        return lungime * lungime;
    }

    @Override
    public String toString(){
        double lungime = Math.sqrt((p2.getX()-p1.getX())^2 + (p2.getY()-p1.getY())^2);
        return "lungimea=" + lungime + " punct p1= " + p1;
    }

    public static void main(String[] args) {
        Punct p1 = new Punct(10, 0);
        Punct p2 = new Punct(0, 0);
        Punct p3 = new Punct(0, 10);
        Punct p4 = new Punct(10, 10);
        Patrat d = new Patrat(p1, p2, p3, p4);
        Patrat p = new Patrat(p1, p2, p3, p4);
        System.out.println(p);
        System.out.println(p.aria());
        Patrat pa2 = new Patrat();
        pa2.p1 = p1;
        System.out.println(p.equals(pa2));
    }
}
