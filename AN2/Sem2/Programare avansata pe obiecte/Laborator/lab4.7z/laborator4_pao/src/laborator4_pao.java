import java.util.HashMap;
import java.util.Map;

public class laborator4_pao {

    public static void main(String[] args){
        Map<Object, Object> map = new HashMap<>();
        map.put("str1", "value1");
        map.put(1, 15);

        for(Object key : map.keySet()){
            System.out.println(key + " " + key.getClass().getSimpleName());
        }
        Map<String,Integer> newMap = new HashMap<>();
        newMap.put("cheie1", 15);
        newMap.put("cheie2", 18);

        System.out.println(newMap);
        newMap.remove("cheie2");
        newMap.put("cheie1", 20);
        System.out.println(newMap);


    }
}
