public class Dreptunghi {
    //constructor,equals,hashcode,toString
    //metoda aria
    //clasa Patrat alt fisier
    //suprascrieti arie lat*lat
    //suprascrieti toString lungimea unei laturi si un punct
    //getter setter
    protected Punct p1;
    protected Punct p2;
    protected Punct p3;
    protected Punct p4;

    public Punct getP1() {
        return p1;
    }

    public Punct getP2() {
        return p2;
    }

    public Punct getP3() {
        return p3;
    }

    public Punct getP4() {
        return p4;
    }

    public void setP1(Punct p1) {
        this.p1 = p1;
    }

    public void setP2(Punct p2) {
        this.p2 = p2;
    }

    public void setP3(Punct p3) {
        this.p3 = p3;
    }

    public void setP4(Punct p4) {
        this.p4 = p4;
    }

    public Dreptunghi(){

    }

    public Dreptunghi(Punct p1, Punct p2, Punct p3, Punct p4) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.p4 = p4;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        } else {
            if(obj instanceof Dreptunghi) {
                Dreptunghi d2 = (Dreptunghi) obj;
                return this.p1 == d2.getP1() &&
                        this.p2 == d2.getP2() &&
                        this.p3 == d2.getP3() &&
                        this.p4 == d2.getP4();
            } else {
                return false;
            }
        }
    }

    @Override
    public String toString(){
        return "Puncte (p1=" + p1 + ", p2=" + p2 +", p3=" + p3 +", p4=" + p4 + ")";
    }

    public double aria(){
        double lungime = Math.sqrt(Math.pow(p2.getX()-p1.getX(), 2) + Math.pow(p2.getY()-p1.getY(),2));
        double latime = Math.sqrt(Math.pow(p3.getX()-p1.getX(), 2) + Math.pow(p1.getY(), 2));
        return lungime * latime;
    }

    public static void main(String[] args) {
        Punct p1 = new Punct(1, 2);
        Punct p2 = new Punct(1, 5);
        Punct p3 = new Punct(7, 2);
        Punct p4 = new Punct(7, 5);
        Dreptunghi d = new Dreptunghi(p1, p2, p3, p4);
        System.out.println(d);
        System.out.println(d.aria());
        Dreptunghi d2 = new Dreptunghi();
        d2.p1 = p1;
        System.out.println(d.equals(d2));
    }
}
