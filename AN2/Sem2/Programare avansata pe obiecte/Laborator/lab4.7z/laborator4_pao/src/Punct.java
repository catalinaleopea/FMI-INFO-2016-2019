import java.util.*;

public class Punct {
    //constructor cu x si y
    //set si get pt x si y
    //suprascrie metoda equals a i 2 ob de tipul Punct sunt egale doar daca au x si y egale
    //suprascrie toString() sa se afiseze x=? y=?
    private int x;
    private int y;

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    Punct(int x, int y){
        this.x = x;
        this.y = y;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        } else {
            if(obj instanceof Punct) {
                Punct p2 = (Punct) obj;
                return this.x == p2.getX() && this.y == p2.getY();
            } else {
                return false;
            }
        }
    }

    @Override
    public String toString(){
        return "Punct (x=" + x + ", y=" + y + ")";
    }

    @Override
    public int hashCode(){
        return x + y;
    }

    public static int increment(int value){
        value++;
        return value;
    }

    public static Punct incrementX(Punct punct){
        int x = punct.getX();
        x++;
        punct.setX(x);
        System.out.println("E acelasi p1= " + punct.equals(punct));
        return punct;
    }

    public static int[] initFirstELem(int [] vector){
        vector[0] = 1;
        return vector;
    }
    public static void main(String[] args) {
        /*Punct p1 = new Punct(1, 2);
        Punct p2 = new Punct(5, 10);
        Punct p3 = new Punct(100, 200);
        String str1 = "not a point";
        System.out.println(p1.equals(p1));
        System.out.println(p1.equals(p2));
        System.out.println(p1.equals(str1));
        */

        /*Map<Punct, Integer> newMap = new HashMap<>();
        newMap.put(p1, 1);
        newMap.put(p2, 2);
        newMap.put(p3, 3);
        System.out.println(p1.equals(p2));
        System.out.println(newMap);
        */

        /*List<Punct> punctList = new ArrayList<>();
        punctList.add(p1);
        punctList.add(p2);
        punctList.add(p3);
        System.out.println(punctList);
        int index = punctList.indexOf(p2);
        int lastIndexOf = punctList.indexOf(p1);
        System.out.println("index " + index);
        System.out.println("last index " + lastIndexOf);
        */

        /*Map<String, Punct> punctMap = new HashMap<>();
        punctMap.put("key1", p1);
        punctMap.put("key2", p2);
        punctMap.put("key3", p3);
        System.out.println(punctMap.containsValue(p2));
        */

        /*Punct p1 = new Punct(10, 0);
        Punct p2 = incrementX(p1);
        System.out.println(p1);
        System.out.println(p2);
        */

        int [] v = new int[10];
        int [] vector2 = initFirstELem(v);
        System.out.println(vector2[0]);
        System.out.println(v.equals(vector2));
    }
}
