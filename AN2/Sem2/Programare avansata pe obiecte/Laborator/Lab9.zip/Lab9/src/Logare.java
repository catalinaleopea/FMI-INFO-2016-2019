public class Logare {
    public Logare(String username, String parola) {

        if(username.equals("username") && parola.equals("parola"))
            System.out.println("DA");
        else
            System.out.println("NU");


    }
}
