import javax.swing.*;
import java.awt.*;

public class Fereastra {
    public static void main(String[] args) {
        JFrame jFrame = new JFrame("Fereastra simpla");
        JButton[] jButtons = new JButton[5];

        for(int i=0; i<jButtons.length; i++){
            jButtons[i] = new JButton("Button"+i+i+i);
        }
        BorderLayout borderLayout = new BorderLayout();
        jFrame.setLayout(borderLayout);
        jFrame.add(jButtons[0], BorderLayout.PAGE_START);
        jFrame.add(jButtons[1], BorderLayout.PAGE_END);
        //jFrame.add(jButtons[2], BorderLayout.CENTER);
        jFrame.add(jButtons[3], BorderLayout.LINE_START);
        jFrame.add(jButtons[4], BorderLayout.LINE_END);

        JPanel jPanelCentru = new JPanel();
        jPanelCentru.setLayout(new GridLayout(2, 2));
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        for(int i=0; i<2; i++){
            for(int j=0; j<2; j++)
            {
                JLabel jLabel = new JLabel("Label_"+i+"_"+j);
                gridBagConstraints.gridx=i;
                gridBagConstraints.gridy=j;
                jPanelCentru.add(jLabel, gridBagConstraints);
            }
        }
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;

        JLabel jLabel = new JLabel("2 celule");
        jPanelCentru.add(jLabel, gridBagConstraints);

        jFrame.add(jPanelCentru, BorderLayout.CENTER);
        jFrame.pack();
        jFrame.setVisible(true);



    }
}
