import java.util.ArrayList;
import java.util.List;

public class UserService {

    List <User> registerdUsers = new ArrayList<>();

    public boolean login(User user){
        return registerdUsers.contains(user);
    }

    public boolean register(User user){
        if (registerdUsers.contains(user)){
            System.out.println("User-ul e deja in baza de date");
            return false;
        }
        registerdUsers.add(user);
        System.out.println("User-ul a fost creat");
        return true;
    }

}
