import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Register {
    public static void main(String[] args) {
        JFrame jFrame = new JFrame("Fereastra register");
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        BorderLayout borderLayout = new BorderLayout();
        jFrame.setLayout(borderLayout);


        JLabel username = new JLabel("Username");
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        JPanel jPanelCentru = new JPanel();
        jPanelCentru.setLayout(new GridLayout(4, 2));

        gridBagConstraints.gridx=0;
        gridBagConstraints.gridy=0;
        jPanelCentru.add(username, gridBagConstraints);

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        JTextField jTextField = new JTextField(20);
        jPanelCentru.add(jTextField, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        JLabel password = new JLabel("Password");
        jPanelCentru.add(password, gridBagConstraints);

        gridBagConstraints.gridx=1;
        gridBagConstraints.gridy=1;
        JPasswordField jPasswordField = new JPasswordField(20);
        jPanelCentru.add(jPasswordField, gridBagConstraints);

        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        JLabel password2 = new JLabel("Retype-Password");
        jPanelCentru.add(password2, gridBagConstraints);

        gridBagConstraints.gridx=2;
        gridBagConstraints.gridy=1;
        JPasswordField jPasswordField2 = new JPasswordField(20);
        jPanelCentru.add(jPasswordField2, gridBagConstraints);

        gridBagConstraints.gridx=3;
        gridBagConstraints.gridy=0;
        JButton jButton = new JButton("Register");
        jPanelCentru.add(jButton, gridBagConstraints);

        jFrame.add(jPanelCentru, BorderLayout.CENTER);
        jFrame.setSize(600, 600);
        jFrame.pack();
        jFrame.setVisible(true);

        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String text = jTextField.getText();
                String password = new String(jPasswordField.getPassword());
                User user = new User();
                user.setUsername(text);
                user.setPassword(password);
                UserService userService = new UserService();
                if(userService.register(user)){
                    jFrame.dispose();
                    Login login = new Login();
                    login.main(null);
                }
            }
        });
    }
}
