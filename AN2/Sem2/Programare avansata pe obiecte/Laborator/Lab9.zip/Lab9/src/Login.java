import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login {
    public static void main(String[] args) {
        JFrame jFrame = new JFrame("Frame Smecher");
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLocationRelativeTo(null);

        CardLayout cardLayout = new CardLayout();
        JPanel cards = new JPanel(cardLayout);
        JPanel loginPanel = new JPanel();
        cards.add(loginPanel, "login");

        loginPanel.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.insets = new Insets(5,5,5,5);

        JLabel usernameLAbel = new JLabel("Username: ");
        gridBagConstraints.gridx=0;
        gridBagConstraints.gridy=0;
        loginPanel.add(usernameLAbel, gridBagConstraints);

        JTextField jTextField = new JTextField(20);
        gridBagConstraints.gridx=1;
        gridBagConstraints.gridy=0;
        loginPanel.add(jTextField, gridBagConstraints);


        JLabel paswdLabel = new JLabel("Password: ");
        gridBagConstraints.gridx=0;
        gridBagConstraints.gridy=1;
        loginPanel.add(paswdLabel, gridBagConstraints);

        JTextField pasdField = new JPasswordField(20);
        gridBagConstraints.gridx=1;
        gridBagConstraints.gridy=1;
        loginPanel.add(pasdField, gridBagConstraints);

        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = jTextField.getText();
                String password = new String(((JPasswordField) pasdField).getPassword());
                User user = new User();
                user.setPassword(password);
                user.setUsername(username);
                UserService userService = new UserService();
                if(userService.login(user)){
                    System.out.println("User logat");
                    cardLayout.show(cards, "after");
                }
                else {
                    JOptionPane.showMessageDialog(jFrame,
                            "Ai gresit username-ul sau parola baiatule",
                            "WARNING",
                            JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        JButton registerBtn = new JButton("Register");
        registerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                Register register = new Register();
                register.main(null);
            }
        });

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        loginPanel.add(loginBtn, gridBagConstraints);

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        loginPanel.add(registerBtn, gridBagConstraints);

        jFrame.add(cards);
        cards.add(createAfterLoginPAne(), "after");

        cardLayout.show(cards, "login");
        jFrame.pack();
        jFrame.setVisible(true);
    }

    private static JPanel createAfterLoginPAne(){
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BorderLayout());
        jPanel.add(new JLabel("Te-ai logat"));
        return jPanel;
    }
}