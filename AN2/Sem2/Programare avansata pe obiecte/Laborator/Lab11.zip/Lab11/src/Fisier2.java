import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Fisier2 extends Thread {

    private List lista;

    public void run() {
        File file = new File("C:\\Users\\Andrei Badeci\\Documents\\Info\\Facultate\\PAO\\Lab11\\src\\fisier1.txt");
        Scanner sc = null;
        try {
            sc = new Scanner(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        while (sc.hasNextInt())
            lista.add(sc.hasNextInt());

        Collections.sort(lista);
    }
}
