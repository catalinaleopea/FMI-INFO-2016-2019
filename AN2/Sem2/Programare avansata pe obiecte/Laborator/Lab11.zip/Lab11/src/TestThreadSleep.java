public class TestThreadSleep extends Thread{
    public void run(){
        for(int i=0; i<5; i++) {
            try {
                Thread.sleep(5*1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
