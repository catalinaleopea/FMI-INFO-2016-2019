public class Lab11 {
    /*2 fisiere cu numar aleatoriu de numere
     * calculam suma numerelor din cele 2 fisiere in paralel si apoi sa calculam suma sumelor si sa o afisam*/
    /*public static void main(String[] args) {
        ThreadPar threadPar = new ThreadPar();
        Thread thread = new Thread(threadPar);
        thread.start();

        Thread theadImpar = new Thread(new TheadImpar());
        theadImpar.start();

        try {
            threadPar.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        try {
            theadImpar.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final");*/
    public static void main(String[] args) {
        long milisecunde = System.currentTimeMillis();
        System.out.println("miliseconds = " + milisecunde);
        try {
            Thread.sleep(5 * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        milisecunde = System.currentTimeMillis();
        System.out.println("after milisecunde = " + milisecunde);
    }
}
