public class Numar {
    /*
    * creati un thread care apeleaza increment de 100 de ori
    * si altul care apeleaza decrese pe acelasi obiect de tipul Numar
    * in main dupa care cele 2 thead-uri au terminat executia sa se afiseze valoarea
    * lui c din obiectul comun de tipul Numar*/

    private int c = 0;
    public void increment(){
        c++;
    }
    public void decrese(){
        c--;
    }
    public int getC(){
        return c;
    }
}
