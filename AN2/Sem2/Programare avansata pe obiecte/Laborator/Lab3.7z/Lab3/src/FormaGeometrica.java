import java.text.Normalizer;

public class FormaGeometrica {
    private int x1;
    private int y1;

    public FormaGeometrica(int x1, int y1){
        this.x1 = x1;
        this.y1 = y1;
        System.out.println("Constructorul pentru x1 si y1");
    }

    public FormaGeometrica(){
        System.out.println("Clasa este: " + getClass().getSimpleName());
    }

    @Override
    public String toString() {
        return "FormaGeometrica{" +
                "x1=" + x1 +
                ", y1=" + y1 +
                '}';
    }

    @Override
    public boolean equals(Object obj){
        if(obj == null){
            return false;
        }
        else
        {
            if(obj instanceof FormaGeometrica)
            {
                FormaGeometrica formaGeometrica = (FormaGeometrica) obj;
                return formaGeometrica.getX1() == x1 && formaGeometrica.getY1() == y1;
            }
            else{
                return false;
            }
        }
    }

    public int getX1() {
        return x1;
    }

    public int getY1() {
        return y1;
    }

    protected int suma (){
        System.out.println("Suma din FormaGeometrica");
        return x1+y1;
    }
}
