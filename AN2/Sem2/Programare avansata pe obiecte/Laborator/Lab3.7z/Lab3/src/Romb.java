public class Romb extends FormaGeometrica {
    public Romb(int x1,int y1){
        super(x1,y1);
    }

    public int suma(){
        System.out.println("Suma din romb");
        return 10;
    }

    public int suma2(){
        return suma()*super.suma();
    }
}
