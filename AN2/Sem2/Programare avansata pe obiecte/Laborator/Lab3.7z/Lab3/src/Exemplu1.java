public class Exemplu1 {
    public static void main(String[] args) {
        Laborator3 laborator3 = new Laborator3(10);
        System.out.println(laborator3);
        Laborator3 laborator31 = new Laborator3(10,10);
        System.out.println(laborator31);
    }
}
