import java.util.List;
import java.util.ArrayList;

public class Laborator3 {

    private int x;
    private int y = 10;

    public final static int nr = 10;

    private List<Integer> listaNr;

    public Laborator3(int x){
        this.x = x;
    }

    public Laborator3(int x, int y){
        this.x = x;
        this.y = y;
    }

    public Laborator3(List<Integer> listaNr){
        this.listaNr = listaNr;
    }

    @Override
    public String toString(){
        return "Laborator3(" +
                "x=" + x +
                ",listaNr=" + listaNr +
                ")";
    }

    public int getX(){
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    private static Integer z;
    private static Object obj;
    private static String str;
    private static int z2;

    public static void main(String[] args) {
        /*List<Integer> integerList = new ArrayList<>();
        Laborator3 laborator3 = new Laborator3(integerList);
        laborator3.listaNr.add(10);
        System.out.println(laborator3.listaNr);*/
        /*Romb romb = new Romb(1,2);
        if(romb instanceof Romb){
            System.out.println("Avem un romb");
        }
        if(romb instanceof  Object){
            System.out.println("Si un obiect");*/
        /*Romb romb = new Romb(1,2);
        Romb romb2 = new Romb(1,3);
        Romb romb3 = new Romb(1,2);
        System.out.println(romb.equals(romb2));
        System.out.println(romb.equals(romb3));*/
        /*int x = 10;
        Integer y = 10;
        x = z;
        System.out.println(y.equals(x));*/
        /*int x = 10;
        Integer y = 10;
        ArrayList<Integer> lista = new ArrayList<>();*/
        Romb romb = new Romb(1,2);
        if(romb instanceof FormaGeometrica){
            System.out.println("Forma Geometrica");
        }
        if(romb instanceof Romb){
            System.out.println("Romb");
        }
    }
}
