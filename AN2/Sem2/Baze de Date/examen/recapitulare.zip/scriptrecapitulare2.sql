alter session set nls_language=American;

insert into turist (id_turist,nume, prenume)
values(9, 'Tudor', 'Laurentiu');

insert into turist (id_turist,nume, prenume)
values(10, 'Zamfirache','Nadia');

insert into turist (id_turist,nume, prenume)
values(11,'Anghel','Simona');

Insert into ACHIZITIONEAZA (COD_EXCURSIE,COD_TURIST,DATA_START,DATA_END,DATA_ACHIZITIE,DISCOUNT) values (301,9,to_timestamp('10-SEP-09','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('15-SEP-09','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('11-AUG-09','DD-MON-RR HH.MI.SSXFF AM'),0.3);
Insert into ACHIZITIONEAZA (COD_EXCURSIE,COD_TURIST,DATA_START,DATA_END,DATA_ACHIZITIE,DISCOUNT) values (104,9,to_timestamp('06-SEP-09','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('09-SEP-09','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('07-AUG-09','DD-MON-RR HH.MI.SSXFF AM'),0.1);
Insert into ACHIZITIONEAZA (COD_EXCURSIE,COD_TURIST,DATA_START,DATA_END,DATA_ACHIZITIE,DISCOUNT) values (201,9,to_timestamp('14-AUG-11','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('21-AUG-11','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('01-APR-09','DD-MON-RR HH.MI.SSXFF AM'),null);

Insert into ACHIZITIONEAZA (COD_EXCURSIE,COD_TURIST,DATA_START,DATA_END,DATA_ACHIZITIE,DISCOUNT) values (201,10,to_timestamp('14-AUG-11','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('21-AUG-11','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('01-APR-09','DD-MON-RR HH.MI.SSXFF AM'),null);

Insert into ACHIZITIONEAZA (COD_EXCURSIE,COD_TURIST,DATA_START,DATA_END,DATA_ACHIZITIE,DISCOUNT) values (201,11,to_timestamp('14-AUG-11','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('21-AUG-11','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('01-APR-09','DD-MON-RR HH.MI.SSXFF AM'),null);
Insert into ACHIZITIONEAZA (COD_EXCURSIE,COD_TURIST,DATA_START,DATA_END,DATA_ACHIZITIE,DISCOUNT) values (104,11,to_timestamp('06-SEP-09','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('09-SEP-09','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('07-AUG-09','DD-MON-RR HH.MI.SSXFF AM'),0.1);

commit;

