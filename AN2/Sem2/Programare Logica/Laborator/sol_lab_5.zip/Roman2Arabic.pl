/* Translate a Roman number into the equivalent Arabic number */

symbol('I',1).
symbol('V',5).
symbol('X',10).
symbol('L',50).
symbol('C',100).
symbol('D',500).
symbol('M',1000).

symbols2numbers([],[]).
symbols2numbers(['I','V'|Tail], [4|Result]) :- symbols2numbers(Tail,Result).
symbols2numbers(['I','X'|Tail], [9|Result]) :- symbols2numbers(Tail,Result).
symbols2numbers(['X','L'|Tail], [40|Result]) :- symbols2numbers(Tail,Result).
symbols2numbers(['X','C'|Tail], [90|Result]) :- symbols2numbers(Tail,Result).
symbols2numbers(['C','D'|Tail], [400|Result]) :- symbols2numbers(Tail,Result).
symbols2numbers(['C','M'|Tail], [900|Result]) :- symbols2numbers(Tail,Result).
symbols2numbers([S|Tail],[Number|Result]) :- symbol(S,Number), symbols2numbers(Tail,Result).

sum([],0).
sum([Head|Tail],Result) :- sum(Tail,LocalResult), Result is Head + LocalResult.

roman2arabic(Roman,Arabic) :- atom_chars(Roman,ListSymbols), symbols2numbers(ListSymbols,ListNumbers), sum(ListNumbers,Arabic).