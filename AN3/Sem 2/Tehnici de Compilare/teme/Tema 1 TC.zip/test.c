int e25  ;;/* kjik k kh kj 
ghuiy i     e


  'a'"'k'""""\'\n'  *//**/   /***/  



  /*


    **/"  /*ah'h'*/"'"'"'" '('void main(){}{

if((a+++12e3==e12.e+12)*/e20+++=++20e-3<<=1)  a**p*/*/*//++e+3;
return 0;"jkhkjk      \""lkjlkjlkjkl
"}
