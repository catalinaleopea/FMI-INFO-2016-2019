from enum import Enum

keyword_list = [
    "auto",
    "break",
    "case",
    "char",
    "const",
    "continue",
    "default",
    "do",
    "double",
    "else",
    "enum",
    "extern",
    "float",
    "for",
    "goto",
    "if",
    "int",
    "long",
    "register",
    "return",
    "short",
    "signed",
    "sizeof",
    "static",
    "struct",
    "switch",
    "typedef",
    "union",
    "unsigned",
    "void",
    "volatile",
    "while"
]

class Token_Type(Enum):
    NONE = 0
    KEYWORD = 1
    IDENTIFIER = 2
    INTEGER = 3
    FLOAT = 4
    CHAR = 5
    STRING = 6
    OPERATOR = 7
    LINE_COMMENT = 8
    MULTILINE_COMMENT = 9
    SEPARATOR = 10

class Token(object):
    def __init__(self, _type, value):
        self.type = _type
        self.value = value

class State(object):
    def __init__(self, id, token_type = Token_Type(0)):
        self.id = id
        self.token_type = Token_Type(token_type)
        self.transitions = dict() #dictionar de forma litera -> stare, i.e. din aceasta stare se ajunge cu litera x in starea y

class AFD(object):
    def __init__(self):
        self.states = dict()
        self.final_states = dict()
        self.seeker = 0
        self.input = ""

    def set_input(self, input:str):
        self.input = input

    def config_from_file(self, file):
        line = file.readline()
        init_state_id = int(line)
        self.states[init_state_id] = State(init_state_id)

        line = file.readline()
        no_final_states = int(line)

        for i in range(no_final_states):
            line = file.readline()

            final_state_id, token_type = line.split()
            
            final_state_id = int(final_state_id)
            token_type = int(token_type)

            self.states[final_state_id] = State(final_state_id)
            self.final_states[final_state_id] = State(final_state_id, token_type)
        
        while file.readable():
            line = file.readline()

            if line == "":
                break

            if len(line.split()) == 1 or line == '\n':
                continue
            
            from_state, letter, to_state = line.split()

            if letter == "\\n":
                letter = "\n"

            if letter == "ss":
                letter = " "
            
            from_state = int(from_state)
            to_state = int(to_state)

            if from_state not in self.states:
                self.states[from_state] = State(from_state)
            
            self.states[from_state].transitions[letter] = to_state

    def extract_token(self):
        input = self.input

        current_state_id = 0
        
        current_state = self.states[current_state_id]
        
        token_value = str("")
        
        while self.seeker < len(input):
            letter = input[self.seeker]
            self.seeker += 1

            if letter in current_state.transitions:
                token_value += letter
                current_state_id = current_state.transitions[letter]
                current_state = self.states[current_state_id]

                if self.seeker != len(input):
                    continue
                else:
                    self.seeker += 1
            
            if current_state_id in self.final_states:
                token_type = self.final_states[current_state_id].token_type

                if token_type == Token_Type.NONE or token_type == Token_Type.LINE_COMMENT or token_type == Token_Type.MULTILINE_COMMENT:
                    current_state_id = 0
                    current_state = self.states[current_state_id]
                    token_value = str("")
                    self.seeker -= 1
                    continue

                if token_value in keyword_list:
                    token_type = Token_Type.KEYWORD
                
                token = Token(token_type, token_value)

                current_state_id = 0
                current_state = self.states[current_state_id]
                token_value = str("")
                self.seeker -= 1
                return token
            else:
                print("Invalid text because of lexical error at character: " + letter)
                print("Trying to build token " + "TOKEN_BEGIN " + token_value + " TOKEN_END")

                return Token(Token_Type.NONE, "")
                
        return Token(Token_Type.NONE, "")

    def extract_tokens(self):
        self.seeker = 0

        while self.seeker < len(self.input):
            token = self.extract_token()

            if token != None:
                print("Token Type: " + str(token.type))
                print("Token Value: " + token.value)
                print("---")

        
if __name__ == "__main__":
    afd = AFD()

    afd_config_file = open("C:\\Users\\isaia\\OneDrive\\Documents\\Facultate\\Anul 3\\Semestrul 2\\Tema 1 TC\\afd_config_file.txt", "r")
    afd.config_from_file(afd_config_file)

    test_file = open("C:\\Users\\isaia\\OneDrive\\Documents\\Facultate\\Anul 3\\Semestrul 2\\Tema 1 TC\\aici.txt", "r")
    afd.set_input(test_file.read())

    afd.extract_tokens()
    