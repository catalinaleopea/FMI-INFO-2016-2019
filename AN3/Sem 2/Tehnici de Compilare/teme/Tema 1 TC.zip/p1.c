xe,12.34e-25" ;;kjk 'a'"'"'/*  dfh sfg fsg 
   sdgf sdf
   
   
   



 sdfvvs  svd sdv
 *//*3rf 3rfg 3f
 
 
 
 e2f2efef*//*/*/*/ /* 23.34 " as a" 'e'*/int
  main(int argc, char*argv[]){
/*inceput program */
int var1,e[100][20 ];
if((e25+++=++e-2&&12te25**=e>>=5)+e25.f12.e--){;;;}12.34-e+ee.f;
double var2; 12et

char s[10];+

var1=0x1a0d;
var2=3.141592;
strcpy(s,"caractere");

//acesta este un comentariu
if(var1==0) return 1;
return 0;
/*sfarsit program! ++ */
}
