from django.contrib import admin
from .models import Car, SavedAdvertisement

admin.site.register(Car)
admin.site.register(SavedAdvertisement)
