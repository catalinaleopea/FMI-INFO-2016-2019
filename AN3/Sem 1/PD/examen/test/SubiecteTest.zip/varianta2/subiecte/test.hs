--PROGRAMARE DECLARATIVĂ - test de laborator
-- NUMĂRUL 2



import Data.List     
import Data.Maybe

test1, test21, test22, test31, test32, test33 :: Bool
test41, test42, test51, test52, test61, test62, test63 :: Bool

-- În cele ce urmează vom implementa funcționalități legate de jocul "memory". 

type Imagine = Char 
type Coloana = Int
type Linie = Int

type  Elem = (Imagine, Linie, Coloana)
linie :: Elem -> Int
linie (_, x, _) = x
coloana :: Elem -> Int
coloana (_, _, x) = x
imagine :: Elem -> Char 
imagine (x , _, _) = x

type  Tabla = [Elem]

-- Exemplu: 

tabla :: Tabla
tabla = [('A',1,1), ('C',1,2), ('B',2,1),  ('C',2,2), ('B',2,3), ('A',3,1)]


-- Exercițiul 1 (1.5 puncte)


imaginiTabla :: Tabla -> [Imagine]
imaginiTabla = undefined

test1 = (sort (imaginiTabla tabla)) == "ABC"


-- Exercițiul 2 (1.5 puncte)

par :: Tabla -> Bool
par = undefined


test21 = par tabla
test22  = not (par [('A',1,1), ('C',1,2), ('B',2,1),  ('C',2,2)])


-- Exercițiul 3 (2 puncte)

type Pozitie = (Linie, Coloana)
type Mutare = (Pozitie, Pozitie)
 

joacaRunda :: Tabla  -> Mutare -> Tabla 
joacaRunda = undefined

test31  = joacaRunda tabla ((1,1),(3,1)) == [('C',1,2), ('B',2,1),  ('C',2,2), ('B',2,3)]
test32  = joacaRunda tabla ((1,1),(1,2)) == tabla
test33  = joacaRunda tabla ((1,4),(1,2)) == tabla


-- Exercițiul 4(0.5p) (exercițiu suplimentar)

getElement :: Tabla -> Pozitie -> Maybe Imagine 
getElement = undefined

test41 = getElement tabla (2,1) == Just 'B'
test42 = getElement tabla (2,10) == Nothing
 

-- Exercițiul 5 (1p)

data Arb =  Nod Tabla [Arb]

varf :: Arb -> Tabla
varf (Nod tabla _) = tabla

-- Exemple:

tabla1 = [('C',1,2), ('B',2,1), ('C',2,2), ('B',2,3)]
tabla2 = [('A',1,1),  ('C',1,2),  ('C',2,2), ('A',3,1)]
tabla3 = [('A',1,1), ('B',2,1),  ('B',2,3), ('A',3,1)]


arb1 = Nod tabla [Nod tabla1 [], 
                  Nod tabla2 [], 
                  Nod tabla3 []]

tabla11 = [('B',2,1),('B',2,3)]
tabla12 = [('C',1,2), ('C',2,2)] 

arb2 = Nod tabla [Nod tabla1 [Nod tabla11 [], Nod tabla12 []], 
                  Nod tabla2 [], 
                  Nod tabla3 []]




corectArb :: Arb -> Bool
corectArb = undefined  

test51 = corectArb arb1
test52 = not (corectArb (Nod tabla [Nod tabla []]))
 


-- Exercitiul 6 (1p)

type Joc = [Tabla]


cautaJoc:: Tabla -> Arb -> Maybe Joc
cautaJoc = undefined

test61 = cautaJoc tabla arb1 == Just [tabla]
test62 = cautaJoc tabla11 arb1 == Nothing  
test63 = cautaJoc tabla11 arb2 == Just [tabla, tabla1, tabla11] 
                        

  
