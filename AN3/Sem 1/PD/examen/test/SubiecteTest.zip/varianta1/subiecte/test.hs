-- PROGRAMARE DECLARATIVĂ - test de laborator

-- NUMĂRUL 1


import Data.List     
import Data.Maybe

test1, test21, test22, test31, test32, test33 :: Bool
test41, test42, test51, test52, test61, test62, test63 :: Bool

-- În cele ce urmează vom implementa funcționalități legate de jocul "memory". 


type Imagine = Char 


type Coloana = Int
type Linie = Int
type Pozitie = (Linie, Coloana)


type  Elem = (Imagine, Pozitie)
type  Tabla = [Elem]

-- Exemplu: 

tabla :: Tabla
tabla = [('A',(1,1)), ('C',(1,2)), ('B',(2,1)),  ('C',(2,2)), ('B',(2,3)), ('A',(3,1))]


-- Exercițiul 1 (1.5 puncte)

imaginiTabla :: Tabla -> [Imagine]
imaginiTabla = undefined

test1 = (sort (imaginiTabla tabla)) == "ABC"

-- Exercițiul 2 (1.5 puncte)

par :: Tabla -> Bool
par = undefined


test21 = par tabla
test22  = not (par [('A',(1,1)), ('C',(1,2)), ('B',(2,1)),  ('C',(2,2))])


-- Exercitiul 3 (2 puncte)

type Mutare = (Pozitie, Pozitie)


joacaRunda :: Mutare -> Tabla -> Tabla 
joacaRunda = undefined

test31  = joacaRunda  ((1,1),(3,1)) tabla == [('C',(1,2)), ('B',(2,1)),  ('C',(2,2)), ('B',(2,3))]
test32  = joacaRunda  ((1,1),(1,2)) tabla  == tabla
test33  = joacaRunda  ((1,4),(1,2)) tabla  == tabla


-- Exercițiul 4(0.5 puncte) (exercițiu suplimentar)

getElement :: Pozitie -> Tabla  -> Maybe Imagine 
getElement = undefined 

test41 = getElement (2,1) tabla == Just 'B'
test42 = getElement (2,10) tabla  == Nothing
 

-- Exercitiul 5 (1 punct)


data Arb =  Nod Tabla [Arb]

varf :: Arb -> Tabla
varf (Nod tabla _) = tabla

-- Exemple:

tabla1 = [('C',(1,2)), ('B',(2,1)), ('C',(2,2)), ('B',(2,3))]
tabla2 = [('A',(1,1)),  ('C',(1,2)),  ('C',(2,2)), ('A',(3,1))]
tabla3 = [('A',(1,1)), ('B',(2,1)),  ('B',(2,3)), ('A',(3,1))]


arb1 = Nod tabla [Nod tabla1 [], 
                  Nod tabla2 [], 
                  Nod tabla3 []]

tabla11 = [('B',(2,1)),('B',(2,3))]
tabla12 = [('C',(1,2)), ('C',(2,2))] 

arb2 = Nod tabla [Nod tabla1 [Nod tabla11 [], Nod tabla12 []], 
                  Nod tabla2 [], 
                  Nod tabla3 []]


lm :: [Mutare] 
lm = [((1,1), (3,1)), 
      ((1,2),(2,2))]


esteValida :: [Mutare] -> Arb -> Bool
esteValida = undefined


test51 = esteValida lm arb2
test52 = not (esteValida lm arb1)

-- Exercițiul 6 (1p)

type Joc = [Tabla]


cautaJoc:: Tabla -> Arb -> Maybe Joc
cautaJoc = undefined

test61 = cautaJoc tabla arb1 == Just [tabla]
test62 = cautaJoc tabla11 arb1 == Nothing  
test63 = cautaJoc tabla11 arb2 == Just [tabla, tabla1, tabla11] 