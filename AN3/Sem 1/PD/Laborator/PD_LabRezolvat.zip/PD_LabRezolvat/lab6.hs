module Lab6 where
import Data.List (nub)
import Data.Maybe (fromJust)

data Fruct
  = Mar String Bool
  | Portocala String Int

ionatanFaraVierme = Mar "Ionatan" False
goldenCuVierme = Mar "Golden Delicious" True
portocalaSicilia10 = Portocala "Sanguinello" 10

ePortocalaDeSicilia :: Fruct -> Bool
ePortocalaDeSicilia (Portocala tip _) = tip `elem` ["Sanguinello", "Moro", "Tarocco"]
ePortocalaDeSicilia _ = False

test_ePortocalaDeSicilia1 =
    ePortocalaDeSicilia (Portocala "Moro" 12) == True
test_ePortocalaDeSicilia2 =
    ePortocalaDeSicilia (Mar "Ionatan" True) == False

type Nume = String
data Prop
  = Var Nume
  | F
  | T
  | Not Prop
  | Prop :|: Prop
  | Prop :&: Prop
  | Prop :->: Prop
  | Prop :<->: Prop
  deriving (Eq, Read)
infixr 2 :|:
infixr 3 :&:

p1 :: Prop
p1 = (Var "P" :|: Var "Q") :&: (Var "P" :&: Var "Q")

p2 :: Prop
p2 = (Var "P" :|: Var "Q") :&: (Not (Var "P") :&: Not (Var "Q"))

p3 :: Prop
p3 = (Var "P" :&: (Var "Q" :|: Var "R")) :&: ((Not (Var "P") :|: Not (Var "Q")) :&: (Not (Var "P") :|: Not (Var "R")))

instance Show Prop where
  show (Var nume) = nume
  show F = "0"
  show T = "1"
  show (Not prop) = "(~" ++ show prop ++ ")"
  show (prop1 :|: prop2) = "(" ++ show prop1 ++ "\\/" ++ show prop2 ++ ")"
  show (prop1 :&: prop2) = "(" ++ show prop1 ++ "/\\" ++ show prop2 ++ ")"
  show (prop1 :->: prop2) = "(" ++ show prop1 ++ "->" ++ show prop2 ++ ")"
  show (prop1 :<->: prop2) = "(" ++ show prop1 ++ "<->" ++ show prop2 ++ ")"
 
test_ShowProp :: Bool
test_ShowProp =
    show (Not (Var "P") :&: Var "Q") == "((~P)/\\Q)"

type Env = [(Nume, Bool)]

impureLookup :: Eq a => a -> [(a,b)] -> b
impureLookup a = fromJust . lookup a

eval :: Prop -> Env -> Bool
eval (Var nume) v = impureLookup nume v
eval F _ = False
eval T _ = True
eval (Not prop) v = not (eval prop v)
eval (prop1 :|: prop2) v = (eval prop1 v) || (eval prop2 v)
eval (prop1 :&: prop2) v = (eval prop1 v) && (eval prop2 v)
eval (prop1 :->: prop2) v = (eval (Not prop1) v) || (eval prop2 v)
eval (prop1 :<->: prop2) v = (eval (prop1 :->: prop2) v) && (eval (prop2 :->: prop1) v)
 
 
test_eval = eval  (Var "P" :|: Var "Q") [("P", True), ("Q", False)] == True

variabile :: Prop -> [Nume]
variabile (Var nume) = [nume]
variabile (Not prop) = variabile prop
variabile (prop1 :|: prop2) = nub (variabile prop1 ++ variabile prop2)
variabile (prop1 :&: prop2) = nub (variabile prop1 ++ variabile prop2)
variabile (prop1 :->: prop2) = nub (variabile prop1 ++ variabile prop2)
variabile (prop1 :<->: prop2) = nub (variabile prop1 ++ variabile prop2)
variabile _ = []
 
test_variabile =
  variabile (Not (Var "P") :&: Var "Q") == ["P", "Q"]

genstr :: [a] -> Int -> [[a]]
genstr sir 0 = [[]]
genstr sir n = [x : y | x <- sir, y <- sirO]
  where sirO = genstr sir (n - 1)
  
envs :: [Nume] -> [[(Nume, Bool)]]
envs sir = [zip sir x | x <- genstr [False, True] (length sir)]
 
test_envs = 
    envs ["P", "Q"]
    ==
    [ [ ("P",False)
      , ("Q",False)
      ]
    , [ ("P",False)
      , ("Q",True)
      ]
    , [ ("P",True)
      , ("Q",False)
      ]
    , [ ("P",True)
      , ("Q",True)
      ]
    ]

satisfiabila :: Prop -> Bool
satisfiabila prop = or [eval prop x | x <- envs (variabile prop)]
 
test_satisfiabila1 = satisfiabila (Not (Var "P") :&: Var "Q") == True
test_satisfiabila2 = satisfiabila (Not (Var "P") :&: Var "P") == False

valida :: Prop -> Bool
valida prop = and [eval prop x | x <- envs (variabile prop)]

test_valida1 = valida (Not (Var "P") :&: Var "Q") == False
test_valida2 = valida (Not (Var "P") :|: Var "P") == True

tabelaAdevar :: Prop -> IO ()
tabelaAdevar prop = do
  putStrLn (pvar ++ " " ++ show prop)
  putStrLn (undsco ++ " ------------------")
  mapM_ putStrLn totpos
  where
    vars = variabile prop
    pvar = foldr (\x y -> x ++ " " ++ y) "|" vars
    undsco = foldr (\x y -> x ++ " " ++ y) "|" [ a | (a, b) <- [("-", y) | y <- [1..length vars]]]
    totpos = [ foldr (\x y -> x ++ " " ++ y) "|" [ [head (show y)] | (x, y) <- list ] ++ "       " ++ [head (show $ eval prop list)] | list <- envs vars ]

echivalenta :: Prop -> Prop -> Bool
echivalenta prop1 prop2 = valida (prop1 :<->: prop2)
 
test_echivalenta1 =
  True
  ==
  (Var "P" :&: Var "Q") `echivalenta` (Not (Not (Var "P") :|: Not (Var "Q")))
test_echivalenta2 =
  False
  ==
  (Var "P") `echivalenta` (Var "Q")
test_echivalenta3 =
  True
  ==
  (Var "R" :|: Not (Var "R")) `echivalenta` (Var "Q" :|: Not (Var "Q"))

