import Control.Monad
import Data.Char (toUpper)
import Data.List.Split

prelStr strin = map toUpper strin

ioString = do
            strin <- getLine
            putStrLn $ "Intrare\n" ++ strin
            let  strout = prelStr strin
            putStrLn $ "Iesire" 
            putStrLn strout          
        
 
prelNo noin =  sqrt noin 
ioNumber = do
            noin  <- readLn :: IO Float 
            putStrLn $ "Intrare\n" ++ (show noin)
            let  noout = prelNo noin
            putStrLn $ "Iesire" 
            print noout  

            
            
inoutFile = do 
               sin <- readFile "Input.txt" 
               putStrLn $ "Intrare\n" ++ sin
               let sout = prelStr sin
               putStrLn $ "Iesire\n" ++ sout
               writeFile "Output.txt" sout

type Nume = String
type Varsta = Int

data Persoana = Persoana Nume Varsta

nume :: Persoana -> String
nume (Persoana str _) = str

varsta :: Persoana -> Int
varsta (Persoana _ vst) = vst

maxVst :: [Persoana] -> Int
maxVst l = maximum $ map varsta l 

stringSplit :: String -> (Nume, Varsta)
stringSplit l = let sir = splitOn "," l in (head sir, read (head $ tail sir) :: Int)

dataToPers :: (Nume, Varsta) -> Persoana
dataToPers (str, vst) = Persoana str vst

-- main = do
  -- strNumar <- getLine
  -- let numar = read strNumar :: Int
  -- persoane <- forM [1..numar] (\a -> do
    -- putStrLn $ "Numele persoanei nr. " ++ show a
    -- numeA <- getLine
    -- putStrLn $ "Varsta persoanei nr. " ++ show a
    -- vstA <- getLine
    -- return (Persoana numeA (read vstA :: Int)))
  -- let persVstMax = [x | x <- persoane, varsta x == maxVst persoane]
  -- mapM_ print (map nume persVstMax)

main = do
  continut <- readFile "L6P2.txt"
  let linii = lines continut
  let numar = read (head linii) :: Int
  let persoane = map (dataToPers . stringSplit) (tail linii)
  let persVstMax = [x | x <- persoane, varsta x == maxVst persoane]
  mapM_ print (map nume persVstMax)
  
