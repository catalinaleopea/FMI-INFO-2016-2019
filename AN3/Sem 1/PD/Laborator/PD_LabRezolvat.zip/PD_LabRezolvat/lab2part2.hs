import           Test.QuickCheck


---------------------------------------------
-------RECURSIE: FIBONACCI-------------------
---------------------------------------------

fibonacciCazuri :: Integer -> Integer
fibonacciCazuri n
  | n < 2     = n
  | otherwise = fibonacciCazuri (n - 1) + fibonacciCazuri (n - 2)

fibonacciEcuational :: Integer -> Integer
fibonacciEcuational 0 = 0
fibonacciEcuational 1 = 1
fibonacciEcuational n =
    fibonacciEcuational (n - 1) + fibonacciEcuational (n - 2)

{-| @fibonacciLiniar@ calculeaza @F(n)@, al @n@-lea element din secvența
Fibonacci în timp liniar, folosind funcția auxiliară @fibonacciPereche@ care,
dat fiind @n >= 1@ calculează perechea @(F(n-1), F(n))@, evitănd astfel dubla
recursie. Completați definiția funcției fibonacciPereche.

Indicație:  folosiți matching pe perechea calculată de apelul recursiv.
-}
fibonacciLiniar :: Integer -> Integer
fibonacciLiniar 0 = 0
fibonacciLiniar n = snd (fibonacciPereche n)
  where
    fibonacciPereche :: Integer -> (Integer, Integer)
    fibonacciPereche 1 = (0, 1)
    fibonacciPereche n = undefined

prop_fib :: Integer -> Property
prop_fib x = x >= 0 ==> fibonacciEcuational x == fibonacciLiniar x

---------------------------------------------
----------RECURSIE PE LISTE -----------------
---------------------------------------------
semiPareRecDestr :: [Int] -> [Int]
semiPareRecDestr l
  | null l    = l
  | even h    = h `div` 2 : t'
  | otherwise = t'
  where
    h = head l
    t = tail l
    t' = semiPareRecDestr t

semiPareRecEq :: [Int] -> [Int]
semiPareRecEq [] = []
semiPareRecEq (h:t)
  | even h    = h `div` 2 : t'
  | otherwise = t'
  where t' = semiPareRecEq t

---------------------------------------------
----------DESCRIERI DE LISTE ----------------
---------------------------------------------
semiPareComp :: [Int] -> [Int]
semiPareComp l = [ x `div` 2 | x <- l, even x ]

prop_semiPare :: [Int] -> Bool
prop_semiPare l = semiPareRecEq l == semiPareComp l


-------- Dir & Drum

data Directie
  = Nord
  | Est
  | Sud
  | Vest
  deriving (Eq, Show)

type Punct = (Integer, Integer)

origine = (0, 0)

type Drum = [Directie]

misDir :: Punct -> Directie -> Punct
misDir (a, b) d
  | d == Nord  = (a, b - 1)
  | d == Est   = (a - 1, b)
  | d == Sud   = (a, b + 1)
  | d == Vest  = (a + 1, b)

miscare :: Punct -> Drum -> Punct
miscare p l
  | null l     = p
  | otherwise  = q
  where
    h = head l
    t = tail l
    r = misDir p h
    q = miscare r t

eqDrum :: Drum -> Drum -> Bool
eqDrum d1 d2 = 
  miscare origine d1 == miscare origine d2
