import   Data.List
import   Test.QuickCheck

--- Ex 1
factori :: Int -> [Int]
factori n = [ d | d <- [1..n], n `rem` d == 0]

prim :: Int -> Bool
prim n = length (factori n) == 2

numerePrime :: Int -> [Int]
numerePrime n = [ p | p <- [2..n], prim p]

ciurList :: [Int] -> [Int]
ciurList [] = []
ciurList (x:xs) = x : ciurList [y | y <- xs, y `mod` x /= 0]

numerePrimeCiur :: Int -> [Int]
numerePrimeCiur n = ciurList [2..n]

--- Ex 2
myzip3 :: [Int] -> [Int] -> [Int] -> [(Int, Int, Int)]
myzip3 l1 l2 l3 = 
  [ (x, y, z) | (x, a) <- r1, (y, b) <- r2, (z, c) <- r3, a == b, b == c ]
  where
    r1 = zip l1 [1..length l1]
    r2 = zip l2 [1..length l2]
    r3 = zip l3 [1..length l3]

--- Ex 3
ordonataNat1 :: [Int] -> Bool
ordonataNat1 [] = True
ordonataNat1 [x] = True
ordonataNat1 (x:xs) = 
  (ordonataNat1 xs) &&
  (and [ x <= y | y <- xs]) -- varianta fara zip
  
ordonataNat :: [Int] -> Bool
ordonataNat [] = True
ordonataNat [x] = True
ordonataNat (x:xs) =
  and [ a <= b | (a, x) <- l, (b, y) <- l, x < y]
  where l = zip (x:xs) [1..length(x:xs)]
  
prop_ordNat :: [Int] -> Bool
prop_ordNat x = ordonataNat x == ordonataNat1 x

--- Ex 4
ordonata :: [a] -> (a -> a -> Bool) -> Bool
ordonata l p = and [p x y | (x, a) <- ll, (y, b) <- ll, a < b]
  where ll = zip l [1..length l]

(*<*) :: (Integer, Integer) -> (Integer, Integer) -> Bool
(a, b) *<* (c, d) = a < b && c > d

-- Ex 5
firstEl :: [(a, b)] -> [a]
firstEl l = map fst l

sumList :: [[Integer]] -> [Integer]
sumList l = map sum l

op2 :: Integer -> Integer
op2 x
  | even x = x `div` 2
  | otherwise = x * 2

prel2 :: [Integer] -> [Integer]
prel2 l = map op2 l

compuneList :: (b -> c) -> [(a -> b)] -> [(a -> c)]
compuneList f l = map (f.) l

aplicaList :: a -> [(a -> b)] -> [b]
aplicaList x l = map (\f -> f x) l

myzip3v2 :: [Int] -> [Int] -> [Int] -> [(Int, Int, Int)]
myzip3v2 a b c = map (\(x, (y, z)) -> (x, y, z)) (zip a (zip b c))

-- Ex 6
apSir :: Char -> [String] -> [String]
apSir c l = filter (c `elem`) l

listSqOdd :: [Integer] -> [Integer]
listSqOdd l = map (^2) (filter odd l)

listSqPosOdd :: [Integer] -> [Integer]
listSqPosOdd l = map ((^2).fst) (filter (\x -> odd (snd x)) (zip l [1..length l]))

numaiVocale :: [String] -> [String]
numaiVocale l = map (filter (`elem` "aeiouAEIOU")) l

-- Ex 7
mymap :: (a -> b) -> [a] -> [b]
mymap f [] = []
mymap f (x:xs) = (f x) : (mymap f xs)

myfilter :: (a -> Bool) -> [a] -> [a]
myfilter p [] = []
myfilter p (x:xs)
  | p x = x : (myfilter p xs)
  | otherwise = myfilter p xs




