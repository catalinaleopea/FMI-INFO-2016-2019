import Data.Functor

main = do  
  putStrLn "Hello, what's your name?"  
  name <- getLine  
  putStrLn ("Hey " ++ name ++ ", you rock!")

showPlusZece :: Integer -> IO Integer
showPlusZece n = putStr (show n) $> n + 10

showPlusZeceX2 :: Integer -> IO Integer
showPlusZeceX2 n = showPlusZece n >>= showPlusZece

citesteSiAdunaZece :: IO Integer
citesteSiAdunaZece = fmap read getLine >>= showPlusZece

suma :: IO Integer
suma = 
  fmap read getLine >>=
  (\x -> fmap read getLine >>=
    (\y -> return (x + y)
    )
  )
