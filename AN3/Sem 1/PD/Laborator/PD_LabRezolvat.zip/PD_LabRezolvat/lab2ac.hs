import           Test.QuickCheck


---------------------------------------------
-------RECURSIE: FIBONACCI-------------------
---------------------------------------------

fibonacciCazuri :: Integer -> Integer
fibonacciCazuri n
  | n < 2     = n
  | otherwise = fibonacciCazuri (n - 1) + fibonacciCazuri (n - 2)

fibonacciEcuational :: Integer -> Integer
fibonacciEcuational 0 = 0
fibonacciEcuational 1 = 1
fibonacciEcuational n =
    fibonacciEcuational (n - 1) + fibonacciEcuational (n - 2)

{-| @fibonacciLiniar@ calculeaza @F(n)@, al @n@-lea element din secvența
Fibonacci în timp liniar, folosind funcția auxiliară @fibonacciPereche@ care,
dat fiind @n >= 1@ calculează perechea @(F(n-1), F(n))@, evitănd astfel dubla
recursie. Completați definiția funcției fibonacciPereche.

Indicație:  folosiți matching pe perechea calculată de apelul recursiv.
-}
fibonacciLiniar :: Integer -> Integer
fibonacciLiniar 0 = 0
fibonacciLiniar n = snd (fibonacciPereche n)
  where
    fibonacciPereche :: Integer -> (Integer, Integer)
    fibonacciPereche 1 = (0, 1)
    fibonacciPereche n = (b, a + b)
      where
        (a, b) = fibonacciPereche (n - 1)

prop_fib :: Integer -> Property
prop_fib x = (x >= 0 && x <= 20) ==> fibonacciEcuational x == fibonacciLiniar x

---------------------------------------------
----------RECURSIE PE LISTE -----------------
---------------------------------------------
semiPareRecDestr :: [Int] -> [Int]
semiPareRecDestr l
  | null l    = l
  | even h    = h `div` 2 : t'
  | otherwise = t'
  where
    h = head l
    t = tail l
    t' = semiPareRecDestr t

semiPareRecEq :: [Int] -> [Int]
semiPareRecEq [] = []
semiPareRecEq (h:t)
  | even h    = h `div` 2 : t'
  | otherwise = t'
  where t' = semiPareRecEq t

inInterval :: Int -> Int -> [Int] -> [Int]
inInterval a b l
  | l == []           = l
  | a <= h && h <= b  = h : t'
  | otherwise         = t'
  where
    h = head l
    t = tail l
    t' = inInterval a b t


  
---------------------------------------------
----------DESCRIERI DE LISTE ----------------
---------------------------------------------
semiPareComp :: [Int] -> [Int]
semiPareComp l = [ x `div` 2 | x <- l, even x ]

prop_semiPare :: [Int] -> Bool
prop_semiPare l = semiPareRecEq l == semiPareComp l


inIntervalComp :: Int -> Int -> [Int] -> [Int]
inIntervalComp a b l = [ x | x <-l, a <= x, x <= b]

prop_inInterval :: Int -> Int -> [Int] -> Bool
prop_inInterval a b l = inInterval a b l == inIntervalComp a b l

---- LISTARE POZITIVE

pozitiveRec :: [Integer] -> Int
pozitiveRec l
  | l == []   = 0
  | h > 0     = 1 + z
  | otherwise = z
  where
    h = head l
    t = tail l
    z = pozitiveRec t
    
pozitiveComp :: [Integer] -> Int
pozitiveComp l = length [ x | x <- l, x > 0]

prop_pozitive :: [Integer] -> Bool
prop_pozitive l = pozitiveRec l == pozitiveComp l

---- POZITII IMPARE

pozImp :: [Integer] -> Int -> [Int]
pozImp l a
  | l == []   = []
  | even h    = pl
  | otherwise = a : pl
  where
    h = head l
    t = tail l
    b = a + 1
    pl = pozImp t b
    
pozitiiImpareRec :: [Integer] -> [Int]
pozitiiImpareRec l = pozImp l 0
    
adaugarePozitii :: [Integer] -> Int -> [(Integer, Int)]
adaugarePozitii [] _ = []
adaugarePozitii (h : t) a =
  (h, a) : t'
  where
    b = a + 1
    t' = adaugarePozitii t b

pozitiiImpareComp :: [Integer] -> [Int]
pozitiiImpareComp l = [b | (a, b) <- adaugarePozitii l 0, odd a]

prop_pozImp :: [Integer] -> Bool
prop_pozImp l = pozitiiImpareRec l == pozitiiImpareComp l



