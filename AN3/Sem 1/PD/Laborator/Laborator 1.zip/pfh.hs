

data Alegere = Piatra | Foarfeca | Hartie
               deriving (Eq, Show)

--data Rezultat = 
--                deriving (Show, Eq)

-- partida :: Alegere -> Alegere -> Rezultat
