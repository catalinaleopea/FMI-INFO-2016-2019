
type Key = Int
type Value = String

class Collection c where
  cempty :: c 
  csingleton :: Key ->  Value -> c 
  cinsert:: Key -> Value -> c  -> c 
  cdelete :: Key -> c  -> c 
  clookup :: Key -> c -> Maybe Value
  ctoList :: c  -> [(Key, Value)]
  ckeys :: c  -> [Key]
  cvalues :: c  -> [Value]
  cfromList :: [(Key,Value)] -> c
-- minimum definition: cempty, csingleton, cinsert, cdelete, clookup,ctoList

  ckeys c = [fst p | p <- ctoList c]
  cvalues c = [snd p | p <- ctoList c]
  cfromList [] = cempty
  cfromList ((k,v):es)  = cinsert k v (cfromList es)
 


newtype  PairList 
  = PairList { getPairList :: [(Key,Value)] }
  
instance Show PairList where  
  show (PairList ps) = "PairList " ++ (show ps) 
  
  
  
instance Collection PairList  where
   cempty = PairList []
   csingleton  k v = PairList [(k,v)]   
   cinsert k v (PairList l) = PairList $ (k,v):filter ((/= k). fst) l
   clookup k = lookup k . getPairList
   cdelete k (PairList l) = PairList $ filter ((/= k). fst) l
   ctoList = getPairList 
  
  

data SearchTree 
  = Empty
  | Node
      SearchTree  -- elemente cu cheia mai mica 
      Key                    -- cheia elementului
      (Maybe Value)          -- valoarea elementului
      SearchTree  -- elemente cu cheia mai mare
   deriving Show   


instance Collection SearchTree where
   cempty = Empty
   csingleton k v = Node Empty k (Just v) Empty
   cinsert k v = go
     where
       go Empty = csingleton k v
       go (Node t1 k1 v1 t2)
         | k == k1   = Node t1 k1 (Just v) t2
         | k < k1    = Node (go t1) k1 v1 t2
         | otherwise = Node t1 k1 v1 (go t2)
   cdelete k = go
     where
       go Empty = Empty
       go (Node t1 k1 v1 t2)
         | k == k1   = Node t1 k1 Nothing t2
         | k < k1    = Node (go t1) k1 v1 t2
         | otherwise = Node t1 k1 v1 (go t2)
   clookup k = go
     where
       go Empty = Nothing
       go (Node t1 k1 v1 t2)
         | k == k1   = v1
         | k < k1    = go t1
         | otherwise = go t2
   ctoList Empty = []
   ctoList (Node ltk k v gtk) = ctoList ltk ++ embed k v ++ ctoList gtk
     where
       embed k (Just v) = [(k,v)]
       embed _ _ = []


-- *Main> cfromList [(1,"a"),(2,"b"),(3,"c")] :: PairList
-- PairList [(1,"a"),(2,"b"),(3,"c")]
-- *Main> cfromList [(1,"a"),(2,"b"),(3,"c")] :: SearchTree
-- Node (Node (Node Empty 1 (Just "a") Empty) 2 (Just "b") Empty) 3 (Just "c") Empty
