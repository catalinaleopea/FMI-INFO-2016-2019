data Program  = On Statements deriving (Show,Eq)
data Statements  = Off | Expression :> Statements   deriving (Show,Eq)
data Expression  =  Mem | V Int | Expression :+ Expression  deriving (Show,Eq)

type Env = Int
type DomStm = Env -> [Int]

prog :: Program -> [Int]
prog (On s) = stmt s 0 

stmt :: Statements -> DomStm
stmt  (e :> s) m = let v = expr e m in  (v : (stmt s v))
stmt Off _ = []


expr ::  Expression -> Env -> Int
expr (e1 :+  e2) m = (expr  e1 m) + (expr  e2 m)
expr (V n) _  =  n
expr  Mem m  = m

val = On ((V 3) :> (( Mem :+ (V 5)) :> Off))
test = prog val == [3,8]
-- > val 
-- > prog val 
-- > test