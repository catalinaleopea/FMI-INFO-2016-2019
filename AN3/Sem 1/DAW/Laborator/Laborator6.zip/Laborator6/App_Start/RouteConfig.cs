﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Laborator6
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Concatenare",
                url: "concatenare/{param1}/{param2}",
                defaults: new { controller = "Example", action = "Concatenare", param1 = UrlParameter.Optional, param2 = UrlParameter.Optional }
            );

            routes.MapRoute(
               name: "Produs",
               url: "produs/{param1}/{param2}",
               defaults: new { controller = "Example", action = "Produs", param1 = 1, param2 = UrlParameter.Optional }
           );

            routes.MapRoute(
                name: "Operatie",
                url: "operatie/{param1}/{param2}/{param3}",
                defaults: new { controller = "Example", action = "Operatie", param1 = UrlParameter.Optional, param2 = UrlParameter.Optional, param3 = UrlParameter.Optional }
            );

            // Ex 2.
            routes.MapRoute(
                name: "StudentIndex",
                url: "students/all", 
                defaults: new { controller = "Student", action = "Index" }
            );
            routes.MapRoute(
                name: "StudentNew",
                url: "students/new",  
                defaults: new { controller = "Student", action = "Create" }
            );
            routes.MapRoute(
                name: "StudentShow",
                url: "students/{id}/show", 
                defaults: new { controller = "Student", action = "Show", id = UrlParameter.Optional}
            );
            routes.MapRoute(
                name: "StudentEdit",
                url: "students/{id}/edit", // students/3/edit <-- se editeaza stud. cu id 3
                defaults: new { controller = "Student", action = "Edit", id = UrlParameter.Optional }
            );
            routes.MapRoute(
                name: "StudentDelete",
                url: "students/{id}/delete",
                defaults: new { controller = "Student", action = "Delete", id = UrlParameter.Optional }
            );

            // Ex 3

            routes.MapRoute(
                name: "SearchCNP",
                url: "search/cnp/{cnp}",
                defaults: new { controller = "Search", action = "CNP", cnp = UrlParameter.Optional },
                constraints: new { cnp = @"^[1256][0-9]{12}$" }
            );
            routes.MapRoute(
                name: "SearchTelefon",
                url: "search/telefon/{telefon}",
                defaults: new { controller = "Search", action = "NumarTelefon", telefon = UrlParameter.Optional },
                constraints: new { telefon = @"^[0][0-9]{9}$" }
            );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
