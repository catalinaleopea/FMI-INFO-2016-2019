﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Laborator6.Controllers
{
    public class StudentController : Controller
    {
        // Lista tuturor studentilor
        public string Index()
        {
            return "Lista tuturor studentilor";
        }
        // Afisarea unui student
        public string Show(int? id)
        {
            return "Afisare student cu ID: " + id.ToString();
        }
        // Formular de adaugare al unui student
        public string Create()
        {
            return "Formular adaugare student nou";
        }
        // Formular de editare al unui student
        public string Edit(int? id)
        {
            return "Editare student cu ID: " + id.ToString();
        }
        // Stergerea unui student
        public string Delete(int? id)
        {
            return "Stergere student cu ID: " + id.ToString();
        }
    }
}