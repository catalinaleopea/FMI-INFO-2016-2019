﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Laborator6.Controllers
{
    public class SearchController : Controller
    {
        
        public string NumarTelefon(string telefon)
        {
            return "Cautare pentru nr de telefon: " + telefon;
        }

        public string CNP(string cnp)
        {
            return "Cautare pentru CNP: " + cnp;
        }
        
    }
}