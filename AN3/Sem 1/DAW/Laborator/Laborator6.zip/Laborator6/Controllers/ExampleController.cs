﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Laborator6.Controllers
{
    public class ExampleController : Controller
    {
        // GET: Example
        public string Index()
        {


            return "";
            //return View();
        }

        public string Concatenare(string param1, string param2)
        {
            return param1 + " " + param2;
        }

        public string Produs(int param1, int? param2)
        {   
           if(param2 == null)
           {
                return "Introduceti ambii parametri";
           }

           return (param1 * param2).ToString();
        }

        public string Operatie(int? param1, int? param2, string param3)
        {

            if(param1 == null)
            {
                return "Va rugam introduceti parametrul 1";
            }
            if(param2 == null)
            {
                return "Va rugam introduceti parametrul 2";
            }
            if(param3 == null)
            {
                return "Va rugam introduceti parametrul 3";
            }

            if (param3 == "plus")
                return (param1 + param2).ToString();
            else
                if (param3 == "minus")
                return (param1 - param2).ToString();
            else
                if (param3 == "ori")
                return (param1 * param2).ToString();
            else
                if (param3 == "div")
                return (param1 / param2).ToString();
            else
                return "Operatie invalida";
        }
    }
}