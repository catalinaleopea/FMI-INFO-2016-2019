﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CosCumparaturi : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Verificam daca exista un mesaj in sesiune
        if(Session["message"] != null)
        {
            // Afisam mesajul din sesiune
            Response.Write("<div style='padding: 5px; width: 100%; text-align: center; color: #fff; background: #065A82'>" + Session["message"] + "</div>");
            // Stergem mesajul din sesiune
            Session["message"] = null;
        }
        // Citim cookie-ul cart si afisam tot ce este in el
        if (Request.Cookies["cart"] != null)
        {
            NameValueCollection cartCookies;
            cartCookies = Request.Cookies["cart"].Values;
            // Iteram prin toate cheile cookie-ului "cart" (adica id-urile de produse)

            string idProduse = string.Join(",", cartCookies.AllKeys);
            SqlDataSource1.SelectCommand = "SELECT * FROM products WHERE Id IN (" + idProduse + ")";
        }
        else
        {
            Response.Write("Cosul de cumparaturi este gol");
        }

        
        if (Request.Params["remove"] != null)
        {
            if (Request.Params["remove"] == "1")
            {
                Response.Cookies["cart"].Expires = DateTime.Now.AddDays(-1);
                Session["message"] = "Cosul de cumparaturi a fost golit";
                Response.Redirect("/CosCumparaturi.aspx");
            }
        }
    }
}