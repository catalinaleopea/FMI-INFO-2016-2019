﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Produse : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        // Verificam daca se vrea adaugarea in cosul de cumparaturi
        if (Request.Params["addToCart"] != null)
        {
            string idProdus = Request.Params["addToCart"];
            // Adaugam acest ID de produs in cookie-ul pentru CART 
            if(Request.Cookies["cart"] == null)
            {
                // Cookie-ul pentru cosul de cumparaturi (cart) este gol -> adaugam prima valoare
                Response.Cookies["cart"][idProdus] = "1";
            }
            else
            {
                // Luam o colectie de cookies existente
                NameValueCollection cartCookies;
                cartCookies = Request.Cookies["cart"].Values;
                // Iteram prin toate cheile cookie-ului "cart" (adica id-urile de produse)
                foreach( string productId in cartCookies)
                {
                    // Re-adaugam valoarea veche a cookie-ului in cookieul cart
                    Response.Cookies["cart"][productId] = cartCookies[productId];
                }

                // Adaugam sau modificam noua valoare pentru idProdus
                if (Request.Cookies["cart"][idProdus] == null)
                {
                    Response.Cookies["cart"][idProdus] = "1";
                }
                else
                {
                    int count = int.Parse(Request.Cookies["cart"][idProdus]);
                    Response.Cookies["cart"][idProdus] = (count + 1).ToString();
                }
                
            }
            Response.Cookies["cart"].Expires = DateTime.Now.AddDays(15);
            // Am adaugat cookie-ul, facem redirect la produse
            Session["message"] = "Produsul a fost adaugat in cosul de cumparaturi";
            Response.Redirect("/CosCumparaturi.aspx");
        }
        
    }

}