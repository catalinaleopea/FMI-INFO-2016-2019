﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Curs4Exemplu.Startup))]
namespace Curs4Exemplu
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
