﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Show : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Afisarea formularului
        if (!Page.IsPostBack && Request.Params["id"] != null)
        {
            // Luam ID-ul
            int ID = int.Parse(Request.Params["id"].ToString());
            // Salvam cererea SQL intr-un string
            string query = "SELECT *"
                    + " FROM agenda"
                    + " WHERE id = @id";

            // Deschidem conexiunea la baza de date
            SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["AgendaDB"].ConnectionString);
            // Incercam sa executam comanda
            try
            {
                con.Open();
                // Se construieste comanda SQL
                SqlCommand com = new SqlCommand(query, con);
                com.Parameters.AddWithValue("id", ID);

                // Se executa comanda si se returneaza valorile intr-un reader
                SqlDataReader reader = com.ExecuteReader();

                // Citim rand cu rand din baza de date
                while (reader.Read())
                {
                    Nume.Text = reader["nume"].ToString();
                    Prenume.Text = reader["prenume"].ToString();
                    Email.Text = reader["email"].ToString();
                    Telefon.Text = reader["telefon"].ToString();
                }
            }
            catch (Exception ex)
            {
                EroareBazaDate.Text = "Eroare din baza de date: " + ex.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}