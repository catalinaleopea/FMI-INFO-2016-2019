﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using Microsoft.AspNet.Identity;

public partial class Members_Delete : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Afisarea de formular
        if (Request.Params["id"] != null)
        {
            // Luam ID-ul
            int ID = int.Parse(Request.Params["id"].ToString());
            // Salvam cererea SQL intr-un string
            string query = "DELETE"
                    + " FROM agenda"
                    + " WHERE id = @id"
                    + " and user_id = @user_id";

            // Deschidem conexiunea la baza de date
            SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["AgendaDB"].ConnectionString);

            // Incercam sa executam comanda
            try
            {
                con.Open();
                // Se construieste comanda SQL
                SqlCommand com = new SqlCommand(query, con);
                com.Parameters.AddWithValue("id", ID);
                com.Parameters.AddWithValue("user_id", User.Identity.GetUserId());

                int deleted = com.ExecuteNonQuery();

                if (deleted > 0)
                {
                    Response.Write("Intrarea a fost stearsa din baza de date");
                }
                else
                {
                    Response.Write("Intrarea nu a fost stearsa deoarece nu aveti permisiune de stergere");
                }
                
            }
            catch (Exception ex)
            {
                Response.Write("Eroare din baza de date: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}