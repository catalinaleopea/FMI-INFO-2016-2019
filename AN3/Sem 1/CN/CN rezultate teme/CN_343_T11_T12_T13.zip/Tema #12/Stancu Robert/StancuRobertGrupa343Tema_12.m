%%
% ===================== EXERCITIUL 1 ======================================

syms t h f(x);


n = 3;
x = sym('x',[1 n+1]);

I = 0;

for k = 1:n+1
   prod = 1;
   for i = 1:n+1
       if k ~= i
           prod = prod * ((t - i) / (k - i));
       end
      
   end
   w = h * int(prod,1,n+1);
   I = I + f(x(k)) * w;
end

disp("Metoda newton este: ");
disp(matlabFunction(I));

%%
% ===================== EXERCITIUL 2 ======================================

a = 0;
b = pi;

f = @(x) sin(x);

m = 10;

metoda = ["dreptunghi","trapez","Simpson","Newton"];

ValoareIntegrala = integral(f,a,b);

disp( strcat('Valoarea integralei este: ', int2str(ValoareIntegrala)));
for i = 1:length(metoda)
    integrala = Integrare(f,a,b,m,metoda(i));
    disp(strcat('Valoarea integralei data de metoda : '," ",metoda(i),...
            ' este: ', " ",num2str(integrala)));
        
    disp(strcat("Diferenta in modul este: ",num2str(abs(integrala-...
            ValoareIntegrala))));
end


%%

% ======================== EXERCITIUL 4 ===================================

% Comentariu: Nu stiu daca ce am rezolvat aici este bine, insa as dori 
%               feedback. Multumesc frumos.
% % % Warning: Failure at t=7.658339e-01.  Unable to meet integration
% % % tolerances without reducing the step size below the smallest value
% % % allowed (1.776357e-15) at time t. 
% Vorbeste cu Belcineanu de la grupa 344. Te poate lamuri f bine asupra
% acestui exercitiu.

f = @(t,x) x * cos(t) + (x^2) * cos(t);
t0 = 0;
tf = asin(log(2));
x0 = 1;

[t,x] = ode45(f,[t0 tf],x0);
plot(t,x,'r');
hold on

[xe,te] = metodaEuler(f,t0,tf,x0,100);

plot(te,xe,'g')


function [x,t] = metodaEuler(f,t0,tf,x0,N)
    t = zeros(1,N+1);
    x = zeros(1,N+1);
    t(1) = t0;
    h = (tf - t0)/N;
    for i = 2:N+1
        t(i) = t(i-1) + h;
    end
    x(1) = x0;
    for i = 1:N
        x(i+1) = x(i) + h * f(t(i),x(i));
    end
end


function I = Integrare(f,a,b,m,metoda)

    I = 0;
    switch metoda
        case 'dreptunghi'
            h = (b-a)/(2*m);
            for i = 1:m
                I = I + f(a+(2*i-1)*h);
            end
            I = 2 * h * I;
            
        case 'trapez'
            h = (b-a)/m;
            for i = 2:m
                I = I + f(a+(i-1)*h);
            end
            I = 2 * I;
            I = I + f(a) + f(b);
            I = I * (h/2);
            
        case 'Simpson'
            h = (b-a)/(2*m);
            for i = 1:m
               I = I + (1/3 * f(a + (2*i-2)*h) + 4/3  * f(a+(2*i-1)*h) + ...
                    + 1/3 * f(a+(2*i)*h)) * ((a+2*i*h-a-(2*i-2)*h) / 2);
            end
        case 'Newton'
            h = (b-a)/m;
            
            syms t;
            
            for k = 1:m+1
                prod = 1;
                
                for i = 1:m+1
                    if k ~= i
                        prod = prod * ((t - i) / (k - i));
                    end
                end
                
                w = h * int(prod,t,1,m+1);
                I = I + f(a+(k-1)*h) * w;
            end
            
            I = double(I);

            
            
        otherwise
            disp('Alta metoda, eroare');
    end

end
