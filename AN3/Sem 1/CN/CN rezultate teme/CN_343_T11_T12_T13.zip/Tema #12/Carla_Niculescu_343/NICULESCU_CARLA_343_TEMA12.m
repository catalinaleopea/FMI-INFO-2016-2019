%%
%ex2 b - calculul erorilor absolute 
% 9.5/10 -> Explicatia de la ex.4?
a=0;
b=pi;
f = @(x) sin(x);
F = @(x) (-1)*cos(x);
m=10;
metoda = 'trapez';
I=Integrare(f,a,b,m,metoda)
Iexacta = F(b)-F(a)

eps = abs(Iexacta - I)
%%
a=0;
b=pi;
f = @(x) sin(x);
F = @(x) (-1)*cos(x);
m=10;
metoda = 'dreptunghi';
I=Integrare(f,a,b,m,metoda)
Iexacta = F(b)-F(a)

eps = abs(Iexacta - I)

%%
a=0;
b=pi;
f = @(x) sin(x);
F = @(x) (-1)*cos(x);
m=10;
metoda = 'Simpson';
I=Integrare(f,a,b,m,metoda)
Iexacta = F(b)-F(a)

eps = abs(Iexacta - I)
%%
%ex.4.
f=@(t,x) (-x^2/3-2/(3*t^2));
t0=1;
x0=0;
tf=8-0.1;
N=100;
[x,t]=Euler(f,t0,tf,x0,N);

close all;
plot(t,x);
hold on;
xexact=1./(t-2*t.^(2/3))+1./t;

plot(t,xexact);

figure(2)
plot(t,x-xexact);

%%
f=@(t,x) (-x^2/3-2/(3*t^2));
t0=1;
x0=0;
tf=8-0.1;
[t,x] = ode45(f,[t0 tf],x0);

close all;
plot(t,x);
hold on;
xexact=1./(t-2*t.^(2/3))+1./t;

plot(t,xexact);

figure(2)
plot(t,x-xexact);
%%

%ex 2.a - metoda ce calculeaza valoarea aproximativa a integralei I(f)
function [I] = Integrare(f,a,b,m,metoda)    
    switch metoda
        case 'trapez'
            x =  linspace(a,b,m+1);
            y = f(x);
            h = (b-a)/m;
            s=y(1)+y(m+1);
            for i=2:m
                s=s+2*y(i);
            end
            s=h/2 * s;
        case 'dreptunghi'
            x =  linspace(a,b,2*m+1);
            y = f(x);
            h = (b-a)/(2*m);
            s=0;
            for i=1:m
                s=s+y(2*i);
            end
            s=h * 2 * s;
        case 'Simpson'
            x =  linspace(a,b,2*m+1);
            h = (b-a)/(2*m);
            s=0;
            for k=1:m
                s=s+f(x(2*k));
            end
            s=s*4;
            s1=0;
            for k=1:m-1
                s1=s1+f(x(2*k+1));
            end
            s1=2*s1;
            s=s+f(x(2*m+1))+s1;
            s=h/3 * s; 
    end
    I=s;
end

%ex.4.
function [ x,t ] = Euler (f,t0,tf,x0,N  )
    t(1)=t0;
    h=(tf-t0)/N;
    for i=2:N+1
        t(i)=t(i-1)+h;
    end
    x(1)=x0;
    for i=1:N
        x(i+1)=x(i)+h*f(t(i),x(i));
    end
end

