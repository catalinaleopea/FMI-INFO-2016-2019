%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMA 12                                                                 %
% - Madalina Pietreanu, grupa 343                                         %
% - acest fisier reprezinta implementarile anumitor exercitii din tema 12 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 7*/10
%% %%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% b)
% initializari
% % Error using subs
% % Expected input number 1, S, to be one of these types:
% % 
% % sym
% % 
% % Instead its type was function_handle.
% % 
% % Error in sym/subs (line 60)
% % validateattributes(F, {'sym'}, {}, 'subs', 'S', 1);
% % 
% % Error in Madalina_Pietreanu_343>Integrare (line 79)
% %                 I = I + 2*h*subs(f,xsim,x(2*k));
% % 
% % Error in Madalina_Pietreanu_343 (line 20)
% % I1 = Integrare(f,a,b,m,met1);

syms xsim;
f = @(xsim) sin(xsim);
a = 0;
b = pi;
m = 10;
met1 = 'dreptunghi';
met2 = 'trapez';
met3 = 'Simpson';
met4 = 'Newton';

I1 = Integrare(f,a,b,m,met1);
err1 = abs(int(f,xsim,a,b) - I1);

I2 = Integrare(f,a,b,m,met2);
err2 = abs(int(f,xsim,a,b) - I2);

I3 = Integrare(f,a,b,m,met3);
err3 = abs(int(f,xsim,a,b) - I3);

I4 = Integrare(f,a,b,m,met4);
err4 = abs(int(f,xsim,a,b) - I4);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
syms t x;
f = @(t,x) x*cos(t)+x^2*cos(t);
phi=@(t) -exp(sin(t))./(exp(sin(t))-2);
N = 100;
t0 = 1;
x0 = 1;
tf = asin(log(2)) - 0.1;
phiNum = Euler(f,t0,tf,x0,N);
t = linspace(t0,tf,N+1);

figure(1);
plot(t,phi(t),'-b');
hold on
plot(t,phiNum,'--r');
hold off

figure(2)
plot(t,abs(phi(t)- phiNum));
title('Eroarea');

[t,y]=ode45(f,[t0 tf],x0);

figure(3)
plot(t,phi(t),'-b');
hold on
plot(t,y,'--r');
hold on
plot(t,abs(phi(t) - y),'--m');
hold off
legend('Solutia reala','Solutia cu ode45', 'Eroarea');

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUNCTII %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [I] = Integrare(f,a,b,m,metoda)
    
    syms xsim;
    I = 0;

    switch lower(metoda)
        case 'dreptunghi'
            x = zeros(1, 2*m+1);
            
            h = (b-a)/2*m;
            for k = 1 : (2*m + 1)
                x(k) = a + (k - 1) * h;
            end
            for k = 1 : m
                I = I + 2*h*subs(f,xsim,x(2*k));
            end
            
        case 'trapez'
            x = zeros(1, m+1);
            
            h = (b - a) / m;
            for k = 1 : m+1
                x(k) = a + (k - 1) * h;
            end
            % din relatia (19) din curs
            I = h/2 * (subs(f,xsim,x(1)) + subs(f,xsim,x(m+1)));
            for k = 2 :  m
                I = I + h*subs(f,xsim,x(k));
            end
            
        case 'simpson'
            x = zeros(1, 2*m + 1);
            
            h = (b-a) / 2*m;
            for k = 1 : 2*m + 1
                x(k) = a + (k - 1) * h;
            end
            % din relatia (21) din curs 
            I = h/3 * subs(f,xsim,x(2*m + 1));
            for k = 1 : m
                I = I + 4 * h/3 * subs(f,xsim,x(2*k+1));
            end
            for k = 1 : m-1
                I = I + 2 * h/3 * subs(f,xsim,x(2*k + 1));
            end
            
        case 'newton'
            x = zeros(1, 3*m + 1);
            
            h = (b - a) / 3*m;
            for k = 1 : 3*m + 1
                x(k) = a + (k - 1) * h;
            end
            for k = 1 : m
               I = I + subs(f,xsim,x(3*k - 2)) + 3 * subs(f,xsim,x(3*k - 1)) ...
                     + subs(f,xsim,x(3*k)) + subs(f,xsim,x(3*k + 1));
            end
            I = I * 3 * h/8;
            
        otherwise
            error('optiune necunoscuta (verificati textul introdus)')
    end
end

function [x] = Euler(f,t0,tf,x0,N)

    x = zeros(1,N+1);

    t = linspace(t0,tf,N+1);
    h = t(2) - t(1); % pasul
    x(1) = x0;
    
    for i = 1 : N
        x(i + 1) = x(i) * h * f(t(i),x(i));
    end
    
end