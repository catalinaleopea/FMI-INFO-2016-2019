%% Exercitiul 2
%b)
a = 0;
b = pi;
f = @(x) sin(x);
m = 10;

F = integral(f, a, b);

F_dreptunghi = Integrare(f, a, b, m, 'dreptunghi');
F_trapez = Integrare(f, a, b, m, 'trapez');
F_simpson = Integrare(f, a, b, m, 'simpson');
F_newton = Integrare(f, a, b, m, 'newton');

fprintf('Eroarea metodei dreptunghiului este %f\n', abs(F - F_dreptunghi));
fprintf('Eroarea metodei trapez este %f\n', abs(F - F_trapez));
fprintf('Eroarea metodei simpson este %f\n', abs(F - F_simpson));
fprintf('Eroarea metodei newton este %f\n', abs(F - F_newton));

%% Exercitiul 4
close all;
% 
phi = @(t) -exp(sin(t)) ./ (exp(sin(t)) - 2);
x0 = 1;
t0 = 0;
tf = 1;
xx = linspace(t0, tf);
yy = phi(xx);
figure;
plot(xx, yy);
title("Graficul solutiei exacte");
f = @(t, x) phi(x) .* cos(t) + phi(x).^2 .* cos(t);

[t, y] = ode45(f, [t0 tf], x0);
figure;
plot(t, y);
hold on;

x = MetodaEuler(f, t0, tf, x0, length(t)-1);
figure;
plot(t, y(:) - x(:));
title("Eroarea aproximarii cu metoda Euler");
%% functii ajutatoare
function I = Integrare(f, a, b, m, metoda)
    switch lower(metoda)
        case "dreptunghi"
            h = (b - a) / (2*m);
            k = 1:2*m+1;
            x = a + (k-1) .* h;
            I = 2*h*sum(f(x(2:2:2*m)));
        case "trapez"
            h = (b - a) / m;
            k = 1:m+1;
            x = a + (k-1) .* h;
            I = h/2*(f(x(1)) + 2 * sum(f(x(2:m))) + f(x(m+1)));
        case "simpson"
            h = (b - a) / (2*m);
            k = 1:2*m+1;
            x = a + (k-1) .* h;
            I = h/3 * (4*sum(f(x(2:2:2*m))) + 2 * sum(f(x(3:2:2*m-1))) + f(x(2*m+1)));
        case "newton"
            h = (b - a) / m;
            k = 1:m+1;
            x = a + (k-1) .* h;
            
            syms t;
            
            p_orig = sym('p', [length(k) 1]);
            p = sym('p', [length(k) 1]);
            
            for kk = k
                for i = k
                    if i ~= kk
                        p(kk) = p(kk) * (t-i) / (kk-i);
                    end
                end
            end
            
            for i=1:length(p)
                p(i) = subs(p(i), p_orig(i), 1);
            end
            
            s = 0;
            
            for i = k
                s = s + h * int(p(i), 1, 4) * f(x(i));
            end
            
            I = s;
        otherwise
            error('Metoda aleasa nu este cunoscuta sau exista un typo');
    end
end

function x = MetodaEuler(f, t0, tf, x0, N)
    t = zeros(1, N+1);
    x = zeros(1, N+1);

    t(1) = t0;
    h = (tf - t0) / N;
    
    for i = 2:N+1
        t(i) = t(i-1) + h;
    end
    
    x(1) = x0;
    
    for i = 1:N
        x(i+1) = x(i) + h*f(t(i), x(i));
    end
end