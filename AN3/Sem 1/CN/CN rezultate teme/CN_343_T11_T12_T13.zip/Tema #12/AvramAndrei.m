% Avram Andrei-Alexandru, grupa 343, Tema 12
% 7 /10

%% Prolema 2

a = 0;
b = pi;
f = @(x) sin(x);
m = 10;
Edreptunghi = abs(integral(f,a,b) - Integrare(f,a,b,m,'dreptunghi'))
Etrapez = abs(integral(f,a,b) - Integrare(f,a,b,m,'trapez'))
ESimpson = abs(integral(f,a,b) - Integrare(f,a,b,m,'Simpson'))
ENewton = double(abs(integral(f,a,b) - Integrare(f,a,b,m,'Newton')))

%% Functii

function I = Integrare(f, a, b, m, metoda)

switch metoda
    case 'dreptunghi'
        h = (b-a)/(2*m);
        x = zeros(1,2*m+1);
        for k = 1:2*m+1
            x(k) = a + (k-1)*h;
        end
        
        sum = 0;
        for k = 1:m
            sum = sum + f(x(2*k));
        end
        I = 2*h*sum;
        
    case 'trapez'
        h = (b-a)/m;
        x = zeros(1,m+1);
        for k = 1:m+1
            x(k) = a + (k-1)*h;
        end
        
        sum = f(x(1)) + f(x(m+1));
        for k = 2:m
            sum = sum + 2*f(x(k));
        end
        I = (h/2)*sum;
        
    case 'Simpson'
        h = (b-a)/(2*m);
        x = zeros(1,2*m+1);
        for k = 1:2*m+1
            x(k) = a + (k-1)*h;
        end
        
        sum = f(x(1)) + f(x(2*m+1));
        for k = 1:m-1
            sum = sum + 2*f(x(2*k+1));
        end
        for k = 1:m
            sum = sum + 4*f(x(2*k));
            %in curs era cu 1* dar nu iese bine
            %pe net era cu 4* si vad ca e mult mai ok
        end
        I = (h/3)*sum;
        
    case 'Newton'
        h = (b-a)/m;
        x = zeros(1,m+1);
        for k = 1:m+1
            x(k) = a + (k-1)*h;
        end
        
        w = zeros(1,m+1);
        syms f(t) t
        for k = 1:m+1
            f(t) = 1;
            for i = 1:m+1
                if k ~= i
                    f(t) = f(t) * (t-i)/(k-i);
                end
            end
            w(k) = h*int(f(t),t,1,m+1);
        end
        
        I = 0;
        for k = 1:m+1
            I = I + w(k) * f(x(k));
        end
        
        clear f(t) t
end

end

function x = Euler(f ,t0,tf , x0, N)

h = (tf - t0)/N;
t = zeros(1,N+1);
t(1) = t0;

for i = 2:N+1
    t(i) = t(i-1) + h;
end

x = zeros(1,N);
x(1) = x0;
for i = 1:N
    x(i+1) = x(i) + h * f(t, xi);
end

end