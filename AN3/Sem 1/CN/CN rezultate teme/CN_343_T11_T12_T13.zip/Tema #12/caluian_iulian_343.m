% 9.5/10 > Explicatia de la ex.4?
syms t
f1 = (t-2)*(t-3)*(t-4)/(-6);
g1 = int(f1, [1 4]);

syms t
f2 = (t-1)*(t-3)*(t-4)/(2);
g2 = int(f2, [1 4]);

syms t
f3 = (t-1)*(t-2)*(t-4)/(-2);
g3 = int(f3, [1 4]);

syms t
f4 = (t-1)*(t-2)*(t-3)/(6);
g4 = int(f4, [1 4]);

g1 
g2
g3
g4

% Asadar avem I3 = 3/8 * f(a) + 9/8 * f((2a+b)/3) + 9/8 * f((a + 2b)/3) +
% 3/8 f(b);
%
% Avem formula de cuadratura sumata:
%
% I(3,m)(f) = SUM (k = 1:m) de 3/8 * f(a) + 9/8 * f((2a+b)/3) + 
%                              9/8 * f((a + 2b)/3) + 3/8 f(b)
%   unde a = x(2*k-1) si b = x(2*k+1)

%% Exercitiul 2:

syms t
f = sin(t);

rez = Integrare(f, 0, pi, 10, 'dreptunghiului');
rezultat1 = double(rez)

rez = Integrare(f, 0, pi, 10, 'trapezului');
rezultat2 = double(rez)

rez = Integrare(f, 0, pi, 10, 'Simpson');
rezultat3 = double(rez)

%%erorile abolute sunt abs(2-rez) pentru cazul precizat (int de la 0 la pi
%%din sin(x)

%asadar avem:
err1 = abs(2 - rezultat1);
err2 = abs(2 - rezultat2);
err3 = abs(2 - rezultat3);
err1
err2
err3



%% Ex 3.
%% a) 
% f = x * cost + (x^2) cost
% i) f continua in raport cu ambele argumente - da , toate sunt functii
% continue
% ii) |f(t,x)- f(t,y)| = |cost(x-y)(1+x+y)| < L |x-y|  <=> 
%     cost(1+x+y) < L , alegem L astfel incat L > (1+x+y) unde 
%     (t,x) , (t,y) apartin unei vecinatati D0 => L = 2 + max(|x|,|y|)*2;
% => Admite conditia E.U.L

% f(0) = 1, din b) avem fK(t) = - e^(sint) / (e^sint + K)
%   avem deci 1 = 1 /( 1 + K) => K = 0
%

%% Exercitiu 4
f=@(x) x^2 + x;
a=0;
b=1;
x0=0;
M=100;
YY =euler(f,a,b,x0,M)
plot(YY(:,1),YY(:,2))


function E=euler(f,t0,tf,x0,M)
h=(tf-t0)/M;

X=zeros(1,M+1);
T=t0:h:tf;
X(1)=x0;

for j=1:M
    X(j+1)=X(j)+h*f(T(j));
end
E=[T' X'];
end

function I = Integrare(f, a, b, m, metoda)
    h = (b-a)/(2*m);
    x = linspace(a,b,2*m+1);
    switch metoda 
        case 'dreptunghiului' 
            vx = x(2:2:(2*m+1));
            vb = subs(f, vx);%valoarea functiei in punctele respective
            I = 2*h*sum(vb);
        case 'trapezului'
            vx = x(1:(2*m));
            vb = subs(f, vx);%valoarea functiei in punctele respective
            s1 = sum(vb);
            vx = x(2:(2*m+1));
            vb = subs(f, vx);%valoarea functiei in punctele respective
            s2 = sum(vb);
            I = h/2 * (s1 + s2);
        case 'Simpson'
            %Formula wikipedia s1 + 2s2 + 4s3 + s4 (formula din curs pare
            %gresita )
            s1 = subs(f,x(1));
            
            vx = x(3:2:(2*m-1));
            vb = subs(f, vx);%valoarea functiei in punctele respective
            s2 = sum(vb);
            
            vx = x(2:2:(2*m));
            vb = subs(f, vx);%valoarea functiei in punctele respective
            s3 = sum(vb);
            
   
            s4 = subs(f,x(2*m+1));
            
            I = h/3 * (s1 + 2*s2 + 4*s3 + s4);
    end 
end
