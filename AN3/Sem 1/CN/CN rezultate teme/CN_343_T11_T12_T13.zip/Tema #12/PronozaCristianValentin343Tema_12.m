% 5/10 -> Mai multa atentie la ce cod livrezi!
%% Exercitiul 1:  
f=@(x)sin(x); 
I = Integrare(f,0,pi,10,'dreptunghi'); 
EroareDreptunghi=abs(I-2)
I = Integrare(f,0,pi,10,'trapez');  
EroareTrapez=abs(I-2)
I = Integrare(f,0,pi,10,'Simpson');  
EroareSimpson=abs(I-2)
I = Integrare(f,0,pi,10,'Newton'); 
EroareNewton=abs(I-2)


%%
function I = Integrare(f,a,b,m,metoda)  
X=linspace(a, b, m);  
I=0;
for i=1:m-1 
    a=X(i);
    b=X(i+1);
    switch metoda 
       case 'dreptunghi' 
            I=I+(b-a)*f((a+b)/2);
       case 'trapez' 
            I=I+((b-a)/2)*(f(a)+f(b));     
       case 'Simpson'
            I=I+((b-a)/6)*(f(a)+4*f((a+b)/2)+f(b));
       case 'Newton'
            I=I+((b-a)/8)*(f(a)+3*f((2*a+b)/3)+3*f((a+2*b)/3)+f(b));
end  
end

end 

function x= Euler(f,t0,tf,x0,N)  
    t(1)=t0; 
    h=(tf-t0)/N; 
    for i=2:N+1 
        t(i)=t(i-1)+h; 
    end 
    x(1)=x0; 
    for i=1:N 
        x(i+1)=x(i)+h*f(t(i),x(i)); 
    end 
end