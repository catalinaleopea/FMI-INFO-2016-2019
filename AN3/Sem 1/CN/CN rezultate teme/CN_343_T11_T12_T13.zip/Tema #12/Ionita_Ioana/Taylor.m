function [t, x] = Taylor (f, t0, tf, x0, N, fderiv, fderiv2, fderiv3)
    t = linspace (t0, tf, N+1);
    
    x(1) = x0;
    h = t(2) - t(1);
    for i = 1:N
        x(i+1) = x(i) + h*(f(t(i),x(i)) + h/2 * fderiv(t(i),x(i)) + h*h/6 * fderiv2(t(i),x(i)) + h*h*h/24 * fderiv3(t(i),x(i)));
    end

end