function [x, t] = Euler(f, t0, tf, x0, N)
    t = linspace(t0, tf, N+1);
    x(1) = x0;
    h = t(2)- t(1);
    
    for i = 1:N
        x(i+1) = x(i) + h * f(t(i),x(i));
    end
    
end