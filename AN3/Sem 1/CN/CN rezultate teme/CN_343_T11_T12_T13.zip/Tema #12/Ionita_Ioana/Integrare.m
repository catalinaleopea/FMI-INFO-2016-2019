function [I] = Integrare (f, a, b, m, metoda)

    switch metoda
        case 'trapez' %formula de cuadratura sumata a trapezului
            x = linspace(a, b, m+1);
            sum = 0;
            for k = 2:m
                sum = sum + f(x(k));
            end
            I = (b-a)/m/2*(f(x(1))+2*sum+f(x(m+1)));
            
        case 'dreptunghi' %formula de cuadratura a dreptunghiului
            x = linspace (a, b, 2*m+1);
            sum = 0;
            for k = 1:m
                sum = sum + f(x(2*k));
            end
            I = (b-a) / m * sum;
            
        case 'Simpson' %formula de cuadratura Simpson
            x = linspace (a, b, 2*m+1);
            sum = 0;
            for k = 1:m
                if 2*k == (a+b)/2 
                    sum = sum + 4*f(x(2*k));
                else
                sum = sum + f(x(2*k));
                end
            end
            I = (b-a)/m/6*sum;
        case 'Newton'
            
    end