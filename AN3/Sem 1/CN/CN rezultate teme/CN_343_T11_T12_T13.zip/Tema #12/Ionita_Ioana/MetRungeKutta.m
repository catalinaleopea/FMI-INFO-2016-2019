function [x, t] = MetRungeKutta (f, t0, tf, x0, N,tip_met)
    t = linspace(t0, tf, N+1);
    h = t(2) - t(1);
    x(1) = x0;
    switch tip_met
        case 'pct_central'
            for i = 1:N
                K1 = h *f(t(i),x(i));
                K2 = h * f(t(i) + (h/2),x(i) + (K1/2));
                x(i+1) = x(i) + K2;
            end
        case 'euler_mod'
            for i = 1:N
                K1 = h * f(t(i),x(i));
                K2 = h/f(t(i) + h,x(i) + K1);
                x(i+1) = x(i) + (K1 + K2)/2;
            end
        case 'Heun'
            for i = 1:N
                K1 = h*f(t(i),x(i));
                K2 = h*f(t(i) + (2*h)/3, x(i) + (2*K1)/3);
                x(i+1) = x(i) + (K1 + 3*K2)/4;
            end
        case 'Ordin4'
            for i = 1:N
                K1 = h * f(t(i), x(i));
                K2 = h * f(t(i) + h/2, x(i) + K1/2);
                K3 = h * f(t(i) + h/2, x(i) + K2/2);
                K4 = h * f(t(i) + h, x(i) + K3);
                x(i+1) = x(i) + (K1 + 2*K2 + 2*K3 + K4)/6;
            end
    end
end