function [ t, x] = PunctCentral( f, t0, tf, x0, N )

    t = linspace (t0, tf, N+1);
    x(1) = x0;
    h = (tf - t0)/N;
    for i=1:N 
        K1 = h*f(t(i), x(i));
        K2 = h*f(t(i) + h/2, x(i) + K1/2);
        x(i+1) = x(i) + K2;
    end

end

