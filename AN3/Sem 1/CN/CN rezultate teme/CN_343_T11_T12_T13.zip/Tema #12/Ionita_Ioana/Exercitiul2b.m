%Exercitiul 2b)
a = 0;
b = pi;
m = 1000;
f = @(x)sin(x);
F = @(x)(-cos(x));

I = Integrare(f, a, b, m, 'trapez');
Iexact = F(b) - F(a);
eps = abs(Iexact - I);

m2 = 500;
I2 = Integrare(f, a, b, m2, 'dreptunghi');
eps2 = abs(Iexact - I2);