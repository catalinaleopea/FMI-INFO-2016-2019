% De ce nu ai tratat toata tema 12? 
% 8*/10
%Exercitiul 1 (tema 13) + exercitiul 4 (tema 12)
syms x t;
f = x*cos(t) + x*x*cos(t);
f_deriv = diff(f, t) + diff(f,x)*f;
f_deriv_2 = diff(f_deriv, t) + diff(f_deriv,x) * f;
f_deriv_3 = diff(f_deriv_2,t) + diff(f_deriv_2,x) * f;

f = matlabFunction(f, 'Vars',[t,x]);
f_deriv = matlabFunction(f_deriv, 'Vars',[t,x]);
f_deriv_2 = matlabFunction(f_deriv_2, 'Vars',[t,x]);
f_deriv_3 = matlabFunction(f_deriv_3, 'Vars',[t,x]);
t0 = 0;
x0 = 1;

sol =@(t) - exp(sin(t))./(exp(sin(t))-2);

tf = 0.7;
N = 100;
metoda = 'Ordin4';
[x, t] = MetRungeKutta(f, t0, tf, x0, N, metoda);
plot(t,x);
hold on
[t, x] = Taylor(f, t0, tf, x0, N, f_deriv, f_deriv_2, f_deriv_3);
plot(t,x);
hold on
[t, x] = PunctCentral(f, t0, tf, x0, N);
plot(t,x);
hold on
[t, x] = Heun(f, t0, tf, x0, N );
plot(t, x);
hold off;
figure
plot(t,sol(t));
size(t);
figure(2);
plot(t, x-sol(t));

RelTot = 10^-6;
AbsTol = 10^-6;

figure(3);
[t, y] = ode45(f,[t0 tf], x0, 10^-6);
plot(t,y);

figure(4);
plot(t, y - sol(t));
size(t);