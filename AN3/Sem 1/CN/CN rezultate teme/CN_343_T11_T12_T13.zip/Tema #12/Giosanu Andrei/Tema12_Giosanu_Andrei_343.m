% Giosanu Andrei
% Grupa 343
% 7.5/10 -> Te-ai complicat destul de mult la ex.3. + a) incomplet +
% prezentarea rezultatelor intr-o forma greu de inteles.
a = 0;
b = pi;
m = 10;
f = inline('sin(x)', 'x');
metoda1 = 'dreptunghi';
metoda2 = 'trapez';
metoda3 = 'Simpson';
metoda4 = 'Newton';

syms x;
I = int(sin(x), a, b);
I0 = Integrare(f, a, b, m, metoda1);
I1 = Integrare(f, a, b, m, metoda2);
I2 = Integrare(f, a, b, m, metoda3);
I3 = Integrare(f, a, b, m, metoda4);

I = vpa(I);

error(1) = abs(I - I0);
error(2) = abs(I - I1);
error(3) = abs(I - I2);
error(4) = abs(I - I3);
error

f = @(t,x)(x*cos(t) + x^2*cos(t));
t0 = 0;
x0 = 1;
tf = asin(log(2))-0.1;
N = 10;
[t,x] = MetodaEuler(f,t0,tf,x0,N);
figure; hold on;
plot(t,x,'-r');

f1 = @(t)(-exp(sin(t))./(exp(sin(t))-2));
plot(t,f1(t),'--k');

[t_ode45,x_ode45] = ode45(f,[t0,tf],x0);
plot(t_ode45,x_ode45, '-g');
figure; hold on;
plot(t, f1(t) - x, '-r');
plot(t_ode45, x_ode45 - f1(t_ode45), '-g');

function I = Integrare(f, a, b, m, metoda)
    I = 0;
    switch metoda
        case 'dreptunghi'
            x = linspace(a, b, 2 * m + 1);
            h = (b-a) / 2;
            for k = 1:m
                I = I + f(x(2*k)) * (x(2*k+1) - x(2*k-1));
            end
        case 'trapez'
            x = linspace(a, b, m + 1);
            for k = 1:m
                I = I + (f(x(k)) + f(x(k+1)))/2 * (x(k+1) - x(k)); 
            end
        case 'Simpson'
            x = linspace(a, b, 2 * m + 1);
            for k = 1:m
                I = I + 1/3 * f(x(2*k-1)) + 4/3 * f(x(2*k)) + 1/3 * f(x(2*k+1));
            end
            I = I * (x(2*k+1) - x(2*k-1))/2;
        otherwise
            x = linspace(a, b, 3 * m + 1);
            h = x(2) - x(1);
            for k = 1:m
                I = I + f(x(3*k-2)) + 3 * f(x(3*k-1)) + 3 * f(x(3*k)) + f(x(3*k+1)); 
            end

            I = I * (3 * h / 8);
    end
end

function [t,x] = MetodaEuler(f,t0,tf,x0,N)
t(1) = t0;
h = (tf-t0)/N;

for i = 2:N+1
    t(i) = t(i-1) + h;
end

x(1)= x0;
for i = 1:N
    x(i+1) = x(i)+ h*f(t(i),x(i));
end
end
