% 8/10
function MarinoiuAndrei343_Tema12()

%% Exercitiul 2
% Subpunctul b)

% Datele din cerinta
f = @(x) sin(x);
a = 0;
b = pi;
m = 10;

% Calculam integrala functiei impreuna cu valorile aproximative ale
% integralei utilizand metodele cerute
i = integral(f,a,b);
i0 = Integrare(f,a,b,m,"dreptunghi");
i1 = Integrare(f,a,b,m,"trapez");
i2 = Integrare(f,a,b,m,"Simpson");

% Afisam erorile absolute rezultate
disp("Dreptunghi: "+abs(i-i0));
disp("Trapez: "+abs(i-i1));
disp("Simpson: "+abs(i-i2));

end

% Functie specifica metodei de integrare

% f -> functia pentru care dorim sa calculam integrala
% a,b -> intervalul pe care calculam integrala
% m -> numarul de valori
% metoda -> tipul de metoda pe (este de 3 tipuri)

% Date de iesire :
% rez -> vectorul calculat conform algoritmului

function [rez] = Integrare(f,a,b,m,metoda)

switch metoda
    case "dreptunghi" % Algoritmul este implementat dupa formula nr. 16
% aflata in cursul 12,pagina 15.
        sum = 0;
        h = (b - a) / (2 * m);
        for k = 1:(2*m + 1)
            x(k) = a + (k-1) * h;
        end
        for k = 1:m
            sum = sum + f(x(2*k));
        end
        rez = 2*h*sum;
    case "trapez" % Algoritmul este implementat dupa formula nr. 19
% aflata in cursul 12,pagina 17.
        sum = 0;
        h = (b - a) / m;
        for k = 1:(m + 1)
            x(k) = a + (k-1) * h;
        end
        for k = 2:m
            sum = sum + f(x(k));
        end
        rez = (h / 2) * (f(x(1)) + (2 * sum) + f(x(m+1)));
    case "Simpson" % Algoritmul este implementat dupa formula nr. 21
% aflata in cursul 12,pagina 19.
        sum1 = 0;
        sum2 = 0;
        h = (b - a) / (2 * m);
        for k = 1:(2*m + 1)
            x(k) = a + (k-1) * h;
        end
        for k = 1:m
            sum1 = sum1 + f(x(2*k));
        end
        for k = 1:(m-1)
            sum2 = sum2 + f(x(2*k+1));
        end
        rez = (h / 3) * (sum1 + (2 * sum2) + f(x(2*m+1)));
end

end

% Functie specifica metodei Euler

% f -> functie
% t0,tf -> intervalul pe care este definita functia specifica solutiei
% problemei Cauchy
% x0 -> conditia initiala

%Algoritmul este implementat dupa pseudocodul aflat in cursul 12,pagina 26.
function [trez,xrez] = MetEuler(f,t0,tf,x0,N)

t = zeros(1,N+1);
x = zeros(1,N+1);
t(1) = t0;
x(1) = x0;
h = (tf - t0) / N;

for i = 2:(N+1)
    t(i) = t(i-1) + h;
end

for i = 1:N
    x(i+1) = x(i) + h * f(t(i),x(i));
end

trez = t;
xrez = x;

end