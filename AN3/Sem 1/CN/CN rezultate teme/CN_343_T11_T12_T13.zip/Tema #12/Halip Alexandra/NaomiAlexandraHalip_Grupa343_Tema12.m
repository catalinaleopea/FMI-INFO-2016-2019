% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 12
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2019
% =========================================================================
% 8.5/10 -> Prezinta rezultatele obtinute la consola + ex.4? + vezi PDF

%%
% pentru Ex. 1
n = 3;
a = 0;
b = pi;
f = @(x)(sin(x));
syms r
I = NewtonCotesInc(a,b,n,f,r);

%%


%%
% Ex. 2
% b)
a = 0;
b = pi;
m = 10;
f = @(x)(sin(x));
syms x
f1 = sin(x);
I = int(f1,a,b);
I0 = Integrare(f,a,b,m,'dreptunghi');
I1 = Integrare(f,a,b,m,'trapez');
I2 = Integrare(f,a,b,m,'Simpson');
% erprile absolute
e0 = abs(I-I0);
e1 = abs(I-I1);
e2 = abs(I-I2);

%%

%%
% Ex. 1
function [I] = NewtonCotesInc(a,b,n,f,r)
    x(1) = a;
    h = (b -a)/n;

    for i = 1:n+1
        x(i) = a + (i-1)*h;
    end

    for k = 1:n+1
           syms r
           g=Produs(k,n,r,x);
           w(k) = h *int(g,a,b); 
    end

    I = 0;
    for i = 1:n+1
        I = I +w(i)*f(x(i));
    end
end
%%

%%
% functie folosita pentru determinarea cuadraturii Newton-Cotes inchisa,
% n=3
function [p] = Produs(k,n,r,x)
    p = 1;
    for i =1:n+1
        if i ~= k
         p = p * ((r-x(i))/(x(k)-x(i)));
        end
    end
end
%%


%%
% Ex. 2
% a)
function [I] = Integrare(f,a,b,m,metoda)
    switch metoda
        case 'dreptunghi'
            x(1) = a;
            x(2:2*m) = linspace(a,b,2*m-1);
            x(2*m+1) = b;
            h = (b-a)/2*m;
            s3 = 0;
            for k =1:m
                if mod(k,2) == 0
                    s3 = s3 + f(x(k));
                end
            end
            I = ((b-a)/m)*s3;
        case 'trapez'
            x(1) = a;
            x(2:m) = linspace(a,b,m-1);
            x(m+1) = b;
            h = (b-a)/m;
            s2 = 0;
            for k =1:m
                s2 = s2 + f(x(k));
            end
            I = (h/2)*(f(x(1)) + 2*s2 + f(x(m+1)));
        case 'Simpson'
            x(1) = a;
            x(2:2*m) = linspace(a,b,2*m-1);
            x(2*m+1) = b;
            h = (b-a)/2*m;
            s = 0;
            s1 = 0;
            for k =1:m
                if mod(k,2) == 0
                 s = s + f(x(k));
                end
            end
            for k =1:m-1
                if mod(k,2) ~= 0
                 s1 = s1 + f(x(k));
                end
            end
            I = (h/3) *(f(x(1)) +4*s + 2*s1+f(2*m+1));
    end
    
end
%%


%%
% Ex. 4
function [] = MetEulerExplicit(f,t0,tf,x0,N)
    t(1) = t0;
    h = (tf-t0)/N;
    for i = 2:N+1
        t(i) = t(i-1) + h;
    end
    x(1) = x0;
    for i = 1:N
        x(i+1) = x(i) + h*f(t,x(i));
    end
end
%%