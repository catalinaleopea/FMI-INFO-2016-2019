% 9.5/10 -> Prezinta datele intr-o maniera usor de inteles pentru toata
% lumea (i.e. legenda + mesaj la consola)

%% Exercitiul 1.

syms x
f = sin(x);

x = linspace(0,pi,101);
dxc = DerivNum(x,sin(x),'diferente finite regresive');
g = diff(f);
figure(1);
ezplot(g,[0,pi]);
vd = subs(g,x(2:100));
hold on;
plot(x(2:100),dxc);


figure(2);
plot(x(2:100),abs(dxc - vd));

%% Exercitiul 2.

f=@(x) sin(x)
fp=@(x) cos(x);
fs=@(x) -sin(x);

% Point of evaluation
x = linspace(0,pi,101);

% Exact values of the derivatives
f_prime4_x = fp(x);
f_prime6_x = fp(x);
f_prime8_x = fp(x);
f_second4_x = fs(x);
f_second6_x = fs(x);
f_second8_x = fs(x);


figure(1);
axis([0 pi -1.5 1.5])

ezplot(fp,[0,pi]);
hold on;

% Step initial value
h_in = 0.4;
% Order of extrapolation 
N = 4;
for idx = 1:numel(x)
    elem = x(idx);
    [f_prime4_x(idx),f_second4_x(idx)] = MetRichardson(f,elem,h_in,N);
end
plot(x,f_prime4_x);
N = 6;
for idx = 1:numel(x)
    elem = x(idx);
    [f_prime6_x(idx),f_second6_x(idx)] = MetRichardson(f,elem,h_in,N);
end
plot(x,f_prime6_x);
N = 8;
for idx = 1:numel(x)
    elem = x(idx);
    [f_prime8_x(idx),f_second8_x(idx)] = MetRichardson(f,elem,h_in,N);
end
plot(x,f_prime8_x);
figure(2);
vd = subs(fp,x);
plot(x,abs(f_prime4_x - vd));





figure(3);
hold on;

ezplot(fs,[0,pi]);
plot(x,f_second4_x);
plot(x,f_second6_x);
plot(x,f_second8_x);
axis([0 pi -1.5 1.5])


%diferenta
figure(4);
vd = subs(fs,x);
plot(x,abs(f_second4_x - vd));

%plot(x,f_second_x);



function [dy] = DerivNum(x,y,metoda)
    m = max(size(x,1),size(x,2)) - 1;
    dy = zeros(1,m-1);

    switch metoda 
        case 'diferente finite progresive'
            for i = 2:m 
                dy(i-1) =( y(i+1)-y(i) )/ (x(i+1) - x(i)); 
            end
        case 'diferente finite regresive'
             for i = 2:m 
                dy(i-1) =( y(i)-y(i-1) )/ (x(i) - x(i-1)); 
            end
            
        case 'diferente finite centrale'
            for i = 2:m 
                dy(i-1) =( y(i+1)-y(i-1) )/ (x(i+1) - x(i-1)); 
            end
    end

end



function [df,d2f] = MetRichardson(f,x,h,N)

% h=zeros(N,1);
% h(1)=h0;
% for j=2:N
%     h(j)=h(j-1)/2;
% end


f_df=zeros(N,N+1); %n linii , n+1 col mat 
f_d2f=f_df;

% col 1:
f_df(:,1)=h;
f_d2f(:,1)=h;

% col 2: (de fapt c1 din curs
for j=1:N
    f_df(j,2)= ( f(x+h) - f(x) )/(h);
    
    f_d2f(j,2)=f(x + h)/h^2 - 2*f(x)/h^2  +  f(x-h)/h^2;

end

for i=3:N+1
    for j=i-1:N
        f_df(j,i)=(2^(2*(i-2))*f_df(j,i-1)-f_df(j-1,i-1))/...
            (2^(2*(i-2))-1);
        
        f_d2f(j,i)=(2^(2*(i-2))*f_d2f(j,i-1)-f_d2f(j-1,i-1))/...
            (2^(2*(i-2))-1);
    end
end

df = f_df(N,N+1);
d2f = f_d2f(N,N+1);
end


