%%
%ex 1.b
f = @(x) sin(x);
g = @(x) cos(x);
X = linspace(0,pi,100);
Y=f(X);
Z=g(X);

%metoda = 'p' = metoda finite progresive 
figure(1)
df = DerivNum(X,Y,'p'); %df e derivata obtinuta din procedura DerivNum
subplot(1,3,1);
plot(X,Y); %plotarea graficului functiei f 
hold on;
subplot(1,3,2);
plot(X(2:length(X)-1), df(2:length(X)-1)); %plotare derivata df

%ex 1.c) - plotare diferenta dintre derivata exacta a functiei f si cea 
%calculata numeric
subplot(1,3,3);
plot(abs(Z(2:length(X)-1)-df(2:length(X)-1)));

% metoda = 'r' = diferente finite regresive 
figure(2)
df = DerivNum(X,Y,'r');
subplot(1,3,1);
plot(X,Y);
hold on;
subplot(1,3,2);
plot(X(2:length(X)-1), df(2:length(X)-1));
subplot(1,3,3);
plot(abs(Z(2:length(X)-1)-df(2:length(X)-1)));

%metoda = 'c' = diferente finite centrale 
figure(3)
df = DerivNum(X,Y,'c');
subplot(1,3,1);
plot(X,Y);
hold on;
subplot(1,3,2);
plot(X(2:length(X)-1), df(2:length(X)-1));
subplot(1,3,3);
plot(abs(Z(2:length(X)-1)-df(2:length(X)-1)));

%%
%ex 2)
syms x
f = @(x) sin(x);
%g = @(x) cos(x);
g = matlabFunction(diff(f,x));
X = linspace(0,pi,100);
Y=f(X);
Z=g(X);
h=X(2)-X(1);
%apelare procedura in fiecare nod al discretizarii 
for i=1:length(X)
    df(i)=MetRichardson(f,X(i),h,5); 
end

figure(1)
subplot(1,2,1);
plot(X,df);
hold on;
subplot(1,2,2);
plot(abs(Z-df));

%2d)
df2 = zeros(length(X), 1);
f2 = matlabFunction(diff(g,x)); %derivata a doua exacta a functiei f
Y = f2(X);

for i = 1:length(X)
    df2(i) = MetRichardsonModif(f, X(i), h, 4);
end

%2e)
figure(2)
subplot(1,2,1);
plot(X,Y);
legend('Derivata2 exacta');
hold on;
subplot(1,2,2);
plot(X,df2);
legend('Derivata2 aproximativa');
%%

%algoritm Derivare Numerica ex.1a.
function [dy] = DerivNum(X,Y,metoda)
    m = length(X)-1;
    switch metoda
        case 'p'
            for i=2:m
                dy(i)=(Y(i+1)-Y(i))/(X(i+1)-X(i));
            end
        case 'r'
            for i=2:m
                dy(i)=(Y(i)-Y(i-1))/(X(i)-X(i-1));
            end
        case 'c'
            for i=2:m
                dy(i)=(Y(i+1)-Y(i-1))/(X(i+1)-X(i-1));
            end
    end
end

%ex 2a) - Metoda de extrapolare Richardson
function [df] = MetRichardson(f,x,h,n)
    Q = zeros(n, n, length(x));  
    for i=1:n
        Q(i,1) = (f(x+h/2^(i-1))-f(x))/(h/2^(i-1));
    end
    for i=2:n
        for j=2:i
            Q(i,j)=1/(2^(j-1)-1) * (2^(j-1)*Q(i,j-1)-Q(i-1,j-1));
        end
    end
    df = Q(n,n);
end

%metoda Richardson modificata pentru calculul derivatei de ordinul 2
function [df2] = MetRichardsonModif(f,x,h,n)
    Q = zeros(n-1, n-1, length(x));  
    for i=1:n
        Q(i,1) = (f(x+h)-2*f(x) + f(x-h)) / (h^2);
    end
    for i=2:n
        for j=2:i
            Q(i,j)=1/(2^(j-1)-1) * (2^(j-1)*Q(i,j-1)-Q(i-1,j-1));
        end
    end
    df2 = Q(n-1,n-1);
end