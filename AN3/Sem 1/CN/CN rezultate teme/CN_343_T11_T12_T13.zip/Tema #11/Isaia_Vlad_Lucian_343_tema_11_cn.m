%% Exercitiul 1
% 8/10.
close all;

% b)
f = @(x) sin(x);

a = 0;
b = pi;
m = 100;
h = (b-a) / (m-1);

xs = zeros(1, m+2);

xs(2:m+1) = linspace(a, b, m);
xs(1) = xs(2) - h;
xs(end) = xs(end-1) - h;

y = f(xs);
tip_diferente = 'diferente finite centrale';
dy = DerivNum(xs, y, tip_diferente);

syms x;
df = matlabFunction(diff(f, x));

figure(1);
plot(xs(2:end-1), df(xs(2:end-1)), 'r', 'LineWidth', 2);
hold on;
title(['{\color{blue}df(x) = cos(x);','\color{red}df(x) = cos(x), calculata numeric cu ' ++ tip_diferente ++ ';}'],'interpreter','tex');
plot(xs(2:end-1), dy, 'b', 'LineWidth', 1);

% c)
figure(2);
df_y = df(xs(2:end-1));
plot(xs(2:end-1), abs(df_y - dy));
title(['Diferenta in modul dintre derivata calculata numeric cu ' ++ tip_diferente ++ ' si cea exacta']);

%% Exercitiul 2
% b)
close all;
a = 0;
b = pi;
f = @(x_) sin(x_);
n = [4, 6, 8];

len_n = length(n);

x = linspace(a, b, 100);
Y = cell(len_n, 1);

h = 0.1;

syms x_;
df = matlabFunction(diff(f, x_));

for i = 1:len_n
    Y(i) = { MetRichardson(f, x, h, n(i)) };
    figure;
    plot(x, df(x), 'LineWidth', 2);
    hold on;
    plot(x, Y{i}, 'LineWidth', 1);
    title(['{\color{blue}df(x) = cos(x);',...
        '\color{red}df(x) = cos(x), calculata numeric cu Metoda Richardson pentru n = ' ++ num2str(n(i)) ++ ';}'],'interpreter','tex');
end

% c)
for i = 1:len_n
    figure;
    plot(x, abs(Y{i} - df(x)));
    title(['Diferenta in modul intre derivata exacata si cea calculata numeric cu  Metoda Richardson pentru n = ' ++ num2str(n(i))]);
end

% d)
Y2 = cell(len_n, 1);
d2f = matlabFunction(diff(df, x_));

for i = 1:len_n
    Y2(i) = { MetRichardson2(f, x, h, n(i)-1) };
end

% e)
for i = 1:len_n
    figure;
    plot(x, d2f(x), 'LineWidth', 2);
    hold on;
    plot(x, Y2{i}, 'LineWidth', 1);
    title(['{\color{blue}ddf(x) = -sin(x);',...
        '\color{red}ddf(x) = -sin(x), calculata numeric cu Metoda Richardson pentru n = ' ++ num2str(n(i)) ++ ';}'],'interpreter','tex');
end
%% Functii ajutatoare
function [dy] = DerivNum(x, y, metoda)

    m = length(x)-1;

    dy = zeros(1, m);

    switch lower(metoda)
        case 'diferente finite progresive'
            for i = 2:m
                dy(i) = (y(i+1)-y(i))/(x(i+1)-x(i));
            end
        case 'diferente finite regresive'
            for i = 2:m
                dy(i) = (y(i) - y(i-1)) / (x(i) - x(i-1));
            end
        case 'diferente finite centrale'
            for i = 2:m
                dy(i) = (y(i+1) - y(i-1)) / (x(i+1) - x(i-1));
            end
        otherwise
            error('Metoda aleasa nu este cunoscuta sau exista un typo');
    end
    
    dy = dy(2:m);
end

function [df] = MetRichardson(f, x, h, n)
    theta = @(x, h) (f(x + h) - f(x)) ./ h;

    Q = zeros(n, n, length(x));
    
    for i = 1 : n
        Q(i, 1, :) = theta(x, h / 2^(i-1));
    end
    
    for i = 2 : n
        for j = 2 : i
            Q(i, j, :) = Q(i, j-1, :) + 1/(2^(j-1) - 1) .* (Q(i, j-1, :) - Q(i-1, j-1, :));
        end
    end
    
    df = reshape(Q(n, n, :),[1 length(Q(n, n, :))]);
end

function [d2f] = MetRichardson2(f, x, h, n)
    theta = @(x, h) (f(x + h) - 2*f(x) + f(x-h)) ./ h^2;

    Q = zeros(n, n, length(x));
    
    for i = 1 : n
        Q(i, 1, :) = theta(x, h / 2^(i-1));
    end
    
    for i = 2 : n
        for j = 2 : i
            Q(i, j, :) = Q(i, j-1, :) + 1/(2^(j-1) - 1) .* (Q(i, j-1, :) - Q(i-1, j-1, :));
        end
    end
    
    d2f = reshape(Q(n, n, :),[1 length(Q(n, n, :))]);
end