%

%%

% ========================== EXERCITIUL 1 =================================

f = @(x) sin(x);
a = 0;
b = pi;
m = 100;
x = linspace(a,b,m+2);
y = f(x);

syms w;
df = matlabFunction(diff(f(w)));

metode = ["diferente finite progresive","diferente finite regresive",...
            "diferente finite centrale"];
        
for i = 1:length(metode)

    dy = DerivNum(x,y,metode(i));

    figure(2*i-1);
    plot(x(2:m+1),dy,'k');
    hold on
    plot(x(2:m+1),df(x(2:m+1)),'b-.');
    
    title(strcat('Metoda: ',metode(i)));
    
    ylim([df(b) df(a)]);
    xlim([a,b]);
    
    legend({'Derivata functiei f','Rezultatul aplicarii metodei'},...
            'Location','East');
        
    figure(2*i);
    
    plot(x(2:m+1),abs(dy - df(x(2:m+1))));
    
    title(strcat('Eroarea metodei: ',metode(i)));

end

%%

% ======================= EXERCITIUL 2 ====================================

a = 0;
b = pi;
f = @(x) sin(x);
n = [4,6,8];

psi1 = @(x,h) (f(x + h) - f(x)) / h;
psi2 = @(x,h) (f(x + h) - 2 * f(x) + f(x - h))/(h^2);

x = linspace(a,b);

syms w
fd = matlabFunction(diff(f(w)));
fdd = matlabFunction(diff(fd(w)));

y = fd(x);

for i = 1:length(n)
    df = zeros(1,length(x));
    ddf = zeros(1,length(x));
    
    for j = 1:length(x)
        df(j) = MetRichardson(psi1,x(j),x(2) - x(1),n(i)); 
        ddf(j) = MetRichardson(psi2,x(j),x(2) - x(1),n(i)-1);
    end
    

    figure(3 * i - 2);
    plot(x,fd(x),'k');
    hold on
    plot(x,df,'g-.');

    title(strcat('Metoda Richardson pentru n = ',int2str(n(i))));
    
    legend({'Aproximarea derivatei','Derivata'},'Location','North');
    
    ylim([min(fd(a),fd(b)) max(fd(a),fd(b))]);
    xlim([a,b]);
    
    figure(3 * i - 1)
    
    plot(x,abs(df - fd(x)));
    
    title(strcat('Eroarea pentru n = ',int2str(n(i))));
    
    figure(3*i)
    
    plot(x,fdd(x),'k');
    hold on
    plot(x,ddf,'g-.');
    
    title(strcat('Metoda Richardson pentru derivata de ordin 2 cu n = ',...
        int2str(n(i))));
    
    legend({'Aproximarea derivatei','Derivata'},'Location','East');
end



function [df] = MetRichardson(func,x,h,n)
    Q = zeros(n,n);
    
    for i = 1:n
       Q(i,1) = func(x,h/(2^(i-1))); 
    end
    
    for i = 2:n
        for j = 2:i
            Q(i,j) = Q(i,j-1) + (Q(i,j-1) - Q(i-1,j-1)) / (2 ^(j-1) - 1); 
        end
    end
    
    df = Q(n,n);

end







function [dy] = DerivNum(x,y,metoda)
    dy = zeros(1,length(x) - 2);
    m = length(x) - 1;
    switch metoda
        case 'diferente finite progresive'
            for i = 2:m
                dy(i-1) = (y(i+1) - y(i))/(x(i+1) - x(i));
            end
        case 'diferente finite regresive'
            for i = 2:m
                dy(i-1) = (y(i) - y(i-1))/(x(i) - x(i-1));
            end
        case 'diferente finite centrale'
            for i = 2:m
                dy(i-1) = (y(i+1) - y(i-1))/(x(i+1) - x(i-1));
            end
        otherwise
            disp('Metoda necunoscuta');
    end
end






