% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'x'       = reprezinta discretizarea
% 'y'       = reprezinta valorile functiei f in x
% 'metoda'  = metoda cu care se calculeaza dy ('diferente finite progresive'
%           = 'diferente finite regresive' sau 'diferente finite centrale'
% -------------------------------------------------------------------------
% Date de iesire:
% 'df'      = valoarea functiei spline patratica S(x)
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [dy] = DerivNum(x, y, metoda)
    m = numel(y) - 1;
    dy = zeros(1, m - 1);

    switch metoda
        case 'diferente finite progresive'
            for i = 2 : m
                dy(i - 1) = (y(i + 1) - y(i)) / (x(i + 1) - x(i));
            end
        case 'diferente finite regresive'
            for i = 2 : m
                dy(i - 1) = (y(i) - y(i - 1)) / (x(i) - x(i - 1));
            end
        case 'diferente finite centrale'
            for i = 2 : m
                dy(i - 1) = (y(i + 1) - y(i - 1)) / (x(i + 1) - x(i - 1));
            end
    end
end
