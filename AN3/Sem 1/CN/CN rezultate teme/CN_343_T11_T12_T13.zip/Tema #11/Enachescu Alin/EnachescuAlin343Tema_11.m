% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Rezolv exercitiile 1 si 2
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================
% 10/10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% exercitiul 1                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f  = @(x) sin(x);
df = @(x) cos(x);
a = 0;
b = pi;
m = 100;
x = linspace(a, b, m);
y = f(x);
metoda = [
    'diferente finite progresive';
    'diferente finite regresive ';
    'diferente finite centrale  '
];

dy1 = DerivNum(x, y, metoda(1, :));
dy2 = DerivNum(x, y, metoda(2, 1 : end - 1));
dy3 = DerivNum(x, y, metoda(3, 1 : end - 2));
dy  = df(x);
tx  = x(1 : end - 2);

% punctul b
figure(1)
hold on
xlabel('x')
ylabel('y')
plot(x, dy, 'k', 'LineWidth', 3);
plot(tx, dy1, 'r--');
plot(tx, dy2, 'g--');
plot(tx, dy3, 'b--');
legend('f', metoda(1, :), metoda(2, :), metoda(3, :));

% punctul c
figure(2)
hold on
xlabel('x')
ylabel('y')
plot(tx, abs(dy(1 : end - 2) - dy1), 'r--');
plot(tx, abs(dy(1 : end - 2) - dy2), 'g--');
plot(tx, abs(dy(1 : end - 2) - dy3), 'b--');
legend(metoda(1, :), metoda(2, :), metoda(3, :));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% exercitiul 2                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

phi1 = @(f, x, h) ((f(x + h) - f(x)) / h);
phi2 = @(f, x, h) ((f(x + h) - 2 * f(x) + f(x - h)) / (h^2));
a = 0;
b = pi;
f   = @(x) (sin(x));
df  = @(x) (cos(x));
d2f = @(x) (-sin(x));
n = 4
m = 100;
h = 0.1;
x = linspace(a, b, m);
y = zeros(1, m);

for j = 1 : m
    y(j) = MetRichardson(f, x(j), h, n, phi1);
end

% punctul b
figure(3)
hold on
xlabel('x')
ylabel('y')
plot(x, df(x), 'k', 'LineWidth', 3);
plot(x, y, '--r', 'LineWidth', 3);
legend('df(x)', 'MetRichardson');

% punctul c
figure(4)
hold on
xlabel('x')
ylabel('y')
plot(x, abs(y - dy), 'r--');

% punctul d
y = zeros(1, m);
for j = 1 : m
    y(j) = MetRichardson(f, x(j), h, n - 1, phi2);
end

% punctul e
figure(5)
hold on
xlabel('x')
ylabel('y')
plot(x, d2f(x), 'k', 'LineWidth', 3);
plot(x, y, '--r', 'LineWidth', 3);
legend('d2f(x)', 'MetRichardson');
