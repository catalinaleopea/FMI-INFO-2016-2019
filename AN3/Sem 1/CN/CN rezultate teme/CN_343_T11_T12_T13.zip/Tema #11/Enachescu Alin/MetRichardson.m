% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = functia pentru care se aproximeaza derivata
% 'x'       = punctul in care se aproximeaza derivata
% 'h'       = 
% 'n'       = 
% 'phi'     = 
% -------------------------------------------------------------------------
% Date de iesire:
% 'df'      = valoarea aproximata a derivatei in punctul x
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [df] = MetRichardson(f, x, h, n, phi)
    q = zeros(n);

    for i = 1 : n
        q(i, 1) = phi(f, x, h / (2^(i - 1)));
    end

    for i = 2 : n
        for j = 2 : i
            q(i, j) = q(i, j - 1) + (q(i, j - 1) - q(i - 1, j - 1)) / (2^(j - 1) - 1);
        end
    end

    df = q(n, n);
end
