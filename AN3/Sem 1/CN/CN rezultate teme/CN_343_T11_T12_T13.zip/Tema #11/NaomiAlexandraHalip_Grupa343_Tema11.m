% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 11
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2019
% =========================================================================
% 10*/10 -> Cu mentiunea ca la ex.1 mai trebuie lucrat putin.

%% Ai considerat si capetele discretizarii in grafice, ceea ce a condus la 
% balarii in grafice! Mai multa atentie, te rog! 
% Ex. 1
% b)

f = @(x) sin(x);
a = 0;
b = pi;
m = 100;
xs = zeros(1,m+1);
h = (b-a)/(m-1);
xs(2:100) = linspace(a,b,m-1); % discretizare interval 
xs(1) = xs(2)-h;
xs(end) = xs(end-1) +h;
y = f(xs);


% calculul derivatei cu ajutorul metodelor numerice
% metoda 'diferente finite progresive'
dfp = DerivNum(xs,y,'diferente finite progresive');

% metoda 'diferente finite regresive'
dfr = DerivNum(xs,y,'diferente finite regresive');

% metoda 'diferente finite centrale'
dfc = DerivNum(xs,y,'diferente finite centrale');

% calcul derivata functie cu ajutorul metodei predefinite 'diff'
syms x
df = matlabFunction(diff(f(x)));
z = df(xs); % valorile derivatei functiei f in nodurile de interpolare

figure(1);
plot(xs,z,'-r'); % derivata functiei f
hold on
grid on
plot(xs(2:end),dfp,'--b'); % derivata numerica calculata cu metoda 'diferente 
% finite progresive'
xlim([0 3]);
ylim([-1 1]);
legend('derivata functiei f', 'derivata numerica calculata cu diferente finite progresive');

figure(2);
plot(xs,z,'-r'); % derivata functiei f
hold on
grid on
plot(xs(2:end),dfr,'--b'); % derivata numerica calculata cu metoda 'diferente 
% finite regresive'
xlim([0 3]);
ylim([-1 1]);
legend('derivata functiei f', 'derivata numerica calculata cu diferente finite regresive');

figure(3);
plot(xs,z,'-r'); % derivata functiei f
hold on
grid on
plot(xs(2:end),dfc,'--b'); % derivata numerica calculata cu metoda 'diferente 
% finite centrale'
xlim([0 3]);
ylim([-1 1]);
legend('derivata functiei f', 'derivata numerica calculata cu diferente finite centrale');

% Ex. 1
% c)
% eroarea dintre derivata exacta si derivata numerica

% derivata numerica calculata cu metoda 'diferente finite progresive'
figure(4);
plot(xs(2:end),abs(df(xs(2:end))-dfp));
hold on
grid on
xlim([0 3]);
ylim([-1 1]);
legend('eroarea dintre derivata exacta si derivata numerica calculata cu diferente finite progresive');

% derivata numerica calculata cu metoda 'diferente finite progresive'
figure(5);
plot(xs(2:end),abs(df(xs(2:end))-dfr));
hold on
grid on
xlim([0 3]);
ylim([-1 1]);
legend('eroarea dintre derivata exacta si derivata numerica calculata cu diferente finite regresive');

% derivata numerica calculata cu metoda 'diferente finite progresive'
figure(6);
plot(xs(2:end),abs(df(xs(2:end))-dfc));
hold on
grid on
xlim([0 3]);
ylim([-1 1]);
legend('eroarea dintre derivata exacta si derivata numerica calculata cu diferente finite centrale');
%%


%%
% Ex. 2
% b)
f = @(x) sin(x);
a = 0;
b = pi;
m = 100;
xs1 = linspace(a,b,100); % discretizarea intervalului [a,b] in 100 de noduri
h = (b-a)/(m-1);
y = f(xs1);

% pentru n = 4
n = 4;
for i = 1:100
    dfmr(i) = MetRichardson(f,xs1(i),h,n);
end
syms x
df1 = matlabFunction(diff(f(x))); % derivata functiei f
z = df1(xs1);

figure(7);
plot(xs1,z,'-r'); % derivata functiei f
hold on
grid on

plot(xs1,dfmr,'--b');% derivata aproximativa in baza procedurii MetRichardson
legend('derivata functiei f', 'derivata aproximativa in baza procedurii MetRichardson pentru n = 4');

%pentru n = 6
n = 6;
for i = 1:100
    dfmr(i) = MetRichardson(f,xs1(i),h,n);
end

figure(8);
plot(xs1,z,'-r'); % derivata functiei f
hold on
grid on

plot(xs1,dfmr,'--b');% derivata aproximativa in baza procedurii MetRichardson
legend('derivata functiei f', 'derivata aproximativa in baza procedurii MetRichardson pentru n = 6');

% pentru n = 8
n = 8;
for i = 1:100
    dfmr(i) = MetRichardson(f,xs1(i),h,n);
end

figure(9);
plot(xs1,z,'-r'); % derivata functiei f
hold on
grid on

plot(xs1,dfmr,'--b');% derivata aproximativa in baza procedurii MetRichardson
legend('derivata functiei f', 'derivata aproximativa in baza procedurii MetRichardson pentru n = 8');

% Ex. 2
% c)
% eroarea dintre derivata functiei f si derivata aproximativa calculata in
% baza MetRichardson
figure(10);
plot(xs1,abs(df1(xs1)-dfmr));
hold on
grid on
xlim([0 3]);
ylim([-1 1]);
legend('eroarea dintre derivata functiei f si derivata aproximativa calculata in baza MetRichardson');

% d)
n = 4;
for i = 1:100
    d2f(i) = MetRichardson2(f,xs1(i),h,n-1); %derivata a 2-a calculata cu 
    % MetRichardson
end

% e)
syms x
dff = matlabFunction(diff(df1(x))); % derivata a 2-a a functiei f
t = dff(xs1);

figure(11);
plot(xs1,t,'-r'); % derivata a 2-a a functiei f
hold on;
grid on;
plot(xs1,d2f,'--b');% derivata aproximativa in baza procedurii MetRichardson
legend('derivata a 2-a a functiei f', 'derivata a 2-a aproximativa in baza procedurii MetRichardson');
hold off;
%%

%%
% Ex. 1
% a) DerivNum
% -------------------------------------------------------------------------
% Date de intrare:
% 'x' = matrice reprezantand discretizarea
% 'y' = matrice reprezentand valorile 
% 'metoda' = sir de caractere, reprezentand metoda ce urmeaza a fi aplicata
% -------------------------------------------------------------------------
% Date de iesire:
% 'dy' = derivata numerica calculata conform algoritmului
% -------------------------------------------------------------------------

function [dy] = DerivNum(x,y,metoda)
    n1 = size(x);
    m = n1(2) - 1;
    
    switch metoda
        case 'diferente finite progresive'
            for i = 2:m
                dy(i) = (y(i+1) - y(i))/(x(i+1) - x(i));
            end
        case 'diferente finite regresive'
            for i = 2:m
                dy(i) = (y(i) - y(i-1))/(x(i) - x(i-1));
            end
        case 'diferente finite centrale'
            for i = 2:m
                dy(i) = (y(i+1) - y(i-1))/(x(i+1) - x(i-1));
            end
    end
end
%%

%%
% Ex. 2
% a) MetRichardson
% -------------------------------------------------------------------------
% Date de intrare:
% 'f' = functie
% 'x' = matrice reprezantand discretizarea
% 'h' = 
% 'n' = 
% -------------------------------------------------------------------------
% Date de iesire:
% 'df' = derivata aproximativa calculata in baza MetRichardson
% -------------------------------------------------------------------------
function [df] = MetRichardson(f,x,h,n)
    Q = zeros(n);
    fi = @(x,h)((f(x+h)-f(x))/h);
    for i = 1:n
        Q(i,1) = fi(x,h/(2^(i-1)));
    end
    for i = 1:n
        for j = 2:i
            Q(i,j) = Q(i,j-1) + (1/(2^(j-1)-1))*(Q(i,j-1)-Q(i-1,j-1));
        end
    end
    df = Q(n,n);
end
%%

%%
% Ex. 2
% d) MetRichardson2
% -------------------------------------------------------------------------
% Date de intrare:
% 'f' = functie
% 'x' = matrice reprezantand discretizarea
% 'h' = scalar
% 'n' = scalar
% -------------------------------------------------------------------------
% Date de iesire:
% 'df' = derivata aproximativa calculata in baza MetRichardson
% -------------------------------------------------------------------------
function [df] = MetRichardson2(f,x,h,n)
    Q = zeros(n);
    fi = @(x,h)((f(x+h)-2*f(x)+f(x-h))/(h^2));
    for i = 1:n
        Q(i,1) = fi(x,h/(2^(i-1)));
    end
    for i = 1:n
        for j = 2:i
            Q(i,j) = Q(i,j-1) + (1/(2^(j-1)-1))*(Q(i,j-1)-Q(i-1,j-1));
        end
    end
    df = Q(n,n);
end
%%