% -------------------------------------------------------------------------
% Author: David Pacioianu, 2019
% -------------------------------------------------------------------------
%% Ex 1
f = @sin;
df = @cos;
X = linspace(0, pi, 100);
Y = arrayfun(f, X);

[dy1] = derivNum(X, Y, 'diferente finite progresive'); 
[dy2] = derivNum(X, Y, 'diferente finite regresive'); 
[dy3] = derivNum(X, Y, 'diferente finite centrale'); 
dx = X(2:end-1);
dy = arrayfun(df, dx);

% 1.b
figure(1)
hold on
plot(dx, dy);
plot(dx, dy1, '--');
plot(dx, dy2, '-.');
plot(dx, dy3, ':');
legend({...
    'derivata exacta',...
    'diferente finite progresive',...
    'diferente finite regresive',...
    'diferente finite centrale'...
 },'Location','southwest')
hold off

% 1.c
figure(2)
hold on
subplot(3,1,1);
plot(dx, abs(dy-dy1))
title('Eroare - diferente finite progresive')
subplot(3,1,2);
plot(dx, abs(dy-dy2))
title('Eroare - diferente finite regresive')
subplot(3,1,3);
plot(dx, abs(dy-dy3))
title('Eroare - diferente finite centrale')
hold off

%% Ex2
f = @sin;
d1f = @cos;
d2f = @(x) -sin(x);

fi1 = @(x,h) (f(x+h) - f(x)) / h; 
fi2 = @(x,h) (f(x+h) + f(x-h) - 2*f(x)) / h^2; 
a = 0;
b = pi;
m = 100;
h = (b-a) / (m-1);
X = linspace(a, b, m);

df = arrayfun(d1f, X);
for i = 1:m
    df4(i) = metRichardson(f, X(i), h, 4, fi1);  
    df6(i) = metRichardson(f, X(i), h, 6, fi1);  
    df8(i) = metRichardson(f, X(i), h, 8, fi1); 
end

% 2.b
figure(3)
hold on
plot(X, df);
plot(X, df4, '--');
plot(X, df6, '-.');
plot(X, df8, ':');
legend({...
    'Derivata de ordinul 1',...
    'Richardson n=4',...
    'Richardson n=6',...
    'Richardson n=8',...
 },'Location','southwest')
hold off

% 2.c
figure(4)
hold on
subplot(3,1,1);
plot(X, abs(df-df4))
title('Eroare - Richardson n=4')
subplot(3,1,2);
plot(X, abs(df-df6))
title('Eroare - Richardson n=6')
subplot(3,1,3);
plot(X, abs(df-df8))
title('Eroare - Richardson n=8')
hold off

% 2.d
ddf = arrayfun(d2f, X);
for i = 1:length(X)
    ddf4(i) = metRichardson(f, X(i), h, 3, fi2);  
    ddf6(i) = metRichardson(f, X(i), h, 5, fi2);  
    ddf8(i) = metRichardson(f, X(i), h, 7, fi2); 
end

% 2.e
figure(5)
hold on
plot(X, ddf)
plot(X, ddf4, '--')
plot(X, ddf6, '-.')
plot(X, ddf8, ':')
legend({...
    'Derivata de ordinul 2',...
    'Richardson n=4',...
    'Richardson n=6',...
    'Richardson n=8',...
 },'Location','southwest')
hold off

%% functions
function [dY] = derivNum(X, Y, metoda) 
    m = length(X) - 1;
    i = 2:m;
    dY = zeros(1, m);
    switch lower(metoda)
        case 'diferente finite progresive'
            dY(i) = (Y(i+1) - Y(i)) ./ (X(i+1) - X(i));
        case 'diferente finite regresive'
            dY(i) = (Y(i) - Y(i-1)) ./ (X(i) - X(i-1));
        case 'diferente finite centrale'
            dY(i) = (Y(i+1) - Y(i-1)) ./ (X(i+1) - X(i-1));
    end
    dY = dY(2:end);
end

function [df] = metRichardson(f, x, h, n, fi)
    Q = ones(n,n);
    for i = 1:n
        Q(i, 1) = fi(x, h/(2^(i-1)));
    end 
    
    for i = 2:n
        for j = 2:n
            Q(i,j) = Q(i,j-1) + (Q(i,j-1)-Q(i-1,j-1)) / (2^(j-1)-1);
        end
    end
    df = Q(n,n);
end