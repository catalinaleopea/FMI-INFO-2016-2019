%% Exercitiul 1: 
f=@(x)sin(x); 
fDerivat=@(x)cos(x);
a=0;  
a=a-(pi/100); 
b=pi;  
b=b+(pi/100);
m=100; 
x=linspace(a, b, 100); 
y=f(x);  

%diferente finite progresive

metoda='diferente finite progresive';
dy=DerivNum(x,y,metoda);  

x=x(2:length(x)-1); 
dy=dy(2:length(dy));

figure(1); 
title('Diferente finite progresive')
hold on;
plot(x,dy,'b');
plot(x,fDerivat(x),'r');   

figure(4); 
title('Diferente finite progresive - eroare')
hold on;
plot(x,abs(dy-fDerivat(x)),'b');

 
%diferente finite regresive
x=linspace(a, b, 100); 
y=f(x); 
metoda='diferente finite regresive';
dy=DerivNum(x,y,metoda);  

x=x(2:length(x)-1); 
dy=dy(2:length(dy));

figure(2); 
title('diferente finite regresive')
hold on;
plot(x,dy,'b');
plot(x,fDerivat(x),'r');   

figure(5); 
title('diferente finite regresive - eroare')
hold on;
plot(x,abs(dy-fDerivat(x)),'b');

%diferente finite centrale

x=linspace(a, b, 100); 
y=f(x); 
metoda='diferente finite centrale';
dy=DerivNum(x,y,metoda);  

x=x(2:length(x)-1); 
dy=dy(2:length(dy));

figure(3); 
title('diferente finite centrale')
hold on;
plot(x,dy,'b');
plot(x,fDerivat(x),'r');  

figure(6); 
title('diferente finite centrale - eroare')
hold on;
plot(x,abs(dy-fDerivat(x)),'b');

%% Exercitiul 2: 

f=@(x)sin(x); 
fDerivat=@(x)cos(x);
a=0;  
b=pi;  
m=100; 
x=linspace(a, b, 100);  
N=[4,6,8]; 
for j=1:3
    for i=1:m 
        df(i)=MetRichardson(f,x(i),0.1,N(j)); 
    end  
    figure(10+j); 
    title('Richardson')
    hold on;
    plot(x,df,'b');
    plot(x,fDerivat(x),'r'); 
    
    figure(20+j); 
    title('Richardson - eroare')
    hold on;
    plot(x,abs(df-fDerivat(x)),'b');
end





f2d=@(x)(-sin(x)); 

for i=1:m 
        d2f(i)=MetRichardson2(f,x(i),0.1,4); 
end
figure(52);
title('Richardson 2')
hold on;
plot(x,d2f,'b');
plot(x,f2d(x),'r');   

figure(55); 
title('Richardson 2 - eroare')
hold on;
plot(x,abs(d2f-f2d(x)),'b');

    




function dy = DerivNum(x,y,metoda)  
m=length(x)-1;  
switch metoda 
    case 'diferente finite progresive' 
        for i=2:m 
            dy(i)=(y(i+1)-y(i))/(x(i+1)-x(i)); 
        end
    case 'diferente finite regresive' 
        for i=2:m 
            dy(i)=(y(i)-y(i-1))/(x(i)-x(i-1));
        end 
    case 'diferente finite centrale' 
        for i=2:m  
            dy(i)=(y(i+1)-y(i-1))/(x(i+1)-x(i-1));
        end
end 
end 


function df = MetRichardson(f,x,h,n)  
o=@(x,h)(f(x+h)-f(x))/h; 
for i=1:n 
    Q(i,1)=o(x,h/2^(i-1)); 
end 
for i=2:n 
    for j=2:i 
        Q(i,j)= Q(i,j-1)+(1/2^(j-1)-1)*(Q(i,j-1)-Q(i-1,j-1));
    end 
end 
df=Q(n,n);
end 

function d2f = MetRichardson2(f,x,h,n)  
o=@(x,h)(f(x+h)-2*f(x)+f(x-h))/h^2;  
n=n-1;
for i=1:n 
    Q(i,1)=o(x,h/2^(i-1)); 
end 
for i=2:n 
    for j=2:i 
        Q(i,j)= Q(i,j-1)+(1/2^(j-1)-1)*(Q(i,j-1)-Q(i-1,j-1));
    end 
end 
d2f=Q(n,n);
end
