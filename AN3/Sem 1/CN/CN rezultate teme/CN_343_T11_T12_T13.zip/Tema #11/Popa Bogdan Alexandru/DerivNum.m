% Am implementat algoritmul urmarind indicatiile din cerinta si aplicand
% metodele prezentate in cursul 11 incepand cu pag.2. Datele de intrare
% sunt x, discretizarea x1-xm+1, y reprezentand valoarea functiei in x,
% metoda un sir de caractere care reprezinta metoda folosita pentru
% derivare. La iesire avem dy derivata functiei sub forma de vector de
% puncte.
function [ dy ] = DerivNum( x, y, metoda )

m = length(x)-1; % pastream lungimea lui x
dy = zeros(1,m-1); % prealocam vectorul solutie

% folosind indicatia din cerinta oferim optiuni de rezolvare print-un
% switch
switch lower(metoda)
	case 'diferente finite progresive'
		for i = 2:m
			dy(i-1) = (y(i+1)-y(i))/(x(i+1)-x(i));
		end
	case 'diferente finite regresive'
		for i = 2:m
			dy(i-1) = (y(i)-y(i-1))/(x(i)-x(i-1));
		end
	case 'diferente finite centrale'
		for i = 2:m
			dy(i-1) = (y(i+1)-y(i-1))/(x(i+1)-x(i-1));
		end
    otherwise % in orice alt caz intoarcem o eroare
		error('metoda aleasa nu este cunoscuta/typo');


end

