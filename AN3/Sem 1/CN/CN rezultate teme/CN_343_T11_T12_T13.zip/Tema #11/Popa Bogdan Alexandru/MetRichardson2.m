% Am implementat MetRichardson urmarind algoritmul din cursul 11 de la
% pag.15.Avem ca date de intrare functia f pe care realizam aproximarea,
% diviziunea x,termenul h si nodurile n. La iesire avem derivata
% aproximata.
function [d2f] = MetRichardson2(f,x,h,n)
n = n-1; % conform indicatiei din tema
o = @(x,h) ((f(x+h)-2*f(x)+f(x-h))/h^2); % am definit functia o conform cerintei
Q = zeros(n); % prealocam Q
for i=1:n % calculam prima coloana a lui Q
    Q(i,1)=o(x,h/(2^(i-1)));
end

for i=2:n % calculam Q conform algoritmului
    for j=2:i
        Q(i,j)=Q(i,j-1)+(1/(2^(j-1)-1))*(Q(i,j-1)-Q(i-1,j-1));
    end
end
d2f = Q(n,n); % intoarcem aproximarea
end

