% Tema 11
% Ex 1
% a)
% A fost rezolvat si se regaseste in fisierul DerivNum.m

% b)
f = @(x) sin(x); % declaram functia folosita
a = 0; b = pi; % intervalul pe care studiem functia f
m = 100; % numarul de puncte din care este conceputa diviziunea 
% pregatim punctele diviziunii folosite de functia f
h = (b-a)/(m-1); 
xs = zeros(1,m+2);
xs(2:101) = linspace(a,b,m);
xs(1)     = xs(2)-h;
xs(end)   = xs(end-1)+h;
n = {'diferente finite progresive','diferente finite regresive',...
    'diferente finite centrale'}; % cazurile derivatei numerice
y = f(xs); % pastram rezultatul functiei in punctele din xs
syms x; % folosim un numar simbolic
df = matlabFunction(diff(f,x)); % pastram functia de derivare
for i=1:length(n) % tratam toate cazurile
    dy = DerivNum(xs,y,n{i}); % aplicam DerivNum

    figure;
    % afisam in grafic comparatia celor 2 derivate
    plot(xs(2:end-1), df(xs(2:end-1)),'r','LineWidth',2); % derivata exacta
    hold on;
    grid on;
    t=linspace(a,b,m); % diviziunea folosita pentru calculul derivatei
    plot(t,dy,'b--'); % afisarea derivatei prin DerivNum
    legend('df','df Numeric');
    title(['Comparatie derivata exacta si cea numerica ' n{i}]);
    hold off;
    
    % c)
    figure;
    plot(t,abs(df(xs(2:end-1))-dy),'b-'); % afisam eroarea
    title(['Eroarea derivatei numerice ' n{i}]);
    hold on; grid on;
end


% Ex 2
% a)
% A fost rezolvat si se regaseste in fisierul MetRichardson.m

% b) 
a = 0; b=pi; % declaram intervalul functiei
m = 100; % nodurile diviziunii
f = @(x) sin(x); % functia studiata
% pregatim punctele diviziunii folosite de functia f
h = (b-a)/(m-1); 
xs = zeros(1,m+2);
xs(2:101) = linspace(a,b,m);
xs(1)     = xs(2)-h;
xs(end)   = xs(end-1)+h; 
y = f(xs); % pastram valoarea functiei in xs
n = [4,6,8]; % n pentru MetRichardson
syms x; % folosim un numar simbolic
df = matlabFunction(diff(f,x)); % pastram functia de derivare
dy = zeros (1,m); % prealocam dy
for i=1:length(n) % tratam toate cazurile
    for j=1:m % aplicam MetRichardson pe toate nodurile
        dy(j) = MetRichardson(f,xs(j),h,n(i)); 
    end
    figure;
    % afisam in grafic comparatia celor 2 derivate
    plot(xs(2:end-1), df(xs(2:end-1)),'r','LineWidth',2); % derivata exacta
    hold on;
    grid on;
    t=linspace(a,b,m); % diviziunea folosita pentru calculul derivatei
    plot(t,dy,'b--'); % afisarea derivatei prin MetRichardson
    legend('df','df MR');
    title(['Comparatie derivata exacta si cea prin MetRichardson n=' num2str(n(i))]);
    hold off;
    
    % c)
    figure;
    plot(t,abs(df(xs(2:end-1))-dy),'b-'); % afisam eroarea
    title(['Eroarea derivatei numerice n=' num2str(n(i))]);
    hold on; grid on;
end

% d)
% A fost rezolvat si se regaseste in fisierul MetRichardson2

% e)
df = matlabFunction(diff(diff(f,x))); % pastram functia de derivare
for i=1:length(n) % tratam toate cazurile
    for j=1:m % aplicam MetRichardson pe toate nodurile
        dy(j) = MetRichardson2(f,xs(j),h,n(i)); 
    end
    figure;
    % afisam in grafic comparatia celor 2 derivate
    plot(xs(2:end-1), df(xs(2:end-1)),'r','LineWidth',2); % derivata exacta
    hold on;
    grid on;
    t=linspace(a,b,m); % diviziunea folosita pentru calculul derivatei
    plot(t,dy,'b--'); % afisarea derivatei prin MetRichardson2
    legend('df','df MR2');
    title(['Comparatie derivata exacta si cea prin MetRichardson n=' num2str(n(i))]);
    hold off;
end

