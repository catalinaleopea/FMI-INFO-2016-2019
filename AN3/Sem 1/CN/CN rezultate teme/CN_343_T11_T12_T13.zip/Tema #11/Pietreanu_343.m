%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMA 11                                                                 %
% - Madalina Pietreanu, grupa 343                                         %
% - acest fisier reprezinta implementarile anumitor exercitii din tema 11 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 7/10
%% %%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ai considerat si capetele intervalului si de aceea ai obtinut balarii la
% extremitati. In rest, ok!

% b)
syms x;
f = @(x) sin(x); % derivata functiei f
df = matlabFunction(diff(f(x),x)); % derivata lui f

a = 0;
b = pi;
m = 100;
h = (b- a) / (m - 1);

% pregatirea multimii datelor de intrare
X = zeros(1,m+2);
X(2:101) = linspace(a,b,m);
X(1) = X(2) - h;
X(end) = X(end - 1) + h;

y = f(X(2:end-1));
DF = df(X(2:end-1));
dfp = 'diferente finite progresive';
dfr = 'diferente finite regresive';
dfc = 'diferente finite centrale';
DF_DFP = DerivNum(X,y,dfp); 
DF_DFR = DerivNum(X,y,dfr);
DF_DFC = DerivNum(X,y,dfc);

figure(1)
plot(X(2:end-1),y,'-r');
hold on;
plot(X(2:end-1),DF,'-b');
plot(X(2:end-1),DF_DFP,'--g');
plot(X(2:end-1),DF_DFR,'--m');
plot(X(2:end-1),DF_DFC,'--y'); % are cea mai mare precizie
legend('Functia','Derivata functiei','Derivata numerica DFP', ...
    'Derivata numerica DFR','Derivata numerica DFC', ...
    'Location', 'Southwest');
hold off;

% c)
figure(2);
plot(X(2:end-1),abs(DF - DF_DFP));
hold on;
plot(X(2:end-1),abs(DF - DF_DFP));
plot(X(2:end-1),abs(DF - DF_DFP));
legend('Eroare DFP','Eroare DFR','Eroare DFC','Location', 'Southwest');
hold off;

%% EXERCITIUL 2

%% FUNCTII

function dy = DerivNum(x,y,metoda)

    m = length(x) - 2;
    dy = zeros(1,m);
    
    % calculez derivata numerica conform uneia din metodele prezentate la
    % curs si in functie de alegerea utilizatorului
    switch lower(metoda)
        case 'diferente finite progresive'
            for i = 1 : m-1
                dy(i) = (y(i+1) - y(i)) / (x(i+1) - x(i));
            end
        case 'diferente finite regresive'
            for i = 2 : m
                dy(i) = (y(i) - y(i-1)) / (x(i) - x(i-1));
            end
        case 'diferente finite centrale'
            for i = 2 : m-1
                dy(i) = (y(i+1) - y(i-1)) / (x(i+1) - x(i-1));
            end
        otherwise
            error('optiune necunoscuta (verificati textul introdus)');
    end
   
end