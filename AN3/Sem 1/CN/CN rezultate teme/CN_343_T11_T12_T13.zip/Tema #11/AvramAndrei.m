% Avram Andrei-Alexandru, grupa 343, Tema 11


%% Problema 1

a = 0;
b = pi;
m = 100;
x = a:(b-a)/(m-1):b;
y = sin(x);

h = (b-a)/(m-1);
xs = a+h:h:b-h;

figure(1)
hold on
dyp = DerivNum(x,y,'diferente finite progresive');
plot(xs,dyp);
plot(xs,cos(xs));
legend('diferente finite progresive','real');
hold off

figure(2)
hold on
dyr = DerivNum(x,y,'diferente finite regresive');
plot(xs,dyr);
plot(xs,cos(xs));
legend('diferente finite regresive','real');
hold off

figure(3)
hold on
dyc = DerivNum(x,y,'diferente finite centrale');
plot(xs,dyc);
plot(xs,cos(xs));
legend('diferente finite centrale','real');
hold off

figure(4)
Ep = abs(cos(xs) - dyp);
plot(xs,Ep);
title('eroare diferente finite progresive');

figure(5)
Er = abs(cos(xs) - dyr);
plot(xs,Er);
title('eroare diferente finite regresive');

figure(6)
Ec = abs(cos(xs) - dyc);
plot(xs,Ec);
title('eroare diferente finite centrale');

%% Problema 2

a = 0;
b = pi;
f = @sin;
m = 100;
h = (b-a)/(m-1);
x = a:h:b;
df = zeros(1,size(x,2));
for n = [4,6,8]
    %b)
    for i = 1:size(df,2)
        df(i) = MetRichardson(f,x(i),h,n);
    end
    
    figure
    plot(x,df);
    title(strcat('Richardson cu n = ', num2str(n)));
    
    %c)
    figure
    plot(x,abs(cos(x) - df));
    title(strcat('eroare derivata la n = ', num2str(n)));
    
    %d)
    for i = 1:size(df,2)
        df(i) = MetRichardson(f,x(i),h,n-1);
    end
    %e)
    figure
    hold on;
    plot(x,df,'ro');
    plot(x,-sin(x));
    legend('MetRichardson','-sin');
    hold off;
end

%% Functii

function dy = DerivNum(x, y, metoda)

m = size(x,2) - 1;
dy = zeros(1,m-1);

switch metoda
    case 'diferente finite progresive'
        for i = 1:m-1
            dy(i) = ( y(i+2) - y(i+1) )/( x(i+2) - x(i+1) );
        end
    case 'diferente finite regresive'
        for i = 1:m-1
            dy(i) = ( y(i+1) - y(i) )/( x(i+1) - x(i) );
        end
    case 'diferente finite centrale'
        for i = 1:m-1
            dy(i) = ( y(i+2) - y(i) )/( x(i+2) - x(i) );
        end
end

end

function [df] = MetRichardson(f, x, h, n)

Q = zeros(n,n);

if mod(n,2) == 1
    teta = @teta2;
else
    teta = @teta1;
end

for i = 1:n
    Q(i,1) = teta(f, x, h/( 2^(i-1) ) );
end

for i = 2:n
    for j = 2:i
        Q(i,j) = Q(i,j-1) + ( Q(i,j-1) - Q(i-1,j-1) )/( 2^(j-1) - 1 );
    end
end
df = Q(n,n);

end

function t = teta1(f,x,h)

t = (f(x+h) - f(x))/h;

end

function t = teta2(f,x,h)

t = (f(x+h) - 2*f(x) + f(x-h))/(h^2);

end