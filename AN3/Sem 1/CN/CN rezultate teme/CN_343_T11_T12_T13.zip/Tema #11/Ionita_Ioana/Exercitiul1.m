% 1. 8/10 -> neatentie!
% 2. 8/10 -> NU obtii ce trebuie + nu ai legenda la grafice! 
% Total: 8/10 
%Exercitiul 1
f = @(x) sin(x);
a = 0;
b = pi;
m = 100;
h = (b - a) / (m-1);
%xs = zeros(1, m+2);
xs(2:101) = linspace(a, b, m);
xs(1) = xs(2) - h;
xs(end) = xs(end - 1) + h; 
y = f(xs);

dy = DerivNum(xs, y, 'diferente finite progresive');
syms x1;
% f = @(x) sin(x1); Atentie ca iti trebuia si aceasta linie de cod. Functia
% f era definita mai sus pentru x real.
df = matlabFunction(diff(f, x1));
plot(xs(2:end-1), df(xs(2:end-1)), 'r', 'LineWidth', 2);
hold on;
grid on;
t = linspace(a, b, m);
plot(t, dy, 'b', 'LineWidth', 2);
legend('df', 'df numeric');
hold off;
