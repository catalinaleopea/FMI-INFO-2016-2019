%Exercitiul 2
f = @(x) sin(x);
g = @(x) cos(x);
A = 0;
B = 2*pi;
X = linspace(0, pi, 200);
Z = g(X);
T = -f(X);
h = X(2) - X(1);

for i = 1:length(X)
    V1(i) = MetRichardson(f, X(i), h, 32);
    V2(i) = MetRichardson2(f, X(i), h, 3);
end

figure(1);
plot(X, V1, 'r', 'LineWidth', 2);
hold on;
plot(X, abs(Z-V1), 'b', 'LineWidth', 2);
hold off;

figure(2);
plot(X, V2, 'r', 'LineWidth', 2);
hold on;
plot(X, abs(T-V2), 'b', 'LineWidth', 2);