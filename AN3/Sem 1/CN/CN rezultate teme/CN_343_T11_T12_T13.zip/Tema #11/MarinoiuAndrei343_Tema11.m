% 8/10 -> Adauga legenda in figurile afisate.
function MarinoiuAndrei343_Tema11()

%% Exericitul 1
% Subpunctul b)

% Date de intrare

syms x; % Definim x simbolic pentru derivata

% Datele din cerinta
f = @(x) sin(x);
A = 0;
B = pi;
m = 100;

X = linspace(A,B,m); % Atribuim valori lui x
Y = f(X); % Calculam valorile functiei in x

% Calculam derivata functiei si derivata functiei obtinuta numeric
dy = DerivNum(X,Y,"Diferente finite regresive");
df = matlabFunction(diff(f(x),x));

Z1 = df(X);
Z2 = dy;

figure(1); % Construim figura 1

hold on;
plot(X,Z1,'--r'); % Construim graficul pentru derivata exacta

hold on;
% Eliminam ultimele 2 valori din X si ultima valoare din Z2 pentru a putea
%afisa graficul
X(end)=[];
X(end)=[];
Z2(end)=[];
plot(X,Z2,'--b'); % Construim graficul pentru derivata obtinuta numeric
hold off;

figure(2); % Construim figura 2

% Subpunctul b)

% Eliminam ultimele 2 valori din Z1 pentru a putea afisa graficul
Z1(end)=[];
Z1(end)=[];

Z3 = abs(Z1 - Z2);

hold on;
plot(X,Z3,'--g');
hold off;

%% Exercitiul 2

syms x; % Definim x simbolic pentru derivata

% Datele din cerinta
f = @(x) sin(x);
A = 0;
B = pi;
m = 100;
n = 4;
dy = zeros(1,100); % Initializare dy cu 0

X = linspace(A,B,m); % Atribuim valori lui x

% Aplicam metoda de extrapolare Richardson in fiecare nod al discretizarii.
for i = 1:length(X)
    dy(i) = MetRichardson(f,X(i),0.1,n);
end

% Calculam valoarea exacta a derivatei
df = matlabFunction(diff(f(x),x));

Z1 = df(X);
Z2 = dy;

figure(1); % Construim figura 1

hold on;
plot(X,Z1,'--r'); % Construim graficul pentru derivata exacta
hold off;

figure(2); % Construim figura 1
plot(X,Z2,'--b'); % Construim graficul pentru metoda Richardson
hold off;


% Subpunctul c)

% Calculam eroarea pe intervalul dat
E = abs(Z1 - Z2);

figure(3);
plot(X,E,'--b'); % Construim graficul pentru eroarea calculata
hold off;

end

% Functie specifica algoritmului de derivare numerica

% x -> valorile pe care vrem sa i le atribuim functiei
% y -> valorile functiei in x
% metoda -> tipul de metoda pe (este de 3 tipuri)

% Date de iesire :
% rez -> vectorul calculat conform algoritmului

% Algoritmul este implementat dupa pseudocodul aflat in cursul 11,pagina 6.
function [rez] = DerivNum(x,y,metoda)

m = length(x) - 1;
dy = zeros(1,m);

switch metoda
    case "Diferente finite progresive"
        for i = 2:m
            dy(i-1) = (y(i+1) - y(i)) / (x(i+1) - x(i));
        end
    case "Diferente finite regresive"
        for i = 2:m
            dy(i-1) = (y(i) - y(i-1)) / (x(i) - x(i-1));
        end
    case "Diferente finite centrale"
        for i = 2:m
            dy(i-1) = (y(i+1) - y(i-1)) / (x(i+1) - x(i-1));
        end
end

rez = dy;

end

% Functie specifica metodei de extrapolare Richardson

% f -> functie
% x -> valoare pentru care vrem sa calculam derivata
% h,n -> valori pentru a stabili ordinul de aproximare

% Date de iesire :
% df -> sir format din aproximarile derivatei f

%Algoritmul este implementat dupa pseudocodul aflat in cursul 11,pagina 15.
function [df] = MetRichardson(f,x,h,n)

phi = @(x,h) (f(x+h) - f(x)) / h; 
Q = zeros(n);

for i = 1:n
    Q(i,1) = phi(x,h/2^(i-1));
end

for i = 2:n
    for j = 2:i
        Q(i,j) = Q(i,j-1) + (1 / (2^(j-1) - 1) * (Q(i,j-1)-Q(i-1,j-1)));
    end
end

df = Q(n,n);

end