% Giosanu Andrei
% Grupa 343
% 5/10 -> Haos total! Iau la ghici fiecare figura si dau cu banul ce
% inseamna? Adauga legena si comentarii in cod ca si cum ai scrie pentru
% altcineva.

f = @(x)sin (x);
a = 0;
b = pi;
m = 100;
x = linspace(a,b,m+1);
x = [a-x(2)+x(1) x b+x(2)-x(1)];
y = f(x);

syms xsym;
df = matlabFunction(diff(f(xsym)));

dy = DerivNum(x,y,'diferente finit centrale');
figure;
plot(x(2:m),dy(2:m));

plot(x(2:m),df(x(2:m)));

figure;
plot(x(2:m), abs(dy(2:m)-df(x(2:m))));

dy = DerivNum(x,y,'diferente finit progresive');
figure;
plot(x(2:m),dy(2:m));

plot(x(2:m),df(x(2:m)));

figure;
plot(x(2:m), abs(dy(2:m)-df(x(2:m))));

dy = DerivNum(x,y,'diferente finit regresive');
figure;
plot(x(2:m),dy(2:m));

plot(x(2:m),df(x(2:m)));

figure;
plot(x(2:m), abs(dy(2:m)-df(x(2:m))));

a = 0;
b = pi;
f = @(x)sin (x);
n = 8;
m = 100;
x = linspace(a,b,m+1);
h = abs(x(2) - x(1));

for i = 1:m
    dff(i) = MetRichardson(f,x(i),h,n);
end

syms xsym;
df = matlabFunction(diff(f(xsym)));

figure; hold on;
plot(x(2:m),dff(2:m));
plot(x(2:m),df(x(2:m)),'--k');

figure;
plot(x(2:m), abs(dff(2:m)-df(x(2:m))));

df2 = matlabFunction(diff(df(xsym)));

for i = 1:m
    dff2(i) = MetRichardson2(f,x(i),h,n);
end

figure; hold on;
plot(x(2:m),dff2(2:m));
plot(x(2:m),df2(x(2:m)),'--k');

function dy = DerivNum(x, y, metoda)
m = length(x) - 1;
switch metoda
    case 'diferente finit progresive'
        for i = 2:m
            dy(i) = (y(i+1) - y(i))/(x(i+1) - x(i));
        end
    case 'diferente finit regresive'
        for i = 2:m
            dy(i) = (y(i) - y(i-1))/(x(i) - x(i-1));
        end
    case 'diferente finit centrale'
        for i = 2:m
            dy(i) = (y(i+1) - y(i-1))/(x(i+1) - x(i-1));
        end
end

end

function [df] =MetRichardson(f, x, h, n)
fi = @(x,h)(f(x+h)-f(x))/h;
Q = zeros(n,n);
for i=1:n
    Q(i,1)
    fi(x,(h/2^(i-1)))
    Q(i,1) = fi(x,(h/2^(i-1)));
end

for i = 2:n
    for j = 2:i
        Q(i,j) = Q(i,j-1) + 1/(2^(j-1) - 1)*(Q(i,j-1) - Q(i-1, j-1));
    end
end

df = Q(n,n);
end

function [df] =MetRichardson2(f, x, h, n)
fi = @(x,h)(f(x+h)-2*f(x)+f(x-h))/(h^2);
Q = zeros(n,n);
for i=1:n
    Q(i,1) = fi(x,(h/2^(i-1)));
end

for i = 2:n
    for j = 2:i
        Q(i,j) = Q(i,j-1) + 1/(2^(j-1) - 1)*(Q(i,j-1) - Q(i-1, j-1));
    end
end

df = Q(n-1,n-1);
end

