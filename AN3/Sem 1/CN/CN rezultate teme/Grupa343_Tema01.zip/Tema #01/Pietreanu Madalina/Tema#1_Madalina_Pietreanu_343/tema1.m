%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMA 1                                                              %
% Madalina Pietreanu, grupa 343                                           %
% - acest fisier reprezinta functia "parent" din care se vor apela toate  %
%       celelalte fisiere exN.m, unde N corespunde numarului exercitiului %
% - detalii despre implementari se gasesc in fisierele .m asociate        %
%         exercitiilor                                                    %                                                
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;

ex2();      % 9/10  -> Nu initializezi bine functia
%ex3();     % 5/10  -> Metoda Nu da rezultatul intersectiei
%ex4();     % 5/10  -> Nu ai inteles matematic ce trebuie sa faci
%ex5();     % 10/10 -> Bravo
%ex6();     % 8/10  -> Doua intervale gasesc aceeasi solutie. Al treilea
                       %interval gaseste o solutie din afara domeniului
%ex8();     % 2/10 -> ai facut doar a)

