%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = ex6()
    
    % initializari
    f = @(x)  x.^3 - 7*x.^2 + 14*x - 6; % functia
    df = @(x) 2*x.^2 - 14 * x + 14;     % derivata functiei
    epsi = 10 ^ -3;                     % eroarea
    
    % a) - implementare se gaseste in fisierul MetNR.m
    % b) - conditia pe care trebuie sa o indeplineasca intervalele:
    %                  [a,b] => f(a)*f(b) < 0
    figure(6);
    title('Graficul functiei');
    x = linspace(0,4);
    y = f(x);
    plot(x,y,'-r');
    grid on;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    x1 = linspace(0,1); % PRIMUL INTERVAL
                        % justificarea alegerii:
                        % f(0) = -6 
                        % f(1) = 2 
                        % f(0)*f(1) < 0
    p1 = 1;             % PRIMUL PUNCT
                        % justificarea alegerii:
                        % p1 apartine [0,1]
                        % f(1)*df(1) > 0
    y1 = f(x1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(61);
    title('Intervalul [0,1]');
    plot(x,y,'-r');
    grid on;
    hold on;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plot(x1,y1,'-g');
    hold on;
    plot(0,f(0),'xm');
    hold on;
    plot(1,f(1),'xm');
    hold on;
    xNum1 = MetNR(f,df,p1,epsi);
    plot(xNum1, f(xNum1), '*b');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    x2 = linspace(0.5, 1.5); % AL DOILEA INTERVAL
                             % justificarea alegerii:
                             % f(1/2)*f(3/2) = -105/64 < 0
    p2 = 0.75;               % AL DOILEA PUNCT
                             % jutsificarea alegerii:
                             % f(0.75)*df(0.75) = 2331/512 > 0
    y2 = f(x2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(62);
    title('Intervalul [0.5,1.5]');
    plot(x,y,'-r');
    grid on;
    hold on;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plot(x2,y2,'-g');
    hold on;
    plot(0.5,f(0.5),'xm');
    hold on;
    plot(1.5,f(1.5),'xm');
    hold on;
    xNum2 = MetNR(f,df,p2,epsi);
    plot(xNum2, f(xNum2), '*b');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    x3 = linspace(3.25,4); % AL TREILEA INTERVAL
                           % justificarea alegerii:
                           % f(3.25)*f(4) = -7/32 < 0
    p3 = 3.25;             % AL TREILEA PUNCT
                           % justificarea alegerii:
                           % f(3.25)*df(3.25) = 581/512 > 0
    y3 = f(x3);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(63);
    title('Intervalul [3.25,4]');
    plot(x,y,'-r');
    grid on;
    hold on;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plot(x3,y3,'-g');
    hold on;
    plot(3.25,f(3.25),'xm');
    hold on;
    plot(4,f(4),'xm');
    hold on;
    xNum3 = MetNR(f,df,p3,epsi);
    plot(xNum3, f(xNum3), '*b');
    
end
