%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implementarea metodei bisectiei conform algoritmului din cursul 1       %
% INPUT:  - f : functia                                                   %
%         - a, b : capetele intervalului                                  %
%         - epsi : eroarea                                                %
% OUTPUT: - xaprox: aproximarea numerica a punctului x, unde f(x) = 0     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [xaprox] = MetBisectie(f,a,b,epsi)
% initializari
    A(1) = a; % sirul capetelor din stanga obtinute pe parcursul 
              %       algoritmului
              % primul este chiar capatul din stanga al intervalului
    B(1) = b; % sirul capetelor din dreapta obtinute pe parcursul
              %       algoritmului
              % primul este chiar capatul din dreapta al intervalului
    x(1) = (a + b) / 2; % sirul aproximarilor lui x
                        % incepem cu el la jumatatea intervalului
    n = floor(log((b - a) / epsi) - 1) + 1; % criteriul de oprire (a se
                                            % vedea demonstratia din curs)
    k = 1;
% algoritm    
    for k = 2 : n
        if (f(x(k - 1)) == 0)
            x(k) = x(k-1); %am gasit solutia exacta
            break;
        elseif (f(A(k-1)) * f(x(k-1)) < 0)
            A(k) = A(k - 1); %ramane la fel
            B(k) = x(k - 1); %deplasez b-ul la stanga
            x(k) = (A(k-1) + B(k-1)) / 2;
        else
            A(k) = x(k-1); %deplasez a-ul mai la dreapta
            B(k) = B(k-1);
            x(k) = (A(k-1) + B(k-1)) / 2;
        end
    end
    xaprox = x(k); % aproximarea numerica a lui x
end

