%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implementarea metodei Newton-Raphson conform algoritmului din cursul 1  %
% INPUT:  - f : functia                                                   %
%         - df : derivata functiei                                        %
%         - x0 : un punct pt care f(x0)*df(x0) > 1                        %
%         - epsi : eroarea                                                %
% OUTPUT: - xaprox: aproximarea numerica a punctului x, unde f(x) = 0     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [xaprox] = MetNR(f,df,x0,eps)
        k = 1;
        flag = 1;  % o variabila booleana pe care o folosesc pentru a 
                   % "simula" un do while
        x(1) = x0; % sirul aproximarilor care converge catre solutie
        while flag
            k = k + 1;
            x(k) = x(k-1) - f(x(k-1)) / df(x(k-1));
            if abs((x(k) - x(k-1)) / x(k - 1)) < eps %conditia de oprire
                flag = 0;
            end
        end
        xaprox = x(k); % ultimul element din sir reprezinta aproximarea
                       % numerica a solutiei
end