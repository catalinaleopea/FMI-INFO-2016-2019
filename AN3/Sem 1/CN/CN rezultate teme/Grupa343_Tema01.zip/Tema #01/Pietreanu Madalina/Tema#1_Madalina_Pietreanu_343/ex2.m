%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = ex2()
%initializari
    f = @(x) x.^(3) - 7*x.^2 + 14.*x - 16; %functia data de exercitiu
    epsi = 10 ^ -5; %epsilonul de la punctul b)
    x0 = linspace(0,4);   % intervalul de la b)
    x1 = linspace(0,1);   %\
    x2 = linspace(1,3.2); %- intervalele de la punctul c)
    x3 = linspace(3.2,4); %/

    % a) - fisierul MetBisectie.m
    %    - implementeaza metoda bisectiei (detalii in el)

    % b) - realizarea graficului cerut la punctul b
    y = f(x0); % calcularea valorilor functiei pt intervalul x20
    xNum1 = MetBisectie(f, 0, 1, epsi);   % aproximarea numerica pt x21
    xNum2 = MetBisectie(f, 1, 3.2, epsi); % aproximarea numerica pt x22
    xNum3 = MetBisectie(f, 3.2, 4, epsi); % aproximarea numerica pt x23

    figure(2); % reprezentarea grafica a functiei
    plot(x0,y, '-r');
    xlabel('x');
    ylabel('y = f(x)');
    grid on;
    hold on;

    % c) plotarea punctelor obtinute la b)
    plot(xNum1, f(xNum1), '*r');
    hold on;
    plot(xNum2, f(xNum2), '*g');
    hold on;
    plot(xNum3, f(xNum3), '*b');
    hold off;
end