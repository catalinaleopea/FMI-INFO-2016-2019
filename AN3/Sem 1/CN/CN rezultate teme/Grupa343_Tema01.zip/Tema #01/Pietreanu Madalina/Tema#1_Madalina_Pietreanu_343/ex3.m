%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = ex3()
    % a) - construirea graficelor functiilor cerute
    f1 = @(x) exp(x) - 2; 
    f2 = @(x) cos(exp(x) - 2);
    x1 = linspace(0.5,1.5); %discretizez un interval
    y1 = f1(x1); %imaginea lui f1
    y2 = f2(x1); %imaginea lui f2
    %graficele functiilor
    figure(31)
    plot(x1,y1,'-r');
    axis([-2, 2, -2, 2]); % sa se vada mai bine functiile
    grid on;
    hold on;
    plot(x1,y2,'-b');
    hold on;
    
    % b) - aproximarea solutiei ecuatiei
    %    - trec in stanga cu semn opus membrul din dreapta, obtinand astfel
    %           functia f3; acum folosesc metoda bisectiei pentru a gasi
    %           cu aproximatie punctul in care aceasta functie are 
    %           valoarea 0
    
    f3 = @(x) exp(x) - 2 - cos(exp(x) - 2);
    x2 = linspace(0.5, 1.5);
    epsi = 10 ^ -5; % eroarea
    y3 = f3(x2);
    plot(x2,y3,'-g'); % plotex in acelasi grafic functia f3
    hold on;
    xNum = MetBisectie(f3, 0.5, 1.5, epsi); % aproximarea numerica a
                                            % solutiei ecuatiei
    plot(xNum, f3(xNum), '*m');
    hold off;

end
