%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = ex4()
    %interval: 1 < 3 < 4 => 1 < sqrt(3) < 2 
    %functia: x = sqrt(3) (asta vreau sa gasesc) => x - sqrt(3) = 0
    %alternativa: x.^2 = 3 => x.^2 - 3 = 0
    %f = @(x) x - sqrt(3);
    f = @(x) x.^2 - 3;
    epsi = 10 ^ -5;
    radical3 = MetBisectie(f, 1, 2, epsi) % aproximarea numerica a
                                          % radicalului din 3
end

