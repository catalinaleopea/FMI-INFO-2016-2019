%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = ex5()
    %initializari
    f = @(x)  x.^3 - 7*x.^2 + 14*x - 6;
    df = @(x) 2*x.^2 - 14 * x + 14;
    epsi = 10 ^ -5;
    
    % - conform teoremei 1.2 din cursul 1, f5(2) * df5(2) trebuie sa 
    %           fie > 0 pentru ca algoritmul sa convearga la o solutie;
    %           cum in cazul de fata acest produs este < 0, algoritmul
    %           nu converge
    % - pentru punctul x0 = 1 algoritmul converge deoarece f(1) = 2,
    %          df(1) = 2, iar produsul acestora este > 0; reprezentarea
    %          grafica de mai jos dovedeste acest lucru
    
    x = linspace(0, 2.5); % discretizez intervalul dat
    y = f(x);
    xNum = MetNR(f,df,1,epsi); % aproximarea numerica a punctului x
    figure(5);
    plot(x, y, '-r'); % graficul functiei
    grid on;
    hold on;
    plot(xNum, f(xNum), '*b');
    hold off;

end