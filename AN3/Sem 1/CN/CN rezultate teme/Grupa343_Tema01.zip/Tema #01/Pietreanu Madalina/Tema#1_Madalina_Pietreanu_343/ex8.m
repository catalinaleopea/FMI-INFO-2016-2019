%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 8 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = ex8()
    % initializari
    f = @(x) x.^3 - x*18 - 10;
    
    % a) - plotez graficul functiei f pe intervalul [-5,5]
    x = linspace(-5,5,1000);
    y = f(x);
    figure(8)
    plot(x,y,'-r');
end

