% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficele functiilor f1(x) = e^x - 2 si f2(x) = cos (e^x - 2)
% Calculeaza solutia ecuatiei f1(x) = f2(x) pe intervalul [0.5, 1.5]
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================
% 10/10
% declar functia f1(x) = e^x - 2
f1 = @(x) exp(x) - 2;

% declar functia f2(x) = cos(e^x - 2)
f2 = @(x) cos(exp(x) - 2);

% initializez intervalul [0, 2] pe care sa fie afisate graficele functiilor
% f1 si f2 (am pus eu [0, 2] de la mine pentru ca nu zicea niciun interval in
% enunt)
a = 0;
b = 2;

% n reprezinta cat de des sa se calculeze punctele de pe grafic
n = 1000;

% initializez punctele de pe axa Ox pentru care trebuie sa se calculeze
% y pentru functiile f1(x) si f2(x)
x = a:(b-a)/n:b;

% desenez graficul functiei f1(x)
plot(x, arrayfun(f1, x));

% ii zic sa nu stearga graficul la urmatorul call al functiei plot
hold on;

% afisez graficul functiei f2(x)
plot(x, arrayfun(f2, x));

% declar o functie f care reprezinta ecuatia de la punctul b
% pentru care trebuie sa gasesc solutia
f = @(x) f1(x) - f2(x);

% apelez metoda bisectiei pentru ecuatia respectiva pe intervalul
% [0.5, 1.5] asa cum este cerut in cerinta si epsilon = 10^(-5)
sol = MetBisectiei(f, 0.5, 1.5, 1e-7);

% afisez solutia
printf("Am gasit solutia = %f cu f1(sol) = %f si f2(sol) = %f\n", sol, f1(sol), f2(sol));