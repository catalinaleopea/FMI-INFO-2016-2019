% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Aproximeaza valoarea lui sqrt(3)
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

% declar functia f(x) = x^2 - 3; am plecat de la sqrt(3), am ridicat la patrat
% si am egalat cu 0, asa am ajuns la functia asta
f = @(x) x^2 - 3;

% declar intervalul [1, 2] deoarece stiu ca rezultatul apartine acestui interval
a = 1;
b = 2;

% apelez MetBisectiei pentru functia f(x) in intervalul [1, 2] si cu eroarea
% 10^(-5)
sol = MetBisectiei(f, a, b, 1e-6);

fprintf('Am gasit solutia %f pentru sqrt(3). (%f)^2 = %f\n', sol, sol, sol^2);