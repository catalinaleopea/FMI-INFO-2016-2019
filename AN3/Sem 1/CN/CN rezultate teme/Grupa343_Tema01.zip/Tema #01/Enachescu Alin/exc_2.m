% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul functiei f(x) = x^3 - 7x^2 +14x - 6 pe intervalele
% [0, 1], [1, 3.2], [3.2, 4]
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================
% 9/10 -> rows = size(...)

% 1. -
% 2. 9
% 3. 10
% 4. 10
% 5. - 
% 6. 8
% 7. -
% 8. -
% Total: 36/80 i.e. 4.5/10 

% declar functia
f = @(x) x^3 - 7 * x^2 + 14*x - 6;

% initializez capatul din stanga al intervalului cu 0
a = 0;

% initializez capatul din dreapta al intervalului cu 4
b = 4;

% initializez eroarea cu 10^(-5)
epsilon = 1e-5;

% declar intervalele cerute in cerinta problemei
intervals = [
  [0,1],
  [1,3.2],
  [3.2,4],
];

% n reprezinta cat de des sa se calculeze punctele de pe grafic
n = 1000;

% initializez punctele de pe axa Ox pentru care trebuie sa se calculeze f(x)
x = a:(b-a)/n:b;

% rezultatul functie f(x) pentru fiecare x din array-ul de mai sus
y = arrayfun(f, x);

% initializez vectorul de xaprox care va fi calculat pentru fiecare interval
% din variabila intervals
xaprox = [];

% initializez vectorul de yaprox care va fi calculat pentru fiecare interval
% din variabila intervals, yaprox = f(xaprox)
yaprox = [];

% iterez prin fiecare interval
for i = 1 : rows(intervals)
  % copiez al i-lea interval
  row = intervals(i, :);
  % apelez metoda bisectiei pentru al i-lea interval
  xnow = MetBisectiei(f, row(1), row(2), epsilon);
  % adaug in vectorul xaprox, xaprox-ul gasit pentru al i-lea interval
  xaprox = [xaprox, xnow];
  % adaug in vectorul yaprox, yaprox-ul echivalent pentru xaprox pentru al
  % i-lea interval
  yaprox = [yaprox, f(xnow)];
end % for

% desenez graficul functiei
plot(x, y);

% ii spun sa nu fie sters de urmatorul apel al functiei plot
hold on;

% desenez punctele xaprox gasite pt fiecare interval
plot(xaprox, yaprox, 'or');