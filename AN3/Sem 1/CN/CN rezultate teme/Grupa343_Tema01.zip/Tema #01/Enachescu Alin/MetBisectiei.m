% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'A'       = capatul din stanga al intervalului
% 'B'       = capatul din dreapta al intervalului 
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'    = rezultatul returnat de metoda Bisectiei
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function xaprox = MetBisectiei(f, A, B, epsilon)
  while true
    % calculez mijlocul intervalului
    mid = (A + B) / 2;
    % calculez y-ul pentru mijlocul intervalului
    value = f(mid);
    % daca y-ul pentru mijlocul intervalului are acelasi semn cu y-ul
    % capatului din stang al intervalului atunci mut capatul din stanga
    % al intervalului la mijloc, altfel mut capatul din dreapta al intervalului
    % la mijloc
    if sign(value) == sign(f(A))
      A = mid;
    else
      B = mid;
    end % if
    
    % daca diferenta dintre capetele este mai mica decat eroarea ceruta
    % atunci ne oprim din calculat
    if abs(A - B) < epsilon
      break;
    end % if
   end % while
   
   % returnez xaprox ca fiind mijlocul intervalului
   xaprox = mid;  
end