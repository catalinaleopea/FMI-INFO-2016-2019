% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'df'      = derivata functiei f
% 'x0'      = valoarea initiala
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'    = rezultatul returnat de metoda N-R
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function xaprox = MetNR(f, df, x0, epsilon)
  while true
    % calculez Xn ca fiind X(n-1) - f(X(n-1)) / f'(X(n-1))
    xn = x0 - f(x0) / df(x0);
    
    % conditia de oprire, e echivalentul conditiei din curs
    % adica (X(k) - X(k-1)) / X(k-1) >= eps
    if abs(xn - x0) < epsilon * abs(x0)
      % returnez X(k)
      xaprox = xn;
      break;
    end % if
    
    % aici x0 devine defapt X(k-1)
    x0 = xn;
  end % while
end % function

