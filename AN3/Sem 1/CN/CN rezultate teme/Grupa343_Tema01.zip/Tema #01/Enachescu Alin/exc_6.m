% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul functiei f(x) = x^3 - 7x^2 +14x - 6
% Aleg 3 subintervale si valorile initiale x0 pentru a gasi solutiile
% folosind MetNR.
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================
% Intervalele si punctele de pornire le alegi astfel incat sa ai 
% satisfacuta cerinta cheie  teoremei + celelalte ipoteze. De ce nu citesti
%  cursul?
% 8/10

% declar functia f(x) din enunt
f = @(x) x^3 - 7* x^2 + 14*x - 6;

% declar derivata functiei f(x)
df = @(x) 3 * x^2 - 14 * x + 14;

% declar derivata derivatei functiei f(x)
ddf = @(x) 6*x - 14;

% aleg intervalul [0, 4] asa cum se cere in enunt
a = 0;
b = 4;

% n reprezinta cat de des sa se calculeze punctele de pe grafic
n = 1000;

% initializez punctele de pe axa Ox pentru care trebuie sa se calculeze f(x)
x = a: (b-a) / n: b;

% afisez graficul functiei f(x)
plot(x, arrayfun(f, x));

% ii spun sa nu stearga graficul la urmatorul call de plot
hold on;

% am ales intervalele; 1.5 si 3.1 reprezinta solutiile functiei f'(x) (cu aproximatie
% solutiile fiind (14 +/- sqrt(28)) / 6
intervals = [
  [0.0, 1.5],
  [1.5, 3.1],
  [3.1, 4.0],
];

% declar valoriile initiale, aici nu prea am stiut cum sa fac iar din ce am gasit
% pe net am aflat ca f(x0) * f''(x0) trebuie sa fie > 0 asa ca mai mult le-am ales
% random, respectand doar regula asta.
inits = [
  0.5,
  2.5,
  3.5,
];

% declar arrayul de solutii
sols = [];

% iterez prin intervale
for i = 1 : size(intervals)
  % aleg al i-lea interval
  row = intervals(i, :);
  % iau capetele intervalului
  a = row(1);
  b = row(2);
  % iau x0 care corespunde pentru al i-lea interval
  x0 = inits(i);
  % calculez solutia pentru al i-lea interval
  sols = [sols, MetNR(f, df, x0, 1e-3)];
end %for

% desenez solutiile
plot(sols, arrayfun(f, sols), 'or');

% afisez solutiile
fprintf('Am gasit solutiile: ');
disp(sols);