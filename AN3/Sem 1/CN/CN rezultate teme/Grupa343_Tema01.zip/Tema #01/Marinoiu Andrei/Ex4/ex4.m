% Exercitiul 4
% Script-ul calculeaza solutia data de metoda Bisectiei

f = @(x) x^2 - 3; % Declarare functie
epsilon = 10^(-5); % Eroarea dintre solutia numerica si cea exacta

a = 1; % Initizlizare capat stanga al intervalului
b = 2; % Initizlizare capat dreapta al intervalului

% Se calculeaza solutia m si pasul de oprire N apeland functia MetBisectie
[m,N] = MetBisectie(f,a,b,epsilon);

fprintf('xAprox = %5.2f',m); % Afisare solutie