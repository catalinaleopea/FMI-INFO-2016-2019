% Functie specifica metodei bisectiei

% Date de intrare :
% f -> functie declarata
% a -> capatul din stanga al unui interval
% b -> capatul din dreapta al unui interval
% epsilon -> eroarea dintre solutia numerica si cea exacta

% Date de iesire :
% xAprox -> solutia numerica
% N -> pasul de oprire

function [xAprox, N] = MetBisectie(f,a,b,epsilon)

a(1) = a; % Initializare capat stanga
b(1) = b; % Initializare capat dreapta
x(1) = (a(1) + b(1)) / 2; % Initializare x0
N = floor(log2((b-a)/epsilon)); % Criteriul de oprire

% Iteratiile algoritmului
for k = 2:N+1
    if (f(x(k-1)) == 0)
        x(k) = x(k-1);
        break;
    elseif (f(a(k-1)) * f(x(k-1)) < 0)
        a(k) = a(k-1);
        b(k) = x(k-1);
        x(k) = (a(k-1) + b(k-1)) / 2;
    elseif (f(a(k-1)) * f(x(k-1)) > 0)
        a(k) = x(k-1);
        b(k) = b(k-1);
        x(k) = (a(k-1) + b(k-1)) /2;
    end
end

xAprox = x(k); % Memorarea solutiei

end