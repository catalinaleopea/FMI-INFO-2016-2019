% Exercitiul 2,subpunctele b) si c)
% Script-ul afiseaza graficul unei functii si solutia data de metoda
%bisectiei pe 3 intervale date

f = @(x) x.^3 - 7*x.^2 + 14*x - 6; % Declarare functie
epsilon = 10^(-5); % Eroarea dintre solutia numerica si cea exacta

% Initizlizarea captelelor pentru cele 3 intervale (a->stanga, b->dreapta)
a = 0;
b = 1;
a2 = 1;
b2 = 3.2;
a3 = 3.2;
b3 = 4;

% Se calculeaza solutia m si pasul de oprire N apeland functia MetBisectie
[m,N] = MetBisectie(f,a,b,epsilon);
[m2,N2] = MetBisectie(f,a2,b2,epsilon);
[m3,N3] = MetBisectie(f,a3,b3,epsilon);

x = linspace(a,b3,50); % Atribuim valori lui x
y = f(x); % Valorile lui f(x) adaugate intr-un vector


figure(1); % Construim figura 1
plot(x,y); % Se adauga graficul functiei

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');

% Adaugam pe rand cele trei puncte in care graficul se intersecteaza cu axa
%0x,utilizand hold on pentru a se pastra in acelasi grafic
hold on;
plot(m,0,'o','MarkerFaceColor','r','MarkerSize',10);

hold on;
plot(m2,0,'o','MarkerFaceColor','r','MarkerSize',10);

hold on;
plot(m3,0,'o','MarkerFaceColor','r','MarkerSize',10);

hold off;