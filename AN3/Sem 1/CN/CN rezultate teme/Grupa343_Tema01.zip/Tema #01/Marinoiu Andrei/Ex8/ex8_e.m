% Exercitiul 8,subpunctul e)
% Script-ul afiseaza graficul unei functii si solutia data de metoda
%pozitiei false pe 3 subintervale

f = @(x) x.^3 - 18*x - 10; % Declarare functie
epsilon = 10^(-3); % Eroarea dintre solutia numerica si cea exacta
x = linspace(-5,5); % Atribuim valori lui x

figure(1); % Construim figura 1
plot(x,f(x)); % Se adauga graficul functiei

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');

% Initializem capetele subintervalelor, apoi apelam functia MetSecantei,
%adaugand pe rand cele 3 puncte
hold on;
a = 0;
b = 2;
m = MetPozFalse(f,a,b,epsilon);
plot(m,f(m),'o','MarkerFaceColor','r','Markersize',10);

hold on;
a2 = -5;
b2 = -4;
m2 = MetPozFalse(f,a2,b2,epsilon);
plot(m2,f(m2),'o','MarkerFaceColor','r','Markersize',10);

hold on;
a3 = 4;
b3 = 5;
m3 = MetPozFalse(f,a3,b3,epsilon);
plot(m3,f(m3),'o','MarkerFaceColor','r','Markersize',10);

hold off;