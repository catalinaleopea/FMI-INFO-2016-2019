% Exercitiul 8,subpunctul d)
% Script-ul afiseaza graficul unei functii si solutia data de metoda
%secantei pe 3 subintervale

f = @(x) x.^3 - 18*x - 10; % Declarare functie
epsilon = 10^(-3); % Eroarea dintre solutia numerica si cea exacta
x = linspace(-5,5); % Atribuim valori lui x

figure(1); % Construim figura 1
plot(x,f(x)); % Se adauga graficul functiei

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');

% Initializem capetele subintervalelor si cele 2 puncte, apoi apelam functia
%MetSecantei,adaugand pe rand cele 3 puncte

% Argumentare pentru alegerea intervalelor? 

hold on;
x0 = -3.9;
x1 = -3.1;
a = -4;
b = -2;
m = MetSecantei(f,a,b,x0,x1,epsilon);
plot(m,f(m),'o','MarkerFaceColor','r','Markersize',10);

hold on;
x0 = -0.8;
x1 = -0.2;
a2 = -1;
b2 = -0;
m2 = MetSecantei(f,a2,b2,x0,x1,epsilon);
plot(m2,f(m2),'o','MarkerFaceColor','r','Markersize',10);

hold on;
x0 = 4.4;
x1 = 4.7;
a3 = 4.2;
b3 = 4.8;
m3 = MetSecantei(f,a3,b3,x0,x1,epsilon);
plot(m3,f(m3),'o','MarkerFaceColor','r','Markersize',10);

hold off;