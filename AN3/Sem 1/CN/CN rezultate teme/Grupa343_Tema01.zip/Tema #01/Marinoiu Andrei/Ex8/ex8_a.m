% Exercitiul 8,subpunctul a)
% Script-ul afiseaza graficul unei functii pe intervalul dat

f = @(x) x.^3 - 18*x - 10; % Declarare functie
x = linspace(-5,5); % Atribuim valori lui x

figure(1); % Construim figura 1
plot(x,f(x)); % Se adauga graficul functiei

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');