% Functie specifica metodei pozitiei false

% Date de intrare :
% f -> functie declarata
% a -> capatul din stanga al unui interval
% b -> capatul din dreapta al unui interval
% epsilon -> eroarea dintre solutia numerica si cea exacta

% Date de iesire :
% xAprox -> solutia numerica

function [xAprox] = MetPozFalse(f,a,b,epsilon)

cond = 1; % Retinem daca valoarea de adevar a conditiei
k = 1; % Initializare k
a(1) = a; % Initializare capat stanga
b(1) = b; % Initializare capat dreapta
x(1) = ( a(1)*f(b(1)) - b(1)*f(a(1)) ) / ( f(b(1)) - f(a(1)) ); 
%Initializare x0

% Iteratiile algoritmului
while cond
    k = k + 1;
    if (f(x(k-1)) == 0)
        x(k) = x(k-1);
        break;
    elseif (f(a(k-1))*f(x(k-1)) < 0)
        a(k) = a(k-1);
        b(k) = x(k-1);
        x(k) = ( a(k)*f(b(k)) - b(k)*f(a(k)) ) / ( f(b(k)) - f(a(k)) );
    elseif (f(a(k-1))*f(x(k-1)) > 0)
        a(k) = x(k-1);
        b(k) = b(k-1);
        x(k) = ( a(k)*f(b(k)) - b(k)*f(a(k)) ) / ( f(b(k)) - f(a(k)) );
    end
    if abs((x(k)-x(k-1)) / x(k-1)) < epsilon
        cond = 0;
    end
end

xAprox = x(k); % Memorarea solutiei

end