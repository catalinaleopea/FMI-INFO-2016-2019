% Functie specifica metodei secantei

% Date de intrare :
% f -> functie declarata
% a -> capatul din stanga al unui interval
% b -> capatul din dreapta al unui interval
% x0,x1 -> valori aflate in intervalul a,b
% epsilon -> eroarea dintre solutia numerica si cea exacta

% Date de iesire :
% xAprox -> solutia numerica

function [xAprox] = MetSecantei(f,a,b,x0,x1,epsilon)

k = 2; % Initializare k
x(1) = x0; % Initializare x0
x(2) = x1; % Initializare x1

while abs((x(k)-x(k-1)) / x(k-1)) >= epsilon
    k = k + 1;
    x(k) = ( x(k-2)*f(x(k-1)) - x(k-1)*f(x(k-2)) ) / ( f(x(k-1)) - f(x(k-2)) );
    if x(k) < a ||  x(k) > b
        fprintf('Introduceti alte valori pentru x0,x1');
        break;
    end
end

xAprox = x(k); % Memorarea solutiei

end