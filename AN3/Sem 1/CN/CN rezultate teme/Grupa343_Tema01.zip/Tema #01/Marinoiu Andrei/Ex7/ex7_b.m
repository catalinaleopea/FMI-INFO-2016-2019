% Exercitiul 7,subpunctul b)
% Script-ul afiseaza graficul unei functii si solutia data de metoda
%Newton-Raphson,secantei si pozittiei false

% i)  Nu ai demonstrat unicitatea solutiei
% ii) Ai aflat direct solutia numerica (foarte bine chiar), insa ti se
% cerea doar x-ul numeric pentru k = 2. :( 
% Din nou, apelezi functii care nu sunt in acelasi folder cu fisierul din
% care apelezi si nu imi spui ce folder sa adaug in path...

f = @(x) 8*x.^3 + 4*x - 1; % Declarare functie
df = @(x) 24*x.^2 + 4; % Derivata functiei
epsilon = 10^(-3); % Eroarea dintre solutia numerica si cea exacta
x = linspace(0,1); % Atribuim valori lui x

figure(1); % Construim figura 1
plot(x,f(x)); % Se adauga graficul functiei

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');

title('Grafic pentru metoda bisectiei'); % Adaugare titlu pentru grafic

% Adaugam punctul in care graficul se intersecteaza cu axa 0x,utilizand 
%hold on pentru a se pastra in acelasi grafic
hold on;
a = 0.1;
b = 0.6;
m = MetPozFalse(f,a,b,epsilon); % Calculare solutie cu ajutorul
%metodei pozitiei false
plot(m,f(m),'o','MarkerFaceColor','r','Markersize',10);

hold off;

figure(2); % Construim figura 2
plot(x,f(x)); % Se adauga graficul functiei

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');

title('Grafic pentru metoda Newton-Raphson'); % Adaugare titlu pentru grafic

% Adaugam punctul in care graficul se intersecteaza cu axa 0x,utilizand 
%hold on pentru a se pastra in acelasi grafic
hold on;
x0 = 0.4;
m2 = MetNR(f,df,x0,epsilon); % Calculare solutie cu ajutorul
%metodei Newton-Raphson
plot(m2,f(m2),'o','MarkerFaceColor','r','Markersize',10);

hold off;

figure(3); % Construim figura 2
plot(x,f(x)); % Se adauga graficul functiei

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');

title('Grafic pentru metoda Newton-Raphson'); % Adaugare titlu pentru grafic

% Adaugam punctul in care graficul se intersecteaza cu axa 0x,utilizand 
%hold on pentru a se pastra in acelasi grafic
hold on;
x0 = 0.12;
x1 = 0.67;
a2 = 0.1;
b2 = 0.8;
m3 = MetSecantei(f,a2,b2,x0,x1,epsilon); % Calculare solutie cu ajutorul
%metodei secantei
plot(m3,f(m3),'o','MarkerFaceColor','r','Markersize',10);

hold off;

