% Exercitiul 3,subpunctul a)
% Script-ul afiseaza graficul unei functii si solutia data de metoda
%Bisectiei 

% Punctul a)

% !!! Atentie! Exponentiala are sintagma 'exp(x) si nu 'eps.
% 'eps' reprezinta precizia masinii.
% Totodata, ai grija ca apelezi o functie care nu este in acelasi folder cu
% fisierul din care o apelezi.

f = @(x) eps.^x - 2; % Declarare functie 1
x = linspace(0,0.2,100); % Atribuim valori lui x

figure(1); % Construim figura 1
plot(x,f(x)); % Se adauga graficul functiei

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');

title('Grafic functie 1'); % Titlul graficului

f2 = @(x) cos(eps.^x - 2); % Declarare functie 2
x2 = linspace(0,1,100); % Atribuim valori lui x2

figure(2); % Construim figura 2
plot(x2,f2(x));

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');

title('Grafic functie 2'); % Titlul graficului


% Punctul b)

f2 = @(x) cos(eps.^x - 2) - eps.^x + 2; % Declarare functie
epsilon = 10^(-5); % Eroarea dintre solutia numerica si cea exacta

a = 0.5; % Initizlizare capat stanga al intervalului
b = 1.5; % Initizlizare capat dreapta al intervalului

% Se calculeaza solutia m si pasul de oprire N apeland functia MetBisectie
[m,N] = MetBisectie(f2,a,b,epsilon);

fprintf('Solutia este: %4.2f\n',m); % Afisare solutie