% Exercitiul 6,subpunctul b)
% Script-ul afiseaza graficul unei functii si solutia data de metoda
%Newton-Raphson pe 3 puncte alese din mai 3 subintervale

f = @(x) x.^3 - 7*x.^2 + 14*x - 6; % Declarare functie
df = @(x) 3*x.^2 - 14*x + 14; % Derivata functiei
epsilon = 10^(-3); % Eroarea dintre solutia numerica si cea exacta
x = linspace(0,4); % Atribuim valori lui x

figure(1); % Construim figura 1
plot(x,f(x)); % Se adauga graficul functiei

% Adaugam axele x si y si le marca cu label-uri
line(xlim,[0 0]);
line([0 0],ylim);
xlabel('Axa x');
ylabel('Axa y');

% Adaugam pe rand cele trei puncte in care graficul se intersecteaza cu axa
%0x,utilizand hold on pentru a se pastra in acelasi grafic
% Q: Cum ai ales intervalele? 
hold on;
x0 = 0;
m0 = MetNR(f,df,x0,epsilon); % Se calculeaza solutia apeland functia 
%MetNR
plot(m0,f(m0),'o','MarkerFaceColor','r','Markersize',10);

hold on;
x1 = 2;
m1 = MetNR(f,df,x1,epsilon); % Se calculeaza solutia apeland functia 
%MetNR
plot(m1,f(m1),'o','MarkerFaceColor','r','Markersize',10);

hold on;
x2 = 3.5;
m2 = MetNR(f,df,x2,epsilon); % Se calculeaza solutia apeland functia 
%MetNR
plot(m2,f(m2),'o','MarkerFaceColor','r','Markersize',10);
hold off;