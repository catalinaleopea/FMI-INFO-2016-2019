% Functie specifica metodei Newton-Raphson

% Date de intrare :
% f -> functie declarata
% df -> derivata functiei f
% x0 -> valoarea din subintervalul ales
% epsilon -> eroarea dintre solutia numerica si cea exacta

% Date de iesire :
% xAprox -> solutia numerica

function [xAprox] = MetNR(f,df,x0,epsilon)

cond = 1; % Retinem daca valoarea de adevar a conditiei
k = 1; % Initializare k
x(1) = x0; % Initializare x0

% Iteratiile algoritmului
while cond
    k = k + 1;
    x(k) = x(k-1) - f(x(k-1)) / df(x(k-1));
    if abs((x(k)-x(k-1)) / x(k-1)) < epsilon
        cond = 0;
    end
end

xAprox = x(k); % Memorarea solutiei

end