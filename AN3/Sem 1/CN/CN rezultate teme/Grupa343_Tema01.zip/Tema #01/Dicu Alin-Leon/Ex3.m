% EXERCITIUL 3
% y1 = e^x ? 2 si y2 = cos(e^x ? 2)
% 9/10 -> vezi functia MetodaBisectiei. :(
function Ex3
% A) graful lui y1 si y2
    y1 = @(x) exp(x) - 2;
    y2 = @(x) cos(exp(x) - 2);
    close all
    clc
    X = linspace(-2,2,100);
    Y1 = y1(X);
    plot(X,Y1,'Linewidth',3)
    hold on
    Y2 = y2(X);
    plot(X,Y2,'Linewidth',3)
    line(xlim(), [0,0], 'Linewidth', 1, 'Color', 'k');
    
% B) e^x ? 2 = cos(e^x ? 2) cu ? = 10^(?5) pe intervalul x ? [0, 5; 1, 5].
    f = @(x) exp(x) - 2 - cos(exp(x) - 2);
    A = 0.5; 
    B = 1.5;
    eps = 10^(-5);
    ShowAproxBisectie(f,A,B,eps);
    fprintf('\n')
    
function ShowAproxBisectie(f,A,B,eps)
    [xaprox,N] = MetBisectie(f,A,B,eps);
    fprintf('Metoda Bisectiei\n')
    fprintf('Ecuatia e^x - 2 = cos(e^x - 2)\n')
    fprintf('Intervalul: [%5.2f,%5.2f]\n',A,B)
    fprintf('Eroarea : %5.2f\n',eps)
    fprintf('Xaprox = %4.2f\n',xaprox)
    fprintf('Numarul de iteratii: N = %3i\n',N)
    plot(xaprox,f(xaprox),'o','MarkerFaceColor','yellow','MarkerSize',7)
end

function [xaprox,N] = MetBisectie(f,A,B,eps)
    a(1) = A;
    b(1) = B;
    x(1) = (A+B)/2;
    N = floor(log2((B-A)/eps));
    for k=2:N+1
        if(f(x(k-1)) == 0)
            x(k) = x(k-1);
            break;
        elseif(f(a(k-1))*f(x(k-1)) < 0)
            a(k) = a(k-1);
            b(k) = x(k-1);
            x(k) = (a(k)+b(k))/2;
            % Aici ti-ai luat teapa! :( Ai dat break aiurea
            break;
        elseif(f(a(k-1))*f(x(k-1)) > 0)
            a(k) = x(k-1);
            b(k) = b(k-1);
            x(k) = (a(k)+b(k))/2;
        end
    end
    xaprox=x(k);
end
end