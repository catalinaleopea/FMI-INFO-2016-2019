% EXERCITIUL 4
% sqrt(3) cu eroarea ? = 10^(?5)
% 9/10 . cod Metoda Bisectiei... 
function Ex4
    f = @(x) x.^2 - 3;
    eps = 10^(-5);
    close all
    clc
    X = linspace(0,3,100);
    Y = f(X);
    p = [2 0 -3];
    r = roots(p);
    plot(X,Y,'Linewidth',3)
    hold on
    %plot(r(1),f(r(1)),'o','MarkerFaceColor','red','MarkerSize',7)
    ShowAproxBisectie(f,0,3,eps);
end

function ShowAproxBisectie(f,A,B,eps)
    [xaprox] = MetBisectie(f,A,B,eps);
    fprintf('Metoda Bisectiei\n')
    fprintf('Ecuatia x.^2 - 3 (adica sqrt(3))\n')
    fprintf('Intervalul: [%5.2f,%5.2f]\n',A,B)
    fprintf('Eroarea : %.5f\n',eps)
    fprintf('Xaprox = %4.2f\n',xaprox)
    plot(xaprox,f(xaprox),'o','MarkerFaceColor','yellow','MarkerSize',7)
end

function [xaprox] = MetBisectie(f,A,B,eps)
    a(1) = A;
    b(1) = B;
    x(1) = (A+B)/2;
    N = floor(log2((B-A)/eps));
    for k=2:N+1
        if(f(x(k-1)) == 0)
            x(k) = x(k-1);
            break;
        elseif(f(a(k-1))*f(x(k-1)) < 0)
            a(k) = a(k-1);
            b(k) = x(k-1);
            x(k) = (a(k)+b(k))/2;
            % Teapaaaaaaa! 
            break;
        elseif(f(a(k-1))*f(x(k-1)) > 0)
            a(k) = x(k-1);
            b(k) = b(k-1);
            x(k) = (a(k)+b(k))/2;
        end
    end
    xaprox=x(k);
end