% EXERCITIUL 2
% x^3 - 7x^2 + 14x - 6 = 0
% 9/10 -> vezi cod functie Metoda Bisectiei
% 1. 9 _unicitate?
% 2. 9
% 3. 9
% 4. 9
% 5. 10
% 6. -
% 7. -
% 8. -
% Total: 46/80 i.e. 5.75 :(


function Ex2
% B) graficul + rezultatele pentru intervalele 1. [0, 1]; 2. [1; 3, 2]; 3. [3, 2; 4].
f = @(x) x.^3 - 7*x.^2 + 14*x - 6;
A = 0;
B = 4;
eps = 10^(-5);
% Graficul
close all
clc
X = linspace(A,B,100);
Y = f(X);
p = [1 -7 14 -6];
r = roots(p);
plot(X,Y,'Linewidth',3)
hold on
%plot(r,f(r),'o','MarkerFaceColor','red','MarkerSize',7)
line(xlim(), [0,0], 'Linewidth', 1, 'Color', 'k');
grid on
xlabel('x')
ylabel('f(x) = x^3 - 7*x^2 + 14*x - 6')

% 1. [0, 1]
ShowAproxBisectie(f,0,1,eps);
fprintf('\n')
% 2. [1; 3, 2]
ShowAproxBisectie(f,1,3.2,eps);
fprintf('\n')
% 3. [3, 2; 4]
ShowAproxBisectie(f,3.2,4,eps);
fprintf('\n')

function ShowAproxBisectie(f,A,B,eps)
    [xaprox] = MetBisectie(f,A,B,eps);
    fprintf('Metoda Bisectiei\n')
    fprintf('Ecuatia f = x^3 - 7x^2 + 14x - 6 = 0')
    fprintf('Intervalul: [%5.2f,%5.2f]\n',A,B)
    fprintf('Eroarea : %5.2f\n',eps)
    fprintf('Xaprox = %4.2f\n',xaprox)
    plot(xaprox,f(xaprox),'o','MarkerFaceColor','yellow','MarkerSize',7)
end

% A) functia pentru Metoda Bisectiei
function [xaprox] = MetBisectie(f,A,B,eps)
    a(1) = A;
    b(1) = B;
    x(1) = (A+B)/2;
    N = floor(log2((B-A)/eps));
    for k=2:N+1
        if(f(x(k-1)) == 0)
            x(k) = x(k-1);
            break;
        elseif(f(a(k-1))*f(x(k-1)) < 0)
            a(k) = a(k-1);
            b(k) = x(k-1);
            x(k) = (a(k)+b(k))/2;
            % Aici iti iei teapa! 
            break;
        elseif(f(a(k-1))*f(x(k-1)) > 0)
            a(k) = x(k-1);
            b(k) = b(k-1);
            x(k) = (a(k)+b(k))/2;
        end
    end
    xaprox=x(k);
end
end