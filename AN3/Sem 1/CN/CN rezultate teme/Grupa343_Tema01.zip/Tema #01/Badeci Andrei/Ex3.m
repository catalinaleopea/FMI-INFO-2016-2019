% 10/10
function Ex3
    f1 = @(x) exp(x) - 2;
    f2 = @(x) cos(exp(x) - 2);
    X1 = linspace(0.5, 1.5, 100);
    Y1 = f1(X1);
    X2 = linspace(0.5, 1.5, 100);
    Y2 = f2(X2);
    close all;
    figure(1);
    plot(X1, Y1, 'Linewidth', 3);
    grid on;
    hold on;
    line(xlim, [0 0], 'color', 'k', 'linewidth', 1);
    line([0.5 0.5], ylim, 'color', 'k', 'linewidth', 1);
    xlabel('x');
    ylabel('y');
    title('Graficul funcitiei f(x) = exp(x) - 2');
    figure(2);
    plot(X2, Y2, 'Linewidth', 3);
    grid on;
    hold on;
    line(xlim, [0 0], 'color', 'k', 'linewidth', 1);
    line([0.5 0.5], ylim, 'color', 'k', 'linewidth', 1);
    xlabel('x');
    ylabel('y');
    title('Graficul funcitiei f(x) = cos(exp(x) - 2)');
    f3 = @(x) exp(x) - 2 - cos(exp(x) - 2);
    A = 0.5;
    B = 1.5;
    err = 10^(-5);
    X3 = linspace(0.5, 1.5, 100);
    Y3 = f3(X3);
    [xAprox] = MetBisectie(f3, A, B, err)
    figure(3);
    plot(X3, Y3, 'Linewidth', 3);
    grid on;
    hold on;
    line(xlim, [0 0], 'color', 'k', 'linewidth', 1);
    line([0.5 0.5], ylim, 'color', 'k', 'linewidth', 1);
    plot(xAprox, f3(xAprox), 'o', 'MarkerFaceColor', 'b', 'MarkerSize',10);
    xlabel('x');
    ylabel('y');
    title('Graficul funcitiei f(x) = exp(x) - 2 - cos(exp(x) - 2) si metoda bisectiei');
end