% Si solutia? Cat e sqrt(3) ?
% 4/10
function Ex4
    f = @(x) x.^2 - 3;
    X = linspace(1, 2, 100);
    Y = f(X);
    plot(X, Y, 'Linewidth', 3);
    grid on;
    xlabel('x');
    ylabel('y');
    title('Graficul funcitiei f(x) = x.^2 - 3 pe intervalul [1, 2]');
end