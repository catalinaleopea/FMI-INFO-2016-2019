% Nu face ce trebuie. Gaseste solutii care nu fac parte din domeniu
% 5/10
function Ex8
    f = @(x) x.^3 - 18 * x - 10;
    A = -5;
    B = 5;
    x0 = A;
    x1 = B;
    err = 10*(-3);
    [xAprox] = MetSecantei(f, A, B, x0, x1, err)
    [xAprox1] = MetPozFalse(f, A, B, err)
    x = linspace(A, B, 100);
    figure(1);
    plot(x, f(x), 'Linewidth', 3);
    hold on;
    grid on;
    xlabel('x');
    ylabel('y');
    line(xlim , [0 0], 'color', 'k', 'linewidth', 1);
    line([0 0], ylim, 'color', 'k', 'linewidth', 1);
    plot(xAprox, f(xAprox), 'o', 'MarkerFaceColor', 'b', 'MarkerSize', 10);
    figure(2);
    plot(x, f(x), 'Linewidth', 3);
    hold on;
    grid on;
    xlabel('x');
    ylabel('y');
    line(xlim , [0 0], 'color', 'k', 'linewidth', 1);
    line([0 0], ylim, 'color', 'k', 'linewidth', 1);
    plot(xAprox1, f(xAprox1), 'o', 'MarkerFaceColor', 'b','MarkerSize',10);
end