% NU ai ales subintervale. Ai gasit doar o solutie. :(
% 6/10
function Ex6
    f = @(x) x.^3 - 7*x.^2 + 14*x - 6;
    df = @(x) 3*x.^2 - 14*x + 14;
    A = 0;
    B = 4;
    x0 = 0;
    err = 10*(-3);
    X = linspace(A, B, 100);
    Y = f(X);
    [xAprox] = MetNR(f, df, x0, err)
    plot(X, Y, 'Linewidth', 3);
    hold on;
    grid on;
    line(xlim , [0 0], 'color', 'k', 'linewidth', 1);
    line([0 0], ylim, 'color', 'k', 'linewidth', 1);
    xlabel('x');
    ylabel('y');
    plot(xAprox, f(xAprox), 'o', 'MarkerFaceColor', 'b', 'MarkerSize', 10);
end