% 10/10

% Total all> 35/80 i.e. 4,38
function Ex2
    f = @(x) x.^3 - 7*x.^2 + 14*x - 6;
    A1 = 0;
    B1 = 1;
    A2 = 1;
    B2 = 3.2;
    A3 = 3.2;
    B3 = 4;
    err = 10^(-5);
    [xAprox1] = MetBisectie(f, A1, B1, err)
    [xAprox2] = MetBisectie(f, A2, B2, err)
    [xAprox3] = MetBisectie(f, A3, B3, err)
    X1 = linspace(A1, B1, 100);
    Y1 = f(X1);
    X2 = linspace(A2, B2, 100);
    Y2 = f(X2);
    X3 = linspace(A3, B3, 100);
    Y3 = f(X3);
    close all;
    figure(1)
    plot(X1, Y1, 'Linewidth', 3); 
    grid on;
    hold on;
    line(xlim, [0 0], 'color', 'k', 'linewidth', 1)
    line([0 0], ylim, 'color', 'k', 'linewidth', 1)
    plot(xAprox1, f(xAprox1), 'o', 'MarkerFaceColor', 'b','MarkerSize',10);
    xlabel('x');
    ylabel('y');
    title('Metoda bisectiei pe intervalul [0, 1]');
    figure(2);
    plot(X2, Y2, 'Linewidth', 3);
    grid on;
    hold on;
    line(xlim, [0 0], 'color', 'k', 'linewidth', 1)
    line([1 1], ylim, 'color', 'k', 'linewidth', 1)
    plot(xAprox2, f(xAprox2), 'o', 'MarkerFaceColor', 'b','MarkerSize',10);
    xlabel('x');
    ylabel('y');
    title('Metoda bisectiei pe intervalul [1, 3.2]');
    figure(3);
    plot(X3, Y3, 'Linewidth', 3); 
    grid on;
    hold on;
    line(xlim, [0 0], 'color', 'k', 'linewidth', 1)
    line([3.2 3.2], ylim, 'color', 'k', 'linewidth', 1)
    plot(xAprox3, f(xAprox3), 'o', 'MarkerFaceColor', 'b','MarkerSize',10);
    xlabel('x');
    ylabel('y');
    title('Metoda bisectiei pe intervalul [3.2, 4]');
end