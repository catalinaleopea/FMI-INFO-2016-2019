 ex-1 8/10 -> Verificarea ipotezelor metodei bisectiei + eroarea

fct1 = @(x) 8 * x.^3 + 4 * x - 1;
A = zeros(3);
B = zeros(3);
X = zeros(3);
A(1) = 0;
B(1) = 1;
for i = 1:2
    X(i) = (A(i) + B(i)) / 2;
    if(fct1(A(i)) * fct1(X(i)) < 0)
        B(i + 1) = X(i);
        A(i + 1) = A(i);
    else if (fct1(B(i)) * fct1(X(i)) < 0)
           B(i + 1) = B(i);
           A(i + 1) = X(i);
        else
            X(i + 1) = X(i);
        end
    end
end
error = fct1(X(2))

%% ex-2

figure;
fct2 = @(x) x.^3 - 7 * x.^2 + 14 * x - 6;
epsilon = 10 ^ -5;
x = linspace(0,4,100);
plot(x,fct2(x));
hold on;
line(xlim,[0 0]);
line([0 0],ylim);
estimateVal1 = MetBisectiei(fct2, 0, 1, epsilon);
estimateVal2 = MetBisectiei(fct2, 1, 3.2, epsilon);
estimateVal3 = MetBisectiei(fct2, 3.2, 4, epsilon);
plot(estimateVal1, fct2(estimateVal1), 'o', 'MarkerSize', 10);
plot(estimateVal2, fct2(estimateVal2), 'o', 'MarkerSize', 10);
plot(estimateVal3, fct2(estimateVal3), 'o', 'MarkerSize', 10);
hold off;
clear all;

%% ex-3

fct1 = @(x) exp(1) .^ x - 2;
fct2 = @(x) cos(fct1(x));
X = linspace(1, 3, 100);
plot(X, fct1(X));
hold on;
plot(X, fct2(X));

f = @(x) fct1(x) - fct2(x); 
epsilon = 10 ^ (-5);
figure;
hold on;
X = linspace(0.5, 1.5, 100);
estimateVal = MetBisectiei(f, 0.5, 1.5, epsilon);
plot(estimateVal, f(estimateVal),'o');

%% ex-4

figure
hold on;
f =@(x) x .^ 2 - 3;
X = linspace(0, 3, 100);
epsilon = 10 ^ (-5);
estimateVal = MetBisectiei(f, 0, 3, epsilon);
plot(estimateVal, f(estimateVal), 'o');

%% ex-5

f = @(x) x .^ 3 - 7 * (x .^ 2) + 14 * x - 6;
derf = @(x) 3 * (x .^ 2) - 14 * x + 14;
X = linspace(0, 2.5, 100);
epsilon = 10 ^ (-5);
figure;
hold on;
plot(X,f(X));
line(xlim, [0 0]);
estimateVal = MetNR(f, derf, 0, epsilon);
plot(estimateVal, f(estimateVal));

%% ex-6

X = linspace(0, 4, 1000);
epsilon = 10 ^ (-3);
f = @(x) x .^ 3 - 7 * (x .^ 2) + 14 * x - 6;
derf = @(x) 3 * (x .^ 2) - 14 * x + 14;

figure;
hold on;
plot(X,f(X));
line(xlim,[0 0]);
line([0 0],ylim);
estimateVal1 = MetNR(f, derf, 1.2, epsilon);
estimateVal2 = MetNR(f, derf, 2.6, epsilon);
estimateVal3 = MetNR(f, derf, 3.5, epsilon);
plot(estimateVal1, f(estimateVal1), 'o', 'MarkerSize', 10);
plot(estimateVal2, f(estimateVal2), 'o', 'MarkerSize', 10);
plot(estimateVal3, f(estimateVal3), 'o', 'MarkerSize', 10);

% % ex-7
%a) ec. are solutie unica pentru ca:  f(0)*f(1)<0 & f(1)*f''(1)>0, 0<x0=1<=1
%b)
figure;
hold on;
f = @(x) 8 * (x .^ 3) + 4 * x - 1;
derf = @(x) 24 * (x .^ 2) + 4;

line(xlim,[0 0])
line([0 0],ylim)
epsilon = 10 ^ (-5);
X = linspace(0, 1, 100);
estimateVal1 = MetNR(f, derf, 3, epsilon);
estimateVal2 = MetSec(f, 0, 1, 0, 1, epsilon);
estimateVal3 = MetPoz(f, 0, 1, epsilon);
plot(X, f(X));
plot(estimateVal1, f(estimateVal1), 'o', 'MarkerSize', 10);
plot(estimateVal2, f(estimateVal2), 'o', 'MarkerSize', 30);
plot(estimateVal3, f(estimateVal3), 'o', 'MarkerSize', 50);

%% ex-8
%a)
f = @(x) x.^3 - 18 * x - 10;
X = linspace(-5, 5, 1000);
figure;
plot(X,f(X));
hold on;
line(xlim,[0 0]);
line([0 0],ylim);

%d)
epsilon = 10 ^ -3;
estimateVal1 = MetSec(f, -5, -3, -5, -3, epsilon);
estimateVal2 = MetSec(f, -3, 0, -3, 0, epsilon);
estimateVal3 = MetSec(f, 4, 5, 4, 5, epsilon);
plot(estimateVal1, f(estimateVal1), 'o', 'MarkerSize', 10);
plot(estimateVal2, f(estimateVal2), 'o', 'MarkerSize', 10);
plot(estimateVal3, f(estimateVal3), 'o', 'MarkerSize', 10);

%e)
figure;
plot(X,f(X));
hold on;
line(xlim,[0 0]);
line([0 0],ylim);
estimateVal1 = MetPoz(f, -5, -3, epsilon);
estimateVal2 = MetPoz(f, -3, 0, epsilon);
estimateVal3 = MetPoz(f, 4, 5, epsilon);
plot(estimateVal1, f(estimateVal1), 'o', 'MarkerSize', 10);
plot(estimateVal2, f(estimateVal2), 'o', 'MarkerSize', 10);
plot(estimateVal3, f(estimateVal3), 'o', 'MarkerSize', 10);

%% 
function y = MetBisectiei(f, a, b, epsilon)
k = floor(log2((b - a) / epsilon))
A = zeros(k + 1);
B = zeros(k + 1);
X = zeros(k + 1);
A(1) = a;
B(1) = b;
for i = 1:k
    X(i) = (A(i) + B(i)) / 2;
    if(f(A(i)) * f(X(i)) < 0)
        B(i + 1) = X(i);
        A(i + 1) = A(i);
    else if (f(B(i)) * f(X(i)) < 0)
           B(i + 1) = B(i);
           A(i + 1) = X(i);
        else
            X(i + 1) = X(i);
        end
    end
end
y = X(k);
end

function y = MetNR(f, fD, x0, epsilon)
error = Inf;
x1 = 0;
while (error > epsilon)
    x1 = x0 - (f(x0) / fD(x0));
    error = abs(x1 - x0) / abs(x1);
    x0 = x1;
end
y = x1;
end

function y = MetPoz(f, a, b, epsilon)
i = a;
j = b;
x0 = (i * f(j) - j * f(i)) / (f(j) - f(i));
x1 = x0;
error = inf;
while (error > epsilon)
    x0 = x1;
    i = a;
    j = b;
    if (f(x0) == 0)
        x1 = x0;
        break;
    else if (f(i) * f(x0) < 0)
            a = i;
            b = x0;
            x1 = (a * f(b) - b * f(a)) / (f(b) - f(a));
        else if (f(i) * f(x0) > 0)
                a = x0;
                b = j;
                x1 = (a * f(b) - b * f(a)) / (f(b) - f(a));
            end
        end
    end
    error = abs(x1 - x0) / abs(x0);
end
y = x1;
end

function [y] = MetSec(f, a, b, x0, x1, epsilon)
k = 1;
while (abs(x1 - x0) / abs(x0) > epsilon)
    temp = x1;
    x1 = (x0 * f(x1) - x1 * f(x0)) / (f(x1) - f(x0));
    if (x1 < a || x1 > b)
        y = inf
        break
    end
    x0 = temp;
end
y = x1;
end