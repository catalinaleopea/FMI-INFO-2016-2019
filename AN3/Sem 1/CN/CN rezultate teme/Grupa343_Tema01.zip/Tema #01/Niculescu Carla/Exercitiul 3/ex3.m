% =========================================================================
% Fisier SCRIPT
% Ex 3.a.
% -------------------------------------------------------------------------
% Afiseaza graficele functiilor f1 si f2 compus cu f1 pe un interval [A, B]
% -------------------------------------------------------------------------
A=-5; B=5; %fixam capetele intervalului pe care vrem sa reprezentam graficele
           %celor doua functii 
           
% !!!!!!!!!!!!!!!!!!
% Atentie, sintagma inline e invechita. Foloseste f = @(x) expresie
% !!!!!!!!!!!!!!!!!!
f1 = inline('exp(x)-2', 'x'); %Declararea functiei f1 = e^x-2
f2 = inline('cos(x)', 'x');   %Declararea functiei f2 = cos(e^x-2)

x = linspace(A,B); %discretizarea intervalului A,B
y1 = f1(x);     %vector cu valorile functiei f1(x) = e^x-2
y2 = f2(y1);    %vector cu valorile functiei f2(y1) = f2(f1(x))
% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Graficele functiilor e^x-2 si cos(e^x-2)')
% -------------------------------------------------------------------------
%               Cele doua grafice cerute
% -------------------------------------------------------------------------
close all       %Inchide graficele anterioare
figure(1)
xlabel('x')
ylabel('y')
plot(x,y1,x,y2,':')  %plotare simultana a celor doua grafice
%--------------------------------------------------------------------------
% Ex 3.b.
% A rezolva ecuatia e^x-2 = cos(e^x-2) revine la a aplica metoda bisectiei
%pentru functia e^x-2 - cos(e^x-2) = f1(x) - f2(f1(x))
%--------------------------------------------------------------------------
%fixam capetele intervalului pe care se va aplica metoda bisectiei
A1 = 0.5;  
B1 = 1.5;
epsilon = 10^(-5);  % Seteaza eroarea dintre solutia numerica si cea exacta
f       = @(x) f1(x) - f2(f1(x));  % Declararea functiei 'f'
        % Asa! 

% Calculez solutia numerica si pasul de oprire apeland functia 'metBisectie'
% din fisierul 'metBisectie.m'
[xaprox, N] = metBisectie(f, A1, B1, epsilon); %calculam xaprox pe [A1,B1]
X       = linspace(A1, B1, 50); %discretizarea intervalului [A1,B1]
Y       =f(X);                 % Vector al valorilor lui f(X) 

% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Metoda: Bisectie')
disp('Ecuatia: e^x-2-cos(e^x-2) = 0')
fprintf('Intervalul: [%5.2f,%5.2f ]\n', A1, B1)
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutia numerica: xaprox = %4.2f\n', xaprox)
fprintf('Numarul de iteratii: N = %3i\n', N)
% -------------------------------------------------------------------------
%               Graficul functiei 'f' si solutia numerica 
% -------------------------------------------------------------------------
hold on
plot(X, Y, 'Linewidth', 4)   % Graficul functiei
plot(xaprox, f(xaprox), 'o','MarkerFaceColor','b','MarkerSize', 6)    % xaprox
hold off
xlabel('x')
ylabel('y')
legend('y1=exp(x)-2','y2=cos(exp(x)-2)','y3 = exp(x)-2-cos(exp(x)-2)', 'x aprox', 'Location', 'Northwest')
title('Grafice si Metoda Bisectiei')