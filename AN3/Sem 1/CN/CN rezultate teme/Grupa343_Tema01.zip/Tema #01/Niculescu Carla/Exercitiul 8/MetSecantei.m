% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'A'       = capatul din stanga al intervalului
% 'B'       = capatul din dreapta al intervalului 
% 'x0', 'x1'= primele doua valori din sirul aproximarilor calculat prin 
             %metoda secantei
             % valorile initiale x0,x1 se aleg din vecinatatea solutiei exacte,
             % astfel incat la ?ecare iteratie se testeaza ca termenul xk sa
             %ramana in intervalul [A,B]
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'    = solutia numerica data de metoda secantei
% -------------------------------------------------------------------------
function [xaprox] = MetSecantei(f, A, B, x0, x1, epsilon)
x(1) = x0;
x(2) = x1;
k = 2;
while abs(x(k) - x(k-1))/abs(x(k-1))>=epsilon
    k = k+1;
    x(k) = (x(k-2)*f(x(k-1)) - x(k-1)*f(x(k-2)))/(f(x(k-1)) - f(x(k-2)));
    if x(k)<A || x(k)>B
       fprintf('Introduceti alte valori pentru x0, x1');
    end
end
xaprox = x(k);
