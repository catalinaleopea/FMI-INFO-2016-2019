%8.a.
%Reprezentarea graficului functiei f pe intervalul [-5 5]
%--------------------------------------------------------------------------
f = @(x) x.^3-18*x-10;  % Declararea expresiei functiei f ca functie handle
x = linspace(-5,5,50); % Discretizarea intervalului [-5,5]
y = f(x);  % Vector al valorilor lui f(x)
% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Graficul functiei x^3-18*x-10')
fprintf('Intervalul: [-5,5]')
% -------------------------------------------------------------------------
%               Graficul functiei 'f'
% -------------------------------------------------------------------------
close all           % Inchide graficele anterioare
figure(1)
plot(x, y, '--r')   % Graficul functiei
xL = xlim; %xlim furnizeaza limitele axei Ox 
yL = ylim; %ylim furnizeaza limitele axei Oy 
line(xL, [0 0],'color','k','linewidth',2,'HandleVisibility','off') %axa Ox 
line([0 0], yL,'color','k','linewidth',2,'HandleVisibility','off') %axa Oy
xlabel('x')
ylabel('y')
%--------------------------------------------------------------------------
%8.d. 
%Aplic metoda secantei pentru 3 subintervale alese astfel incat sa respecte
%ipotezele din teorema I.3 din cursul 1

epsilon = 10^(-3);  % Seteaza eroarea dintre solutia numerica si cea exacta
%initializam capetele pentru fiecare dintre cele trei intervale alese 
% convenabil: [-5, -sqrt(6)-epsilon], [-sqrt(6)+epsilon, sqrt(6)-epsilon],
% [sqrt(6)+epsilon, 5] (epsilon este o valoare suficient de mica pentru
% care f(-sqrt(6)-epsilon)>0, f(-sqrt(6)+epsilon)>0, f(sqrt(6)-epsilon)<0
% si f(sqrt(6)+epsilon)<0 (ne dorim acest lucru pentru a respecta conditia
% f(a)*f(b)<0 pentru fiecare subinterval [a,b] ales)

A       = -5;       
B       = 5;        
A1      =-sqrt(6)-epsilon;
B1      =-sqrt(6)+epsilon;
C1      = sqrt(6)-epsilon;
D1      = sqrt(6)+epsilon;
D2      = (-1)*epsilon;
[xaprox1] = MetSecantei(f, A, A1, -4, -3, epsilon); %calculam xaprox pentru 
                                                    %intervalul [A,A1]
[xaprox2] = MetSecantei(f, B1, C1, 0, 1, epsilon);%calculam xaprox pe 
                                                  %intervalul [B1,C1]
[xaprox3] = MetSecantei(f, D1, B, 3, 4, epsilon);%calculam xaprox pe 
                                                 %intervalul [D1,B]
% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Metoda: Secantei')
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutia numerica1: xaprox1 = %4.2f\n', xaprox1)
fprintf('Solutia numerica2: xaprox2 = %4.2f\n', xaprox2)
fprintf('Solutia numerica3: xaprox3 = %4.2f\n', xaprox3)

% -------------------------------------------------------------------------
%           Reprezentarea solutiilor numerice pentru subintervale
% -------------------------------------------------------------------------
hold on             % Pastreaza in figura graficul
plot(xaprox1, f(xaprox1), 'o','MarkerFaceColor','b','MarkerSize', 10)% xaprox1
plot(xaprox2, f(xaprox2), 'o','MarkerFaceColor','b','MarkerSize', 10,...
                                    'HandleVisibility','off')    % xaprox2
plot(xaprox3, f(xaprox3), 'o','MarkerFaceColor','b','MarkerSize', 10,...
                                    'HandleVisibility','off')    % xaprox3
hold off
%--------------------------------------------------------------------------
%8.e.
%Aplic metoda pozitiei false pentru subintervalele [A,A1],[B1,D2],[D1,B]
[xaprox4] = MetPozFalse(f, A, A1, epsilon); %calculam xaprox pentru 
                                            %intervalul [A,A1]
[xaprox5] = MetPozFalse(f, B1, D2, epsilon);%calculam xaprox pe 
                                            %intervalul [B1,D2]
[xaprox6] = MetPozFalse(f, D1, B, epsilon);%calculam xaprox pe 
                                           %intervalul [D1,B]
% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Metoda: Pozitiei False')
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutia numerica1: xaprox1 = %4.2f\n', xaprox4)
fprintf('Solutia numerica2: xaprox2 = %4.2f\n', xaprox5)
fprintf('Solutia numerica3: xaprox3 = %4.2f\n', xaprox6)

% -------------------------------------------------------------------------
%           Reprezentarea solutiilor numerice pentru subintervale
% -------------------------------------------------------------------------
hold on             % Pastreaza in figura graficul
plot(xaprox4, f(xaprox4), 'o','MarkerFaceColor','y','MarkerSize', 6)    % xaprox1
plot(xaprox5, f(xaprox5), 'o','MarkerFaceColor','y','MarkerSize', 6)    % xaprox2
plot(xaprox6, f(xaprox6), 'o','MarkerFaceColor','y','MarkerSize', 6)    % xaprox3
hold off
 
legend('y = f(x)','x aprox met secantei','xaprox met poz falsa', ...
                                                   'Location', 'Northwest')
title('Metoda Secantei si Pozitiei False')