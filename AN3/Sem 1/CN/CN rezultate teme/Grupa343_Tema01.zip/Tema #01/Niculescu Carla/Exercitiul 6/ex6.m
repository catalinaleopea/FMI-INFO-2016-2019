% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unei functii 'f' pe un interval [A, B] si
% solutia numerica data de Metoda Newton-Raphson
% -------------------------------------------------------------------------
%initializam capetele pentru intervalul [0,4] pe care aplicam metoda
A       = 0;       
B       = 4;        
epsilon = 10^(-3);  %Seteaza eroarea dintre solutia numerica si cea exacta 
syms x              %creeaza variabila simbolica x
f = @(x) x.^3-7*x.^2+14*x-6 % Declararea functiei 'f'
df = eval(['@(x)' char(diff(f(x)))])%df este derivata de ordinul I a lui f 
                                    %in raport cu x
% Am ales cele 3 subintervale ale [0,4] si valorile x0 corespunzatoare 
% astfel incat sa fie respectate ipotezele teoremei I.2 din Cursul#1,
% conform calculelor din documentatie; 
% Calculez solutiile numerice pentru fiecare subinterval, apeland functia
%'metNR' din fisierul 'metNR.m';
[xaprox1] = metNR(f, df, 1/4, epsilon); %calculez xaprox1 pe primul subinterval
[xaprox2] = metNR(f, df, 2.5, epsilon) %calculez xaprox2 pe subintervalul II
[xaprox3] = metNR(f, df, 4, epsilon) %calculez xaprox1 pe subintervalul III

X       = linspace(A, B, 50);   % Discretizarea intervalului [0,4]
Y       = f(X);                 % Vector al valorilor lui f(X)

% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Metoda: Newton-Raphson')
disp('Ecuatia: x^3-7*x^2+14*x-6 = 0')
fprintf('Intervalul: [%5.2f,%5.2f ]\n', A, B)
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutia numerica1: xaprox1 = %4.2f\n', xaprox1)
fprintf('Solutia numerica2: xaprox2 = %4.2f\n', xaprox2)
fprintf('Solutia numerica3: xaprox3 = %4.2f\n', xaprox3)

% -------------------------------------------------------------------------
%               Graficul functiei 'f' si solutia numerica 
% -------------------------------------------------------------------------
close all           % Inchide graficele anterioare
figure(1)
plot(X, Y, '--r')   % Graficul functiei
grid on
hold on             % Pastreaza in figura graficul
plot(xaprox1, f(xaprox1), 'o','MarkerFaceColor','b','MarkerSize', 6)    % xaprox1
plot(xaprox2, f(xaprox2), 'o','MarkerFaceColor','b','MarkerSize', 6)    % xaprox2
plot(xaprox3, f(xaprox3), 'o','MarkerFaceColor','b','MarkerSize', 6)    % xaprox3

line(xlim, [0 0],'color','k','linewidth', 0.5)  % Axa Ox
hold off
xlabel('x')
ylabel('y')
title('Metoda Newton-Raphson')
legend('y = f(x)', 'x aprox', 'Location', 'Northwest')