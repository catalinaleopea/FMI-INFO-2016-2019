% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'= o functie declarata anterior
% 'df' = derivata de ordinul I a functiei f in raport cu variabila x
% 'x0' = prima valoare din sirul aproximarilor returnat de metoda N-R
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'  = solutia numerica data de metoda Newton-Raphson
% -------------------------------------------------------------------------
function [xaprox] = metNR(f, df, x0, epsilon)
x(1) = x0; %atribuim primului element din sirul aproximarilor valoarea x0
k=2;
x(k) = x(k-1) - f(x(k-1))/df(x(k-1)); %calculam x(2)
%in matlab am implementat structura do while prin while, cu verificarea 
%conditiei la inceputul iteratiei
while abs(x(k)-x(k-1))/abs(x(k-1))>=epsilon
    k=k+1;
    x(k) = x(k-1) - f(x(k-1))/df(x(k-1));
end
xaprox = x(k); %aproximarea data de metoda N-R este ultimul x(k) calculat
end
  