% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unei functii 'f' pe un interval [A, B] si
% solutia numerica data de Metoda Bisectiei
% -------------------------------------------------------------------------
%initializam capetele pentru fiecare dintre cele trei intervale: [0,1], 
%[1,3.2], [3.2,4]
A       = 0;       
B       = 4;        
A1      =3.2;
B1      =1;
epsilon = 10^(-5);  % Seteaza eroarea dintre solutia numerica si cea exacta
f       = @(x) x.^3-7*x.^2+14*x-6;  % Declararea functiei 'f'

% Calculez solutia numerica si pasul de oprire apeland functia 'metBisectie'
% regasite in fisierul 'metBisectie.m'
[xaprox1, N] = metBisectie(f, A, B1, epsilon); %calculam xaprox pe 
                                               %intervalul [0,1]
[xaprox2, N] = metBisectie(f, B1, A1, epsilon);%calculam xaprox pe 
                                               %intervalul [1,3.2]
[xaprox3, N] = metBisectie(f, A1, B, epsilon);%calculam xaprox pe 
                                               %intervalul [3.2,4]
x       = linspace(A, B, 50);   % Discretizarea intervalului [0,4]
y       = f(x);                 % Vector al valorilor lui f(x)

% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Metoda: Bisectie')
disp('Ecuatia: x^3-7*x^2+14*x-6 = 0')
fprintf('Intervalul: [%5.2f,%5.2f ]\n', A, B)
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutia numerica1: xaprox1 = %4.2f\n', xaprox1)
fprintf('Solutia numerica2: xaprox2 = %4.2f\n', xaprox2)
fprintf('Solutia numerica3: xaprox1 = %4.2f\n', xaprox3)
fprintf('Numarul de iteratii: N = %3i\n', N)

% -------------------------------------------------------------------------
%               Graficul functiei 'f' si solutia numerica 
% -------------------------------------------------------------------------
close all           % Inchide graficele anterioare
figure(1)
plot(x, y, '--r')   % Graficul functiei
hold on             % Pastreaza in figura graficul
plot(xaprox1, f(xaprox1), 'o','MarkerFaceColor','b','MarkerSize', 6)    % xaprox1
plot(xaprox2, f(xaprox2), 'o','MarkerFaceColor','b','MarkerSize', 6)    % xaprox2
plot(xaprox3, f(xaprox3), 'o','MarkerFaceColor','b','MarkerSize', 6)    % xaprox3

line(xlim, [0 0],'color','k','linewidth', 0.5)  % Axa Ox
hold off
xlabel('x')
ylabel('y')
title('Metoda Bisectiei')
legend('y = f(x)', 'x aprox', 'Location', 'Northwest')