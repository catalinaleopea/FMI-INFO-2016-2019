% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% O aproximare a valorii sqrt(3) se poate obtine rezolvand ecuatia 
% x^2 = 3 <=> x^2-3 = 0 
% Astfel, aplicam metoda bisectiei pentru functia f(x) = x^2-3 si afisam 
% solutia numerica obtinuta 
% -------------------------------------------------------------------------
% 1<3<4, atunci aplicand functia radical, obtinem 1<sqrt(3)<2
% initializam capetele de interval [A,B] astfel incat intervalul (1,2) 
% sa fie inclus in [A,B]
A = 1;       
B = 2;  
epsilon = 10^(-5);  % Seteaza eroarea dintre solutia numerica si cea exacta
f = @(x) x.^2-3; %declararea functiei f
% Calculez solutia numerica si pasul de oprire apeland functia 'metBisectie'
% regasite in fisierul 'metBisectie.m'
[xaprox, N] = metBisectie(f, A, B, epsilon); %calculam xaprox pe [A,B]
x       = linspace(A, B, 50);   % Discretizarea intervalului [A,B]
y       = f(x);                 % Vector al valorilor lui f(x)

% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Metoda: Bisectie')
disp('Ecuatia: x^2-3 = 0')
fprintf('Intervalul: [%5.2f,%5.2f ]\n', A, B)
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutia numerica: xaprox = %4.2f\n', xaprox)
fprintf('Numarul de iteratii: N = %3i\n', N)

% -------------------------------------------------------------------------
%               Aproximarea valorii sqrt(3)
% -------------------------------------------------------------------------
close all % Inchide graficele anterioare
figure(1)
xlim([0 2]);
yLim = ylim;
grid on
line(xlim, [0 0],'color','k','linewidth', 3)  % Axa Ox
line([0 0], yLim,'color','k','linewidth', 3)  % Axa Oy
hold on
%Reprezentarea solutiei pe grafic
plot(xaprox, f(xaprox),'o','MarkerFaceColor','g','MarkerSize',10) 
hold off
xlabel('x') 
ylabel('y') 
title('Aproximarea valorii sqrt(3)') 
