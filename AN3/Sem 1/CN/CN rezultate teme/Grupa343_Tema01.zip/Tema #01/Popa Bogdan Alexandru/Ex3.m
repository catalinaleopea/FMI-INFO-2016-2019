%Tema 1
%Ex3 10/10

y = @(x) exp(x) - 2; % functie handle pentru y1
Y = @(x) cos(exp(x) - 2); % functie handle pentru y2

a = 0; b = 3; % intervalul in care iau valori functiile y si Y

X = linspace(a,b,50); % discretizarea intervalului
Y1 = y(X); % valoarea numerica a lui y
Y2 = Y(X); % valoarea numerica a lui Y

plot(X,Y1,'LineWidth',3);   % graficul lui Y1 pe intervalul discretizat
hold on;
plot(X,Y2,'LineWidth',3); % graficul lui Y2 pe intervalul discretizat
hold on;

Z = @(x) y(x) - Y(x); % functie handle pentru e^x - 2 - cos(e^x - 2) = 0
A = 0.5; B = 1.5; % capetele intervalului in care z ia valori
epsilon = 10^-5;%eroarea numerica de la rezultatul aproximativ si cel reala

% aplicam metoda bisectiei pe intervalul [A,B]
[xaprox,N] = MetBisectie(Z,A,B,epsilon);
fprintf('Aproximarea solutiei ecuatiei e^x - 2 - cos(e^x - 2) = 0\n');
fprintf('este %f realizat in %i pasi\n',xaprox,N);