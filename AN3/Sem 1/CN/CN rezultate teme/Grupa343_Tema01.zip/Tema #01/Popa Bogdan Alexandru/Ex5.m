%Tema 1

%Ex 5 8/10 (argumentarea de la a))
syms x; %valoare symbolica pentru derivatele functiei f
f = @(x) x.^3 - 7*x.^2 + 14 * x - 6; %functie handle pentru ecuatia data
fd = matlabFunction( diff(f(x)) ); %derivata functiei f
fdd = matlabFunction( diff(fd(x)) ); %derivata functiei fd
x0 = 2; %valoare initiala
epsilon = 10^-5; %eroare

%Folosind metoda Newton-Rhapson obtinem solutia 3 deoarece, in urma
%algoritmului obtinem f(2) = 2 iar fd(2) = -2 avand urmatorul 
%xk = 3 (2 - 2/-2 = 3)
%ajunge la cazul de oprire xk+1 = 3 - 0/-1 = 3 => |3 - 3|/3 = 0 < epsilon
[xaprox,k] = MetNewtRaphs(f, fd, x0, epsilon);
fprintf('Aproximarea rezultata pentru x0 = 2 este xaprox = %f\n',xaprox);
fprintf('Realizat in %i pasi\n',k);

%Insa 3 nu converge la intervalul [0,2.5] deoarece avem f * f'' < 0
fprintf('f(2) * f``(2) = %5.2f\n',f(2) * fdd(2));

x0 = 0;
%Alegem x0 = 0 care apartine intervalului [0,2.5]
%Avem f * f'' >= 0
fprintf('f(0) * f``(0) = %5.2f\n',f(0) * fdd(0));

[x1aprox,k1] = MetNewtRaphs(f,fd,x0,epsilon);
fprintf('Aproximarea rezultatului pentru x0 = 0 este xaprox = %f\n',...
    x1aprox);
fprintf('Realizat in %i pasi\n',k1);
fprintf('xaprox apartine intervalului [0,2.5]?\n %s',...
mat2str(0 <= x1aprox <= 2.5));