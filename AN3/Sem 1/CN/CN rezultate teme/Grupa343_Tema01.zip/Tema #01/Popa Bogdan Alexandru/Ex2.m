%Tema 1

%ex 2 10/10

% Total 44/80 i.e. 5.5/10

%Grafic metoda bisectiei
f = @(x) x.^3 - 7*x.^2 + 14*x - 6;
A=0; B=4; eps = 10^(-5);
[xaprox,N]=MetBisectie(f,A,B,eps);
fprintf('Metoda: Bisectie\n')
fprintf('Ecuatia: f(x) = x^3 - 7*x^2 + 14*x - 6\n ')
fprintf('Intervalul: [%5.2f,%5.2f]\n', A,B)
fprintf('Eroarea: %5.2e\n',eps)
fprintf('Solutia aproximativa xaprox= %4.2f\n',xaprox)
fprintf('Numarul de iteratii: N = %3i\n',N)
X=linspace(A,B,100); %Discretizarea intervalului [A,B]
Y=f(X);
close all %Inchide figurile deschise de la rularile precedente

plot(X,Y,'Linewidth',3) %Constructia graficului functiei f(x)

intervale = [ [0,1],
    [1,3.2],
    [3.2,4] 
    ]; %Construim un vector cu intervalele care ne intereseaza


xrezaprox = [];
yrezaprox = [];

for i=1:length(intervale)
  linie = intervale(i,:); % luam fiecare interval in parte
  
  % aplicam metoda bisectiei pe interval
  [xlinie,R] = MetBisectie(f, linie(1), linie(2), eps); 
  % adaugam intervalele in vectorul de rezultate corespunzator
  xrezaprox = [xrezaprox, xlinie];
  yrezaprox = [yrezaprox, f(xlinie)];
end


grid on
hold on

%Construirea axelor de coordonate
xL = xlim; %xlim furnizeaza limitele axei Ox
yL = ylim; %ylim furnizeaza limitele axei Oy
line(xL, [0 0],'color','k','linewidth',3) %axa Ox
line([0 0], yL,'color','k','linewidth',3) %axa Oy

legend('f(x) = x^3 - 7*x^2 + 14*x - 6','Location','NorthWest');
%Reprezentarea solutiei pe grafic
plot(xrezaprox,yrezaprox,'o','MarkerFaceColor','g','MarkerSize',10) 


xlabel('x')
ylabel('y')
title('Metoda bisectiei')