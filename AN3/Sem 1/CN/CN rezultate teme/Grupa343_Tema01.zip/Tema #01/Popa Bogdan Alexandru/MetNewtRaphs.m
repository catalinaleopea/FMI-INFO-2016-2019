function [xaprox,k] = MetNewtRaphs(f, fd, x0, eps)
k = 0; 
  while true
    xk = x0 - f(x0) / fd(x0);
    if abs(xk - x0) < eps * abs(x0)
      break;
    end
    k = k + 1;
    x0 = xk;
  end
  xaprox = x0;
end