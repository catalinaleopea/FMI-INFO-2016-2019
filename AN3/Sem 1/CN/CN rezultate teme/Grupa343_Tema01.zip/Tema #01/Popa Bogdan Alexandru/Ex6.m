%Tema 1

%Ex6 9/10 (alegere intervale fara justificare matematica)
syms x; %valoare symbolica pentru derivatele functiei f
f = @(x) x.^3 - 7*x.^2 + 14 * x - 6; %functie handle pentru ecuatia data
fd = matlabFunction( diff(f(x)) ); %derivata functiei f
fdd = matlabFunction( diff(fd(x)) ); %derivata functiei fd

epsilon = 10^-5; %eroare
A = 0; B = 4; %capetele intervalului

X = linspace(A,B,100); %discretizarea intervalului [A,B]
Y = f(X);              %valorile pe care le ia functia f

plot(X,Y,'LineWidth',3); %graficul lui f

hold on;

intervale = [
    [0,1.5],
    [1.5,3.3],
    [3.3,4]
    ];% vector cu cele 3 intervale din intervalul [0,4]
valori = [
    0.5,
    2.4,
    3.9
    ];% cele 3 valori corespunzatoare fiecarui interval din intervale
solutii = []; %vectorul in care vor fi stocate solutiile

for i = 1:length(intervale) %parcurg cei 2 vectori (valori,intervale)
  interval = intervale(i, :); %trec prin toate intervalele pe rand
  a = interval(1); %capetele fiecarui interval
  b = interval(2);
  x0 = valori(i);%iau toate valorile pe rand
  
  if(f(a) * f(b) >= 0) %verific daca sunt indeplinite condiitle de la l1.2
      fprintf('f(%.2f) * f(%.2f) >= 0',a,b);
      continue;
  end
  if(f(x0) * fdd(x0) <= 0)
      fprintf('f(%.2f) * f``(%.2f) <= 0',x0,x0);
      continue;
  end
  %adaug solutiile in vectorul de solutii
  solutii = [solutii, MetNewtRaphs(f, fd, x0, epsilon)]; 
end

Y1 = f(solutii); %valorile functiei f in punctele stocate in solutii

plot(solutii,Y1,'ro'); % reprezentarea in grafic a punctelor din solutii

