%Tema 1

%Ex4 7/10
% Ai iesit din domeniul de definitie al functiei! 1 < sqrt(3) < 2.


A = 2; B = 4;%declaram intervalul in care este cuprinsa valoarea lui sqrt(3)

f = @(x) x^2 - 3;%consideram ca solutia cautata ne ofera un x^2 = 3
epsilon = 10^-5; %eroarea                                                                                   
%pentru ca 2 < 3 < 4 spunem ca sqrt(2) < sqrt(3) < sqrt(4)
%adica putem aproxima sqrt(3) in intervalul (2,4)

%aplic metoda bisectiei pe intervalul (sqrt(A),sqrt(B))
[xaprox,N] = MetBisectie(f,sqrt(A),sqrt(B),epsilon);

fprintf('Am obtinut aproximarea pentru sqrt(3) = %f cu o eroare de %1.0e\n'...
    ,xaprox,epsilon);

