
%a
x = linspace(0.5,1.5,100);
y1 = exp(x) - 2;
y2 = cos(exp(x)-2);
plot(x,y1,x,y2);

%b
a = 0.5;
b = 1.5;
e = 10 ^ (-5);

f = @(x) exp(x) - 2 - cos(exp(x) - 2);
xaprox = MetBisectie(f,a,b,e);


%xax = linspace(a,b,100);
%yax = f(xax);

%figure(1);
%plot(xax,yax,'--b');
%hold on
%plot(xaprox,f(xaprox),'o','MarkerFaceColor','g','MarkerSize',10);