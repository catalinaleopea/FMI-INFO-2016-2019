function xaprox = MetNR(f,f2,x0,e)
k = 1;
x(1) = x0;
aux = 1;

while aux == 1
    k = k + 1;
    x(k) = x(k-1) - f(x(k-1))/f2(x(k-1));
    
    if abs(x(k)-x(k-1))/abs(x(k-1)) >= e
        aux = 0;
    end
end
xaprox = x(k);

end