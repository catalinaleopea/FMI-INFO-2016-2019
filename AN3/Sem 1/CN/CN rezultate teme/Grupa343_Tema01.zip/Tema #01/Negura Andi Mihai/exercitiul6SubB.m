%subpunctul b de la exercitiul 6
%syms y(x);
%f = 2*y^2;
%D = functionalDerivative(f,y)
% x2 nu este ok
% 8/10 

f = @(x) x.^3 - 7*x.^2 + 14*x - 6;

xi = linspace(0,4,100);
yi = f(xi);
plot(xi,yi)

%f2 = functionalDerivative(f,x);
f2 = @(x) 2*x.^2 - 14*x + 14;
e = 10 ^ (-3);

x1 = MetNR(f,f2,0,e);
x2 = MetNR(f,f2,1,e);
x3 = MetNR(f,f2,3.2,e);