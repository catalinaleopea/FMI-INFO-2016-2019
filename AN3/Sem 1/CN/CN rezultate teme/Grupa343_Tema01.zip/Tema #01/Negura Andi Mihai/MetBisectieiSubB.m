%aici de fapt nu e doar subpunctul b
%e intreg exercitiul 2 

% 1. -
% 2,3,4 -> 10/10
% 5. -
% 6. 8
% 7. -
% 8. 7
% Total: 45/80 i.e. 5.63

f = @(x) x.^3 - 7*x.^2 + 14*x - 6;
e = 10 ^(-5);

a2 = 1;
b2 = 3.2;

x2 = MetBisectie(f,a2,b2,e);


a3 = 0;
b3 = 1;

x3 = MetBisectie(f,a3,b3,e);


a4 = 3.2;
b4 = 4;

x4 = MetBisectie(f,a4,b4,e);

xax = linspace(0,4,100);
yax = f(xax);
figure(1);
plot(xax,yax,'--b');

grid on;
hold on;

xl = xlim;
yl = ylim;
line (xl,[0 0],'color','k','linewidth',3);
line ([0 0],yl,'color','k','linewidth',3);
plot(x2,f(x2),'o','MarkerFaceColor','g','MarkerSize',10);
hold on;
plot(x3,f(x3),'o','MarkerFaceColor','r','MarkerSize',10);
hold on;
plot(x4,f(x4),'o','MarkerFaceColor','b','MarkerSize',10);

xlabel('x')
ylabel('y')