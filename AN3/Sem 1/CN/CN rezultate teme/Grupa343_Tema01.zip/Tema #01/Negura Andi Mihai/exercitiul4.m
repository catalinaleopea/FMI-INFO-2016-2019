
f = @(x) x.^2 -3;
a = 0;
b = 10;
e = 10 ^ (-5);

xaprox2 = MetBisectie(f,a,b,e);

xax = linspace(a,b,100);
yax = f(xax);

figure(1);
plot(xax,yax,'--b');
hold on
plot(xaprox2,f(xaprox2),'o','MarkerFaceColor','g','MarkerSize',10);