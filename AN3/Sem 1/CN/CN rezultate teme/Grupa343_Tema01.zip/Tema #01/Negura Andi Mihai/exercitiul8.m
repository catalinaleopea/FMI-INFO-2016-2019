f = @(x) x.^3 - 18 * x - 10;

x1 = linspace(-5,5,100);
y1 = f(x1);

plot(x1,y1);