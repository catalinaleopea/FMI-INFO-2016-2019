% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'a'       = capatul din stanga al intervalului
% 'b'       = capatul din dreapta al intervalului 
% 'err' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'x_aprox'    = solutia numerica data de metoda Bisectiei
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
function [x_aprox] = MetBisectie(f, a, b, err)
    a_prec = a;                             % Scrie capatul din stanga
    b_prec = b;                             % Scrie capatul din dreapta
    x_prec = (a + b) / 2;                   % Calculeaza x0
    N = floor(log2((b - a) / err) - 1) + 1; % Criteriul de oprire
    
    for k = 1:N
            if f(x_prec) == 0
                break;
            elseif f(a_prec) * f(x_prec) < 0
                b_prec = x_prec;
                x_prec = (a_prec + b_prec) / 2;
            elseif f(a_prec) * f(x_prec) > 0
                a_prec = x_prec;
                x_prec = (a_prec + b_prec) / 2;
            end
    end
    x_aprox = x_prec;
end