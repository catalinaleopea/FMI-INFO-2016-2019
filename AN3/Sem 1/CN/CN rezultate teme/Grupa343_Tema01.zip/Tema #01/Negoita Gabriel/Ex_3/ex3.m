% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul functiilor y1 si y2 cerute in cerinta si calculez
% aproximarea numerica pentru functia data
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
% 10/10
x = 0.5 : 0.01 : 1.5;						% Discretizam intervalul [0.5 ; 1.5]
y1 = exp(x) - 2;							% Calculam functia exp(x) - 2 pe intervalul dat
y2 = cos(exp(x) - 2);						% Calculam functia cos(exp(x) - 2) pe intervalul dat

figure								
plot(x,y1);									% Plotam functia exp(x) -2

figure
plot(x,y2);									% Plotam functia cos(exp(x) - 2)

f = @(x)exp(x) - 2 - cos(exp(x) - 2);		% Initializam functia data cu un handle
disp(MetBisectie(f, 0.5, 1.5, 10^(-5)));	% Afisam aproximarea numerica