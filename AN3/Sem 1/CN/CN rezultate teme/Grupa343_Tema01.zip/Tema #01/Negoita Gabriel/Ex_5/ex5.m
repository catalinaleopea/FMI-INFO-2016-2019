% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Testez enuntul problemei cu presupunerea ca exista un punct de inflexiune
% apropiat de 2
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
% 9/10 -> argumentare
f = @(x) x.^3 - 7*x.^2 + 14*x - 6;      % Functia data
df = @(x) 3*x.^2 - 14*x + 14;           % Prima derivata
ddf = @(x) 6*x - 14;                    % A doua derivata
x = 0 : 0.01 : 2.5;
y = f(x);
plot(x,y);
disp(MetNR(f,df,1.45,10^(-5)));
disp(f(2.3));
disp(df(2.3));
disp(ddf(2.3));