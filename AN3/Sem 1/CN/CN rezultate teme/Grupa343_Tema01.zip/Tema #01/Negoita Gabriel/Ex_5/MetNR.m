% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'df'      = derivata de ordinul 1 a functiei f
% 'x0'      = un punct din interval in care f(x0) * f''(x0) > 0
% 'err'     = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'x_aprox'    = solutia numerica data de metoda Newton-Raphson
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
function [x_aprox] = MetNR(f, df, x0, err)
    x_pred = x0;
    x = x_pred - f(x_pred) / df(x_pred);
    
    while abs(x - x_pred) / abs(x_pred) >= err
        x_pred = x;
        x = x_pred - f(x_pred) / df(x_pred);
    end
    
    x_aprox = x;
end