% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul functiei  pe intervalul [-5 ; 5] si afiseaza 3 solutii
% pe 3 intervale folosind MetSecantei si MetPozFalse
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
% 9/10
f = @(x)x.^3 - 18.*x - 10;                  % Functia data initializata cu un handle

a = -5;                                     % capatul stang al intervalului
b = 5;                                      % capatul drept al intervalului
x = a : 0.01 : b;                           % discretizarea intervalului
y = f(x);                                   % calculul functiei pe intervalul dat
plot(x,y);                                  % plotarea functiei

hold on;                                    % hold on pentru a afisa cele 6 puncte

err = 10^(-3);                              % eroarea maxima

x1 = MetSecantei(f, a, b, -4, -3, err);
plot(x1, f(x1), 'r*');

x2 = MetSecantei(f, a, b, -1, 1, err);
plot(x2, f(x2), 'r*');

x3 = MetSecantei(f, a, b, 4, 5, err);
plot(x3, f(x3), 'r*');

x4 = MetPozFalse(f, -4, -3, err);
plot(x4, f(x4), 'go');

x5 = MetPozFalse(f, -1, 1, err);
plot(x5, f(x5), 'go');

x6 = MetPozFalse(f, 4, 5, err);
plot(x6, f(x6), 'go');