% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% 
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
% 8/10
% Cum ai ales intervalele? Doar convexitate?
f = @(x)x.^3 - 7.*x.^2 + 14.*x - 6;     % Initializam functia ceruta cu un handle
df = @(x)3.*x.^2 - 14.*x +14;           % Calculam derivata 1
ddf = @(x)6.*x - 14;                    % Calculam derivata 2

x = 0 : 0.01 : 4;                       % Discretizam intervalul [0 ; 4]
y = f(x);                               % Calculam functia pe intervalul dat
plot(x,y);                              % Plotam functia

err = 10^(-3);                          % Initializam eroarea maxima

disp('intervalul [0.5, 1]');            
disp(f(0.5));
x0 = 0.5;                               % Alegem x0 = 0.5 pentru ca f concava si f(0.5) < 0
disp(MetNR(f,df,x0,err));

disp('intervalul [2.5, 3.1]');
disp(f(2.5));
x0 = 2.5;                               % Alegem x0 = 2.5 pentru ca f convexa si f(2.5) > 0
disp(MetNR(f,df,x0,err));

disp('intervalul [3.3, 3.5]');
disp(f(3.3));
x0= 3.3;                                % Alegem x0 = 3.3 pentru ca f concava si f(3.3) < 0
disp(MetNR(f,df,x0,err));