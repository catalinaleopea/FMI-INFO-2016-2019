% Nu gasesti x_2 ci x numeric dat de fiecare metoda in parte. Atentie la
% cerinta. Unicitatea?
% 6/10
f = @(x) 8*x.^3 + 4*x - 1;
df = @(x) 24*x.^2 + 4;
x = 0 : 0.001 : 1;
y = f(x);
err = 10^(-10);
plot(x,y);
disp(f(0));
disp(f(1));
disp(MetNR(f,df,0,err));