% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'a'       = capatul din stanga al intervalului
% 'b'       = capatul din dreapta al intervalului
% 'err'     = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'x_aprox'    = solutia numerica data de metoda Newton-Raphson
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
function [x_aprox] = MetPozFalse(f,a,b,err)
    a_pred = a;
    b_pred = b;
    x_pred = (a_pred * f(b_pred) - b_pred * f(a_pred)) / (f(b_pred) - f(a_pred));
    x = x_pred;
    
    check = true;   % Variabila semafor pentru while
    while check
        if f(x_pred) == 0
            x = x_pred;
            check = false;
        elseif f(a_pred) * f(x_pred) < 0
            b_pred = x_pred;
            x_pred = x;
            x = (a_pred * f(b_pred) - b_pred * f(a_pred)) / (f(b_pred) - f(a_pred));
        elseif f(a_pred) * f(x_pred) > 0
            a_pred = x_pred;
            x_pred = x;
            x = (a_pred * f(b_pred) - b_pred * f(a_pred)) / (f(b_pred) - f(a_pred));
        end
        
        if abs(x - x_pred) / abs(x_pred) < err
            check = false;
        end
    end
    
    x_aprox = x;
end