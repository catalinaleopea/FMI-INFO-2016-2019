% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'a'       = capatul din stanga al intervalului
% 'b'       = capatul din dreapta al intervalului
% 'err'     = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'x_aprox'    = solutia numerica data de metoda Newton-Raphson
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
function [x_aprox] = MetSecantei(f, a, b, x0, x1, err)
    x_pred = x0;
    x = x1;
    
    while abs(x - x_pred) / abs(x_pred) >= err
        x_ppred = x_pred;
        x_pred = x;
        x = (x_ppred * f(x_pred) - x_pred * f(x_ppred)) / (f(x_pred) - f(x_ppred));
        if x < a || x > b
            disp('Introduceti alte valori pentru x0 si x1');
            break;
        end
    end
    
    x_aprox = x;
end