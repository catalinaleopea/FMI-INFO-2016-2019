% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unei functii 'f' pe un interval [A ; B] si
% solutia numerica data de Metoda Bisectiei
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
% 10/10
% Exercitiul 1?
% Total 64/80 i.e. 8
f = @(x) x.^3 - 7.*x.^2 + 14.*x -6;		% Initializez functia f
x = 0 : 0.01 : 4;                       % Intervalul [0 ; 4]
y = f(x);
plot(x,y);                              % Plotam functia pe [0 ; 4]

disp('[0,1]');
x1 = MetBisectie(f, 0, 1, 10^(-5));     % Calculam solutia aproximativa pe intervalul [0 ; 1]
disp(x1);                               % Afisam solutia aproximativa

disp('[1, 3.2]');
x2 = MetBisectie(f, 1, 3.2, 10^(-5));   % Calculam solutia aproximativa pe intervalul [1 ; 3.2]
disp(x2);                               % Afisam solutia aproximativa

disp('[3.2, 4]');
x3 = MetBisectie(f, 3.2, 4, 10^(-5));   % Calculam solutia aproximativa pe intervalul [3.2 ; 4]
disp(x3);                               % Afisam solutia aproximativa

% -------------------------------------------------------------------------
%               Punctul c) plotam xaprox si f(xaprox) in acelasi grafic
% -------------------------------------------------------------------------
hold on
x_aprox = [x1,x2,x3];                   % Intializam vectorul x_aprox cu valorile calculate anterior                 
y_aprox = f(x_aprox);                   % Calculam f(x_aprox)
plot(x_aprox,y_aprox,'*');

hold off