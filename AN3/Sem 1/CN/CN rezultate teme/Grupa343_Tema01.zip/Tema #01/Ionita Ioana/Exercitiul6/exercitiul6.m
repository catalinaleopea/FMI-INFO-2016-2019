% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unei functii 'f' pe 3 subintervale ale unui interval
% [A,B] si valorile solutiilor numerice calculate folosit Metoda 
% Newton-Raphson.
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================

%exercitiul 6, subpunctul b)
f = @(x) x.^3 - 7*(x.^2) + 14*x - 6;    %declararea functiei 'f'
A = 0;                                  %capatul inferior al intervalului
B = 4;                                  %capatul superior al intervalului
X = linspace(A, B, 10);                 %discretizarea intervalului
Y = f(X);                               %vector al valorilor lui f(X)
% -------------------------------------------------------------------------
%                   Graficul functiei 'f' 
% -------------------------------------------------------------------------
figure(1)
plot(X, Y, '-b');

df = @(x) 3*x.^2 - 14*x +14;        %derivata functiei 'f'
%Am ales subintervalul [0, 1], vazand ca exista o solutie a ecuatiei in
%acel subinterval si am ales x0 cat mai apropiat de 1.
X01 = 1;                        %o valoare din [0, 1] care respecta 
                                %ipotezele met NR
epsilon = 10^(-3);              %eroarea dintre solutia numerica si cea exacta
[xaprox1] = MetNR(f, df, X01, epsilon); %solutia numerica

hold on                         %adaug punctul gasit pe acelasi grafic
plot(xaprox1, f(xaprox1), 'o','MarkerFaceColor','b','MarkerSize',10);
hold off

% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% intervalul [2, 3]
X02 = 3.1;                        %o valoare din [2, 3] care respecta ipotezele
                                %met NR
[xaprox2] = MetNR(f, df, X02, epsilon); %solutia numerica
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

hold on                         %adaug punctul gasit pe acelasi grafic
plot(xaprox2, f(xaprox2), 'o', 'MarkerFaceColor', 'g', 'MarkerSize', 10);
hold off
%intervalul [3, 4]
X03 = 4;                        %o valoare din [3, 4] care respecta 
                                %ipotezele met NR
[xaprox3] = MetNR(f, df, X03, epsilon); %solutia numerica

hold on
plot(xaprox3, f(xaprox3), 'o', 'MarkerFaceColor', 'y', 'MarkerSize', 10);
hold off
grid on
xlabel('x');
ylabel('y = f(x)');
legend('y=f(x)', 'xNumeric1', 'xNumeric2', 'xNumeric3', 'Location', 'SouthEast');