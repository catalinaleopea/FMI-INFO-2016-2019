% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'df'      = derivata functiei 'f'
% 'x0'      = o valoare din intervalul pe care este definita 'f' a.i.
%           = daca functia este convexa f(x0)>0
%           = daca functia este concava f(x0)<0
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'    = solutia numerica data de metoda Newton-Raphson
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ xaprox ] = MetNR( f, df, x0, epsilon )
k=1;            %valoarea pasul curent
x(1)=x0;        %initializez prima valoare a vectorului x
cond=1;         %contor care determina cat timp continui algoritmul,
                %neavand un numar prestabilit de pasi (o conditie de oprire
                %cunoscuta dinainte)
while cond == 1 
     k=k+1;     
     x(k) = x(k-1) - f(x(k-1))/df(x(k-1));
     if abs((x(k) - x(k-1))/x(k-1)) < epsilon   %daca gasesc o solutie 
                                                %numerica care se apropie 
                                                %de cea exacta
            cond = 0;                           %opresc executia
     end
end
xaprox = x(k);
end

