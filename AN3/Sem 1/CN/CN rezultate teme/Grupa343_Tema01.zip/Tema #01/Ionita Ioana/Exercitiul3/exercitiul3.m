% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unor functii 'f1' si 'f2' pe 2 intervale distincte 
% si apoi calculeaza solutia numerica a unei functii 'f' folosind Metoda
% Bisectiei.
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================

f1 = @(x) exp(x) - 2;       %declararea functiei 'f1'
A1 = 0;                     %capatul inferior al intervalului pe care e
                            %e definita functia f1
B1 = 4;                     %capatul superior al intervalului
X1 = linspace(A1, B1, 10);  %discretizarea intervalului [A1, B1]
Y1 = f1(X1);                %vector al valorilor lui f1(X1)
% -------------------------------------------------------------------------
%                   Graficul functiei 'f1' 
% -------------------------------------------------------------------------
close all                   % Inchide graficele anterioare
figure(1)   
plot(X1, Y1, '-r');         %graficul functiei f1
xlabel('x');
ylabel('y = f(x)');
hold on                     %pastreaza in figura graficul
% -------------------------------------------------------------------------
%                   Graficul functiei 'f2' 
% -------------------------------------------------------------------------
f2 = @(x) cos(exp(x)-2);    %declararea functiei 'f2'
A2 = 0;                      %capatul inferior al intervalului pe care e
                            %e definita functia f2
B2 = 5*pi/4;                %capatul superior al intervalului
X2 = linspace(A2, B2, 10);  %discretizarea intervalului [A2, B2]
Y2 = f2(X2);                %vector al valorilor lui f2(X2)
plot(X2, Y2, '--b');        %graficul functiei f2
hold off                    
legend('y=e^x-2', 'y=cos(e^x-2)', 'Location', 'SouthEast');
%------------------------------------------------------------
%Subpunctul b
%e^x - 2 = cos(e^x - 2) se poate scrie:
% cos(e^x-2) - e^x + 2 = 0
f = @(x) cos(exp(x) - 2) - exp(x) + 2;  %declararea functiei 'f'
A = 0.5;                                %capatul inferior al intervalului 
                                        %pe care e definita functia f
B = 1.5;                                %capatul superior
epsilon = 10^(-5);                      %eroarea dintre solutia numerica
                                        %si cea exacta
[xaprox, N] = MetBisectie(f, A, B, epsilon);    %xnumeric
% -------------------------------------------------------------------------
%               Mesaje in consola cu solutia numerica
% -------------------------------------------------------------------------
disp('Valoarea aproximata a lui xNumeric este') 
disp(xaprox)
