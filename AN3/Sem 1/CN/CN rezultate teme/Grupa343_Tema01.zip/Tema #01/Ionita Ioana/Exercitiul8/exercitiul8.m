% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unei functii 'f' pe un interval [A, B] si
% determina, folosind pe rand metoda Secantei si metoda Pozitiei False, 
% considerand 3 intervale distincte, valorile solutiilor numerice
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
%exercitiul 8, subpunctul a)
f = @(x) x.^3 - 18*x - 10;      %definirea functiei
A = -5;                         %capatul inferior al intervalului pe care e 
                                %definita f
B = 5;                          %capatul superior
X = linspace(A, B, 10);         %discretizarea intervalului
Y = f(X);                       %vectorul de valori f(X)    
% -------------------------------------------------------------------------
%               Graficul functiei 'f' si solutiile numerice 
% -------------------------------------------------------------------------
figure(1)
plot(X, Y, '-b');               %graficul functiei
grid on

%subpunctul d) Metoda Secantei
%intervalul 1: [-5, -2]
epsilon = 10^(-3);   %seteaza eroarea dintre solutia numerica si cea exacta
[xaprox1] = MetSec(f, -5, -2, -4.5, -2.5, epsilon); %solutia numerica
%adaug punctul pe aceeasi figura
hold on             
plot(xaprox1, f(xaprox1), 'p', 'MarkerFaceColor', 'r', 'MarkerSize', 10);
hold off

%intervalul 2: [-2, 0]
[xaprox2] = MetSec(f, -2, 0, -1.5, -0.5, epsilon); %solutia numerica
%adaug punctul pe aceeasi figura
hold on         
plot(xaprox2, f(xaprox2), 'p', 'MarkerFaceColor', 'g', 'MarkerSize', 10);
hold off

%intervalul 3: [1, 5]
[xaprox3] = MetSec(f, 1, 5, 1, 5, epsilon);     %solutia numerica
%adaug noul punct pe aceeasi figura
hold on
plot(xaprox3, f(xaprox3), 'p', 'MarkerFaceColor', 'm', 'MarkerSize', 10);
hold off

%Creez o figura noua pentru calculele efectuate cu metoda Pozitiei False
figure(2)
plot(X, Y, '-b');           %graficul functiei f
grid on

%Metoda Pozitiei False
%intervalul 1: [-5, -2]
[xaprox4] = MetPozFalse(f, -5, -2, epsilon);    %solutia numerica
%adaug punctul pe aceeasi figura cu graficul functiei
hold on 
plot(xaprox4, f(xaprox4), 'o', 'MarkerFaceColor', 'r', 'MarkerSize', 10);
hold off

%intervalul 2: [-2, 0]
[xaprox5] = MetPozFalse(f, -3, 0, epsilon); %solutia numerica
%adaug punctul pe aceeasi figura cu graficul functiei
hold on
plot(xaprox5, f(xaprox5), 'o', 'MarkerFaceColor', 'g', 'MarkerSize', 10);
hold off

%intervalul 3: [1, 5]
[xaprox6] = MetPozFalse(f, 0, 5, epsilon);  %solutia numerica
%adaug punctul pe aceeasi figura cu graficul functiei
hold on
plot(xaprox6, f(xaprox6), 'o', 'MarkerFaceColor', 'm', 'MarkerSize', 10);
hold off