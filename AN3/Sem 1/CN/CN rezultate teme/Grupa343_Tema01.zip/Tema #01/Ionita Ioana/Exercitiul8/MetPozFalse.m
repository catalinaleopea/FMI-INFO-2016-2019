% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'A'       = capatul din stanga al intervalului
% 'B'       = capatul din dreapta al intervalului 
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'    = solutia numerica data de metoda Pozitiei False
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ xaprox ] = MetPozFalse( f, A, B, epsilon )
k = 0;      %pasul curent
a(1) = A;   %salvez in vectorii a, b valorile capetelor initiale ale 
b(1) = B;   %intervalului
x(1) = (a(1)*f(b(1)) - b(1)*f(a(1)))/(f(b(1))-f(a(1)));
k = 2;
if f(x(k-1)) == 0
    x(k) = x(k-1);
elseif f(a(k-1))*f(x(k-1)) < 0 
    a(k) = a(k-1);
    b(k) = x(k-1);
    x(k) = (a(k)*f(b(k))-b(k)*f(a(k)))/(f(b(k))-f(a(k)));
elseif f(a(k-1))*f(x(k-1)) > 0
    a(k) = x(k-1);
    b(k) = b(k-1);
    x(k) = (a(k)*f(b(k)) - b(k)*f(a(k)))/(f(b(k))-f(a(k)));
end
%La fiecare pas xk reprezinta intersectia segmentului determinat de 
%[Ak, Bk] cu axa OX, unde Ak = (ak, f(ak)) si Bk = (bk, f(bk))
while abs(x(k)-x(k-1))/abs(x(k-1))>=epsilon
    k = k+1;
    if f(x(k-1)) == 0
        x(k) = x(k-1);
    elseif f(a(k-1))*f(x(k-1)) < 0 
        a(k) = a(k-1);
        b(k) = x(k-1);
        x(k) = (a(k)*f(b(k))-b(k)*f(a(k)))/(f(b(k))-f(a(k)));
        elseif f(a(k-1))*f(x(k-1)) > 0
        a(k) = x(k-1);
        b(k) = b(k-1);
        x(k) = (a(k)*f(b(k)) - b(k)*f(a(k)))/(f(b(k))-f(a(k)));
    end
end
xaprox = x(k);  %salvez in xaprox valoarea solutiei numerice
end

