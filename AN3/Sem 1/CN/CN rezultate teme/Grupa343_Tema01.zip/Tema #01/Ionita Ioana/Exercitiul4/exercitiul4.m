% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Determina o aproximare a valorii sqrt(3) folosind Metoda Bisectiei.
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================

f = @(x) x^2 - 3;           %o functie care are ca solutie sqrt(3)
epsilon = 10^(-5);          %eroarea dintre solutia numerica si cea exacta
A = 1.5;                    %capatul inferior al intervalului in care este
                            %cuprins sqrt(3)
B = 2;                      %capatul superior al intervalului
[xaprox, N] = MetBisectie(f, A, B, epsilon);    %calculul solutiei numerice
                                                %si al pasului de oprire
% -------------------------------------------------------------------------
%               Afisarea in consola a valorii gasite
% -------------------------------------------------------------------------
disp('Valoarea aproximata a lui sqrt(3) este:')
disp(xaprox)
