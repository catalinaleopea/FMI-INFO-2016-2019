% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unei functii 'f' pe un interval [A, B] si
% solutia numerica data de Metoda Bisectiei
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================

f = @(x) x.^3 - 7*(x.^2) + 14*x - 6;    %functia a carei solutii doresc sa 
                                        % o determin
A = 0;                                  %capatul inferior al intervalului
B = 4;                                  %capatul superior al intervalului
X = linspace(A, B, 10);                 %discretizarea intervalului [A, B]
Y = f(X);                               %vector al valorilor lui f(X)
epsilon = 10^(-5);                      %eroarea dintre solutia numerica
                                        %si cea exacta
% -------------------------------------------------------------------------
%               Graficul functiei 'f' si solutia numerica 
% -------------------------------------------------------------------------
close all           % inchide graficele anterioare
figure(1) 
plot(X, Y, '--r');  %graficul functiei
xlabel('x');        
ylabel('y = f(x)');

A1 = 0;             %aleg un subinterval 
B1 = 1;             
[xaprox1, N1] = MetBisectie(f, A1, B1, epsilon);    %calculez xnumeric
hold on             %pastreaza tot in figura 1 punctul gasit
plot(xaprox1, f(xaprox1), 'o','MarkerFaceColor','b','MarkerSize',10);
hold off

A2 = 1;             %aleg un alt subinterval 
B2 = 3.2;           
[xaprox2, N2] = MetBisectie(f, A2, B2, epsilon);    %calculez xnumeric
hold on             %pastreaza tot in figura 1 punctul gasit
plot(xaprox2, f(xaprox2), 'o','MarkerFaceColor','g','MarkerSize',10);
hold off

A3 = 3.2;           %aleg un al treilea subinterval 
B3 = 4;            
[xaprox3, N3] = MetBisectie(f, A3, B3, epsilon);    %calculez xnumeric
hold on             %pastrez noul punct tot in figura 1
plot(xaprox3, f(xaprox3), 'o', 'MarkerFaceColor', 'y', 'MarkerSize', 10);
hold off
legend('y = f(x)','xNumeric1', 'xNumeric2', 'xNumeric3', 'Location', 'SouthEast')
%--------------------------------------------------------------------------