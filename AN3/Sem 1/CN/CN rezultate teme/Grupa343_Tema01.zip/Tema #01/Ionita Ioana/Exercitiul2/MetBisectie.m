% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'A'       = capatul din stanga al intervalului
% 'B'       = capatul din dreapta al intervalului 
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'    = solutia numerica data de metoda bisectiei
% 'N'       = iteratia la care ne oprim (data de criteriul de oprire)
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ xaprox, N ] = MetBisectie( f, A, B, epsilon )
a(1)=A;                         %salveaza capatul din stanga
b(1)=B;                         %salveaza capatul din dreapta
x(1)=1/2*(a(1)+b(1));           %calculeaza "x0"
N = floor(log2((B-A)/epsilon)); %numarul de pasi care se efectueaza
% -------------------------------------------------------------------------
%                           Iteratiile algoritmului
% -------------------------------------------------------------------------
for k=2:N+1
    if (f(x(k-1))==0)
        x(k) = x(k-1);
        break;
    elseif (f(a(k-1))*f(x(k-1))<0)
        a(k)=a(k-1); 
        b(k)=x(k-1); 
        x(k)=1/2*(a(k-1)+b(k-1));
    elseif (f(a(k-1))*f(x(k-1))>0)
    a(k)=x(k-1); 
    b(k)=b(k-1); 
    x(k)=1/2*(a(k-1)+b(k-1));
    end
end
xaprox=x(k);
end

