% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unei functii 'f' pe un interval [A, B] si
% solutia numerica data de metoda Newton-Raphson, Secantei si a Pozitiei
% False
% -------------------------------------------------------------------------
% Author: Alexandru Ghita, 2018
% =========================================================================

f = @(x) 8*x.^3 + 4*x - 1;  %definirea functiei 'f'
df = @(x) 24*x.^2+4;        %derivata functiei 'f' necesara metodei NR
A = 0;                      %capatul inferior al intervalului pe care e 
                            %definita 'f'
B = 1;                      %capatul superior
X = linspace(A, B, 10);     %discretizarea intervalului
Y = f(X);                   %vectorul valorilor lui f(X)
% -------------------------------------------------------------------------
%               Graficul functiei 'f' si solutiile numerice 
% -------------------------------------------------------------------------
figure(1)                   
plot(X, Y, '-b');
grid on
[xNR] = MetNR(f, df, 0.8, 1/4);    %solutia numerica obtinuta prin m NR
[xSec] = MetSec(f, 0, 1, 0, 1, 1/4);  %solutia numerica obtinuta prin
                                        %metoda Secantei
[xPoz] = MetPozFalse(f, 0, 1, 1/4);    %solutia numerica obtinuta prin 
                                        %metoda Pozitiei False