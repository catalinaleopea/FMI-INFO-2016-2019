%aproximare sqrt(3) 
%x= sqrt(3); x^2 = 3; x^2 - 3 = 0 
%folosim metoda bisectiei pentru a aproxima solutia ecuatiei. 
% 10/10
ec = @(x) x^2-3  
epsilon = 10 ^ (-5); 
aprox = MetBisectiei(ec,-1,3,epsilon); 
fprintf('Aproximarea lui sqrt(3) este %f',aprox); 
