%Presupunem ca datele de intrare sunt valide
function [Xaprox] = MetNR(f,fDerivat,x0,E) 
xAnterior=x0; 
while(true) 
    xCurent=xAnterior-(f(xAnterior)/fDerivat(xAnterior));  
    if (abs(xCurent-xAnterior)/abs(xAnterior))<E  
        Xaprox=xCurent;
        break; 
    end
    xAnterior=xCurent;
end  
Xaprox=xCurent;
end