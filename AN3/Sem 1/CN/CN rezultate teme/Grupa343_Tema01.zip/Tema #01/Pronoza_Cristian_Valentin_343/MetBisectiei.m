%Presupunem ca datele de intrare sunt valide
function [Xaprox] = MetBisectiei(f,a,b,E)
ak=a; 
bk=b; 
xk=(ak+bk)/2; 
N=(log2((bk-ak)/E)-1)+1; 
for k=1:N  
    if f(xk) == 0 
        break; 
    elseif f(ak) * f(xk) < 0  
        bk=xk; xk=(ak+bk)/2; 
    elseif f(ak) * f(xk) > 0 
        ak=xk; xk=(ak+bk)/2; 
    end 
end
Xaprox=xk;
end

