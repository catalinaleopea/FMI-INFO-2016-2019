function [Xaprox] = MetSecantei(f,a,b,x0,x1,E) 

while abs(x1-x0)/abs(x0)>=E 
    xNew=(x0*f(x1)-x1*f(x0))/(f(x1)-f(x0));
    if xNew<a || xNew>b 
        fprintf('x0,x1 GRESITE!!'); 
        break; 
    end  
    x0=x1; 
    x1=xNew;
end 
Xaprox=xNew;
end

