% Se poate aplica metoda bisectiei? In rest f bine
% 8/10

% Total 74/100 i.e. 9.25
%aproximare folosing metoda bisectiei
f = @(x) 8 * x^3 + 4*x - 1;
epsilon = 10 ^ (-10); 
aprox = MetBisectiei(f,0,1,epsilon);  
fprintf('aproximarea lui x este: %f',aprox); 
%aproximare manuala k=2 
%a=0;b=1;x=0.5 
%K=1 
%f(x)=2; f(a)=-1; f(x)f(a)=-2 < 0 ; 
%a=0;b=x=0.5;x=0.25; 
%K=2 
%f(x)=0.125; f(a)=-1; f(x)f(a)=-0.125 < 0;
%a=0; b=x=0.25; x=0.125 

%Eroarea de aproximare: 
%K=2; 
%2=[(log2(1/E)-1]+1  
%1=[(log2(1/E)-1] 
%2<=log2(1/E)<3 
%E<1/4 
%In concluzie eroarea de estimare este mai mica de 0.25