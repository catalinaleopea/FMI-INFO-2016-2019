% 8/10
% iese din domeniul de definitie + incalca ipotezele teoremei.

%solutiile ecuatiei x^3 ? 7x^2 + 14x ? 6 = 0 sunt: 
%x1=3; x2=2+sqrt(2) si x3=2-sqrt(2) 
%dintre care x3 este unica solutie din invervalul [0,2.5] 
%fDerivat= 3* x^2 - 14* x +14 
%Aplicand algoritmul NR obtinem: 
%xk= 2 - ( 2/ (-2)); xk=3  
%Algoritmul se opreste dupa primul pas la o solutie valida. 
%Dat fiind faptul ca nu exista nicio limitare cu privire la intervalul 
%in care se poate afla solutia (teorema I.2 nu se verifica), acesta va converge catre una dintre
%acestea, in cazul curent aceasta fiind 3. 




%Determinarea valorii lui x0 a.i. algoritmul sa convearga la 2-sqrt(2):
%Aplicam teorema I.2:
%f(x0) * f''(x0)>0 (1) 
%0<=x0<=2.5        (2) 

%f''(x)= 6*x -14 
%6 *x^4 - 56 * x^3+ 182 * x^2 - 232* x + 84 > 0 
%x<2-(sqrt(2)) 
%x0=0.5 satisface conditia de convergenta in [0,2.5] si converge la x3.

f= @(x) x^3 - 7*x^2 + 14*x - 6; 
fDerivat =@(x) 3*x^2-14*x+14;  
epsilon = 10 ^ (-5);  
rezultat=MetNR(f,fDerivat,0.5,epsilon);
fprintf('Cu x0=0.5 algoritmul converge la: %f',rezultat);