function [Xaprox] = MetPozFalse(f,a,b,E)
x=(a*f(b)-b*f(a))/(f(b)-f(a));
final = 0;
while(final==0)  
    xAnt=x;
    if f(x) == 0 
        Xaprox=x;   
        final=1;
    elseif f(a)*f(x)<0 
        b=x; x=(a*f(b)-b*f(a))/(f(b)-f(a)); 
    elseif f(a)*f(x)>0 
        a=x; x=(a*f(b)-b*f(a))/(f(b)-f(a)); 
    end 
    if abs(x-xAnt)/abs(xAnt)<E 
        Xaprox=x; 
        final=1; 
    end 
end 
end

