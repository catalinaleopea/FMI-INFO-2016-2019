% 10/10
%y=e^x-2 si y=cos(e^x-2) 
y1 = @(x) exp(x)-2; 
X = linspace(-5,5); 
Y = arrayfun(y1,X); 
plot(X,Y); 
hold on; 
y2 =@(x) cos(y1(x));  
Y2 = arrayfun(y2,X); 
plot(X,Y2); 
%met bisectiei pt y1-y2; 
f= @(x) y1(x)-y2(x); 
epsilon = 10 ^ (-5);  
x = MetBisectiei(f,0.5,1.5,epsilon); 
fprintf('x = %f',x); 
%plotare f si x 
figure(2);
Y3 = arrayfun(f,X);  
axis([0 2 -10 10]);
plot(X,Y3);  
hold on;
plot(x,f(x),'x');