% 10/10
f = @(x) (x^3) - (7 * x^2) + (14 * x) - 6; 
% plotare [0,4] 
X = linspace(0,4);
Y = arrayfun(f,X);
plot(X,Y); 
% calculare x aprox pentru x1 [0, 1]; x2 [1; 3, 2]; x3 [3, 2; 4] 
epsilon = 10 ^ (-5); 
x1 = MetBisectiei(f, 0, 1, epsilon); 
x2 = MetBisectiei(f, 1, 3.2, epsilon); 
x3 = MetBisectiei(f, 3.2, 4, epsilon); 
% ploatare x1,x2,x3 pe graficul functiei f 
hold on; 
plot(x1,f(x1),'x'); 
plot(x2,f(x2),'x'); 
plot(x3,f(x3),'x');