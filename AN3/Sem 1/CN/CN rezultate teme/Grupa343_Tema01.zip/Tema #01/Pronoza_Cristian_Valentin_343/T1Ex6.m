% 10/10
f= @(x) x^3 - 7*x^2 + 14*x - 6; 
X=linspace(0,4); 
Y=arrayfun(f,X); 
plot(X,Y); 
%alegem cele 3 intervale astfel:
%(0.5,1); x1=0.25
%(2.5,3.2); x2=2.75
%(3.41,4); x3=3.75
%Intervalele au fost alese deoarece pastreaza monotonia si convexitatea 
f= @(x) x^3 - 7*x^2 + 14*x - 6; 
fDerivat =@(x) 3*x^2-14*x+14;    
epsilon = 10 ^ (-3); 
rezultat=MetNR(f,fDerivat,0.75,epsilon); 
fprintf('Pentru (0.5,1) si x1=0.75 avem solutia:%f\n',rezultat); 
rezultat=MetNR(f,fDerivat,2.75,epsilon); 
fprintf('Pentru (2.5,3.2) si x1=2.75 avem solutia:%f\n',rezultat); 
rezultat=MetNR(f,fDerivat,3.75,epsilon); 
fprintf('Pentru (3.41,4) si x1=3.75 avem solutia:%f',rezultat); 