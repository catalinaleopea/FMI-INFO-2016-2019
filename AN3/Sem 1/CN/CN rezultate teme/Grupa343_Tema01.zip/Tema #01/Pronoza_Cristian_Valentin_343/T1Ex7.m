% 10/10
%8x^3 +4x -1 = 0,x ? [0, 1] 
f=@(x) 8*x^3 + 4*x -1 
X=linspace(-1,1); 
Y=arrayfun(f,X); 
plot(X,Y); 
%f'(x)=24x+4 
%24x+4>0 oricare ar fi x ? [0, 1], deci functia este monotona si strict
%cresatoare. f(0) = -1, iar f(1) = 11. Data fiind continuitatea functiei
%si faptul ca este strict crescatoare aceasta va avea o unica solutie pe
%[0,1]. 
 
%Calculul solutie prin cele trei metode: 
epsilon = 10 ^ (-5);    
fDerivat=@(x)24*x+4; 

x=MetNR(f,fDerivat,0.5,epsilon);  
fprintf('Solutia determinata prin metoda NR este %f\n',x);  

x=MetSecantei(f,0,1,0,1,epsilon); 
fprintf('Solutia determinata prin metoda secantei este %f\n',x);  

x=MetPozFalse(f,0,1,epsilon); 
fprintf('Solutia determinata prin metoda pozitiei false este %f',x);