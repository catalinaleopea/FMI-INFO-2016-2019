% 9/10 -> argumentare intervale
f=@(x) x^3 - 18*x -10; 
X=linspace(-5,5); 
Y=arrayfun(f,X) ;
plot(X,Y);  
hold on;
%Intervalele pentru metoda metodei secantei: 
%[-5,-3.5];[-1,0];[4,5]; 
epsilon = 10 ^ (-3); 
x=MetSecantei(f,-5,-3.5,-5,-3.5,epsilon);  
fprintf('x= %f in intervalul [-5,-3.5]\n',x); 
plot(x,f(x),'x');
x=MetSecantei(f,-1,0,-1,0,epsilon);  
fprintf('x= %f in intervalul [-1,0]\n',x); 
plot(x,f(x),'x');
x=MetSecantei(f,4,5,4,5,epsilon); 
fprintf('x= %f in intervalul [4,5]\n',x); 
plot(x,f(x),'x');

%Metoda pozitiei false:

figure(2);   
plot(X,Y); 
hold on;
x=MetPozFalse(f,-5,-3.5,epsilon);  
fprintf('x= %f in intervalul [-5,-3.5]\n',x);  
plot(x,f(x),'x');
x=MetPozFalse(f,-1,0,epsilon);  
fprintf('x= %f in intervalul [-1,0]\n',x);  
plot(x,f(x),'x');
x=MetPozFalse(f,4,5,epsilon); 
fprintf('x= %f in intervalul [4,5]\n',x);  
plot(x,f(x),'x');