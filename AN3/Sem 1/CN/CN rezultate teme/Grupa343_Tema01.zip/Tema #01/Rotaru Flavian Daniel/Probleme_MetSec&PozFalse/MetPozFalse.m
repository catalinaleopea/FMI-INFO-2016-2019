% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'A'       = capatul din stanga al intervalului
% 'B'       = capatul din dreapta al intervalului 
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'      = solutia numerica data de metoda Pozitiei False
% -------------------------------------------------------------------------
% Author: Flavian Rotaru, 2018
% ========================================================================
function [xaprox] = MetPozFalse(f,A,B,epsilon)
    k = 1;                       % Indexul de la care sa inceapa algoritmul
    a(1) = A;                    % Scrie capatul din stanga
    b(1) = B;                    % Scrie capatul din dreapta
    x(1) = ( a(1) * f(b(1)) - b(1) * f(a(1)) ) / ( f(b(1)) - f(a(1)) );
                                 % Calculeaza 'x0'
    conditie = true;             % Stabilirea conditiei ca fiind indeplinita
% -------------------------------------------------------------------------
%                           Iteratiile algoritmului
% -------------------------------------------------------------------------
    while conditie ~=false
        k = k +1;
        if f(x(k-1)) ==0
            x(k) = x(k - 1);
            break
        elseif f(a(k-1)) * f(x(k-1)) <0
            a(k) = a(k-1);
            b(k) = x(k-1);
            ec = ( a(k) * f(b(k)) - b(k) * f(a(k)) ) / ( f(b(k))- f(a(k)));
            x(k) = ec;
        elseif f(a(k-1)) * f(x(k-1)) > 0
            a(k) = x(k-1);
            b(k) = b(k-1);
            ec = ( a(k) * f(b(k)) - b(k) * f(a(k)) ) / ( f(b(k))- f(a(k)));
            x(k) = ec;
        end
        expresie = abs(x(k) - x(k-1)) / abs(x(k-1));
        if expresie < epsilon
            conditie = false;
        end
        xaprox = x(k);
    end
end