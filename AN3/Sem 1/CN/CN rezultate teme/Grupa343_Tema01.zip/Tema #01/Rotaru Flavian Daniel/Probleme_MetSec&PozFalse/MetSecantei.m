% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'A'       = capatul din stanga al intervalului
% 'B'       = capatul din dreapta al intervalului 
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'      = solutia numerica data de metoda Secantei
% -------------------------------------------------------------------------
% Author: Flavian Rotaru, 2018
% =========================================================================
function [xaprox] = MetSecantei(f,A,B,epsilon)
    gasit = false;                  % Conditie care desemneaza daca se reia 
                                    %        sau nu cautarea solutiei
% -------------------------------------------------------------------------
%                           Iteratiile cautarii solutiei
% -------------------------------------------------------------------------
    while gasit ~= true 
        x(1) = A + (B-A).*rand(1,1);    % Generarea lui 'x1' pe [A,B]
        x(2) = A + (B-A).*rand(1,1);    % Generarea lui 'x2' pe [A,B]
        k = 2;                          % Indexul de la care incepe iterarea
        ec = abs(x(k) - x(k-1)) / abs(x(k-1));  % Conditie pentru iterare
% -------------------------------------------------------------------------
%                           Iteratiile algoritmului
% -------------------------------------------------------------------------
        while ec >= epsilon
            k = k+1;
            x(k) = (x(k-2) * f(x(k-1)) - x(k-1)*f( x(k-2))) / (f(x(k-1)) - f(x(k-2)));
            ec = abs(x(k) - x(k-1)) / abs(x(k-1));
        end
        if (x(k) > A) && (x(k) < B)         % Daca valoarea gasita din
            xaprox = x(k);                  % algoritm se afla in intervalul
            gasit = true;                   %[A,B] atunci spunem ca am gasit 
        end                                 %numarul si nu fortam algoritmul
    end                                     %sa o ia de la capat 
end
