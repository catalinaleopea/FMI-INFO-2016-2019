% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unei functii 'f' pe un interval [A, B] si
% solutia numerica data de Metoda Secantei si apoi de Metoda Pozitiei False
% -------------------------------------------------------------------------
% Author: Flavian Rotaru, 2018
% =========================================================================

A = -5;                 % Initierea capatului din stanga al intervalului                             
B =  5;                 % Initierea capatului din dreapta al intervalului
f = @(x) x.^3 - 18 * x - 10;             % Declararea functiei 'f'
epsilon = 1e-3;

% Calculez solutia numerica si pasul de oprire apeland, pe rand, functiile 
% 'MetSecantei' si 'MetPozFalse' regasite in fisierele 'MetSecantei.m' si
% 'MetPozFalse.m'
xaprox1 = MetSecantei(f,-5,-2,epsilon);
xaprox2 = MetSecantei(f,-2, 2,epsilon);
xaprox3 = MetSecantei(f, 2, 5,epsilon);

xaprox4 = MetPozFalse(f,-5,-2,epsilon);
xaprox5 = MetPozFalse(f,-2, 2,epsilon);
xaprox6 = MetPozFalse(f, 2, 5,epsilon);

x = linspace(A,B,100);              % Discretizarea intervalului [A,B]
y = f(x);                           % Vector al valorilor lui f(x)


% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Metoda: Secantei')
disp('Ecuatia: x.^3 - 18 * x - 10 ')
fprintf('Intervalul: [%5.2f,%5.2f ]\n', A, B)
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutiile numerice: xaprox = %4.2f, %4.2f, %4.2f\n\n', xaprox1,xaprox2,xaprox3)
disp('Metoda: Pozitiei False')
disp('Ecuatia: x.^3 - 18 * x - 10 ')
fprintf('Intervalul: [%5.2f,%5.2f ]\n', A, B)
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutiile numerice: xaprox = %4.2f, %4.2f, %4.2f\n', xaprox4,xaprox5,xaprox6)

% -------------------------------------------------------------------------
%               Graficul functiei 'f' si solutia numerica data 
%                           de Metoda Secantei
% -------------------------------------------------------------------------


figure(1);
plot(x,y,'-.r');            % Graficul functiei
grid on;                    % Afiseaza liniile pentru fiecare valoare x,y
hold on;                    % Pastreaza in figura graficul
line(xlim, [0 0],'color','k','linewidth', 0.5);  % Axa Ox

plot(xaprox1,0,'o','MarkerFaceColor', 'b'); %xaprox1
hold on ;
plot(xaprox2,0,'o','MarkerFaceColor', 'g'); %xaprox2
hold on ;
plot(xaprox3,0,'o','MarkerFaceColor', 'y'); %xaprox3
xlabel(' X ');
ylabel('Y = F(x)');
title('Graficul functiei impreuna cu Metoda Secantei');
legend('f(x) = x^3 - 18*x - 10', 'xaprox1','xaprox2','xparox3');
hold off;

% -------------------------------------------------------------------------
%               Graficul functiei 'f' si solutia numerica data 
%                         de Metoda Pozitiei False
% -------------------------------------------------------------------------

figure(2);
plot(x,y,'-.m');            % Graficul functiei
grid on;                    % Afiseaza liniile pentru fiecare valoare x,y
hold on;                    % Pastreaza in figura graficul

line(xlim, [0 0],'color','k','linewidth', 0.5);  % Axa Ox

plot(xaprox4,0,'o','MarkerFaceColor', 'b'); %xaprox4
hold on ;
plot(xaprox5,0,'o','MarkerFaceColor', 'g'); %xaprox5
hold on ;
plot(xaprox6,0,'o','MarkerFaceColor', 'y'); %xaprox6
xlabel(' X ');
ylabel('Y = F(x)');
title('Graficul functiei f impreuna cu Metoda Pozitiei False');
legend('f(x) = x^3 - 18*x - 10', 'xaprox1','xaprox2','xparox3');
hold off;

