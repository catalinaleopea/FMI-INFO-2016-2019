% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'A'       = capatul din stanga al intervalului
% 'B'       = capatul din dreapta al intervalului 
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xfinal'       = solutia numerica data de metoda Bisectiei
% 'N'            = Iteratia la care ne oprim (data de criteriul de oprire)
% -------------------------------------------------------------------------
% Author: Flavian Rotaru, 2018
% =========================================================================

function [xfinal, N] = MetBisectiei(f, A, B, epsilon)
    a(1) = A;                               % Scrie capatul din Stanga
    b(1) = B;                               % Scrie capatul din Dreapta
    x(1) = 1/2 * (a(1) + b(1));             % Calculeaza 'x0'
    total = ( b(1) - a(1) ) / epsilon ;     % Variabila auxiliara pentru 
                                            %       Calculul lui N
    N = floor(log2(total));                 % Criteriul de oprire

% -------------------------------------------------------------------------
%                           Iteratiile algoritmului
% -------------------------------------------------------------------------
    
    for k = 2:N+1
        if (f(x(k-1)) == 0)
            x(k) = x(k-1);
            break;
        elseif f(a(k-1)) * f (x(k-1)) < 0
            a(k) = a(k-1);
            b(k) = x(k-1);
            x(k) = (a(k) + b(k))/2;
        elseif f(a(k-1)) * f (x(k-1)) > 0
            a(k) = x(k-1);
            b(k) = b(k-1);
            x(k) = (a(k) + b(k))/2;
        end
    end
    xfinal = x(k);
end 