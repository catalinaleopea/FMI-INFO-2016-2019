% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul a doua functii 'f1 si f2' pe un interval [A, B] si
% solutia numerica data de Metoda Bisectiei ecuatiei f1(x) = f2(x)
% -------------------------------------------------------------------------
% Author: Flavian Rotaru, 2018
% =========================================================================

A = 0.5;                % Initierea capatului din stanga al intervalului
B = 1.5;                % Initierea capatului din dreapta al intervalului
epsilon = 10 ^ (-5);    % Seteaza eroarea dintre solutia numerica si cea exacta
f1 = @(x) exp(x) - 2 ;          % Declararea functiei 'f1'
f2 = @(x) cos(exp(x) -2) ;      % Declararea functiei 'f2'
f3 = @(x) exp(x) - 2 - cos(exp(x)-2);   % Declararea functiei 'f3 = f1- f2'
% Calculez solutia numerica si pasul de oprire apeland functia 'metBisectiei'
% regasite in fisierul 'MetBisectiei.m' pentru functia f3

[xaprox, N] = MetBisectiei(f3,A,B,epsilon);

x = linspace(0,2,100);      % Discretizarea intervalului [A,B]
y1 = f1(x);                 % Vector al valorilor lui f1(x)
y2 = f2(x);                 % Vector al valorilor lui f2(x)
y3 = f3(x);                 % Vector al valorilor lui f3(x)

% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------

disp('Metoda: Bisectie')
disp('Ecuatia: exp(x) - 2 = cos(exp(x) - 2)')
fprintf('Intervalul: [%5.2f,%5.2f ]\n', A, B)
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutia numerica: xaprox = %4.2f\n', xaprox)
fprintf('Numarul de iteratii: N = %3i\n', N)
% -------------------------------------------------------------------------
%               Graficul functiilor 'f1 f2 f3' si solutia numerica a
%                               ecuatiei f1 = f2
% -------------------------------------------------------------------------
% Atentie la ce plotezi! Totodata ai grija foloseste date din rularile 
% anterioare. Programul trebuie sa mearga independent. In rest e bine.


figure(1);
plot(x,y,'--b');            % Graficul functiei f1
grid on;                    % Afiseaza liniile pentru fiecare valoare x,y
hold on;                    % Pastreaza in figura graficul
line(xlim, [0 0],'color','k','linewidth', 0.5)  % Axa Ox
plot(x,y2,'r');             % Graficul functiei f2
hold on ;                   % Pastreaza in figura graficul
plot(x,y3,'-.m')            % Graficul functiei f3
hold on;                    % Pastreaza in figura graficul
plot(xaprox,0,'o','MarkerFaceColor', 'y');          % xaprox
xlabel('X');
ylabel('Y=F(x)');
title('Graficul functiilor f1,f2,f3 si solutia ecuatiei');
legend ('f(x) = e^x - 2', 'f(x) = cos(e^x - 2)', 'Sol. Ecuatiei e^x - 2 = cos(e^x - 2)');
hold off;
