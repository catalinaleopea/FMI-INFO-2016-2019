% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Aproximeaza valoarea lui sqrt(3) 
% -------------------------------------------------------------------------
% Author: Flavian Rotaru, 2018
% =========================================================================
% !!! Idem problema 3 !!

A = 0;                % Initierea capatului din stanga al intervalului
B = 6;                % Initierea capatului din dreapta al intervalului
f = @(x) x.^2 - 3;          % Declararea functiei 'f'
epsilon = 10 ^ (-5);        % Seteaza eroarea dintre solutia numerica si cea exacta

% Calculez solutia numerica si pasul de oprire apeland functia 'metBisectiei'
% regasite in fisierul 'MetBisectiei.m' pentru functia f
[xaprox,N] = MetBisectiei(f,A,B,epsilon);

x = linspace(0,6,100);      % Discretizarea intervalului [A,B]
y1 = f1(x);                 % Vector al valorilor lui f1(x)

% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------

disp('Metoda: Bisectie')
disp('Ecuatia: x^2 - 3 = 0')
fprintf('Intervalul: [%5.2f,%5.2f ]\n', A, B)
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutia numerica: xaprox = %4.2f\n', xaprox)
fprintf('Numarul de iteratii: N = %3i\n', N)

% -------------------------------------------------------------------------
%               Graficul functiilor 'f1' si aproximarea lui sqrt(3)
% -------------------------------------------------------------------------
figure(1);
plot(x,y,'--b');            % Graficul functiei f1
grid on;                    % Afiseaza liniile pentru fiecare valoare x,y
hold on;                    % Pastreaza in figura graficul
line(xlim, [0 0],'color','k','linewidth', 0.5)  % Axa Ox
plot(xaprox,0,'o','MarkerFaceColor', 'y');   % xaprox
xlabel(' X ');
ylabel('Y = F(x)');
title('Graficul functiei f impreuna cu aproximarea lui sqrt(3)');
legend('f(x) = x^2 - 3', 'xaprox = sqrt(3)');
hold off;