% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul unei functii 'f' pe un interval [A, B] si
% solutia numerica data de Metoda Newton - Raphson
% -------------------------------------------------------------------------
% Author: Flavian Rotaru, 2018
% =========================================================================
% Care sunt intervalele alese ?

A = 0;                   % Initierea capatului din stanga al intervalului                             
B = 4;                   % Initierea capatului din dreapta al intervalului
f = @(x) x.^3 - 7*x.^2 + 14*x - 6;   % Declararea functiei 'f'
df = @(x) 3* x.^2 - 14*x + 14;       % Declararea functiei derivate a lui 'f'
epsilon = 10^ (-3);      % Seteaza eroarea dintre solutia numerica si cea exacta

% Calculez solutia numerica si pasul de oprire apeland functia 'MetodaNR'
% regasite in fisierul 'MetodaNR.m'

xaprox1 = MetodaNR(f,df,1,epsilon);
xaprox2 = MetodaNR(f,df,2,epsilon);
xaprox3 = MetodaNR(f,df,3.9,epsilon);

x = linspace(A,B,100);                  % Discretizarea intervalului [A,B]
y = f(x);                               % Vector al valorilor lui f(x)

% -------------------------------------------------------------------------
%               Mesaje in consola inainte de grafic
% -------------------------------------------------------------------------
disp('Metoda: Newton - Raphson')
disp('Ecuatia: x.^3 - 7*x.^2 + 14*x - 6 = 0')
fprintf('Intervalul: [%5.2f,%5.2f ]\n', A, B)
fprintf('Eroarea: %5.2e\n', epsilon)
fprintf('Solutiile numerice: xaprox = %4.2f, %4.2f, %4.2f\n', xaprox1,xaprox2,xaprox3)

% -------------------------------------------------------------------------
%               Graficul functiei 'f' si solutia numerica 
% -------------------------------------------------------------------------

figure(2);
plot(x,y,'--b');            % Graficul functiei
grid on;                    % Afiseaza liniile pentru fiecare valoare x,y
hold on;                    % Pastreaza in figura graficul

line(xlim, [0 0],'color','k','linewidth', 0.5)  % Axa Ox

plot(xaprox1, 0,'o','MarkerFaceColor','r','MarkerSize',10); % xaprox1
hold on;                    % Pastreaza in figura graficul
plot(xaprox2, 0,'o','MarkerFaceColor','g','MarkerSize',10); % xaprox2
hold on;                    % Pastreaza in figura graficul
plot(xaprox3, 0,'o','MarkerFaceColor','y','MarkerSize',10); % xaprox3
hold on;                    % Pastreaza in figura graficul
xlabel('X');
ylabel('Y = f(x)');
title('Graficul Functiei F');
legend('f(x)','xaprox1','xaprox2','xaprox3', 'Location', 'SouthEast');
hold off;