% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f'       = o functie declarata anterior
% 'df'      = derivata functiei f
% 'x0'      = valoarea initiala cu care se incepe iteratia, aleasa dupa
%             concavitatea functiei
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'       = solutia numerica data de metoda Newton-Raphson
% -------------------------------------------------------------------------
% Author: Flavian Rotaru, 2018
% =========================================================================
function [xaprox] = MetodaNR(f,df,x0,epsilon)
    k = 1;                                  % Stabilim indicele de la care
                                            %        va incepe programul
    x(1) = x0;                              % Copiem valoarea data ca 
                                            %                  parametru
    condition = true;                       % Criteriul de oprire

% -------------------------------------------------------------------------
%                           Iteratiile algoritmului
% -------------------------------------------------------------------------

    while condition
        k = k+1;
        f1 = f(x(k-1));
        df1 = df(x(k-1));
        x(k) = x(k-1) - ( f1/df1 );
        condition = (abs(x(k) - x(k-1))/ abs(x(k-1)) >= epsilon);
    end
    xaprox = x(k);
end

