% 9/10 -> Cum ai ales acele intervale?
%a

%defining the function
f = @(x) x.^3 - 18 * x - 10;

%plotting the function
X = linspace(-5, 5, 1000);
figure;
plot(X,f(X));
hold on;
line(xlim,[0 0]);
line([0 0],ylim);

%d
%computing the three points
epsilon = 10 ^ -3;
Xaprox1 = MetSec(f, -5, -3, -5, -3, epsilon);
Xaprox2 = MetSec(f, -3, 0, -3, 0, epsilon);
Xaprox3 = MetSec(f, 4, 5, 4, 5, epsilon);

%plotting the points
plot(Xaprox1, f(Xaprox1), 'og');
plot(Xaprox2, f(Xaprox2), 'xr');
plot(Xaprox3, f(Xaprox3), '*b');

%e
figure;
plot(X,f(X));
hold on;
line(xlim,[0 0]);
line([0 0],ylim);

%computing the points
Xaprox1 = MetPoz(f, -5, -3, epsilon);
Xaprox2 = MetPoz(f, -3, 0, epsilon);
Xaprox3 = MetPoz(f, 4, 5, epsilon);

%plotting the points
plot(Xaprox1, f(Xaprox1), 'og');
plot(Xaprox2, f(Xaprox2), 'xr');
plot(Xaprox3, f(Xaprox3), '*b');