function y = MetSec(f, a, b, x0, x1, eps)
k=1;

while (abs(x1 - x0) / abs(x0) > eps)
    temp = x1;
    x1 = (x0 * f(x1) - x1 * f(x0)) / (f(x1) - f(x0));
    if (x1 < a || x1 > b)
        y = inf
        break
    end
    x0 = temp;
end
y = x1;
end