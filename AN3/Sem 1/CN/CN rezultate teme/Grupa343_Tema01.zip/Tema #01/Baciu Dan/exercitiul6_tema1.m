% 8/10 -> De ce ai ales acele intervale si de ce ai ales acele puncte de
% pornire? 
%defining stuff
X = linspace(0, 4, 1000);
epsilon = 10 ^ (-3);
f = @(x) x .^ 3 - 7 * (x .^ 2) + 14 * x - 6;
fderivat = @(x) 3 * (x .^ 2) - 14 * x + 14;

%plotting the function
figure;
hold on;
plot(X,f(X));
line(xlim,[0 0]);
line([0 0],ylim);

%computing the three solutions
Xaprox1 = MetNR(f, fderivat, 1.2, epsilon);
Xaprox2 = MetNR(f, fderivat, 2.6, epsilon);
Xaprox3 = MetNR(f, fderivat, 3.5, epsilon);

%plotting the three results
plot(Xaprox1, f(Xaprox1), 'og');
plot(Xaprox2, f(Xaprox2), 'xr');
plot(Xaprox3, f(Xaprox3), '*b');