function y = MetNR(f, fderivat, x0, epsilon)
err = Inf;
x1 = 0;
while (err > epsilon)
    x1 = x0 - (f(x0) / fderivat(x0));
    err = abs(x1 - x0) / abs(x1);
    x0 = x1;
end
y = x1;
end