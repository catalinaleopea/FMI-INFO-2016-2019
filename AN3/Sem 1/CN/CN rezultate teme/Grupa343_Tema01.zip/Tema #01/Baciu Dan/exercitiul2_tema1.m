%declaring stuff
% 10/10
figure;
f = @(x) x.^3 - 7 * x.^2 + 14 * x - 6;
epsilon = 10 ^ -5;
x = linspace(0,4,100);

%plotting the function
plot(x,f(x));
hold on;

line(xlim,[0 0]);

%computing the output
Xaprox1 = MetBisectiei(f, 0, 1, epsilon);
Xaprox2 = MetBisectiei(f, 1, 3.2, epsilon);
Xaprox3 = MetBisectiei(f, 3.2, 4, epsilon);

%plotting the resulting points
plot(Xaprox1, f(Xaprox1), 'og');
plot(Xaprox2, f(Xaprox2), 'xb');
plot(Xaprox3, f(Xaprox3), '*r');
hold off;