function y = MetBisectiei(f, a, b, eps)
k = floor(log2((b - a) / eps));
A = zeros(k + 1);
B = zeros(k + 1);
X = zeros(k + 1);
A(1) = a;
B(1) = b;
for i = 1:k
    X(i) = (A(i) + B(i)) / 2;
    if(f(A(i)) * f(X(i)) < 0)
        B(i + 1) = X(i);
        A(i + 1) = A(i);
    else if (f(B(i)) * f(X(i)) < 0)
           B(i + 1) = B(i);
           A(i + 1) = X(i);
        else
            X(i + 1) = X(i);
        end
    end
end
y = X(k);
end