%defining the function and its derivative
% 5/10 -> Nu ai justificat de ce nu merge pentru x = 2 si nici de ce merge
% pentru x = 0 pe intervalul considerat :(
f = @(x) x .^ 3 - 7 * (x .^ 2) + 14 * x - 6;
fderivat = @(x) 3 * (x .^ 2) - 14 * x + 14;

X = linspace(0, 2.5, 100);
epsilon = 10 ^ (-5);

figure;
hold on;

%plotting using the N-R method
plot(X,f(X));
line(xlim, [0 0]);
Xaprox = MetNR(f, fderivat, 0, epsilon);
plot(Xaprox, f(Xaprox));