% Nu ai demonstrat unicitatea.
% 7/10
figure;
hold on;

%declaring stuff
f = @(x) 8 * (x .^ 3) + 4 * x - 1;
fderivat = @(x) 24 * (x .^ 2) + 4;

line(xlim,[0 0])
line([0 0],ylim)

epsilon = 10 ^ (-5);
X = linspace(0, 1, 100);

%computing the three points
Xaprox1 = MetNR(f, fderivat, 3, epsilon);
Xaprox2 = MetSec(f, 0, 1, 0, 1, epsilon);
Xaprox3 = MetPoz(f, 0, 1, epsilon);

%plotting the points
plot(X, f(X));
plot(Xaprox1, f(Xaprox1), 'o', 'MarkerSize', 10);
plot(Xaprox2, f(Xaprox2), 'o', 'MarkerSize', 30);
plot(Xaprox3, f(Xaprox3), 'o', 'MarkerSize', 50);