% 8/10
%function depending on x
% 1. 8
% 2. 10
% 3. 10
% 4. 10
% 5. 5
% 6. 8
% 7. 7
% 8. 9
% Total: 67/80 i.e. 8.38
f1 = @(x) 8 * x.^3 + 4 * x - 1;

%declaring stuff
% Atentie la ce declari! Ai initializat matrice de 3 x 3, iar tu ai fi avut
% nevoie de vectori. Incarci spatiul din memorie aiurea asa...
% Ai ajuns bine la solutie, insa ai verificat daca se poate aplica metoda
% bisectiei?
A = zeros(3);
B = zeros(3);
X = zeros(3);
A(1) = 0;
B(1) = 1;

%actual calculation
for i = 1:2
    X(i) = (A(i) + B(i)) / 2;
    if(f1(A(i)) * f1(X(i)) < 0)
        B(i + 1) = X(i);
        A(i + 1) = A(i);
    else
        if (f1(B(i)) * f1(X(i)) < 0)
           B(i + 1) = B(i);
           A(i + 1) = X(i);
        else
            X(i + 1) = X(i);
        end
    end
end

%final error
% NU. Vezi la domnisoara Ionita cum trebuia calculata.
err = f1(X(2));
