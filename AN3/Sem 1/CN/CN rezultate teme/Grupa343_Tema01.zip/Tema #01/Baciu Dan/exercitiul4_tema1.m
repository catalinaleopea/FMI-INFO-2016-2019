%the ecuation x^2 - 3 has roots as sqrt(3) and -sqrt(3)
%we only need the positive root so we are computing the
%solution for [0,3]
% 10/10

f =@(x) x .^ 2 - 3;
epsilon = 10 ^ (-5);
Xaprox = MetBisectiei(f, 0, 3, epsilon)