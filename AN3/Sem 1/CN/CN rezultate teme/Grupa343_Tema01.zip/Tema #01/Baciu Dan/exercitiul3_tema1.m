%declaring the functions
% 10/10
f1 = @(x) exp(1) .^ x - 2;
f2 = @(x) cos(f1(x));

%plotting the functions
X = linspace(1, 3, 100);
plot(X, f1(X));
hold on;
plot(X, f2(X));

%computing the result
f = @(x) f1(x) - f2(x); 
epsilon = 10 ^ (-5);
Xaprox = MetBisectiei(f, 0.5, 1.5, epsilon)
