function y = MetPoz(f, a, b, eps)
infLim = a;
supLim = b;
x0 = (infLim * f(supLim) - supLim * f(infLim)) / (f(supLim) - f(infLim));
x1 = x0;
err = inf;
while (err > eps)
    x0 = x1;
    infLim = a;
    supLim = b;
    if (f(x0) == 0)
        x1 = x0;
        break;
    else
        if (f(infLim) * f(x0) < 0)
            a = infLim;
            b = x0;
            x1 = (a * f(b) - b * f(a)) / (f(b) - f(a));
        else
            if (f(infLim) * f(x0) > 0)
                a = x0;
                b = supLim;
                x1 = (a * f(b) - b * f(a)) / (f(b) - f(a));
            end
        end
    end
    err = abs(x1 - x0) / abs(x0);
end
y = x1;
end
