% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul functiei 'f' pe un interval [A, B] si solutia numerica
% data de Metoda Bisectiei
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

%Ex 2 b)
%discretizare interval
x = linspace(0,4);

%creeare functie
f = @(x) x.^3 -7*x.^2 +14*x -6;

%scriu intr-un vecor y, valorile lui f(x)
y = f(x);

%afisez graficul functiei
close all
figure(1)

plot(x, y, '-m')
title('Graficul functiei f(x) = x^3 -7*x^2 +14*x -6 folosind MetBisectie') 
xlabel('Valorile luate pe axa ox')
ylabel('Valorile luate de y = f(x)')

%initializam datele necesare pentru aplicarea metodei bisectiei
epsilon = 10^(-5);   %setez eroarea de aproximare

%Aplicam metoda bisectiei
%1.pe intervalul [0,1]
A = 0;                              % reinitializez caoatul din stanga
B = 1;                              % reinitializez capatul din dreapta
m1 = MetBisectie(f,A,B,epsilon);    % apelez MetBisectie pe interv. [A,B]
hold on
% plotez rezultatul obtinut in acelasi grafic cu graficul functiei
plot(m1, f(m1),'o','MarkerFaceColor','r','Markersize',5)  

%2.pe intervalul [1,3.2]
A = 1;                              % reinitializez caoatul din stanga
B = 3.2;                            % reinitializez caoatul din dreapta
m2 = MetBisectie(f,A,B,epsilon);    % apelez MetBisectie pe interv. [A,B]
% plotez rezultatul obtinut in acelasi grafic cu graficul functiei
plot(m2, f(m2),'o','MarkerFaceColor','b','Markersize',5)

%3.pe intervalul [3.2,4]
A = 3.2;                            % reinitializez caoatul din stanga
B = 4;                              % reinitializez caoatul din dreapta
m3 = MetBisectie(f,A,B,epsilon);    % apelez MetBisectie pe interv. [A,B]
% plotez rezultatul obtinut in acelasi grafic cu graficul functiei
plot(m3, f(m3),'o','MarkerFaceColor','y','Markersize',5)