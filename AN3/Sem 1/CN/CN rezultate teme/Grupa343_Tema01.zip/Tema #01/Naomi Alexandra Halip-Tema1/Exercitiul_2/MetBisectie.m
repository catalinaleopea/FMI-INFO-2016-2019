% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f' = o functie declarata anterior
% 'A' = capatul din stanga al intervalului
% 'B' = capatul din dreapta al intervalului
% 'epsilon' = eroarea de aproximare
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox' = solutia numerica data de metoda Bisectiei
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================
function [xaprox] = MetBisectie(f, A, B, epsilon)
a(1) = A;                           % capatul din stanga
b(1) = B;                           % capatul din dreapta
x(1) = 1/2*(a(1) + b(1));           % calcul 'x0'
N = floor(log2((B - A)/epsilon));   % criteriu de oprire

% -------------------------------------------------------------------------
%                       Iteratiile algoritmului
% -------------------------------------------------------------------------
for k = 2:N+1
    if (f(x(k-1)) == 0)
        x(k) = x(k-1);
        break;
    elseif (f(a(k-1))*f(x(k-1)) < 0)
        a(k) = a(k-1);
        b(k) = x(k-1);
        x(k) = 1/2*(a(k-1) + b(k-1));
    elseif (f(a(k-1))*f(x(k-1)) > 0)
        a(k) = x(k-1);
        b(k) = b(k-1); 
        x(k) = 1/2*(a(k-1) + b(k-1));
    end
end
xaprox = x(k);

end