% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul functiei f pe intervalul [-5, 5] si obtinrea valorilor
% numerice ale functie, aplicand MetSecantei si MetPozFalse,pe subintervale
% din [-5,5]
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

% Ai plotat toate graficele unele peste altele.....

% discretizare interval 
x = linspace(-5,5);

% creeare functie
f = @(x) x.^3 -18*x -10;

% scriu intr-un vecor y, valorile lui f(x)
y = f(x);

% afisez graficul functiei
close all
figure(1)

% plotam graficul functiei
plot(x, y, '-m')
title('Graficul functiei f(x) = x^3 -18*x -10') 
xlabel('Valorile luate pe axa ox')
ylabel('Valorile luate de y = f(x)')


%d.
% initializam variabilele necesare pentru MetSecantei
epsilon = 10^(-3);      % eroarea de aproximare

% alegem 3 intervale pe care sa fie respectate ipotezele teoremei I.3
% pentru primul interval
a = -5;         % initializare capat stang al intervalului
b = -2;         % initializare capat drept al intervalului
% x0 si x1 apartin intervalului [a,b]
x0 = -4;
x1 = -3;

% apelam metoda Secantei pe intervalul ales
m1 = MetSecantei(f,a,b,x0,x1,epsilon);

% plotam valoarea numerca obtinuta pentru primul interval
hold on
plot(m1, f(m1),'o','MarkerFaceColor','r','Markersize',6)

% pentru al 2-lea interval
a = -1;         % initializare capat stang al intervalului
b = 2;         % initializare capat drept al intervalului
% x0 si x1 apartin intervalului [a,b]
x0 = 0;
x1 = 1;

% apelam metoda Secantei pe intervalul ales
m2 = MetSecantei(f,a,b,x0,x1,epsilon);

% plotam valoarea numerca obtinuta pentru al 2-lea interval
plot(m2, f(m2),'o','MarkerFaceColor','r','Markersize',6)

% pentru al 3-lea interval
a = 3;         % initializare capat stang al intervalului
b = 5;         % initializare capat drept al intervalului
% x0 si x1 apartin intervalului [a,b]
x0 = 3.5;
x1 = 4.5;

% apelam metoda Secantei pe intervalul ales
m3 = MetSecantei(f,a,b,x0,x1,epsilon);

% plotam valoarea numerca obtinuta pentru al 3-lea interval
plot(m3, f(m3),'o','MarkerFaceColor','r','Markersize',6)


% e.
% pentru ca ecuatia f(x) = 0 sa aiba solutie unica, trebuie ca f(a)*f(b)<0
% si f', f" sa nu se anuleze pe [a,b], deci f'(x)!=0 si f"(x)!=0 pe [a,b].
% avand in vedere ca f"(x) se anuleaza in 0, iar f'(x) se anuleaza intr-un 
% punct din intervalul (2,3), trebuie sa avem grija la alegerea 
% subintervalelor
% initializam variabilele necesare pentru MetPozFalse
epsilon = 10^(-3);

% pentru pimul interval
a = -5;         % capatul din stanga al intervalului
b = -3;         % capatul din dreapta al intervalului
m4 = MetPozFalse(f,a,b,epsilon);

% plotam valoarea obtinuta pentru primul interval ales
plot(m4, f(m4),'o','MarkerFaceColor','b','Markersize',3)

% pentru al 2-lea interval
a = -2.5;         % capatul din stanga al intervalului
b = -0.5;         % capatul din dreapta al intervalului
m5 = MetPozFalse(f,a,b,epsilon);

% plotam valoarea obtinuta pentru al 2-lea interval ales
plot(m5, f(m5),'o','MarkerFaceColor','b','Markersize',3)

% pentru al 3-lea interval
a = 3;         % capatul din stanga al intervalului
b = 5;         % capatul din dreapta al intervalului
m6 = MetPozFalse(f,a,b,epsilon);

% plotam valoarea obtinuta pentru al 2-lea interval ales
plot(m6, f(m6),'o','MarkerFaceColor','b','Markersize',3)
