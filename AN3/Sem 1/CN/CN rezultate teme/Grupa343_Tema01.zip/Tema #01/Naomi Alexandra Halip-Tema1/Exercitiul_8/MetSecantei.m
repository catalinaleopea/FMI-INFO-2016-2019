% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f' = o functie declarata anterior
% 'a' = capatul din stanga al intervalului
% 'b' = capatul din dreapta al intervalului
% 'x0' = valoare initiala
% 'x1' = valoare initiala
% 'epsilon' = eroarea de aproximare
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox' = solutia numerica data de metoda Secantei
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

function [xaprox] = MetSecantei(f,a,b,x0,x1,epsilon)
    k = 2;
    x(1) = x0;
    x(2) = x1;
    while abs(x(k) - x(k-1))/abs(x(k-1)) >= epsilon
        k = k + 1;
        x(k) = (x(k-2)*f(x(k-1)) -x(k-1)*f(x(k-2)))/(f(x(k-1))-f(x(k-2)));
        if (x(k) < a) || (x(k) > b)
            OUTPUT('Introduceti alte valori pentru x0,x1');
            break;
        end
    end
    xaprox = x(k);
end