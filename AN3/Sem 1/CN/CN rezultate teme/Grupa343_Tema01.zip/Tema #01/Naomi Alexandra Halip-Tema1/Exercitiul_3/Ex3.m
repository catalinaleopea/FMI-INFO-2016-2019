% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul functiei 'f' pe un interval [A, B] si solutia numerica
% data de Metoda Bisectiei
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

%discretizare interval
x = linspace(0,4);

%creeare functii
f1 = @(x) exp(x) -2;
f2 = @(x) cos(exp(x) -2);

%scriu intr-un vecor y, valorile lui f(x)
y1 = f1(x);
y2 = f2(x);

%afisez graficele functiilor in aceeasi figura
close all
figure(1)

plot(x, y1, '-m')
hold on
plot(x, y2, '-c')
title('Graficele functiilor f1(x) = exp(x) -2 si f2(x) = cos(exp(x) -2)') 
xlabel('Valorile luate pe axa ox')
ylabel('Valorile luate de y = f(x)')

% Pentru a calcula o aproximare a solutiei ecuatiei e^x -2 = cos(e^x -2),
% trecem totul in patea stanga si construim o functie f3 pe care aplicam 
% MetBisectie

% creeam functia f3 = e^x -2 -cos(e^x -2)
f3 = @(x) exp(x) -2 -cos(exp(x) -2);

% scriu intr-un vector y3 valorile lui f3(x)
y3 = f3(x);

% initializez datele necesare pentru aplicarea MetBisectie
A = 0.5;                        % capatul din stanga al intervalului
B = 1.5;                        % capatul din dreapta al intervalului
epsilon = 10^(-5);              % eroarea de aproximare

% aplic MetBisectie functiei f3(x) pe intervalul [0.5,1.5]
m = MetBisectie(f3,A,B,epsilon);

%plotez rezultatul obtinut in acelasi grafic cu graficele functiilor
% Atentie la ce plotezi! Who is 'm1' & 'f'?
plot(m1, f(m1),'o','MarkerFaceColor','r','Markersize',5)