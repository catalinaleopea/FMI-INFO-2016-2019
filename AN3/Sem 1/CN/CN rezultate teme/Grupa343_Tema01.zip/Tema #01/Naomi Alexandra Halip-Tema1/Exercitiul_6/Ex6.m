% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza graficul functiei f pe intervalul [0, 4]. Aleg din grafic trei
% subintervale si valorile initiale x0 corespunzatoare fiecarui subinterval
% astfel incat sa fie respectate ipotezele teoremei I.2. Aflu cele 3
% solutii apeland MetNR
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

% discretizare interval
x = linspace(0,4);

% creeare functie
f = @(x) x.^3 -7*x.^2 +14*x -6;

% creeare derivata functie
% Este hard-codata! MATLAB te lasa sa o calculezi automat folosind simbolic
df = @(x) 3*x.^2 -14*x +14;

% plotam fnctia f
plot(x,f(x),'-m')

% eroarea de aproximare
epsilon = 10^(-3); 

% valoare initiala
x0 = 0;         % valoare initiala pentru primul interval
% !!!!!!!!!!! Care sunt intervalele alese?  !!!!!!!!!!!!!!

% apelam metoda Newton-Raphson pentru a calcula solutia numerica
m1 = MetNR(f,df,x0,epsilon)

% plotez rezultatul obtinut in acelasi grafic cu grafiul functiei
hold on
plot(m1, f(m1),'o','MarkerFaceColor','r','Markersize',5)

% plotez rezultatul obtinut in acelasi grafic cu grafiul functiei
x0 = 2;   % valoarea initiala pentru al 2-lea interval
m2 = MetNR(f,df,x0,epsilon)
plot(m2, f(m2),'o','MarkerFaceColor','r','Markersize',5)

% plotez rezultatul obtinut in acelasi grafic cu grafiul functiei
x0 = 3.5;       % valoarea initiala pentru al 3-lea interval
m3 = MetNR(f,df,x0,epsilon)
plot(m3, f(m3),'o','MarkerFaceColor','r','Markersize',5)




