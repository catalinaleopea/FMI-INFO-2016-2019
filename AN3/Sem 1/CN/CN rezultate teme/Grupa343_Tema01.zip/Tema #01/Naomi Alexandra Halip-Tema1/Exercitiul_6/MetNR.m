% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'f' = o functie declarata anterior
% 'df' = derivata functiei f
% 'x0' = valoare initiala
% 'epsilon' = eroarea de aproximare
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox' = solutia numerica data de metoda Newton-Raphson
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

function [xaprox] = MetNR(f,df,x0,epsilon)
    k = 1; 
    cond = 1;
    x(1) = x0;
    while cond
        k = k+1;
        x(k) = x(k-1) - f(x(k-1))/df(x(k-1));
        if abs((x(k) - x(k-1))/x(k-1)) < epsilon
            cond = 0;
        end
    end
    xaprox = x(k);
end