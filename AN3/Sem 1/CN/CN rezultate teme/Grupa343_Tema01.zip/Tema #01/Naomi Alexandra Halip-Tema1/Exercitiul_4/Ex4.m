% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Afiseaza o aproximare a valorii sqrt(3) cu eroarea epsilon = 10^(-5)
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

% Pentru rezolvare luam functia g(x) = x^2 -3 si aplicam MetBisectie

%discretizare interval
x = linspace(1,2);    

%creeare functie
g = @(x) x.^2 -3;

%scriu intr-un vecor y, valorile lui g(x)
y = g(x);

%afisez graficul functiei
close all
figure(1)

plot(x, y, '-m')
title('Estimarea valorii lui sqrt(3)') 
xlabel('Valorile luate pe axa ox')
ylabel('Valorile luate de y = g(x)')

% initializez datele necesare pentru aplicarea MetBisectie
A = 1;                        % capatul din stanga al intervalului
B = 2;                        % capatul din dreapta al intervalului
epsilon = 10^(-5);            % eroarea de aproximare

% aplic MetBisectie functiei g(x) pe intervalul [1,2]
m = MetBisectie(g,A,B,epsilon);

%plotez rezultatul obtinut in acelasi grafic cu graficele functiilor
hold on
plot(m, g(m),'o','MarkerFaceColor','r','Markersize',5)