% Author: Robert Stancu, 2018
% 
% 
% ?u?! 
clear
clc
f = @(x) x .^ 3  - 7 * (x .^ 2) + 14 * x - 6; % Functia corespunzatoare
epsilon = 10 ^ (-5); % Pragul de aproximare

x = linspace(0,4); % Multimea de puncte pe intervalul [0,4]
y = f(x); % Rezultatul aplicarii functiei f pe multimea de puncte x

title('Metoda bisectiei');
xlabel('x');
ylabel('y');
plot(x,y); % Afisarea graficului functiei
line(xlim, [0 0],'color','k','linewidth', 0.5);

sections = [0 1;1 3.2;3.2 4]; % Sectionarea intervalului initial
params = ['ok' ;'og';'ob']; % Optiunile de afisare

hold on
for i = 1:3
    %Pentru fiecare interval, calculam solutia numerica pentru intervalul
    %Respectiv
    xaprox = MetBisectie(f,sections(i,1),sections(i,2),epsilon); 
    %Plotam solutia numerica
    plot(xaprox,f(xaprox),params(i,:));
    
end