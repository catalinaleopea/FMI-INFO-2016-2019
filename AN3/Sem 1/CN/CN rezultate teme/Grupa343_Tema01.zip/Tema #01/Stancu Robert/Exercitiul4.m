clc
clear

f = @(x) x.^2 - 3; % Ecuatia corespunzatoare aproximarii lui sqrt(3)

x = linspace(1,2); % Cum 1 < sqrt(3) < 2 , generam puncte in [1,2]
y = f(x); % Valoarea functiei f(x)

epsilon = 10^(-5); % Pragul de aproximare

xaprox = MetBisectie(f,1,2,epsilon); % Solutia rezultata in urma aplicarii
                                     % Metodei Bisectiei

hold on
plot(x,y,'r')                        %Graficul functiei f
plot(xaprox,f(xaprox),'xb');         %Solutia numerica
xlabel('x');
ylabel('y');
line(xlim, [0 0],'color','k','linewidth', 0.5);