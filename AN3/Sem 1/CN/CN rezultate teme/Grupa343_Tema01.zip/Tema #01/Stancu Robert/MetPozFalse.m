function [xaprox] = MetPozFalse(f,a,b,epsilon)
k = 1;
A = a;
B = b;

x(1) = (A * f(B) - B * f(A)) / (f(B) - f(A));

% ======================= ALGORITMUL PROPRIU-ZIS ==========================


while true
    k = k + 1;
    if f(x(k-1)) == 0
        x(k) = x(k - 1);
    break;
    elseif f(A) * f(x(k-1)) < 0
        B = x(k - 1);
        x(k) = (A * f(B) - B * f(A)) / (f(B) - f(A));
    elseif f(A) * f(x(k-1)) > 0
        A = x(k - 1);
         x(k) = (A * f(B) - B * f(A)) / (f(B) - f(A));
    end
    
    if abs( (x(k) - (x(k - 1))) / (x(k -1))) < epsilon
        break;
    end
end

xaprox = x(k);

end

