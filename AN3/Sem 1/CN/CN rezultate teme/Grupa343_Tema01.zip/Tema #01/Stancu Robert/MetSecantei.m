function [xaprox] = MetSecantei(f,a,b,x0,x1,epsilon)

    k = 2;
    x(1) = x0;
    x(2) = x1;
    
% ======================= ALGORITMUL PROPRIU-ZIS ==========================

    
    while abs ( (x(k) - x(k-1))/(x(k-1)) ) >= epsilon
        k = k + 1;
                
        x(k) = ( x(k - 2) * f(x(k - 1)) - (x(k - 1) * f(x(k-2))) ) / ...
            ( f( x(k - 1)) - f(x(k - 2)) );
        
        if x(k) < a || x(k) > b
            fprintf('Incercati alte valori pentru x0 si pentru x1\n');
            break;
        end
    
    end
    
    xaprox = x(k);
    
end

