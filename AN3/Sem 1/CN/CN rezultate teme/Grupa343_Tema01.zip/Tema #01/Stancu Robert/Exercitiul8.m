
% ============================= EX 8 =======================================
                    % ==  Metoda Secantei == %
clc
clear
close all

f = @(x) x .^3 - 18 .* x - 10; % Functia f
df = @(x) 3 * (x .^2) - 18; % Derivata functiei f

x = linspace(-5,5); % Discretizarea intervalului
y = f(x); % Valoarea functiei f in punctele din x

plot(x,y,'m'); % Graficul functiei f

epsilon = 10 ^(-3); % Pragul de aproximare

hold on

i1 = [-5 -3]; % Primul interval
i2 = [-3 2.5]; % Al doilea interval
i3 = [2.5 5]; % Al treilea interval

% Solutia numerica pentru primul interval
xaprox = MetSecantei(f,-5,5,i1(1,1),i1(1,2),epsilon);
plot(xaprox,f(xaprox),'xr');

% Solutia numerica pentru al doilea interval
xaprox = MetSecantei(f,-5,5,i2(1,1),i2(1,2),epsilon);
plot(xaprox,f(xaprox),'xg');

% Solutia numerica pentru al treilea interval
xaprox = MetSecantei(f,-5,5,i3(1,1),i3(1,2),epsilon);
plot(xaprox,f(xaprox),'xb');

%%
%============================= EX 8 =======================================
                    % ==  Metoda PozitieiFalse == %

clc
clear
close all

f = @(x) x .^3 - 18 .* x - 10; % Functia f

x = linspace(-5,5);% Discretizarea intervalului
y = f(x); % Valoarea functiei f in punctele din x

plot(x,y,'m'); % Graficul functiei f
epsilon = 10 ^(-3); % Pragul de aproximare

hold on

i1 = [-5 -3]; % Primul interval
i2 = [-3 2.5]; % Al doilea interval
i3 = [2.5 5]; % Al treilea interval

% Solutia pentru primul interval
xaprox = MetPozFalse(f,i1(1,1),i1(1,2),epsilon);
plot(xaprox,f(xaprox),'xr');

% Solutia pentru al doilea interval
xaprox = MetPozFalse(f,i2(1,1),i2(1,2),epsilon);
plot(xaprox,f(xaprox),'xg');

% Solutia pentru al treilea interval
xaprox = MetPozFalse(f,i3(1,1),i3(1,2),epsilon);
plot(xaprox,f(xaprox),'xb');