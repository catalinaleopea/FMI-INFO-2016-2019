clc
close all

f = @(x) exp(x) - 2; % Functia 1
g = @(x) cos(exp(x) - 2); % Functia 2

x = linspace(0.5,1.5); %Discretizam intervalul
y1 = f(x); % Calculam Valoarea f(x) 
y2 = g(x); % Calculam valoarea g(x)

figure
hold on
xlabel('x');
ylabel('y');
plot(x,y1,'r'); % Plotam graficul functiei f
plot(x,y2,'b'); % Plotam graficul functiei g
line(xlim, [0 0],'color','k','linewidth', 0.5);
legend('y1 = f(x)','y2 = g(x)');

hold off
% ============================ Punctul b) =================================

epsilon = 10 ^ (-5);
h = @(x) exp(x) - 2 - cos(exp(x) - 2); % Transformam ecuatia

xaprox = MetBisectie(h,0.5,1.5,epsilon); % Folosim Metoda Bisectiei pentru
                                         % a calcula solutia numerica

figure
hold on
xlabel('x');
ylabel('y');
plot(x,h(x),'r');           % plotam graficul functiei
plot(xaprox,h(xaprox),'xg'); % plotam solutia numerica
line(xlim, [0 0],'color','k','linewidth', 0.5);
legend('y = h(x)','Solutia numerica');