function [xaprox] = MetBisectie(f,a,b,epsilon)
    if(f(a) * f(b) < 0)
    
    %Capetele intervalului
        A = a; 
        B = b;
        N = floor(log2( (B - A) / epsilon) - 1) + 1; % Numarul de pasi
    
        x = zeros(1,N);
        x(1) = (A + B) / 2; % x0
    
        
 % ===================== ALGORITMUL PROPRIU-ZIS ===========================
        for k = 2:N
            if f(x(k - 1)) == 0
                x(k) = x(k - 1);
                break;
            elseif f(A) * f(x(k - 1)) < 0
                B = x(k - 1);
                x(k) = (A + B) / 2;
            elseif f(A) * f(x(k - 1)) > 0
            A = x(k - 1);
            x(k) = (A + B) / 2;
            end
        end
        
        xaprox = x(k); % Solutia numerica
    end
end

