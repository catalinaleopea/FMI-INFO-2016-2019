clc
clear

f = @(x) x .^ 3  - 7 * (x .^ 2) + 14 * x - 6; % Functia f
fp = @(x) 3 * (x.^2) - 14 * x + 14; % Derivata functiei f
fs = @(x) 6 * x - 14; % Derivata de ordin 2 a functiei f

x = linspace(0,2.5); % Discretizam intervalul

y = f(x);   % Valorile functiei f aplicate vectorului x
yp = fp(x); % Valorile derivatei functiei f aplicate vectorului x
ys = fs(x); % Valorile derivatei de ordin 2 
            % a functiei f aplicate vectorului x

subplot(1,3,1)
plot(x,y);
title('Functia f');

subplot(1,3,2)
plot(x,yp);
title('Derivata functiei f');

subplot(1,3,3)
plot(x,ys);
title('Derivata de ordin 2 a functiei f');

% Justificare: Cum semnul produsului f(2) * fs(2) este negativ, valoarea
% aleasa x0 = 2 nu va converge catre solutia corecta, conform teoremei
% I.2 din cursul 1

% Alegem x0 = 0
% Se respecta conditia f(0) * f''(0) > 0
fprintf('Valoarea f(0) * fs(0) este: %d', f(0) * fs(0));