clc
clear

f = @(x) x .^ 3  - 7 * (x .^ 2) + 14 * x - 6; % Functia f
fp = @(x) 3 * (x.^2) - 14 * x + 14; % Derivata functiei f

epsilon = 10^(-3); % Pragul de aproximare

x = linspace(0,4); % Discretizam intervalul 

y = f(x); % Valoarea functiei f in punctele din x
yp = fp(x); % valoarea derivatei functiei f in punctele din x

hold on
plot(x,y); % Graficul functiei f

i1 = [0,1.4]; % Primul interval
i2 = [1.4,3.3]; % Al doilea interval
i3 = [3.3,4]; % Al treilea interval

x01 = 0.5; % Valoarea initiala pentru x0 pentru intervalul 1
x02 = 2.5; % Valoarea initiala pentru x0 pentru intervalul 2
x03 = 3.5; % Valoarea initiala pentru x0 pentru intervalul 3

xaprox1 = MetNR(f,fp,x01,epsilon); % Calculul solutiei numerice pe interv 1
xaprox2 = MetNR(f,fp,x02,epsilon); % Calculul solutiei numerice pe interv 2
xaprox3 = MetNR(f,fp,x03,epsilon); % Calculul solutiei numerice pe interv 3

plot(xaprox1,0,'xr');
plot(xaprox2,0,'xg');
plot(xaprox3,0,'xb');
line(xlim, [0 0],'color','k','linewidth', 0.5);
