function [xaprox] = MetNR(f,df,x0,epsilon)

k = 1;
x(k) = x0;

% ======================= ALGORITMUL PROPRIU-ZIS ==========================
while true
    k = k + 1;
    x(k) = x(k - 1)  - ( f(x(k - 1)) / df(x(k - 1)));
    if abs( (x(k) - x(k - 1))/x(k - 1)) < epsilon
        break;
    end
end

xaprox = x(k);


end

