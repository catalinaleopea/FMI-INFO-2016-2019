% 10/10
%eliberam variabilele generate de scriptul anterior
%pentru a le putea folosi cu aceeasi denumire
clear;

%definim inline o functie f care sa aiba ca una din solutii sqrt(3) care
%urmeaza a fi aproximat prin metoda bisectiei
f = @(x) x^2 - 3;
fprintf('f(x) = x^2 - 3\n');
%stim ca sqrt(3) este undeva intre 1 si 2 asa ca alegem acelea ca fiind
%capetele intervalului
a0 = 1;
b0 = 2;
epsilon = 10^(-5);
xAprox = MetBisectie(f, a0, b0, epsilon);
fprintf('sqrt(3) aproximat cu metoda bisectiei cu eroare e = 10^-5\n%f\n', xAprox);
fprintf('sqrt(3) din matlab\n%f\n', sqrt(3));
