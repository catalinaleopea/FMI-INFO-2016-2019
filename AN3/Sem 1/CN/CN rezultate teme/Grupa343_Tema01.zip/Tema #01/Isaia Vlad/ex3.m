% 10/10
%eliberam variabilele generate de scriptul anterior
%pentru a le putea folosi cu aceeasi denumire
clear;

%subpunctul a
%definim inline functiile
f = @(x) exp(x) - 2;
g = @(x) cos(exp(x) - 2);
fprintf('f(x) = e^x - 2\n');
fprintf('g(x) = cos(e^x - 2)\n');
%stabilim un interval pentru x comun celor 2 functii
X = linspace(-2, 4);
%creem o noua figura pentru a nu o desena peste cea veche de la ex2
figure;
%pentru a putea avea ploturi multiple pe aceeasi figura
hold on;
%plotarea efectiva a functiilor
plot(X, f(X));
plot(X, g(X));
title({'f(x) = e^x - 2', 'g(x) = cos(e^x - 2)'});
xlabel('x');
ylabel('f(x), g(x)');
%trasam axele Ox si Oy
line(xlim, [0 0], 'color', 'black');
line([0 0], ylim, 'color', 'black');

legend('f', 'g');

%subpunctul b
h = @(x) f(x) - g(x);
epsilon = 10^(-5);
a0 = 0.5;
b0 = 1.5;
X = linspace(a0, b0);

xAprox = MetBisectie(h, a0, b0, epsilon);
fprintf('Solutia ecuatiei f(x) - g(x) = 0 este %f\n', xAprox);