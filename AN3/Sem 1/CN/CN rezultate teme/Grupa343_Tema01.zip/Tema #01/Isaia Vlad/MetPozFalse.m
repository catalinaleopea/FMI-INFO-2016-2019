function xAprox = MetPozFalse(f, a, b, epsilon)
    a(1) = a;
    b(1) = b;
    k=2;
    x(1) = (a*f(b) - b*f(a)) / (f(b) - f(a));
    if(f(x(k-1)) == 0)
        x(k) = x(k-1);
        xAprox = x(k);
        return;
    elseif(f(a(k-1)) * f(x(k-1)) < 0)
        a(k) = a(k-1);
        b(k) = x(k-1);
        x(k) = (a(k)*f(b(k)) - b(k)*f(a(k))) / (f(b(k)) - f(a(k)));
    else
        a(k) = x(k-1);
        b(k) = b(k-1);
        x(k) = (a(k)*f(b(k)) - b(k)*f(a(k))) / (f(b(k)) - f(a(k)));
    end
    
    while(abs(x(k) - x(k-1)) /abs(x(k-1)) >= epsilon)
        k = k+1;
        if(f(x(k-1)) == 0)
            x(k) = x(k-1);
            break;
        elseif(f(a(k-1)) * f(x(k-1)) < 0)
            a(k) = a(k-1);
            b(k) = x(k-1);
            x(k) = (a(k)*f(b(k)) - b(k)*f(a(k))) / (f(b(k)) - f(a(k)));
        else
            a(k) = x(k-1);
            b(k) = b(k-1);
            x(k) = (a(k)*f(b(k)) - b(k)*f(a(k))) / (f(b(k)) - f(a(k)));
        end
    end
    
    xAprox = x(k);
end