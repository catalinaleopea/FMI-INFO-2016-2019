%  9/10 -> Justificare alegere intervale? 
%eliberam variabilele generate de scriptul anterior
%pentru a le putea folosi cu aceeasi denumire
clear;

%subpunctul a
f = @(x) x.^3 - 18*x - 10;
fprintf('f(x) = x^3 - 18x - 10\n');

X = linspace(-5, 5);
figure;
plot(X, f(X));
title('Plotarea functiei f(x) = x^3 - 18x - 10 pe intervalul [-5, 5]');
line(xlim, [0 0], 'color', 'black');
line([0 0], ylim, 'color', 'black');

%subpunctul b
%MetSecantei.m

%subpunctul c
%MetPozFalse.m

%subpunctul d
epsilon = 10^(-3);

a(1) = -5;
b(1) = -3;
x0(1) = -4.5;
x1(1) = -3.5;

a(2) = -1;
b(2) = 0;
x0(2) = -0.75;
x1(2) = -0.25;

a(3) = 4;
b(3) = 5;
x0(3) = 4.1;
x1(3) = 4.8;

for i = 1 : length(a)
    xAproxSecantei(i) = MetSecantei(f, a(i), b(i), x0(i), x1(i), epsilon);
end

fprintf('Solutiile aproximative pentru ecuatia f(x) = 0 aflate prin metoda secantei:\n');

for i = 1 : length(xAproxSecantei)
    fprintf('f(%f) = %f\n', xAproxSecantei(i), f(xAproxSecantei(i)));
end

figure;
X = linspace(-5, 5);
plot(X, f(X));
line(xlim, [0 0], 'color', 'black');
line([0 0], ylim, 'color', 'black');
hold on;
plot(xAproxSecantei, f(xAproxSecantei), 'o', 'MarkerFaceColor', 'green');
title({'Plotarea functiei f(x) = x^3 - 18x - 10 pe intervalul [-5, 5]', ...
    'Solutiile aproximative aflate prin metoda secantei'});

%subpunctul e
clear a b;

epsilon = 10^(-3);

a(1) = -5;
b(1) = -3;

a(2) = -1;
b(2) = 0;

a(3) = 4;
b(3) = 5;

for i = 1 : length(a)
    xAproxPozFalse(i) = MetPozFalse(f, a(i), b(i), epsilon);
end

fprintf('Solutiile aproximative pentru ecuatia f(x) = 0 aflate prin metoda pozitiei false:\n');

for i = 1 : length(xAproxPozFalse)
    fprintf('f(%f) = %f\n', xAproxPozFalse(i), f(xAproxPozFalse(i)));
end

figure;
X = linspace(-5, 5);
plot(X, f(X));
line(xlim, [0 0], 'color', 'black');
line([0 0], ylim, 'color', 'black');
hold on;
plot(xAproxPozFalse, f(xAproxPozFalse), 'o', 'MarkerFaceColor', 'blue');
title({'Plotarea functiei f(x) = x^3 - 18x - 10 pe intervalul [-5, 5]', ...
    'Solutiile aflate prin metoda pozitiei false'});
