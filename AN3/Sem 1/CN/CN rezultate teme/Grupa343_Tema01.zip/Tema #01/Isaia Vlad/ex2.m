% 10/10
% 2,3,4,5 -> 10
% 1, 6, 7, 8 -> 9
% Total: 76/80 ie. 9.5
%eliberam variabilele generate de scriptul anterior
%pentru a le putea folosi cu aceeasi denumire
clear;

%subpunctul a
%MetBisectie.m

%subpunctul b
%definim inline functia f
f = @(x) x.^3 - 7*x.^2 + 14*x - 6;
fprintf('f(x) = x^3 - 7x^2 + 14x - 6\n');
%stabilim intervalul pe care sa fie plotata functia
X = linspace(0, 4);
%plotam graficul functiei f
figure;
plot(X, f(X));
title({'f(x) = x^3 - 7x^2 + 14x - 6', 'Solutiile aproximative aflate prin metoda bisectiei'});
xlabel('x');
ylabel('f(x)');
%trasam axele Ox si Oy
line(xlim, [0 0], 'color', 'black');
line([0 0], ylim, 'color', 'black');
%stabilim un epsilon
epsilon = 10^(-5);
%calculam x aproximativ pentru fiecare interval in parte
%utilizand metoda bisectiei
%stabilim 3 perechi diferite de capete de interval
a1 = 0;
b1 = 1;

a2 = 1;
b2 = 3.2;

a3 = 3.2;
b3 = 4;
%apelam MetBisectie pentru cele 3 intervale
xAprox(1) = MetBisectie(f, a1, b1, epsilon);
xAprox(2) = MetBisectie(f, a2, b2, epsilon);
xAprox(3) = MetBisectie(f, a3, b3, epsilon);

fprintf('Solutiile aproximative ale ecuatiei f(x) = 0 sunt:\n');
for i = 1 : length(xAprox)
    fprintf('f(%f) = %f\n', xAprox(i), f(xAprox(i)));
end

%subpunctul c
%plotam solutiile aproximative pe graficul functiei
%pastram graficul deja plotat
hold on
%plotarea efectiva'
plot(xAprox, f(xAprox), 'o', 'MarkerFaceColor', 'g');
