function [xAprox] = MetBisectie(f, a0, b0, epsilon)
    a(1) = a0;
    b(1) = b0;
    
    x(1) = 1/2 * (a(1) + b(1));
    
    n = floor(log2((b0 - a0) / epsilon));
    
    for k = 2 : n+1
        if(f(x(k-1)) == 0)
            x(k) = x(k-1);
            break;
        elseif (f(a(k-1)) * f(x(k-1)) < 0)
            a(k) = a(k-1);
            b(k) = x(k-1);
            x(k) = 1/2 * (a(k) + b(k));
        elseif (f(a(k-1)) * f(x(k-1)) > 0)
            a(k) = x(k-1);
            b(k) = b(k-1);
            x(k) = 1/2 * (a(k-1) + b(k-1));
        end
    end
    
    xAprox = x(k);
end

