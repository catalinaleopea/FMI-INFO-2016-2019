% *9/10 -> justificare alegere intervale?
%eliberam variabilele generate de scriptul anterior
%pentru a le putea folosi cu aceeasi denumire
clear;

%subpunctul a
%MetNR.m

%subpunctul b
%definim inline functia f
f = @(x) x.^3 - 7*(x.^2) + 14*x - 6;
df = @(x) 3*(x.^2) - 14*x + 14;
fprintf('f(x) = x^3 - 7x^2 + 14x - 6\n');
%stabilim capetele intervalului de plotare
X = linspace(0, 4);
figure;
plot(X, f(X));
title({'f(x) = x^3 - 7x^2 + 14x - 6','Solutiile aproximative aflate prin metoda Netwon-Raphson:'});
line(xlim, [0 0], 'color', 'black');
line([0 0], ylim, 'color', 'black');
%alegem cele 3 subintervale si x0 initial corespunzator
%a0 = 0.5;
%b0 = 0.75;
xAles(1) = 0.5;

%a1 = 2.8;
%b1 = 3.1;
xAles(2) = 2.85;

%a2 = 3.35;
%b2 = 3.5;
xAles(3) = 3.45;
%stabilim un epsilon
epsilon = 10^(-3);
%calculam x-csii aproximati
for i = 1 : length(xAles)
    xAprox(i) = MetNR(f, df, xAles(i), epsilon);
end

fprintf('Solutiile aproximative ale ecuatiei f(x) = 0 aflate prin metoda Newton-Raphson:\n');

for i = 1 : length(xAprox)
    fprintf('f(%f) = %f\n', xAprox(i), f(xAprox(i)));
end
%plotam solutiile pe grafic
hold on
plot(xAprox, f(xAprox),'o');