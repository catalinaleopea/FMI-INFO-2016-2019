% addpath('D:\Facultate\AN3 Facultate\Sem1\Calcul Numeric\Teme\Tema1');

% 1. 9/10 -> Unde ai testat conditiile teoremei?
% 2 -> 8 -> 10/10
% Total: 79/80 i.e. 9.88
% prepare function
f = @(x) sqrt(x)-cos(x);
A=0; B=1; epsilon = 10^(-5);

% get style
[plotMap] = GetPlotMap1();

% get xaprox and plot
[xaprox,N]=ShowPlotMetBisectieOneInterval(f,A,B,epsilon,plotMap);

% print results to console
disp('Valoarea apxorimat a lui xNumeric este')
disp(xaprox)
disp('Iteratia de oprire')
disp(N)