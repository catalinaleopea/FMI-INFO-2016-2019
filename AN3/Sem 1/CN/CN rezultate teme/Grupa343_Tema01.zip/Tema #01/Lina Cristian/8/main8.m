% addpath('D:\Facultate\AN3 Facultate\Sem1\Calcul Numeric\Teme\Tema1');

% prepare function
f = @(x) x.^3 - 18*x - 10;
A = -5; B = 5; epsilon = 10^(-3);
X = linspace(A,B,20);
Y = f(X);
figure(1);
plot(X,Y,'--r*');
grid on;
syms x;
clear intervals;

fd = matlabFunction(diff(f(x)));
fdd = matlabFunction(diff(fd(x)));

[intervals] = MakeIntervals(fd,A,B);
hold on;
disp('MetSecantei');
for i = 1:length(intervals)
   li = double(intervals{i}(1));
   ls = double(intervals{i}(2));
   ok = 1; l1 = li; l2 = ls;
   while(ok == 1 && l1 < l2)
       [xaprox] = MetSecantei(f,li,ls,l1,l2,epsilon);
       if(isnan(xaprox) == 0)
           ok = 0;
       end
       l1 = l1 + epsilon; l2 = l2 - epsilon;
   end
%    if x0 and x1 were not found
   if(l1+epsilon < l2-epsilon)
       fprintf('Pt int [%.2f %.2f] s-au ales x0 = %.2f si x1 = %.2f\n',...
           li, ls, l1-epsilon, l2+epsilon);
       fprintf('xaprox = %.3f\n', xaprox);
       plot(xaprox,f(xaprox),'bo','markers',8);
   else
       disp('Nu s-au gasit valori pentru x0 si x1');
   end
end
disp('MetPozFalse');
for i = 1:length(intervals)
   li = double(intervals{i}(1));
   ls = double(intervals{i}(2));
   [xaprox] = MetPozFalse(f,li,ls,epsilon);
   if(xaprox >= A && xaprox <=B)
       fprintf('Pt int [%.2f %.2f]\n',li, ls);
       fprintf('xaprox = %.3f\n', xaprox);
       plot(xaprox,f(xaprox),'y*');
   end
end
hold off;
    