%addpath('D:\Facultate\AN3 Facultate\Sem1\Calcul Numeric\Teme\Tema1');

f = @(x) x.^2 - 3;
epsilon = 10^(-5);
A = 1; B = 2;
X = linspace(A,B,15);
[plotMap] = GetPlotMap1();

% get xaprox and plot
[xaprox,N]=ShowPlotMetBisectieOneInterval(f,A,B,epsilon,plotMap);

% print results to console
disp('Valoarea apxorimat a lui xNumeric este')
disp(xaprox)
disp('Iteratia de oprire')
disp(N)