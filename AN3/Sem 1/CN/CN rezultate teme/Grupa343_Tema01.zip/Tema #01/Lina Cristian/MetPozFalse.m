function [xaprox] = MetPozFalse(f,A,B,epsilon)
    k = 1;
    avec(1) = A;
    bvec(1) = B;
    xvec(1) = (avec(k)*f(bvec(k)) - bvec(k)*f(avec(k)))/(f(bvec(k))...
        -f(avec(k)));
    ok = 1;
    while(ok == 1)
       k = k + 1;
       if(xvec(k-1) == 0)
           xvec(k) = xvec(k-1);
           break;
       elseif(f(avec(k-1))*f(xvec(k-1)) < 0)
           avec(k) = avec(k-1);
           bvec(k) = xvec(k-1);
           xvec(k) = (avec(k)*f(bvec(k)) - bvec(k)*f(avec(k)))/(f(bvec(k))...
                -f(avec(k)));
       elseif(f(avec(k-1))*f(xvec(k-1)) > 0 )
           avec(k) = xvec(k-1);
           bvec(k) = bvec(k-1);
           xvec(k) = (avec(k)*f(bvec(k)) - bvec(k)*f(avec(k)))/(f(bvec(k))...
                -f(avec(k)));
       end
       if(abs(xvec(k)-xvec(k-1))/abs(xvec(k-1)) <= epsilon)
           ok = 0;
       end
    end
    xaprox = xvec(k);
end