%addpath('D:\Facultate\AN3 Facultate\Sem1\Calcul Numeric\Teme\Tema1');

% prepare function
f = @(x) x.^3 - 7*x.^2 + 14*x - 6;
A = 0; B = 4; epsilon = 10^(-3);
% declare symbolic variable x
syms x;
clear intervals;
figure(1);
X = linspace(A,B,25);   
Y = f(X);
plot(X,Y,'--r*');
grid on
%xticks(X);
% make first and second derivate functions
fd = matlabFunction(diff(f(x)));
fdd = matlabFunction(diff(fd(x)));
[intervals] = MakeIntervals(fd,A,B);
hold on;
% for each interval
for i = 1:length(intervals)
   li = double(intervals{i}(1));
   ls = double(intervals{i}(2));
   j = li;
%    for some values within the interval
   while(j <= ls)
%        check if it respects the constraint
      if(f(j)*fdd(j) > 0)
          x0 = j;
          break;
      end
      j = j + epsilon;
   end
   [xaprox] = MetNewtonRaphon(f,fd,x0,epsilon);
   fprintf('Pentru intervalul [%.2f %.2f] s-a ales x0 = %.2f\n', li, ls, x0);
   fprintf('xaprox = %.3f\n', xaprox);
   plot(xaprox,f(xaprox),'b*');
end
hold off;

% % create function symbolic for f(x0) * f''(x0)
% ffdd = matlabFunction(f(x) * fdd(x));
% ffddRoots = double(roots(fliplr(coeffs(ffdd(x)))));
%  X1 = linspace(A,B,20); %ylim([-6,5]);
%  plot(X1,ffdd(X1),'--g+');
% % for each interval
% for i = 1:length(intervals)
%    li = double(intervals{i}(1));
%    ls = double(intervals{i}(2));
% %    for each root of ffdd function
%    for j = 1:length(ffddRoots)
% %        check if it is in the interval
%       if(ffddRoots(j) >= li && ffddRoots(j) <= ls)
% %           then we must take the very next pozitive value
% %           so f(x0) * f''(x0) > 0
%           if(ffdd(ffddRoots(j) + 0.1) > 0)
%               x0 = ffddRoots(j) + 0.01;
%           else 
%               x0 = ffddRoots(j) - 0.01;
%           end
%       end
%    end
%    [xaprox] = MetNewtonRaphon(f,fd,x0,epsilon);
%    fprintf('Pentru intervalul [%.2f %.2f] s-a ales x0 = %.2f\n', li, ls, x0);
%    fprintf('xaprox = %.3f\n', xaprox);
%    plot(xaprox,f(xaprox),'b*'); 
% end