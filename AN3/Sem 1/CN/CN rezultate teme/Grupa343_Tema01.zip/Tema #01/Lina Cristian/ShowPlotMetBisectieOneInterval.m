function [xaprox,N] = ShowPlotMetBisectieOneInterval(f,A,B,epsilon,grafic)  
    [xaprox,N]=MetBisectie(f,A,B,epsilon);
    if(isempty(grafic) ~= 1)
        X=linspace(A,B,grafic('nrPoints'));
        Y=f(X);
        figure(grafic('numFigure'));
        plot(X,Y,grafic('plotfStyle'));
        hold on
        plot(xaprox, f(xaprox), grafic('plotxStyle'));
        hold off
        xlabel(grafic('xlabel'));
        ylabel(grafic('ylabel'));
        title(grafic('title'));
        legend('y = f(x)', 'xNumeric', 'Location', grafic('legendLocation'));
    end
end