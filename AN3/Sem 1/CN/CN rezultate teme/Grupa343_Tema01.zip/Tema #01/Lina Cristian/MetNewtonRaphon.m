function [xaprox] = MetNewtonRaphon(f,fd,x0,epsilon)
    k = 1; xvec(1) = x0;
    xvec(k+1) = xvec(k) - f(xvec(k))/fd(xvec(k));
    while(abs(xvec(k+1)-xvec(k))/abs(xvec(k)) >= epsilon)
        k = k + 1;
        xvec(k+1) = xvec(k) - f(xvec(k))/fd(xvec(k));
    end
    xaprox = xvec(k+1);
end