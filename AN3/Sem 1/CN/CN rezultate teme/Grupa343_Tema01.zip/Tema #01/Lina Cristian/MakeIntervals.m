function [intervals] = MakeIntervals(fd,A,B)
    syms x;
    fdRoots = sort(double(roots(sym2poly(fd(x)))));
% create intervals for every time when f change direction (1st derivate=0)
    li=A; k=1;
    for i = 1:length(fdRoots)
        if(fdRoots(i) >= A && fdRoots(i) <= B && isreal(fdRoots(i)))
           ls = fdRoots(i);
           intervals{k}(1)=li;
           intervals{k}(2)=ls;
           li=ls; k = k + 1;
        end
    end
    intervals{k}(1) = li;
    intervals{k}(2) = B;
end