%addpath('D:\Facultate\AN3 Facultate\Sem1\Calcul Numeric\Teme\Tema1');

% prepare function
y1 = @(x) exp(x) - 2;
y2 = @(x) cos(exp(2) - 2);
figure(1);
X=linspace(-5,5,20);
Y1=y1(X);
Y2=y2(X);
plot(X,Y1,'--b*');
hold on
plot(X,Y2,'--r+');
hold off;

f = @(x) exp(x) - 2 - cos(exp(x) - 2);
epsilon = 10^(-5);
A = 0.5; B = 1.5;
X = linspace(A,B,15);
[plotMap] = GetPlotMap1();
plotMap('numFigure') = 2;

% get xaprox and plot
[xaprox,N]=ShowPlotMetBisectieOneInterval(f,A,B,epsilon,plotMap);

% print results to console
disp('Valoarea apxorimat a lui xNumeric este')
disp(xaprox)
disp('Iteratia de oprire')
disp(N)