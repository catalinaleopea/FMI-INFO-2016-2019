function [xaprox] = MetSecantei(f,A,B,x0,x1,epsilon)
    k = 1; xvec(1) = x0; xvec(2) = x1; ok = 1;
    while(abs(xvec(k+1)-xvec(k))/abs(xvec(k)) >= epsilon)
        k = k + 1;
        xvec(k+1) = (xvec(k-1)*f(xvec(k))-xvec(k)*f(xvec(k-1)))/...
            (f(xvec(k))-f(xvec(k-1)));
        if(xvec(k+1) < A || xvec(k+1) > B)
           ok=0;
           break;
        end
    end
    if(ok == 1)
        xaprox = xvec(k+1);
    else 
        xaprox = NaN;
    end
end