% returns a map with styles for plot
function [plotMap] = GetPlotMap1()
    keySet = {'nrPoints', 'numFigure', 'plotfStyle', 'plotxStyle',...
        'xlabel', 'ylabel', 'title', 'legendLocation'};
    valueSet = {10, 1, '--r*', 'b*', 'x', 'f(x)', 'Graf fct f', 'SouthEast'};

    plotMap = containers.Map('KeyType','char','ValueType','any');
    for ii = 1:numel(keySet)
        plotMap(keySet{ii}) = valueSet{ii};
    end
end