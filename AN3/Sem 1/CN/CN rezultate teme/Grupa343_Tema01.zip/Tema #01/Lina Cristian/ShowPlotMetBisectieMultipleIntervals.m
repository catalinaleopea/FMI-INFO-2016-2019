function [xaprox,N] = ShowPlotMetBisectieMultipleIntervals...
    (f,A,B,epsilon,grafic)  
    [xaprox,N]=MetBisectie(f,A,B,epsilon);
    if(isempty(grafic) ~= 1)
        X=linspace(A,B,grafic('nrPoints'));
        Y=f(X);
        plot(X,Y,grafic('plotfStyle'));
        plot(xaprox, f(xaprox), grafic('plotxStyle'));
        xlabel(grafic('xlabel'));
        ylabel(grafic('ylabel'));
        title(grafic('title'));
        legend('y = f(x)', 'xNumeric', 'Location', grafic('legendLocation'));
    end
end