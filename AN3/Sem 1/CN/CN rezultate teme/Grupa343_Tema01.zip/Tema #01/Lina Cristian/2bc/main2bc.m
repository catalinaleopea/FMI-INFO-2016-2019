%addpath('D:\Facultate\AN3 Facultate\Sem1\Calcul Numeric\Teme\Tema1');

% show plot for f in [0,4]
f = @(x) x.^3 - 7*x.^2 + 14*x - 6;
A=0; B=4; epsilon = 10^(-5);
X=linspace(A,B,20);
Y=f(X);
figure(1);
plot(X,Y,'--b*');

% show plot for each interval
intervals = { [0 1], [1 3.2], [3.2 4] };
[plotMap] = GetPlotMap1();
figure(2);
hold on
for i = 1:3
    A=intervals{i}(1); B=intervals{i}(2);
    [xaprox,N]=ShowPlotMetBisectieMultipleIntervals(f,A,B,epsilon,plotMap);
    fprintf('xaprox pentru intervalul %.2f %.2f este %.2f in %d pasi\n',...
        A, B, xaprox, N);
end
hold off