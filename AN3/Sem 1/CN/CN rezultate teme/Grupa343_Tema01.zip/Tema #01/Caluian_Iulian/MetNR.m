function [xaprox] = MetNR(f,df,x0,epsi)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
x = x0;
while 1
    x0 = x;
    x = x0 - f(x0)/df(x0);
    if( abs(x-x0)/abs(x0) < epsi) 
        break;
    end
end

xaprox = x;
end



