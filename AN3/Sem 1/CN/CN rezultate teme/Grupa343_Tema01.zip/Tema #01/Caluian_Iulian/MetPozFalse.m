function [xaprox] = MetPozFalse(f,a,b,epsi)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

x = ( a*f(b) - b*f(a) ) / (f(b) - f(a)) ;
while 1
    x0 = x;
    if(f(x) == 0) 
        break;
    end
    
    if( f(a) * f(x) < 0 ) 
        b = x; 
        x = ( a*f(b) - b*f(a) ) / ( f(b) - f(a) );
    elseif ( f(a) * f(x) > 0 ) 
        a = x;
        x = ( a*f(b) - b*f(a) ) / ( f(b) - f(a) );
    end
    

    if( abs(x-x0)/abs(x0) < epsi) 
        break;
    end
end

xaprox = x;
end




