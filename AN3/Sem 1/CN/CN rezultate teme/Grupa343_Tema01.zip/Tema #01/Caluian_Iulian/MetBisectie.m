function [xaprox] = MetBisectie(f,a,b,epsi)

% Date de intrare:
% 'f'       = o functie declarata anterior
% 'a'       = capatul din stanga al intervalului
% 'b'       = capatul din dreapta al intervalului 
% 'epsi' = eroarea maxima dintre solutia numerica si cea exacta

% Date de iesire:
% 'xaprox' - solutia

% Alte detalii
% x - o matrice 1x1 - nu este necesar sa mentinem mai multe intrucat la fiecare pas avem nevoie doar de valoarea precedenta


x = (a + b) / 2;
N = floor(log2((b-a)/epsi)-1) + 1;
for i = 1:N
    if f(x) == 0 
        break;
    elseif f(a)*f(x) < 0
        b = x;
        x = (a+b)/2;
    elseif f(a)*f(x) > 0
        a = x;
        x = (a+b)/2;
    end  
end

xaprox = x;
end

