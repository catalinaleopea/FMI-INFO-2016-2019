function [xaprox] = MetSecantei(f,a,b,x0,x1,epsi)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
x = x1;
while 1

     if( abs(x1-x0)/abs(x0) < epsi) 
        break;
    end

    x = ( x0*f(x1) - x1*f(x0) ) / ( f(x1) - f(x0) );
    x0 = x1;
    x1 = x;

    
    if( x < a || x > b) 
        print('Introduceti alte valori x0, x1');
        break;
    end
end

xaprox = x;
end




