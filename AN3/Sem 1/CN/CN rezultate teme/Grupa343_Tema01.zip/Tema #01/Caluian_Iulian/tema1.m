% Total 39/80 i.e. 


%% Ex2      10/10


figure;
f1 = @(x) x.^3 - 7*x.^2 + 14*x -6;

x = linspace(0,4,1000);
y = f1(x);
plot(x,y);
line(xlim,[0,0]);
title('Grafic functie'),xlabel('x'),ylabel('y');
epsi = 10^(-5);
x1 = MetBisectie(f1,0,1,epsi);
x2 = MetBisectie(f1,1,3.2,epsi);
x3 = MetBisectie(f1,3.2,4,epsi);
hold on
plot(x1,0,'r*',x2,0,'r*',x3,0,'r*');

%% Ex 3     5/10
figure;
epsi = 10^(-5);
f2 = @(x) exp(1).^x - 2;
f3 = @(x) cos(exp(1).^x - 2);
x = linspace(0,2,100);
y1 = f2(x);
y2 = f3(x);
plot(x,y1,x,y2);
line(xlim,[0,0]);
% Atentie ca nu gasesti ce trebuie! Nu vreau zero-urile functiei, ci
% zero-ul ecuatiei.
x1 = MetBisectie(f2,0.5,1.5,epsi);
x2 = MetBisectie(f3,0.5,1.5,epsi);
hold on
plot(x1,0,'b*',x2,0,'r*');

%% Ex 4     10/10
figure;
f4 = @(x) x - 3^(1/2);
x = linspace(0,5,100);
y = f4(x);
epsi = 10^(-5);
plot(x,y);
x1 = MetBisectie(f4,0,2,epsi);
disp('Aproximarea lui rad(3) = ');
disp(x1);

%% Ex 6     8/10
% De ce ai ales acele valori de pornire si ce intervale ai ales?
figure;
f1 = @(x) x.^3 - 7*x.^2 + 14*x -6;
df1 = @(x) 3*x.^2 - 14*x + 14;

x = linspace(0,4,1000);
y = f1(x);
plot(x,y);
line(xlim,[0,0]);
title('Grafic functie'),xlabel('x'),ylabel('y');
epsi = 10^(-5);
x1 = MetNR(f1 ,df1, 0   ,epsi);
x2 = MetNR(f1 ,df1, 2.9 ,epsi);
x3 = MetNR(f1 ,df1, 3.4 ,epsi);
hold on
plot(x1,0,'r*',x2,0,'r*',x3,0,'r*');

%% Ex 7 a - Este tot b) 6/10
figure;
f = @(x) x.^3 - 18*x - 10;
x = linspace(-5,5,1000);
y = f(x);
plot(x,y);
line(xlim,[0,0]);

epsi = 10^(-3);
x1 = MetSecantei(f,-5,-3.5,-5,-3.5,epsi);
x2 = MetSecantei(f,-1,1,-1,1,epsi);
x3 = MetSecantei(f,4,5,4,5,epsi);
hold on
plot(x1,0,'r*',x2,0,'r*',x3,0,'r*');

%% Ex 7 b
figure;
f = @(x) x.^3 - 18*x - 10;
x = linspace(-5,5,1000);
y = f(x);
plot(x,y);
line(xlim,[0,0]);

epsi = 10^(-3);
x1 = MetPozFalse(f,-5,-3.5,epsi);
x2 = MetPozFalse(f,-1,1,epsi);
x3 = MetPozFalse(f,4,5,epsi);
hold on
plot(x1,0,'r*',x2,0,'r*',x3,0,'r*');