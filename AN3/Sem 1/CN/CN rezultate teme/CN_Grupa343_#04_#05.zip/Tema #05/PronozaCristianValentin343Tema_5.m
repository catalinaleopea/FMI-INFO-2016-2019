%% Exercitiul 1.a
% 
A=[
    3 1 1; 
    1 3 1; 
    1 1 3]; 
N1=normap(A,1) 
N2=normap(A,2) 
NInf=normap(A,Inf)

%% Exercitiul 1.b

RazaSpectrala=max(Jacobi(A,10^(-4)))
%Raza spectrala este egala cu normele calculate la a)  

%% Exercitiul 1.c
K1=condp(A,1) 
K2=condp(A,2) 
KInf=condp(A,Inf) 

%% Exercitiul 1.d

N1MatLab=norm(A,1) 
N2MatLab=norm(A,2) 
NInfMatLab=norm(A,Inf) 

K1MatLab=cond(A,1) 
K2MatLab=cond(A,2) 
KInfMatLab=cond(A,Inf)

%% Exercitiul 2.a 
A=[ 
    10 7 8 7;
    7 5 6 5;
    8 6 10 9;
    7 5 9 10 
    ]; 
b=[32 23 33 31];

X=GaussPivTot(A,b) 

%% Exercitiul 2.b 

delta=[0.1 -0.1 0.1 -0.1]; 

bDelta=b+delta;

Xbperturbat=GaussPivTot(A,bDelta) 

%Observam ca o perturbare mica in date (de 10^(-1)) schimba radical 
%solutiile ecuatiei. 

%% Exercitiul 2.c 

KInf=condp(A,Inf) 

%KInf(A) >> 1 => A este un sistem slab conditionat, deci la mici perturbari
%in intrare, perturbarea in solutie va fi consierabila.

RaportX=norm(Xbperturbat,Inf)/norm(X,Inf) 

Raportb=KInf*(norm(bDelta,Inf)/norm(b,Inf)) 

%Observam ca, desi perturbarea asupra lui b este mica, amplificarea
%acesteia cu numarul de conditionre KInf(A) duce la perturbari considerbile
%in valorile solutiiei x, eroarea relativa fiind de 12.6 la o perturbare a
%lui b cu 0.1.

%% Exercitiul 2.d 

Aperturbat=[
10 7 8.1 7.2; 
7.08 5.04 6 5; 
8 5.98 9.89 9; 
6.99 4.99 9 9.98
]; 

XAperturbat=GaussPivTot(Aperturbat,b) 

RaportXA=norm(XAperturbat,Inf)/norm(X,Inf) 

RaportA=KInf*(norm(Aperturbat,Inf)/norm(A,Inf))  

%Se observa ca solutia sistemului perturbat are o eroare relativa mai mare
%pentru perturbare lui A decat pentru perturbare lui b.

%% Exercitiul 5.a
A=[
    0.2 0.01 0;
    0 1 0.04;
    0 0.02 1 
]; 

B=eye(size(A))-A;

ValoriProprii=Jacobi(B,10^(-4)) 

RazaSpectrala=max(abs(ValoriProprii)); 

if RazaSpectrala<1 
    disp('Se poate aplica Jacobi!');  
    [x,N]=MetJacobi(A,[1; 2; 3],10^(-5))
end
%% Exercitiul 5.b 
A=[ 
    4 1 2;
    0 3 1;
    2 4 8
]; 
isDDL=1;
for i=1:size(A)  
    if abs(A(i,i))<=sum(abs(A(i,:)))-abs(A(i,i))  
        disp('Matricea nu este DDL'); 
        isDDL=0;
        break;
    end
end  

if isDDL==1 
    disp('Matricea este DDL deci se poate aplica Jacobi DDL');  
    [x,N]=MetJacobiDDL(A,[1; 2; 3],10^(-5))
end 

%% Exercitiul 5.c 

A=[ 
    4 2 2;
    2 10 4;
    2 4 6
];
ValoriProprii=Jacobi(A,10^(-4));
sigma=2/(max(ValoriProprii)+min(ValoriProprii)) 
RazaSpectrala=max(Jacobi(A,10^(-4))) 
if sigma<2/RazaSpectrala && sigma>0 
    disp('Se poate aplica Jacobi relaxata');  
    [x,N]=MetJacobiR(A,[1; 2; 3],10^(-5))
end

%% Functii 
function [Kp]=condp(A,p) 
Kp=normap(A,p)*normap(inv(A),p); 

end

function [normp]=normap(A,p) 
if p==Inf 
    normp=max(sum(abs(A),2));
end

if p==1  
    normp=max(sum(abs(A)));
end 

if p==2 
    B=transpose(A)*A;
    ValProprii=Jacobi(B,10^(-4)); 
    normp=max(sqrt(ValProprii));
end

end



function [X] = GaussPivTot(A,b) 
X=0;
b=reshape(b,length(b),1);
A=[A b];  
[m,n]=size(A);  
for i=1:m 
    permutation(i)=i; %memoreaza ordinea necunoscutelor pentru refacerea ulterioara a acesteia.
end 
for k=1:m-1    
      
    max=0;
    for q=k:m 
        for p=k:m  
            if abs(A(q,p))>max 
                II=q;
                JJ=p;
                max=abs(A(q,p)) ;
            end
        end
    end   %for ce determina maximum din submatricea aferenta pasului curent
    if max==0  
        fprintf("Sistem incompatibil sau compatibil nedeterminat");   
        return;
    end  
        
    if k~=II
        A([k,II],:) = A([II,k],:); 
    end  %interschimbare de linii
    
    if k~=JJ  
        A(:,[k,JJ]) = A(:,[JJ,k]);   
        aux=permutation(k);
        permutation(k)=permutation(JJ) ;
        permutation(JJ)=aux;
    end  %interschimbare de coloane si memorarea schimbarilor in permutare
    
    for l=k+1:m  
        M=A(l,k)/A(k,k); 
        A(l,:)=A(l,:)-M*A(k,:);
    end  %calculul valorilor liniilor de sub pivot in vederea obtinerii de zero-uri
end 

if A(m,m)==0 
   fprintf("Sistem incompatibil sau compatibil nedeterminat");   
   return;
end  

unpermutedX=SubsDesc(A(1:m,1:m),A(:,n))  ;
for i=1:m  
    X(permutation(i))=unpermutedX(i);%refacerea ordinii necunoscutelor
end
end

function [X] = SubsDesc(A,b)
[m,n]=size(A);  
X(n)=1/A(m,m)*b(m); 
k=n-1; 
while k>0 
    X(k)=1/A(k,k) *( b(k) - sum( A(k,k+1:m) .* X(k+1:m) ) ); 
    %calcularea solutiei curente prin inmultirea necunoscutelor deja
    %calculate la coeficientii acestora, scaderea acestei sume din termenul
    %liber si impartirea la coeficientul necunoscutei actuale: 
    %b(k) - termen liber de pe linia k 
    %A(k,k+1:m) coeficientii necunoscutelor de pe linia actuala 
    %X(k+1:m) - necunoscutele calculate la pasii anteriori 
    %A(k,k) - coeficientul necunoscute actuale
    k=k-1;
end
end

function[xaprox,N]=MetJacobi(A,a,e)  
[m,n]=size(A);
q=norm(eye(n)-A) 
if q>=1  
    disp('Jacobi nu converge');
    return; 
end 
xaprox=zeros(m, 1); %x0
N=0; %Numarul de iteratii necesare pentru aproximare
B=eye(n)-A; %Parametru pentru sistemul in baza caruia se construieste metoda
ConditieIesire=1; 
x1=0; %solutia dupa prima iteratie
while ConditieIesire  
    N=N+1; 
    xaproxAnterior=xaprox;  
    xaprox=B*xaprox+a; %solutia dupa iteratia curenta
    if x1==0 
        x1=xaprox
    end
    if ((q^N)/(1-q))*norm(x1)<e %conditie de precizie
        ConditieIesire=0; 
    end
end
end 

function[xaprox,N]=MetJacobiDDL(A,a,e)  
[m,n]=size(A);
for i=1:n  
    if abs(A(i,i))<=sum(abs(A(i,:)))-abs(A(i,i))  
        disp('Matricea nu este DDL');
        return;
    end
end 
xaprox=zeros(m, 1); 
N=0;  %Numarul de iteratii necesare pentru aproximare
D=diag(diag(A));
B=eye(n)-inv(D)*A; %Parametru pentru sistemul in baza caruia se construieste metoda
b=a./diag(A); %Parametru pentru sistemul in baza caruia se construieste metoda
q=norm(B,Inf); 
ConditieIesire=1;
x1=0; %solutia dupa prima iteratie
while ConditieIesire  
    N=N+1; 
    xaproxAnterior=xaprox; 
    xaprox=B*xaprox+b;   %solutia dupa iteratia curenta
    if x1==0 
        x1=xaprox;
    end
    if ((q^N)/(1-q))*norm(x1)<e %conditie de precizie
        ConditieIesire=0; 
    end
end
end

function[xaprox,N]=MetJacobiR(A,a,e)    
[m,n]=size(A);
xaprox=zeros(m,1); 
N=0;   %Numarul de iteratii necesare pentru aproximare
ValoriProprii=Jacobi(A,10^(-4));
sigma=2/(max(ValoriProprii)+min(ValoriProprii)); 
q=(max(ValoriProprii)-min(ValoriProprii))/(max(ValoriProprii)+min(ValoriProprii)); 
B=eye(n)-sigma*A;  %Parametru pentru sistemul in baza caruia se construieste metoda
b=sigma*a; %Parametru pentru sistemul in baza caruia se construieste metoda
x1=0; %solutia dupa prima iteratie
ConditieIesire=1;
while ConditieIesire  
    N=N+1; 
    xaproxAnterior=xaprox; 
    xaprox=B*xaprox+b;   %solutia dupa iteratia curenta
    if x1==0 
        x1=xaprox;
    end
    if ((q^N)/(1-q))*norm(x1)<e %conditie de precizie
        ConditieIesire=0; 
    end
end
end 


function [L]=Jacobi(A,e) %Jacobi din tema precedenta
[m,n]=size(A);
while ModulMatrice(A)>=e  
    max=-1; 
    p=0; 
    q=0;
    for i=1:m-1  
        for j=i+1:m 
            if abs(A(i,j))>max 
                p=i;q=j;max=abs(A(i,j)); 
            end
        end
    end
    if(A(p,p)==A(q,q)) 
        o=pi/4; 
    else 
        o=1/2*atan(2*A(p,q)/(A(q,q)-A(p,p))); 
    end 
    c=cos(o); 
    s=sin(o); 
    for j=1:m 
        if j~=p && j~=q 
            u=A(p,j)*c-A(q,j)*s; 
            v=A(p,j)*s+A(q,j)*c; 
            A(p,j)=u; 
            A(q,j)=v; 
            A(j,p)=u; 
            A(j,q)=v; 
        end 
    end 
    u=c*c*A(p,p)-2*c*s*A(p,q)+s*s*A(q,q);  
    v=s*s*A(p,p)+2*c*s*A(p,q)+c*c*A(q,q);
    A(p,p)=u; 
    A(q,q)=v; 
    A(p,q)=0; 
    A(q,p)=0; 
    
end   
for i=1:m
    L(i)=A(i,i);
end
end 

function [M]=ModulMatrice(A)  
[m,n]=size(A);  
M=0;
for i=1:m 
    for j=1:m 
        if i~=j 
            M=M+A(i,j)*A(i,j); 
        end 
    end
end
M=sqrt(M);
end 