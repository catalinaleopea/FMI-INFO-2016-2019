%Leopea Catalina, grupa 343, tema 5

%% Ex. 2 a)
A = [ 10 7 8 7;
      7 5 6 5;
      8 6 10 9;
      7 5 9 10];
b = [ 32; 23; 33; 31];

x = GaussPivTot(A,b);

%% Ex. 5. 2)
%a)
a = [1; 2; 3];
eps = 1e-5;

A = [ 0.2 0.01 0;
      0   1    0.04;
      0   0.02 1 ];
  
[x_aprox, N] = MetJacobi(A, a, eps);
% norm(I - A) < 1, deci metoda converge.

%b)
A = [4 1 2;
     0 3 1;
     2 4 8];

[x_aprox, N] = MetJacobiDDL(A, a, eps);
% Matricea e diagonal dominanta pe linii, deci metoda converge.

%c)
A = [ 4 2 2;
      2 10 4;
      2 4 6];
sigma = 0.0025;
[x_aprox, N] = MetJacobiR(A, a, eps, sigma);
% Sigma e suficient de mic ca sa mearga

%% GaussPivTot
function [x] = GaussPivTot(A, b)
  A = [A, b];
  n = size(A, 1);
  xi = 1:n;
  
  for k = 1 : n - 1
    p = k;
    m = k;
    for i = k : n
      for j = k : n
        if abs(A(i, j)) > abs(A(p, m))
          p = i;
          m = j;
        end
      end
    end
    
    if A(p, m) == 0
      disp('Sistem incompatibil sau compatibil nedeterminat');
    end
    
    if p ~= k
      A([p, k], :) = A([k, p], :);
    end 
    
    if m ~= k
      A(:, [m, k]) = A(:, [k, m]);
      xi([m, k]) = xi([k, m]);
    end
    
    for l = k + 1 : n
      A(l, :) = A(l, :)- A(l, k) / A(k, k) * A(k, :);
    end
  end 
  
  if A(n, n) == 0
    disp('Sistem incompatibil sau compatibil nedeterminat');
  end

  xraw = SubsDesc(A(1: n, 1: n), A(:, n + 1));
  
  for i = 1: n
    x(xi(i)) = xraw(i);
  end 

end

%% SubsDesc
function [x] = SubsDesc(A, b)
  n = length(A);
  x(n) = 1/A(n, n) * b(n);
  k = n - 1;

  while k > 0
    s = 0;
    for j = k + 1:n
      s = s + A(k, j) * x(j);
    end
    x(k) = 1 / A(k, k) * (b(k) - s);
    k = k - 1;
  end

end

%% Ex. 4 a)Metoda Jacobi
function [x_aprox, N] = MetJacobi(A, a, eps)
    x_aprox = zeros(1, size(A, 1));
    N = 0;
    I = eye(size(A));
    q = norm(I-A);
    if q >= 1
       disp('Metoda Jacobi nu asigura convergenta')
       return
    end
    
    B = I - A;
    b = a;
 
    x_old = B * zeros(size(A, 1), 1) + b;
    error_factor = x_old;
    k = 2;
    while 1
        k = k + 1;
        x_new = B * x_old + b;
        if q^k / (1 - q) * norm(error_factor) < eps
            break
        end
        x_old = x_new;
    end
    x_aprox = x_old;
    N = k;
end

%% b)Metoda Jacobi pentru matrice diagonal dominante
function [x_aprox, N] = MetJacobiDDL(A, a, eps)
    n = size(A,1);
    x_aprox = zeros(1, n);
    N = 0;
    for i = 1:n
       if abs(A(i,i)) < sum(A(i,:)) - A(i, i)
           disp('Matricea nu este diag. dom. pe linii')
           return
       end
    end
    I = eye(size(A));
    B = I - A ./ repmat(diag(A), 1, n);
    b = a ./ diag(A);
    x_old = B * zeros(size(A, 1), 1) + b;
    error_factor = norm(x_old, 2);
    k = 1;
    q = norm(B, inf);
    while 1
        x_new = B * x_old + b;
        k = k+1;
        if q^k / (1 - q) * error_factor < eps
            break;
        end
        x_old = x_new;
    end
    
    x_aprox = x_new;
    N = k;
end

%% c)Metoda Jacobi relaxata
function [x_aprox, N] = MetJacobiR(A, a, eps, sigma)
    n = length(A);
    x_aprox = zeros(n, 1);
    N = 0;
    
    if(sigma < 0 || sigma > 2/ norm(A, inf))
        disp('Metoda nu converge.');
        return;
    end
    
    b = sigma * a;
    B = eye(n) - sigma * A;
    
    x_old = B * zeros(n, 1) + b;
    x_new = x_old;
    k = 1;
   
    while 1
        k = k + 1;
        x_new = B * x_old + b;
        if norm(x_new - x_old) < eps * norm(x_old)
            break;
        end
        x_old = x_new;
    end
    
    x_aprox = x_new;
    N = k;
end