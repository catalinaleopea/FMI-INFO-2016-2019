% Metoda primeste ca date de intrare o matrice A si un scalar p si intoace
% norma lui lui A de ordin p conform cursului 5 pag. 3-6
function [normap] = normap(A,p)
[nl,nc] = size(A); % pastram dimensiunea lui A(coloane nc, linii nl)
switch p % vom trata cazurile conform p oferit in cerinta
    case 1 % cazul in care p = 1
        % vom pastra in Aw valorile sumelor conform Teoremei II.6
        Aw = zeros(1,nc);
        for i=1:nl % i de la 1 la n
            Ai = 0; % initializam suma cu 0
            for j=1:nc % j de la 1 la n
                % pastram suma lui Ai conform teoremei
                Ai = Ai + abs(A(i,j));
            end
            Aw(i) = Ai; % adaugam Ai la Aw
        end
        normap = max(Aw); % returnam maximul
    case 2 % in cazul p = 2
        B = A'*A; % calculam matricea simetrica conform Teoremei II.7
        % aplicam MetJacobi din tema 4 pentru aflarea valorilor proprii
        lambda = MetJacobiVP(B,10^(-5));
        % extracem si intoarcem maximul radicalelor valorilor proprii
        % conform teoremie
        normap = max(sqrt(lambda));
        % in orice alt caz (p = inf) aplicam metoda de la cazul 1 conform
        % teoremei II.5
    otherwise
        % vom pastra in Aw valorile sumelor conform Teoremei II.6
        Aw = zeros(1,nc);
        for i=1:nl % i de la 1 la n
            Ai = 0; % initializam suma cu 0
            for j=1:nc % j de la 1 la n
                % pastram suma lui Ai conform teoremei
                Ai = Ai + abs(A(i,j));
            end
            Aw(i) = Ai; % adaugam Ai la Aw
        end
        normap = max(Aw); % returnam maximul
end
    
end

