% metoda primeste ca date de intrare matricea A si scalarul p si intoarce
% numarul de conditionare condp conform teoriei din cursul 5 pag.10-12
function [condp] = condp(A,p)
switch p % vom trata cazurile dupa p
    case 1 % in cazul p = 1
        % calculam inversa folosind GaussJordan din tema 3
        [invA,~] = GaussJordan(A);
        normA = normap(A,p); % pastram norma lui A folosind normap
        % pastram norma inversei lui A folosind normap
        norminvA = normap(invA,p);
        % calculam numarul de conditionare conform teoriei
        condp = normA/norminvA;
    case 2 % in cazul in care p = 2
        n = length(A); % pastram lungimea lui A
        B = A'*A; % creem matricea simetrica B conform teoremei II.9
        % folosim MetJacobi din tema 4 pentru a avea valorile proprii
        lambda = MetJacobiVP(B,10^(-5));
        % calculam numarul de conditionare conform teoremei
        condp = sqrt(lambda(n))/sqrt(lambda(1));
    otherwise % in orice alt caz (p = inf) calculam folosind definitia II.5
        % calculam inversa folosind GaussJordan din tema 3
        [invA,~] = GaussJordan(A);
        normA = normap(A,p); % pastram norma lui A folosind normap
        % pastram norma inversei lui A folosind normap
        norminvA = normap(invA,p);
        % calculam numarul de conditionare conform teoriei
        condp = normA/norminvA;
end
end

