% dam functiei ca date de intrare o matrice A si ca date de iesire inversa
% si determinantul acesteia (invA respectiv detA) conform algoritmului
% descris la Ex1 din Tema3.m
function [invA,detA] = GaussJordan (A)    
    n = length(A); % pastram dimensiunea lui A
    I = eye(n); % pastram o matrice identitate pentru verificare
    invA = I; % initiem inversa cu matricea identitate
    % pastram matricea superior triunghiulara compatibila cu A
    triA = TriangGPP(A);
    % initiem determinantul cu 1 pentru a calcula produsul de pe diagonala lui triA
    detA = 1;
    
    for t = 1:n % calculam produsul de pe diagonala lui triA
        detA = detA * triA(t,t); % pastram determinantul
    end
    
    for k = 1:n % parcurgem fiecare linie a matricei A
        aux = A(k,k); % pastram elementul de pe diagonala liniei curente
        % impartim aux cu fiecare element de pe linia curenta pentru a
        % obtine atat inversa in invA cat si matricea identitate in A
        % conform ecuatiei mentionate in Ex1 din Tema3.m
        for i = 1:n
            invA(k,i) = invA(k,i) / aux;
            A(k,i) = A(k,i) / aux;
        end
        for ii = 1:n % parcurgem toate liniile inafara de linia k  
            % pastram elemntul de pe linia curenta de pe coloana k
            aux2 = A(ii, k);
            if ii == k % sarim peste linia k
                continue
            end
            for j = 1:n % parcurgem fiecare coloana de pe linia curenta
                % vrem sa obtinem 0 sub si deasupra diagonalei principale
                % in A asa ca extragem de pe pozitia curenta produsul
                % dintre aux2 si elementul de pe linia k al coloanei
                % curente atat in A cat si in invA
                invA(ii,j) = invA(ii,j) - (aux2 * invA(k,j)); 
                A(ii,j) = A(ii,j) - (aux2 * A(k,j));
            end
        end
    end
    
    if A ~= I % verificam daca am obtinut identitatea in matricea A
        % afisam o eroare daca nu
        error('GaussJordan nu poate fi aplicat pe matricea oferita');
    end
end

