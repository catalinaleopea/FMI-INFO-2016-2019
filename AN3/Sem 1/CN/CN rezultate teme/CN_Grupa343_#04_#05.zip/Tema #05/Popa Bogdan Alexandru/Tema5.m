% 10/10
% Tema 5

% Ex 1
A = [3 1 1;1 3 1;1 1 3];
    
    % a)
    % rezolvat in fisierul functie normap.m
    
    % b)
    % vom folosi metodac jacobi din tema 4 pentru aflarea valorilor proprii
    % ale lui A
    lambda = MetJacobiVP(A,10^(-5));
    pA = max(abs(lambda)) % conform definitiei II.17 din cursul 5
    % se poate observa ca raza spectrala este cuprinsa intre norma1 si
    % norma2, insa aceasta tinde mai mult spre norma1
    
    % c)
    % rezolvat in fisierul functie condp.m
    
    % d)
    p1 = 1;
    p2 = 2;
    pinf = inf;
    
    norma1 = normap(A,p1)
    norma2 = normap(A,p2)
    normainf = normap(A,pinf)
    
    cond1 = condp(A,p1)
    cond2 = condp(A,p2)
    condinf = condp(A,pinf)
   

% Ex 2
    % a)
    A1 = [10 7 8 7;7 5 6 5;8 6 10 9;7 5 9 10];
    b = [32;23;33;31];
    x = GaussPivTot(A1,b)
    
    % b)
    bpert = [32.1;22.9;33.1;30.9];
    % aplicam gauss cu pivotare totala pentru aflarea solutiei
    xpert  = GaussPivTot(A1,bpert);
    % se poate observa ca o perturbatie mica in datele de intrare produce
    % perturbatii considerabile in solutie
    
    % c)
    pertx = xpert - x; % pastram parturbatia lui x
    pertb = bpert - b;
    
    % folosim normap pentru a calcula norma perturbatiei lui x
    normpertx = normap(pertx,inf);
    % folosim normap pentru a calcula norma lui x
    normx = normap(x,inf);
    % calculam conditionarea lui A1
    condA1 = condp(A1,2);
    % calculam norma perturbatiei lui b
    normpertb = normap(pertb,inf);
    normb = normap(b,inf);
    
    marimea1 = normpertx/normx; % pastram prima marime in marimea1
    marimea2 = condA1*(normpertb/normb);% pastram a doua marime in marimea2
    if marimea1 < marimea2 % afisam rezultatul comparatiei dupa caz
        fprintf('marimea1 este mai mica decat marimea2\n');
    else
        if marimea1 == marimea2
            fprintf('marimea1 este egala cu marimea2\n');
        else
            fprintf('marimea1 este mai mare decat marimea2\n');
        end
    end
    % desi conditionarea este foarte mica pot aparea modificari mari asupra
    % solutiei
    
    % d)
    Apert = [10 7 8.1 7.2;7.08 5.04 6 5;8 5.98 9.89 9;6.99 4.99 9 9.98];
    x1pert = GaussPivTot(Apert,b);
    % desi perturbarea este in matrice mica solutia este afectata 
    % considerabil dar pastreaza valori in Z
    
    
% Ex 4
    % a)
    % rezolvat in fisierul de tip functie MetJacobi.m
    
    % b)
    % rezolvat in fisierul de tip functie MetJacobiDDL.m
    
    % c)
    % rezolvat in fisierul de tip functie MetJacobiR.m
    
% Ex 5
% 1
% definim I matricea identitate pe dimensiunea matricelor din Ex 5 (n = 3)
I = eye(3);

    % a)
    A2 = [ 0.2 0.01 0;
        0   1    0.04;
        0   0.02 1 ];
    
    
    % Metoda jacobi asigura convergenta deoarece norma de I - A2 este < 1
    normA2 = normap(I-A2,1)
    if normA2 < 1
        fprintf('MetJacobi merge pentru a)\n');
    end
    
    % b)
    A3 = [4 1 2;
        0 3 1;
        2 4 8];
    n = length(A3); % pastram dimensiunea lui A3
    % conform definitiei II.19 din cursul 5
    for i = 1:n % parcurgem toata dimensiunea lui A3
        % conform algoritmului verificam daca modulul elementului de pe
        % diagonala principala al liniei curente este mai mare sau egal
        % decat suma pe linia curenta
        if abs(A3(i,i)) < sum(A3(i,:)) - A3(i, i)
            % in caz contrar oprim metoda
            fprintf('Matricea nu este diag. dom. pe linii\n')
        else
            if abs(A3(i,i)) >= sum(A3(i,:)) - A3(i, i) && i == n
                fprintf('Matricea este diag. dom. pe linii\n')
                fprintf('MetJacobiDDL merge pentru b)')
            end
        end
    end
    
    % c)
    A4 = [4  2 2;
        2 10 4;
        2  4 6];
    % metoda jacobi relaxata va alege parametrul optim de relaxare si un q
    % optim pentru gasirea aproximarii lui x. In alte cuvinte MetJacobiR
    % merge pentru c)
    fprintf('MetJacobiR merge pentru c)')
    
% 2
a = [1; 2; 3];
epsilon = 10^(-5);

    % a
    [x_aproxa, Na] = MetJacobi(A2, a, epsilon);

    % b
    [x_aproxb, Nb] = MetJacobiDDL(A3, a, epsilon);


    % c

    [x_aproxc, Nc] = MetJacobiR(A4, a, epsilon);



