% dam functiei datele de intrare o matrice A si o matrice b
% iar ca date de iesire solutia sistemului A*x = b, in variabila x, conform
% algoritmului din cursul 2 pag 22-23
function [x] = GaussPivTot(A, b)
  A = [A,b];
%A(1:size(A,1),(size(A,1)+1)) = b; % extindem matricea
  n = size(A,1); % dimensiunea lui A
  indexi = 1:n; % un vector cu indicii lui A
  
  for k = 1 : n - 1 % parcurgem elementele lui A
    p = k; % initem indicele p cu k
    m = k; % initem indicele m cu k
    % cautam primii indici p si m conform algoritmului
    for i = k : n 
      for j = k : n
        if abs(A(i, j)) > abs(A(p, m))
          p = i;
          m = j;
        end 
      end 
    end 
    
    if A(p, m) == 0
      % afisam un mesaj daca p nu a fost gasit (max A = 0)
      fprintf('Sistem incompatibil sau sistem compatibil nedeterminat\n');
      break; % in acest caz vom opri cautarea
    end 
    
    if p ~= k 
      A([p, k], :) = A([k, p], :); % schimbam linia p cu linia k
    end 
    
    if m ~= k
      A(:, [m, k]) = A(:, [k, m]); % schimbam coloana m cu coloana k
      indexi([m, k]) = indexi([k, m]); % schimbam indicii necesari
    end 
    
    % facem transformarile elemnetare pentru a obtine un sistem compatibil
    % cu cel initial
    for i = k + 1 : n
      A(i, :) = A(i,:) - (A(i, k) / A(k, k) * A(k, :));
    end
  end
  
  % daca obtinem in urma schimbarilor pe linia n coloana n zero inseamna ca
  % sistemul este incompatibil sau este compatibil nedeterminat si afisam
  % un mesaj corespunzator
  if A(n, n) == 0
    fprintf('Sistem incompatibil sau sistem compatibil nedeterminat\n');
  end
  % aplicam substitutia descendenta conform algoritmului 
  xlinie = SubsDesc(A(1: n, 1: n), A(:, n + 1));
  
  %x = zeros(n); % prealocam spatiu pentru solutia x
  for i = 1: n
    % parcurgem liniile solutionate si le adaugam in x
    x(indexi(i)) = xlinie(i);
  end 
end