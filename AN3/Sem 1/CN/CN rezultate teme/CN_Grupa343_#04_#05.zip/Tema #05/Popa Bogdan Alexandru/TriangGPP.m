% dam functiei datele de intrare o matrice A
% iar ca date de iesire matricea dupa triangulare conform
% algoritmului lui Gauss cu pivotare partiala
function [A] = TriangGPP(A)
  %nu vom extinde matricea deoarece nu dorim aflarea lui x
  n = size(A,1); % dimensiunea lui A
  
  % cautam primul p astfel incata modul de A(p,k) este maxim
  % conform algoritmului
  for k = 1 : n - 1 % parcurgem elementele lui A
    p = k; % pastram pasul curent si il folosim conform algoritmului
    for i = k : n % cautam maximul de pe coloana k
      if abs(A(i, k)) > abs(A(p, k))
        p = i;
      end
    end
    
    if A(p, k) == 0
      % afisam un mesaj daca p nu a fost gasit (max A = 0)
      fprintf('Sistem incompatibil sau sistem compatibil nedeterminat\n');
      break; % in acest caz vom opri cautarea
    end
    
    % conform indicatiei din enuntul temei nu vom schimba liniile
    
    % facem transformarile elemnetare pentru a obtine un sistem compatibil
    % cu cel initial
    for i = k + 1 : n
      A(i, :) = A(i,:) - (A(i, k) / A(k, k) * A(k, :));
    end
  end
  
  % daca obtinem in urma schimbarilor pe linia n coloana n zero inseamna ca
  % sistemul este incompatibil sau este compatibil nedeterminat si afisam
  % un mesaj corespunzator
  if A(n, n) == 0
    fprintf('Sistem incompatibil sau sistem compatibil nedeterminat\n');
  end 
  
end