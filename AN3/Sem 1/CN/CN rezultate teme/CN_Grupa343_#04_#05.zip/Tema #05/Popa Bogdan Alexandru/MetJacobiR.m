% definim functia MetJacobiDDL conform algoritmului din cursul 5 pag.36
% care primeste ca date de intrare matricea A, matricea nx1 a si un factor
% de eroare epsilon si ca date de iesire solutia sistemului A*x = a,x_aprox
% si numarul de pasi necesari rezolvari acestui sistem N. Pentru rezolvare
% a fost folosita normap pentru calcularea normelor din algoritm. Pentru
% gasire valorilor proprii a fost folosita metoda MetJacobiVP.
function [x_aprox, N] = MetJacobiR(A, a, epsilon)
    n = size(A,1); % pastram dimensiunea lui A
    x_aprox = zeros(1, n); % prealocam x_aprox
    N = 0; % initializam numarul de pasi cu 0
    lambda = MetJacobiVP(A,epsilon); % pastram valorile prorii
    % pastram matricea identitate cu dimensiunea lui A in I
    I = eye(size(A));
    % calculam parametrul optim de relaxare conform porpozitiei II.8
    tO = 2 / (lambda(n)+lambda(1));
    % calculam qO conform porpozitiei II.8
    qO = (lambda(n)-lambda(1))/(lambda(n)+lambda(1));
    B = I - tO*A; % pastram B conform algoritmului
    b = tO*a; % pastram b conform algoritmului
    % pastram x2 pentru a fi folosit in instructiunile urmatoare
    xk = B * x_aprox' + b;
    % pastram x2 ca fiind membrul drept al produsului din conditia de
    % oprire a pasului 4 al algoritmului
    efact = normap(xk, inf);
    k = 2; % incepem cu k de la 2 deoarece am facut deja primele 2 treceri
    while 1 % pornim o ciclare continua
        k = k + 1; % crestem k conform algoritmului
        x = B * xk + b; % calculam x curent conform algoritmului
        % varificam daca a fost atins pasul de oprire conform algoritmului
        if qO^k / (1 - qO) * efact < epsilon
            break % oprim algoritmul
        end
        xk = x; % atribuim lui xk valoarea curenta
    end
    x_aprox = xk; % xk va avea valoarea lui x_aprox
    N = k; % k reprezinta numarul de pasi
end