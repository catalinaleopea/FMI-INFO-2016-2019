%% Rezultate
% 1. 10
% 2. 10
% 3. 10
% 4. 8/10 -> verificarile pentru a) si c)
% Total: 38/0 i.e. 9.5/10
%%
%Exercitiul 1
%a)
A = [3 1 1; 1 3 1; 1 1 3];
norma1 = normap(A,1);
norma2 = normap(A,2);
normaInf = normap(A,inf);

fprintf('Norma matriciala 1 pentru A: %f \n', norma1);
fprintf('Norma matriciala 2 pentru A: %f \n', norma2);
fprintf('Norma matriciala Inf pentru A: %f \n', normaInf);

%b)
raza = RazaSpect(A);
fprintf('Raza spectrala a matricei A: %f \n', raza);
disp('Raza spectrala are valoare egala cu normele calculate');

%c)
cond1 = condp(A,1);
cond2 = condp(A,2);
condInf = condp(A,inf);

fprintf('Nr de conditionare in raport cu norma 1: %f \n', cond1);
fprintf('Nr de conditionare in raport cu norma 2: %f \n', cond2);
fprintf('Nr de conditionare in raport cu norma Inf: %f \n', condInf);

%d) 
disp('Calcul cu functii predefinite:');
normPred1 = norm(A,1);
normPred2 = norm(A,2); 
normPredInf = norm(A,inf); 
condPred1 = cond(A,1);
condPred2 = cond(A,2); 
condPredInf = cond(A,inf);
fprintf('Norma1: %f\n', normPred1);
fprintf('Norma2: %f\n', normPred2);
fprintf('NormaInf: %f\n', normPredInf);
fprintf('Nr de conditionare 1: %f\n', condPred1);
fprintf('Nr de conditionare 2: %f\n', condPred2);
fprintf('Nr de conditionare Inf: %f\n', condPredInf);

%%

%%
%Exercitiul 2
A = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];
b = [32 23 33 31].';
x = [1 1 1 1].';

%a)
xCalc = MetGaussCuPivTot(A, b);
disp('Solutia sistemului, cu Gauss cu pivotare totala:');
disp(xCalc);

%b)
bPert = [32.1; 22.9; 33.1; 30.9]; %vectorul-coloana b perturbat
xCalcPert = MetGaussCuPivTot(A, bPert);
%calculam nr de conditionare al matricei A in raport cu norma 1
nrCond1A = condp(A,1); 
disp('Solutia x perturbata(varianta 1):');
disp(xCalcPert); 
disp('Nr de conditionare(varianta 1):');
disp(nrCond1A);
disp('Deoarece k(A) = 4488 >>1 => eroarea relativa la solutia x a sistemului');
disp('este mare => sistem slab-conditionat');
 
%c)
disp('Cele doua erori relative pt b si x sunt:');
nrCondInfA = condp(A, inf);
deltax = xCalcPert - xCalc;
normaDeltaxInf = norm(deltax, inf); 
normaxInf = norm(x, inf); 

disp(normaDeltaxInf / normaxInf);

deltab = bPert - b;
normaDeltabInf = norm(deltab, inf); 
normabInf = norm(b, inf); 
disp(nrCondInfA * (normaDeltabInf / normabInf));
disp('Observam ca cele doua marimi sunt egale');
 
%d)
APerturbat = [10 7 8.1 7.2; 7.08 5.04 6 5; 8 5.98 9.89 9; 6.99 4.99 9 9.98];
xPerturbat2 = MetGaussCuPivTot(APerturbat, b); 
nrCondAPerturbat2 = condp(APerturbat,2);
disp('Solutia x perturbata (varianta 2):');
disp(xPerturbat2);
disp('Nr de conditionare A (varianta 2):');
disp(nrCondAPerturbat2);
disp('Deoarece k(A) din varianta 2 este mult mai mare decat cel din varianta 1, ');
disp(' sistemul are o eroare relativa foarte mare si e slab-conditionat;');
disp('Perturbarea aparuta in varianta 2 e mult mai puternica decat in varianta 1');
%%

%%
%Exercitiul 5
%a) -: verificarea?
A = [0.2 0.01 0; 0 1 0.04; 0 0.02 1];
a = [1;2;3]; 
eps = 10^(-5); 
[xaprox,N] = MetJacobi2(A,a,eps);
disp('Solutia sistemului cu metoda iterativa de aproximare Jacobi:');
disp(xaprox);
disp('Solutie exacta a sistemului(verificare):');
disp(A\a); %A*x = a <=> x = inv(A) * a;


%b)
B = [4 1 2; 0 3 1; 2 4 8];
n1 = size (B, 1);
%verificam daca matricea B este diagonal dominanta pe linii(cond == 1)
cond = 1;
for i = 1:n1   
    suma = 0;  
    for j = 1:n1   
        if i~= j    
            suma = suma + abs(B(i,j));  
        end
    end
    if abs(B(i,i)) <= suma    
        cond = 0;   
    end
end
if det(B) == 0   
    fprintf('Matricea nu este inv.\n');
elseif cond == 0   
        fprintf('Matricea nu este diagonal dominanta pe linii.\n'); 
    else
        fprintf('Metoda Jacobi pentru matrice diagonal dominante se poate aplica pe matricea A.\n');    
        [xaprox1,N1] = MetJacobiDDL(B,a,eps);
        disp('xaprox: ');
        disp(xaprox1);
        fprintf('N: %d\n', N1);
end

%c) --apel metoda Jacobi relaxata -: verificarea?
C = [4 2 2; 2 10 4; 2 4 6];
%verificam ca C sa fie simetrica si pozitiv-definita;
if issymmetric(C) 
    [~,p] = chol(C);
    if p == 0 %matricea C este pozitiv-definita
        disp('Metoda Jacobi relaxata:');
        [xaprox2,N2] = MetJacobiR(B,a,eps);
        disp('xaprox: ');
        disp(xaprox2);
        fprintf('N: %d\n', N2);
    else
        disp('Matricea nu e pozitiv-definita');
    end
else
    disp('Matricea nu e simetrica');
end
%%

%Functie ce returneaza norma matriceala a lui A, subordonata normei vectoriale p
function [norma] = normap(A, p)
    n=size(A,1);   
    if p == 1      
        %calculam norma matriciala subordonata normei vectoriale 1
        % = suma maxima a elementelor de pe coloane, luate in modul;
        max = A(1,1);        
        for j = 1:n          
            suma = 0;          
            for i = 1:n        
                suma = suma + abs(A(i,j));        
            end
            if suma > max         
                max = suma;         
            end
        end
    else
        if p == 2  
            %calculam norma matriciala subordonata normei vectoriale 2
            B = transpose(A)*A; %calculam matricea simetrica B;    
            eps = 10^(-5); 
            %calculam prin intermediul metodei Jacobi valorile proprii 
            %ale matricei B;
            lambda = MetJacobi(B, eps);  
            %norma va fi calculata ca max(sqrt(lambda(i))), pt fiecare
            %i de la 1 la n;
            max = sqrt(lambda(1));       
            for i = 1:n          
                if sqrt(lambda(i)) > max         
                    max = sqrt(lambda(i));      
                end
            end
        else
            %calculam norma matriciala subordonata normei vectoriale Inf
            % = suma maxima a elementelor de pe linii, luate in modul;
            max = A(1,1);      
            for i = 1:n          
                suma = 0;         
                for j = 1:n       
                    suma = suma + abs(A(i,j));  
                end
                if suma > max       
                    max = suma;         
                end
            end
        end
    end
    %setam valoarea parametrului de iesire ca fiind norma calculata in 
    %variabila max, conform valorii parametrului de intrare p;
    norma = max;
end

% Metoda Jacobi din Tema 4
function [lambda] = MetJacobi(A,eps)   
    n = size(A,1);   
    lambda = zeros(n,1);
    modul = ModulMatrice(A);   
    while modul >= eps    
        maxim = abs(A(1,2));    
        p = 1; q = 2;      
        for i = 1:n-1         
            for j = i+1 : n    
                if abs(A(i,j)) > maxim       
                    maxim = abs(A(i,j));  
                    p=i;                
                    q=j;          
                end
            end
        end
        if A(p,p) == A(q,q)     
            theta = pi/4;      
        else
            theta = 1/2 * atan(2*A(p,q)/(A(q,q) - A(p,p)));  
        end
        c = cos(theta);  
        s = sin(theta);    
        for j = 1:n         
            if j ~= p && j~=q      
                u = A(p,j)*c - A(q,j)*s;     
                v = A(p,j)*s + A(q,j)*c;     
                A(p,j) = u;            
                A(q,j) = v;             
                A(j,p) = u;             
                A(j,q) = v;        
            end
        end
        u = c*c*A(p,p) - 2*c*s*A(p,q) + s*s*A(q,q);   
        v = s*s*A(p,p) + 2*c*s*A(p,q) + c*c*A(q,q);    
        A(p,p) = u;      
        A(q,q) = v;      
        A(p,q) = 0;      
        A(q,p) = 0;       
        modul = ModulMatrice(A);  
    end
    for i = 1:n      
        lambda(i) = A(i,i); 
    end
end

%functie de calcul al modulului unei matrice A, din tema 4
function m = ModulMatrice(A)   
suma = 0; 
n = size(A,1);   
for i = 1:n     
    for j = 1:n        
        if i~=j       
            suma = suma + A(i,j)*A(i,j);        
        end
    end
end
m = sqrt(suma);
end

%functie de calcul a razei spectrale pt o matrice A data ca parametru
function [razaspect] = RazaSpect(A)    
    %raza spectrala a matricei A = maximul valorilor proprii ale matricei A, 
    %luate in modul;
    
    eps = 10^(-5);      
    lambda = MetJacobi(A, eps);       
    max = abs(lambda(1));        
    n = size(A,1);        
    for i = 1:n           
        if abs(lambda(i)) > max                 
            max = abs(lambda(i));       
        end
    end
    razaspect = max;
end

%functie ce returneaza numarul de conditionare a matricei A, in raport cu
%norma p = norma p a lui A * norma p a inversei matricei A;
function [nrCondp] = condp(A,p)    
    normA = normap(A,p);   
    normInvA = normap(inv(A),p);   
    nrCondp = normA * normInvA;
end

%functie ce returneaza solutia x a sistemului de ecuatii liniare A*x = b,
%folosind metoda Gauss cu pivotare totala;
function x = MetGaussCuPivTot(A, b)  
    A = [A, b];   
    n = length(b); 
    x = zeros(n,1);
    index = (1:n);  
    for k = 1:n-1     
        vmax = abs(A(k, k));    
        p = k;      
        m = k;       
        for i = k:n    
            for j = k:n      
                if abs(A(i, j)) > vmax      
                    vmax = abs(A(i, j));     
                    p = i;               
                    m = j;              
                end
            end
        end
        if(vmax == 0)        
            x(1:n) = 0;         
            disp('Sist. incompatibil sau compatibil nedet.');     
            return;       
        end
        if(p ~= k)   
            A([p k], :) = A([k, p], :);       
        end
        if(m ~= k)    
            A(:, [k, m]) = A(:, [m, k]);    
            aux = index(k);    
            index(k) = index(m);           
            index(m) = aux;      
        end
        for l = k+1:n       
            A(l, :) = A(l, :) - A(l, k) .* A(k, :) / A(k, k);    
        end
    end
    if A(n, n) == 0    
        x(1:n) = 0;    
        disp('Sist. incompatibil sau compatibil nedet.'); 
        return;   
    end
    b = A(:, n+1);
    A(:, n+1) = [];   
    xold = SubsDesc(A, b);  
    for i = 1:n   
        x(index(i)) = xold(i);  
    end
end

%Metoda Substitutiei Descendente pentru un sistem superior triunghiular
function x = SubsDesc(A, b)   
    n = length(b);   
    x(n) = b(n) / A(n, n);   
    for i=n-1:-1:1   
        x(i) = (b(i) - sum(A(i, i+1:n) .* (x(i+1:n)))) / A(i, i);  
    end
end

%Exercitiul 4- a)
%metoda iterativa Jacobi de rezolvare a sistemelor de ecuatii liniare
%conform algoritmului dat in cursul 5
function [xaprox, N] = MetJacobi2(A,a, eps)   
    n = size(A,1);   
    B = eye(n) - A; 
    q = normap(B,1);  
    b = a;
    if q >= 1     
        fprintf ('Metoda Jacobi nu asigura convergenta');    
        return;  
    end
    x(:,1) = zeros(n,1); 
    k = 1;  
    cond = 1;
    while cond       
        k= k+1;      
        x(:,k) =  B * x(:,k-1)+b;    
        if( q^k)/(1-q)*norm(x(:,2) - x(:,1), 1) < eps      
            cond = 0;   
        end
    end
    xaprox = x(:,k);   
    N = k;
end

%Exercitiul 4 -b)
%Metoda Jacobi pentru matrice diagonal dominante pe linii
function [xaprox,N] = MetJacobiDDL(A,a,eps) 
    n = size(A,1); 
    b = zeros(1,n);
    B = zeros(n,n);
    for i = 1:n  
        suma = 0;   
        for j = 1:n   
            if j ~= i     
                suma = suma + abs(A(i,j));  
            end
        end
        if abs(A(i,i)) <= suma     
            fprintf('Matr nu este diag dom pe linii');    
            return;   
        end
    end
    x(:,1) = zeros(n,1);
    k = 1;  
    for i = 1:n   
        b(i) = a(i) / A(i,i);  
        for j = 1:n        
            if i == j       
                B(i,j) = 0;      
            else
                B(i,j) = - A(i,j) / A(i,i);   
            end
        end
    end
    q = normap(B,inf);   
    cond = 1;  
    while cond == 1     
        k = k+1;       
        x(:,k) = B * x(:,k-1) + transpose(b);   
        if (q^k / (1-q) * norm((x(:,2) - x(:,1)),inf)) < eps       
            cond = 0;      
        end
    end
    xaprox = x(:,k);   
    N = k; 
end

%Exercitiul 4 - c)
%Metoda Jacobi relaxata
function [xaprox, N] = MetJacobiR (A,a,eps) 
    lambda = MetJacobi(A, eps); 
    n = size(A,1); 
    B = zeros(n,n);
    b = zeros(1, n);
    lambdaMin = lambda(1);
    lambdaMax = lambda(1);  
    for i = 1:n        
        if lambda(i) > lambdaMax      
            lambdaMax = lambda(i);    
        end
        if lambda(i) < lambdaMin        
            lambdaMin = lambda(i);    
        end
    end
    sigmaO = 2/(lambdaMax + lambdaMin);  
    qO = (lambdaMax - lambdaMin) / (lambdaMax + lambdaMin);   
    I = eye(n);  
    for i = 1:n    
        for j = 1:n      
            B(i,j) = I(i,j) - sigmaO*A(i,j);     
        end
    end
    for i = 1:n   
        b(i) = sigmaO * a(i);   
    end
    x(:,1) = zeros(n,1);  
    k = 1;  
    cond = 1;  
    while cond == 1     
        k = k + 1;  
        x(:,k) = B * x(:,k-1) + transpose(b);    
        if (qO ^ k / (1 - qO)) * normaA( A, (x(:,2) - x(:,1))) < eps     
            cond = 0;       
        end
    end
    xaprox = x(:,k);  
    N = k;
end


function norma = normaA(A, x) 
    n = size(A,1);   
    suma = 0;   
    for i = 1:n     
        for j = 1:n       
            suma = suma + A(i,j) * x(j) * x(i);    
        end
    end
    norma = suma;
end

