%% Lina Cristian 343 - Tema 5
% 9/10 -> Lipsa argumentari

%% Exercitiul 1

A = [3 1 1; 1 3 1; 1 1 3];
n = normap(A,1); n2 = normap(A,2); nInf = normap(A,inf);
disp(n); disp(n2); disp(nInf);


%% b) 

A = [3 1 1; 1 3 1; 1 1 3];
raza = RazaSpect(A);
disp(raza);

%% c)

A = [3 1 1; 1 3 1; 1 1 3];
con1 = condp(A,1); con2 = condp(A,2); conInf = condp(A,Inf);
disp(con1); disp(con2); disp(conInf);

%% d)

A = [3 1 1; 1 3 1; 1 1 3];
n = norm(A,1); n2 = norm(A,2); nInf = norm(A,inf); 
con1 = cond(A,1); con2 = cond(A,2); conInf = cond(A,inf);
disp(n); disp(n2); disp(nInf);
disp(con1); disp(con2); disp(conInf);


%% Exercitiul 2

A = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];
b = [32; 23; 33; 31];
[xsol1] = GaussPivTot(A,b);
disp(xsol1);

%% b)

A = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];
pert = [32.1; 22.9; 33.1; 30.9];
[xsol2] = GaussPivTot(A,pert);
disp(xsol2); 
 
%% c)

A = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];
b = [32; 23; 33; 31]; x = [1; 1; 1; 1];
conInf = condp(A, inf);
dx = xsol2 - xsol1;
ndInf = norm(dx, Inf); nxInf = norm(x, Inf); 
disp(ndInf / nxInf);

db = pert - b;
ndInf = norm(db, Inf); nbInf = norm(b, Inf); 
disp(conInf*(ndInf/nbInf));
 
%% d)

Ap = [10 7 8.1 7.2; 7.08 5.04 6 5; 8 5.98 9.89 9; 6.99 4.99 9 9.98];
b = [32; 23; 33; 31];
xp = GaussPivTot(Ap,b); 
disp(xp);

%% Exercitiul 5

A = [0.2 0.01 0; 0 1 0.04; 0 0.02 1];
a = [1;2;3]; epsilon = 10^(-5); 
[xaprox,N] = MetJacobiSol(A,a,epsilon);
disp(xaprox); disp(N);

%% b)

A = [4 1 2; 0 3 1; 2 4 8];
a = [1;2;3]; epsilon = 10^(-5); 
[xaprox, N] = MetJacobiDDL(A,a,epsilon);
disp(xaprox); disp(N);

%% c)

C = [4 2 2; 2 10 4; 2 4 6];
[xaprox,N] = MetJacobiRel(A,a,epsilon);
disp(xaprox); disp(N);

%%

function [nrm] = normap(A,p)
    n = length(A);
    if(p == 1 || p ~= 2)
        A = abs(A);
        nrm = min(min(A));
        for j = 1:n          
            s = 0;          
            for i = 1:n        
                s = s + A(i,j);        
            end
            if(s > nrm)
                nrm = s;         
            end
        end
    elseif(p == 2)
            B = (A')*A;  
            epsilon = 10^(-5); 
            lmd = MetJacobi(B,epsilon);  
            nrm = max(sqrt(lmd));
    end
end

% din tema 4
function [lmd] = MetJacobi(A, epsilon)
    n = length(A); 
    lmd = zeros(n,1);
    % calculam modulul matricei
    modA = ModA(A);
    while modA >= epsilon
       maxim = 0;
       for i = 1:n-1
          for j = i+1:n
              if abs(A(i,j)) > maxim
                  maxim = abs(A(i,j));
                  p = i; q = j;
              end
          end
       end
       if (A(p,p) == A(q,q))
           t = pi/4;
       else
           t = 1/2 * atan(2 * A(p,q) / (A(q,q) - A(p,p)));
       end
       c = cos(t); s = sin(t);
       for j = 1:n
           if (j~=p && j~=q)
              u = A(p,j)*c-A(q,j)*s;
              v = A(p,j)*s+A(q,j)*c;
              A(p,j) = u; A(q,j) = v; A(j,p) = u; A(j,q) = v;
           end
       end
       u = c.^2*A(p,p) - 2*c*s*A(p,q) + s.^2*A(q,q);
       v = s.^2*A(p,p) + 2*c*s*A(p,q) + c.^2*A(q,q);
       A(p,p) = u; A(q,q) = v; A(p,q) = 0; A(q,p) = 0;
       modA = ModA(A);
    end
    for i = 1:n
        lmd(i) = A(i,i);
    end
end

% modulul matricei (tema 4)
function [modA] = ModA(A)
    modA = 0; n = length(A);
    for i = 1:n      
        for j = 1:n     
            if(i~=j)       
                modA = modA + A(i,j)*A(i,j);      
            end
        end
    end
end


function [maxim] = RazaSpect(A)
    epsilon = 10^(-5);      
    lmb = MetJacobi(A,epsilon);       
    maxim = max(abs(lmb));        
end

function [nrc] = condp(A,p)    
    n1 = normap(A,p);   
    nInv = normap(inv(A),p);   
    nrc = n1*nInv;
end

function [x] = GaussPivTot(a,b)
    % concatenam coloana b la matricea a (mat. extinsa)
    ae = [a, b];
    % nr de linii a matricei
    n = length(b);
    % formam vectorul de indexi
    index = ones(n,1);
    for i = 1:n
       index(i) = i; 
    end
    % implementarea propriu-zisa a algoritmului descris in curs
    for k = 1 : n-1
       % maxim va avea ca valoare initiala minimul din submatrice         
       maxim = min(min(abs(ae(k:n,:))))-1;
       ind1 = 0; ind2 = 0;
       % cautam in submatrice
       for p = k : n
           for m = k : n
               % daca gasim o valoare mai mare ca max, il actualizam
               if(abs(ae(p,m)) > maxim)
                   maxim = abs(ae(p,m));
                   ind1 = p; ind2 = m;
               end
           end          
       end
       if(ae(ind1,ind2) == 0)
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
       end
       if(ind1 ~= k)
%          % interschimbam liniile
           ae([k,ind1],:) = ae([ind1,k],:);
       end
       if(ind2 ~= k)
           % interschimbam coloanele; actualizam vec de indexi
           ae(:,[k,ind2]) = ae(:,[ind2,k]);
           ind = index(ind2);
           index(ind2) = index(k); index(k) = ind;
       end
       for l = k + 1 : n
          if(ae(l,k) ~= 0)
            m = ae(l,k)/ae(k,k);
            ae(l,:) = ae(l,:) - m*ae(k,:); 
          end          
       end
    end
    if(ae(n,n) == 0)
       disp('Sistem incop. sau sistem comp. nedet.');
    end
    [y] = SubsDesc(ae(:,1:n),ae(:,n+1));
    % ordonam rezultatul dupa vectorul de indexi
    x = zeros(length(y),1);
    for i = 1:length(y)
       x(index(i)) = y(i);
    end
end

function [x] = SubsDesc(a,b)
    % avem matricea superior triunghiulara a cu solutiile b
    n = length(a);
    x = zeros(n,1);
    % calculam xn
    x(n) = 1/a(n,n)*b(n);
    k = n - 1;
    % continua algoritmul ca cel descris in curs
    while(k>0)
       sum = 0;
       for j = k+1 : n
           sum = sum + a(k,j)*x(j);
       end
       x(k) = 1/a(k,k)*(b(k)-sum);
       k = k - 1;
    end
end

function [xaprox,k] =  MetJacobiSol(A, a, epsilon)
    n = length(A);
    I = eye(n);
    q = norm(I - A, Inf);
    if(q >= 1)
       disp('Met Jacobi nu asigura convergenta');
       return;
    end
    % in xk0 si xk1 voi retine primele 2 valori calculate
    % in x0 si xaprox vor fi retinute valorile xk si xk-1
    x0 = 0; xk0 = 0; xk1 = 0; k = 0; ok = 1;
    B = I - A; b = a;
    while(ok == 1)
        k = k + 1;
        xaprox = B * x0 + b;
        if(k == 1)
            xk1 = xaprox;
        end
        if((q^k / (1-q)) * norm((xk1 - xk0),Inf) < epsilon)
            ok = 0;
        end
        x0 = xaprox;
    end
    xaprox = xaprox(:,1);
end

function [xaprox,k] = MetJacobiDDL(A,a,epsilon) 
    n = length(A); 
    for i = 1:n
       sum = 0;
       for j = 1:n
          if(j~=i)
             sum = sum + abs(A(i,j)); 
          end
       end
       if(abs(A(i,i)) <= sum)
          disp('Matr. nu este diag. dom. pe linii');
          return;
       end
    end
    % in xk0 si xk1 voi retine primele 2 valori calculate
    % in x0 si xk vor fi retinute valorile xk si xk-1
    x0 = 0; xk0 = 0; xk1 = 0; k = 1;  
    for i = 1:n   
        for j = 1:n        
            if i == j       
                B(i,j) = 0;      
            else
                B(i,j) = (-1)*A(i,j)/A(i,i);   
            end
        end
        b(i) = a(i)/A(i,i);
    end
    q = norm(B,Inf); ok = 1; 
    while(ok == 1)     
        k = k + 1;       
        xk = B * x0 + b';
        if(k == 1)
           xk1 = xk; 
        end
        if((q^k/(1-q)*norm((xk1 - xk0),Inf)) < epsilon)
            ok = 0;      
        end
        x0 = xk;
    end
    xaprox = xk(1,:);
end

function [xaprox,k] = MetJacobiRel(A,a,epsilon) 
    n = length(A);
    [lmb] = MetJacobi(A,epsilon);      
    l1 = min(lmb); l2 = max(lmb);  
    s = 2/(l2 + l1); q = (l2 - l1) / (l2 + l1);   
    I = eye(n);
    for i = 1:n  
        for j = 1:n      
            B(i,j) = I(i,j) - s*A(i,j);     
        end
        b(i) = s * a(i);
    end
    x0 = 0; xk0 = 0; xk1 = 0; k = 0; ok = 1;
    while(ok == 1)
        k = k + 1;
        xk = B * x0 + b';
        if(k == 1)
           xk1 = xk; 
        end
        [nor] = normA(A,(xk1 - xk0));
        if ((q^k/(1-q)*nor) < epsilon)    
            ok = 0;       
        end
    end
    xaprox = xk(:,1);
end

function [s] = normA(A, x) 
    n = length(A); s = 0;   
    for i = 1:n     
        for j = 1:n       
            s = s + A(i,j) * x(j) * x(i);    
        end
    end
end

