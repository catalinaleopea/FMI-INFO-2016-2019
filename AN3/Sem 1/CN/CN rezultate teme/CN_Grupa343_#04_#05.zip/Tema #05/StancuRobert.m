%%

% Author: Stancu Robert
% Grupa: 343
% 9/10 -> argumentari + neatentii

%% !!!
clc
% =================================== 1.a =================================
A = [3 1 1; 1 3 1; 1 1 3];

norma1 = normap(A,1);
norma2 = normap(A,2);
normaInf = normaInf(A,inf); % <- Neatentie

disp('Norma 1 a matricei A este: ')
norma1

disp('Norma 2 a matricei A este: ')
norma2

disp('Norma infinit a matricei A este: ');
normaInf


%%
% =================================== 1.b =================================
A = [3 1 1; 1 3 1; 1 1 3];

epsilon = 10^(-4);
lambda = MetodaJacobi(A,epsilon);

razaSpectrala = max(abs(lambda));

disp('Raza spectrala este: ')
razaSpectrala


%%
% =================================== 1.c =================================

A = [3 1 1; 1 3 1; 1 1 3];

nrCond1 = condp(A,1);
nrCond2 = condp(A,2);
nrCondInf = condp(A,inf);

disp('Numarul de conditionare 1 este :');
nrCond1

disp('Numarul de conditionare 2 este :');
nrCond2

disp('Numarul de conditionare inf este :');
nrCondInf

%%
% =================================== 1.d =================================

A = [3 1 1; 1 3 1; 1 1 3];

norma1 = norm(A,1);
norma2 = norm(A,2);
normaInf = norm(A,inf);

nrCond1 = cond(A,1);
nrCond2 = cond(A,2);
nrCondInf = cond(A,inf);

disp('Norma 1 a matricei A este: ')
norma1

disp('Norma 2 a matricei A este: ')
norma2

disp('Norma infinit a matricei A este: ');
normaInf

disp('Numarul de conditionare 1 este :');
nrCond1

disp('Numarul de conditionare 2 este :');
nrCond2

disp('Numarul de conditionare inf este :');
nrCondInf


%%
% =================================== 2.a =================================

A = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];
b = [32 23 33 31]';

x = GaussPivTotala(A,b);

disp('Solutia x este: ');

x

%%
% =================================== 2.b =================================
A = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];
b = [32.1 22.9 33.1 30.9]';

x = GaussPivTotala(A,b);
disp('Solutia x perturbata este: ');
x

%Solutiile difera 

%%
% =================================== 2.c =================================

A = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];

b = [32 23 33 31]';
bperturbat = [32.1 22.9 33.1 30.9]';

x = GaussPivTotala(A,b);
xperturbat = GaussPivTotala(A,bperturbat);

disp('Numarul K_inf_(A) este: ');
nrCondInf = condp(A,inf)

disp('Raportul normelor in functie de x este: ');
norm(xperturbat-x,inf)/norm(x,inf)

disp('Raportul normelor in functie de b este: ');
nrCondInf * (norm(bperturbat - b,inf) / norm(b,inf))

% Raportul normelor xperturbat si x este egal cu raportul normelor
% bperturbat si b inmultit cu numarul de conditionare al matricei A

%%
% =================================== 2.d =================================

Aperturbat = [10 7 8.1 7.2; 7.08 5.04 6 5; 8 5.98 9.89 9; 6.99 4.99 9 9.98];
b = [32 23 33 31]';

x = GaussPivTotala(Aperturbat,b);

disp('Solutia sistemului este: ')
x

%%
% =================================== 5.a =================================

A1 = [0.2 0.01 0; 0 1 0.04;0 0.02 1];
A2 = [4 1 2; 0 3 1; 2 4 8];
A3 = [4 2 2; 2 10 4; 2 4 6];

n = length(A1);

if norm(eye(n,n) - A1,inf) >= 1
    disp('Nu se poate aplica metoda Jacobi pentru matricea A1');
else
    disp('Se poate aplica metoda Jacobi pentru matricea A1');
end

 n = length(A2);
 Ac = abs(A2);
 ok = 0;
 
for i = 1:n
        if i == 1
            suma = sum(Ac(i,2:end));
        elseif i == n
            suma = sum(Ac(i,1:end-1));
        else
            suma = sum(Ac(i,1:i-1)) + sum(Ac(i,i+1:end));
        end
        
     if Ac(i,i) <= suma
           disp('Se poate aplica metoda JacobiDDL pentru matricea A2');
           ok = 1;
      end
end

if ok == 0
     disp('Se poate aplica metoda JacobiDDL pentru matricea A2');
end

    epsilon = 10^(-4);
    lambda = MetodaJacobi(A3,epsilon);
    
    maxL = max(lambda);
    minL = min(lambda);
    
    sigmaZero = 2 / (maxL + minL);
    razaSpectrala = max(abs(lambda));
    
    
    if(sigmaZero < 0 || sigmaZero > 2 /razaSpectrala)
        disp('Nu se poate aplica metoda Jacobi Relaxata pentru matricea A3');
    else
        disp('Se poate aplica metoda Jacobi Relaxata pentru matricea A3');
    end

%%
A1 = [0.2 0.01 0; 0 1 0.04 ;0 0.02 1];
a = [1 2 3]';

epsilon = 10^(-5);
[xAprox1,N1] = MetJacobi(A1,a,epsilon);

disp('Solutia pentru matricea A1 este:');
xAprox1

A2 = [4 1 2; 0 3 1; 2 4 8];
[xAprox2,N2] = MetJacobiDDL(A2,a,epsilon);

disp('Solutia pentru matricea A2 este:');
xAprox2

A3 = [4 2 2;2 10 4;2 4 6];
[xAprox3,N3] = MetJacobiR(A3,a,epsilon);

disp('Solutia pentru matricea A3 este:');
xAprox3


%%

function [xaprox,N] = MetJacobi(A,a,epsilon)

     [n,~] = size(A);
      q = norm(eye(n,n) - A,inf);
      if q  >= 1
          disp('Metoda Jacobi nu asigura convergenta');
          xaprox = inf;
          N = inf;
          return ;
      end
     
      x0 = zeros(1,length(A))';
      x1 = zeros(1,length(A))';
      
      
      B = eye(n,n) - A;
      b = a;
      
      x1 = B * x0 + b;
      
      x = x1;
      
      k = 1;
   
      while true
        k = k + 1;
        x = B * x + b;
        
        if( (q^k/(1 - q)) * norm(x1 - x0,inf) < epsilon)
            break;
        end
      end
      
    xaprox = x;
    N = k;
      
end

function [xaprox,N] = MetJacobiDDL(A,a,epsilon)

    n = length(A);
    Ac = abs(A);
    
    for i = 1:n
        if i == 1
            suma = sum(Ac(i,2:end));
        elseif i == n
            suma = sum(Ac(i,1:end-1));
        else
            suma = sum(Ac(i,1:i-1)) + sum(Ac(i,i+1:end));
        end
        
        if Ac(i,i) <= suma
           disp('Matricea nu este diagonal dominanta pe linii');
           xaprox = inf;
           N = inf;
           return;
        end
    end
    
    x0 = zeros(length(A),1);
    
    B = zeros(size(A));
    b = zeros(length(A),1);
    
    for i = 1:n
        
        for j = 1:n
           if i == j
               B(i,j) = 0;
           else
               B(i,j) = - A(i,j) / A(i,i);
           end
        end
           
        b(i) = a(i) / A(i,i);
    end
    
    q = norm(B,inf);

    x1 = B * x0 + b;
      
    x = x1;
    
    k = 1;
   
    while true
        k = k + 1;
        
        x = B * x + b;
        
        if( (q^k/(1 - q)) * norm(x1 - x0,inf) < epsilon)
            break;
        end
        
      end
      
    xaprox = x;
    N = k;

end

function [xaprox,N] = MetJacobiR(A,a,epsilon)
   
    n = length(A);
    lambda = MetodaJacobi(A,epsilon);
    
    maxL = max(lambda);
    minL = min(lambda);
    
    sigmaZero = 2 / (maxL + minL);
    q0 = (maxL - minL) / (maxL + minL);
    
    B = eye(n) - (sigmaZero*A);
    b = sigmaZero * a;
    
    x0 = zeros(n,1);
    
    x = x0;
    
    x1 = B * x0 + b;
    
    k = 1;
    
    x = x1;
    
    while true
       k = k + 1; 
       x = B * x + b; 
       
       xtemp = x1 - x0;
       
       suma = 0;
       
       for i = 1:n
           for j = 1:n
                suma = suma + A(i,j) * xtemp(i) * xtemp(j);
           end
       end
       
       if( (q0^k/(1-q0)) * suma < epsilon)
            break;
       end
    end
    
    xaprox = x;
    N = k;
    
end

function [norma] = normap(A,p)
    
    if p == 1
        
    norma = max(sum(abs(A)));
        
    elseif p == 2
        
        epsilon = 10^(-4);
        lambda = MetodaJacobi(A' * A,epsilon);
        maxLambda = max(lambda);
        norma = sqrt(maxLambda);
        
    elseif p == inf
       norma = max(sum(abs(A')));
    end
    
end

function [nrcond] = condp(A,p)
    
    [Ainv,~] = GaussJordan(A);
    
    nrcond =  normap(A,p) * normap(Ainv,p);
    
end

function [invA,detA] = GaussJordan(A)

[n,~] = size(A);

Ae = [A eye(n,n)];
determinant = 1;

for k = 1:n-1
    
   [maxim,index] = max(abs(Ae(k:n,k) ~= 0)); % Cautam maximul pe linia curenta 
   
   if maxim == 0
      fprintf('Sistem incompatibil / Sistem compatibil nedet\n');
      x = infinity;
      return %Oprim algoritmul
   end
   
   index = index + k - 1;
   
   if index ~= k
       Ae([k index],:) = Ae([index k],:); % Interschimbam liniile
       determinant = determinant * (-1);
   end
   
   for l = k+1:n
      factor = Ae(l,k) / Ae(k,k); % Calculam raportul pentru a transforma
                                  % elementele de sub diagonala principala
                                  % in 0
                                  
      Ae(l,:) = Ae(l,:) - factor * Ae(k,:); 
   end
  
end

determinant = determinant * prod(diag(Ae));


for k = n:-1:1
   Ae(k,:) = Ae(k,:) / Ae(k,k);
     
   for l = k-1:-1:1
      factor = Ae(l,k) * Ae(k,k);
      
      Ae(l,:) = Ae(l,:) - factor * Ae(k,:);
   end
end

detA = determinant;
invA = Ae(1:n,n+1:end);

end

function [lambda] = MetodaJacobi(A,epsilon)

% Calculam modulul matricei A dupa formula de la curs
modul = A.*~eye(size(A));
modul = modul .^2;
modul = sum(sum(modul));

[~,n] = size(A);

while modul >= epsilon
        p = 1;
        q = 2;
        maximum = abs(A(1,2));
        
    for i = 1:n - 1
        for j = i + 1:n
            if maximum < abs(A(i,j))
                p = i;
                q = j;
                maximum = abs(A(i,j));
            end
        end
    end
    
    if A(p,p) == A(q,q)
        theta = pi/4;
    else
        theta = 1 / 2 * atan(2 * A(p,q) / (A(q,q) - A(p,p)));
    end
    
    c = cos(theta);
    s = sin(theta);
    
    for j = 1:n
        if j ~= p && j ~= q
            u = A(p,j) * c - A(q,j) * s;
            v = A(p,j) * s + A(q,j) * c;
            A(p,j) = u;
            A(q,j) = v;
            A(j,p) = u;
            A(j,q) = v; 
        end
    end      
    
    u = c ^ 2 * A(p,p) - 2 * c * s * A(p,q) + s ^ 2 * A(q,q);
    v = s ^ 2 * A(p,p) + 2 * c * s * A(p,q) + c ^ 2 * A(q,q);
    
    A(p,p) = u;
    A(q,q) = v;
    A(p,q) = 0;
    A(q,p) = 0;
    
    modul = A.*~eye(size(A));
    modul = modul .^2;
    modul = sum(sum(modul));
   
end

lambda = diag(A);

end

function x = GaussPivTotala(A,b)

faraSolutie = inf(1); 

% Dimensiunea matricei A
[n, ~] = size(A);

% Bordam matricea A cu vectorul coloana b
Ae = [A b];

% Pozitiile elementelor xi,i = 1:n
index = 1:n;

for k = 1:n - 1

    
    %Cautam maximul in modul de pe toata submatricea
    [maximLinie,IndexLinie] = max(abs(Ae(k:n,k:n)));

    % Functia max va returna maximul de pe fiecare coloana,
    % deci functia max va trebui aplicata de doua ori
    
    [~,coloanaMaxim] = max(maximLinie);
    linieMaxim = IndexLinie(coloanaMaxim);
    
    if maximLinie(coloanaMaxim) == 0
      fprintf('Sistem incompatibil / Sistem compatibil nedet\n');
      x = faraSolutie;
      return;
    end
    
    % Incrementam coloana si linia unde se afla elementul respectiv
    coloanaMaxim = coloanaMaxim + k - 1; 
    linieMaxim = linieMaxim + k - 1;
   
    %Interschimbam liniile
   if linieMaxim ~= k
       Ae([k, linieMaxim],:) = Ae([linieMaxim, k],:);
   end
   
   % Interschimbam coloanele
   if coloanaMaxim ~= k
       Ae(:,[k,coloanaMaxim]) = Ae(:,[coloanaMaxim,k]);
       temp = index(k);
       index(k) = index(coloanaMaxim);
       index(coloanaMaxim) = temp;
   end
   
   for l = k+1:n
      factor = Ae(l,k) / Ae(k,k); % Calculam raportul pentru a transforma
                                  % elementele de sub diagonala principala
                                  % in 0
      
      
      Ae(l,:) = Ae(l,:) - factor * Ae(k,:);
   end
   
end

if Ae(n,n) == 0
    fprintf('Sistem incompatibil sau sist comp nedet\n');
    x = faraSolutie;
    return;
end

 % Avand o matrice superior triunghiulara, putem aplica substitutia 
 % descendenta
x = SubsDesc(Ae(1:n,1:n),Ae(1:n,n+1));

 % Schimbam ordinea elementelor solutiei
 
x(index) = x;

end

function x = SubsDesc(A,b)

[n, ~] = size(A); % Dimensiunea matricei A

x(n) = (1/A(n,n)) * b(n); % Aflam elementul xn

k = n - 1;

% Iteratiile algorimtului

while k > 0
    
   product = sum(A(k,k+1:n) .* x(k+1:n)); % Calculam suma din
                                          % produsul scalar 
                                          
                                          
   x(k) = (1/A(k,k)) * (b(k) - product); % Aflam x(k)
   k = k - 1;
end


end




