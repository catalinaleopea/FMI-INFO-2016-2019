function [raza] = razaSpec(A)
    % Am incercat sa implementez algoritm pentru calcularea spectrului de
    % valori proprii ai lui A
    
    %syms lambda;    
    %I3 = [1 0 0; 0 1 0; 0 0 1];
    %newA = A - lambda * I3;
    
    X = eig(A);         % Pun valorile proprii ale lui A intr-un vector
    X = X';             % Deoarece el este vector coloana, il transpun
    n = length(X);      % Calculez lungimea noului vector obtinut
    for i = 1:n
        X(i) = abs(X(i));   % Transform fiecare valoare din vector intr-una
                            %               absoluta a acesteia.
    end
    raza = max(X);     % Returnez maximul din vectorul X modificat anterior
    
end