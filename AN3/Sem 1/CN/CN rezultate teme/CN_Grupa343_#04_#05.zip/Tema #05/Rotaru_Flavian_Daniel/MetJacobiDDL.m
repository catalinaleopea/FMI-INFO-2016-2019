function [x_aprox, N] = MetJacobiDDL(A, a, eps)
    n = size(A,1);
    N = 0;
    I = eye(size(A));
    b = a ./ diag(A);
    B = I - A ./ repmat(diag(A), 1, n);
    y = B * zeros(size(A, 1), 1) + b;
    errfact = norm(y, 2);
    k = 1;
    q = norm(B, inf);
    while 1
        newb = B * y + b;
        k = k+1;
        if q^k / (1 - q) * errfact < eps
            break;
        end
        y = newb;
    end
    
    x_aprox = newb;
    N = k;
end