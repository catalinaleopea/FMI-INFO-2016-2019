function [x_aprox, N] = MetJacobi(A, a, eps)
    N = 0;
    I = eye(size(A));
    q = norm(I-A);
    
    B = I - A;
    b = a;
 
    y = B * zeros(size(A, 1), 1) + b;
    errfac = y;
    k = 2;
    while 1
        k = k + 1;
        newx = B * y + b;
        if q^k / (1 - q) * norm(errfac) < eps
            break
        end
        y = newx;
    end
    x_aprox = y;
    N = k;
end