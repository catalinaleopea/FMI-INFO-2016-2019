% 7.5/10 -> lipsa ex.5 + argumentari
%==========================================================================
% EX.1 - Fie matricea :
% 
%     (3 1 1)
% A = (1 3 1)
%     (1 1 3)
%     
%  Sa se calculeze in matlab: 
%  a) Normele matriciale in functie de p = 1, 2,?.
%  b) Raza spectrala si cum este raza spectrala fata de norme.
%  c) Numarul de conditionare dupa p = 1, 2, ?.
%  d) Normele si numarul de conditionare al lui A prin norm(A,p) si 
%           cond(A,p).
%==========================================================================
    
    A = [3 1 1; 1 3 1; 1 1 3];
    
% - Punctul a) 

normap1 = normap(A,1);
normap2 = normap(A,2);
normapinf = normap(A,'Inf');

Norms = [normap1 normap2 normapinf];

for(i = 1: length(Norms))
    fprintf('Norma lui A cu p = %d este %f \n',i, Norms(i));
end
    fprintf('\n')
%--------------------------------------------------------------------------

% - Punctul b)

Raza = razaSpec(A);

fprintf('Raza Spectrala a lui A este %f \n', Raza);
fprintf('\n')

% Raza spectrala este egala cu normele calculate la punctul anterior

%--------------------------------------------------------------------------

% - Punctul c)

condp1 = condp(A,1);
condp2 = condp(A,2);
condpinf = condp(A,'Inf');

Conds = [condp1 condp2 condpinf];

for(i = 1: length(Conds))
    fprintf('Numarul conditional al lui A cu p = %d este %f \n',i, Conds(i));
end
    fprintf('\n')

%--------------------------------------------------------------------------

% - Punctul d)

Norms2 = [norm(A,1) norm(A,2) norm(A,Inf)];
Conds2 = [cond(A,1) cond(A,2) cond(A,Inf)];

for(i = 1: length(Norms))
    fprintf('Norma lui A, calculata cu functia norm(A,p), cu p = %d este %f \n',i, Norms(i));
end
    fprintf('\n')

for(i = 1: length(Conds))
    fprintf('Numarul conditional al lui A, calculat cu functia cond(A,p), cu p = %d este %f \n',i, Conds(i));
end
    fprintf('\n')


% Normele, calculate cu functia norm, sunt egale cu cele calculate 
%       la punctul a).
% Numerele de conditionare, calculate cu functia cond,
%       nu sunt egale cu cele calculate la punctul c).

%%
%==========================================================================
% EX.2 - Fie matricile :
% 
%     (10 7 8 7 )           (32)        (1)
% A = (7  5 6 5 )       b = (23)    x = (1)
%     (8  6 9 10)           (33)        (1)
%     (7  5 9 10)           (31)        (1)
%     
%  Sa se calculeze in matlab: 
%  c) K(A,inf). Sa se calculeze si sa se masoare marimile:
%     normap(delta * x, inf) / normap(x, p) si
%     condp(delta * b , inf) / condp (b, inf)
%==========================================================================
    
    A = [10 7 8 7; 7 5 6 5; 8 6 9 10; 7 5 9 10];
    
    b = [32; 23; 33; 31];
    newb = [32.1 22.9 33.1 30.9];
    
    x = [1; 1; 1; 1];
    
%--------------------------------------------------------------------------

condA = condp(A,'Inf');
fprintf('Numarul conditional al lui A cu p = inf este %f \n',condA);
    
delta = (newb' - b)/b;

NormDiv1 = norm(delta* x, Inf) / norm(x, Inf);

fprintf('Raportul normelor << norm(delta* x, Inf) si norm(x, Inf)>> \n este egal cu: %f\n\n', NormDiv1);

NormDiv2 = norm(delta*b, Inf) / norm(b,Inf);
ProdFin = cond(A,Inf) * NormDiv2;

fprintf('Produsul final dint numarul conditional al matricei A si raportul normelor <<norm(delta*b, Inf) si norm(b,Inf)>> \n este egal cu: %f\n\n', ProdFin);




    
    
    
