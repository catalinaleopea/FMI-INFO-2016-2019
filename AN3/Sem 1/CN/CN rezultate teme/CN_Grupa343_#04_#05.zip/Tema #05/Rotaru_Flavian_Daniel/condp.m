function [condp] = condp(A,p)
    invA = inv(A);      % Stochez intr-o variabila inversul lui A.
    condp = normap(A,p) * normap(invA,p);   
                        % calculez condp plrin inmultirea normelor in
                        % functie de p.
end