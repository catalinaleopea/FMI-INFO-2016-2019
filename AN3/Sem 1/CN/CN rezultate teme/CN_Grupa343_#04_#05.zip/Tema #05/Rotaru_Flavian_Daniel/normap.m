function [normap] = normap(A,p)
    [m,n] = size(A);        % Stocam in variabilele m si n numarul de 
                            %                   linii, respectiv coloane.
    % Calculam norma matriciala a lui A in functie de p-ul introdus: 1,2
    % sau infinit.
    if (p == 1)         % Cazul in care p-ul introdus este 1.
        for j = 1:n
            sum = 0;
            for i = 1:m
                sum = sum + A(i,j);     % Calculam suma elementelor 
                                        %       fiecarei coloane
            end
            X(j) = sum;     % Punem sumele pentru fiecare coloana
                            %               intr-un vector X.
        end
        normap = max(X);    % Returnam maximul din vectorul sumelor.
    end
    
    if (p == 'Inf')         % Cazul in care p-ul introdus este infinit.
        for i = 1:m
            sum = 0;
            for j = 1:n
                sum = sum + A(i,j);     % Calculam suma elementelor 
                                        %       fiecarei linii
            end
            X(j) = sum;     % Punem sumele pentru fiecare linie
                            %               intr-un vector X.
        end
        normap = max(X);    % Returnam maximul din vectorul sumelor.
    end
    
    if(p == 2)              % Cazul in care p-ul introdus este 2.
        X = svd(A);         % svd = valorile proprii asociate matricei 
                            %              simetrice B = A' * A si le punem
                            %                       intr-un vector X .
        X = X';             % Datorita faptului ca X este vector coloana, 
                            %                       il transpunem.
        normap = max(X);    % Returnam maximul din vectorul X. 
    end
end



