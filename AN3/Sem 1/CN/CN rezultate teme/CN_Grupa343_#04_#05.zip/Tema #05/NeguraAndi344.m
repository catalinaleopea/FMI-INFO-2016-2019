% 5/10
%ex 4
%met jacobi
function [xaprox, N] = MetJacobi(A, a, eps)
    q = norm(eye(size(A,1)) - A);
    if q >= 1
        disp('Metoda Jacobi nu asigura conv.');
        return
    end
    % Nu sunt necesare si parantezele patrate
    x = [zeros(size(A,1),1)];
    k = 1;
    B = eye(size(A)) - A;
    b = a;
    cond = 1;
    while cond == 1
        k = k + 1;
        x = [x, B*x(:,k-1)+b];
        if q^k/(1-q)*norm(x(:,2) - x(:,1)) < eps
            cond = 0;
        end
    end
    xaprox = x(:,k);
    N = k;
end

%MetJacobiDDL
function [xaprox, N] = MetJacobiDDL(A, a, eps)
    n = size(A,1);
    for i = 1:n
       if abs(A(i,i)) <= sum(abs(A(i,1:n))) - abs(A(i,i))
           disp('Matricea nu este diagonal dominanta pe linii');
           break;
       end
    end
    x = [zeros(n,1)];
    k = 1;
    for i = 1:n
        for j = 1:n
            if i==j
                delta = 1;
            else
                delta = 0;
            end
            B(i,j) = delta - A(i,j)/A(i,i);
        end
        b(i,1) = a(i)/A(i,i);
    end
    q = norm(B,inf);
    cond = 1;
    while cond == 1
        k = k + 1;
        x = [x, B*x(:,k-1)+b];
        if q^k/(1-q)*norm(x(:,2) - x(:,1),inf) < eps
            cond = 0;
        end
    end
    xaprox = x(:,k);
    N = k;
end

%met Jacobi R
function [xaprox, N] = MetJacobiR(A, a, eps, sigma)
    n = size(A,1);
    for i = 1:n
        for j = 1:n
            if i==j
                delta = 1;
            else
                delta = 0;
            end
            B(i,j) = delta - sigma*A(i,j);
        end
        b(i,1) = sigma*a(i);
    end
    x = zeros(n,1);
    k = 1;
    cond = 1;
    while cond == 1
        k = k + 1;
        x = [x, B*x(:,k-1)+b];
        s1 = 0;
        s2 = 0;
        t1 = x(:,k) - x(:,k-1);
        t2 = x(:,k-1);
        for i = 1:n
            for j = 1:n
                s1 = s1 + A(i,j)*t1(i)*t1(j);
                s2 = s2 + A(i,j)*t2(i)*t2(j);
            end        
        end
        if s1/s2 < eps
            cond = 0;
        end
    end
    xaprox = x(:,k);
    N = k;
end


