%% 10/10
%Exercitiul 1
disp("Exercitiul 1");
A = [3 1 1;
     1 3 1;
     1 1 3];
%a
norma1 = normap(A, 1);
norma2 = normap(A, 2);
normainf = normap(A, inf);
disp("Subpunctul a");
disp(norma1);
disp(norma2);
disp(normainf);

%b
disp("Subpunctul b");
%stabilim un epsilon oricat de mic
epsilon = 10^(-4);
%aplicam metoda Jacobi pe matrice cu epsilonul stabilit pentru a afla
%valorile proprii
lambda = MetJacobiValProprii(A, epsilon);
%raza spectrala este maximul in valoare absoluta dintre acele valori
raza_spectrala = max(abs(lambda));
disp("Raza spectrala a matricii A:");
disp(raza_spectrala);
disp("Raza spectrala este egala cu normele calculate mai devreme");

%c
disp("Subpunctul c");
disp("Numerele de conditionare sunt (folosind functiile definite aici):");
disp("p = 1");
disp(condp(A, 1));
disp("p = 2");
disp(condp(A, 2));
disp("p = inf");
disp(condp(A, inf));

%d
disp("Subpunctul d");
disp("Folosind functiile predefinite in Matlab");
disp("Normele 1, 2 respectiv infinit ale matricii A:");
disp(norm(A, 1));
disp(norm(A, 2));
disp(norm(A, inf));
disp("Numerele de conditionare Kp unde p = 1, 2 respectiv infinit:");
disp(cond(A, 1));
disp(cond(A, 2));
disp(cond(A, inf));

%%
%Exercitiul 2
disp("Exercitiul 2");
A = [10 7 8 7;
     7 5 6 5;
     8 6 10 9;
     7 5 9 10];
b = [32;
     23;
     33;
     31];
x = [1;
     1;
     1;
     1];
%a)
disp("Subpunctul a");
x_gpt = GaussPivTot(A, b);
disp("Solutiile aflate prin Gauss cu pivotare totala:");
disp(x_gpt);

%b)
disp("Subpunctul b");
%perturbarea vectorului b
d_b = [0.1;
       -0.1;
       0.1;
       -0.1];
%deducem perturbarea
d = d_b / b;

x_per = A \ (b + d_b);
disp("Solutiile dupa perturbarea vectorului b");
disp(x_per);
disp("Observam ca o perturbare minora relativ la marimea componentelor vectorului b " + ...
"a produs solutii total diferite");

%c)
disp("Subpunctul c");
K_inf_A = cond(A, inf);
disp(normap(x_per - x, inf) / normap(x, inf));
disp(K_inf_A * norm(d*b, inf) / normap(b, inf));
disp("Marimile sunt egale");
%d)
disp("Subpunctul d");
%A + D*A;
A_p_D_A = [10 7 8.1 7.2;
          7.08 5.04 6 5;
          8 5.98 9.89 9;
          6.99 4.99 9 9.98];
%x_per = A + D*A \ b;
x_per = A_p_D_A \ b;

disp(x_per);

%%
%Exercitiul 5
disp("Exercitiul 5");
%1)
disp("Subpunctul 1)");
%a)
A_a = [0.2 0.01 0;
       0 1 0.04;
       0 0.02 1];

disp("Subpunctul a)");

if(det(A_a) ~= 0)
    fprintf("det(A) = %f != 0\n", det(A_a));
    disp("Deci matricea este inversabila");
else
    disp("det(A) = 0");
    disp("Deci matricea nu este inversabila deci nu se poate aplica Jacobi");
end

I = eye(size(A_a,1));
q = norm(I-A_a, inf);
if q >= 1
    disp("Metoda Jacobi nu asigura convergenta");
else
    disp("Metoda Jacobi asigura convergenta deci se poate aplica");
end
%b)
A_b = [4 1 2;
       0 3 1;
       2 4 8];
disp("Subpunctul b)");
disp("4 > 1 + 2");
disp("3 > 0 + 1");
disp("8 > 2 + 4");
disp("A de la b) este diagonal dominanta pe linii si se poate aplica JacobiDDL");

%c)
A_c = [4 2 2;
       2 10 4;
       2 4 6];
disp("Subpunctul c");
disp("Matricea este simetrica");
disp("Matricea este si pozitiv definita (det tuturor minorilor principali > 0)");
disp("Deci se poate aplica metoda Jacobi relaxata");

%2)
disp("Subpunctul 2");
a = [1;
     2;
     3];
epsilon = 10^-5;
disp("Solutiile de la 1)a)");
[x, ~] = MetJacobi(A_a, a, epsilon);
disp(x);

disp("Solutiile de la 1)b)");
[x, ~] = MetJacobiDDL(A_b, a, epsilon);
disp(x);

disp("Solutiile de la 1)c)");
[x, ~] = MetJacobiR(A_c, a, epsilon);
disp(x);
%%
function [norma] = normap(A, p)
    switch p
        case 1
            norma = max(sum(abs(A), 1));
        case 2
            B = A' * A;
            lambda = MetJacobiValProprii(B, 10^-4);
            norma = max(sqrt(lambda));
        case inf
            norma = max(sum(abs(A), 2));
    end
end

%Metoda Jacobi de aproximare a valorilor proprii
function [lambda] = MetJacobiValProprii(A, epsilon)
    n = size(A, 1);

    while abs(det(A)) >= epsilon
       	p = 0;
        q = 0;
        
        a_pq = 0;
        
        for i = 1 : n-1
            for j = i+1 : n
                if abs(A(i, j)) > abs(a_pq)
                    a_pq = A(i, j);
                    p = i;
                    q = j;
                end
            end
        end
        
        if p == 0 %q == 0
            break;
        end
        
        theta = 0;
        
        if A(p, p) == A(q, q)
            theta = pi / 4;
        else
            theta = 1/2 * atan(2 * A(p, q) / (A(q, q) - A(p, p)));
        end
        
        c = cos(theta);
        s = sin(theta);
        
        for j = 1 : n
            if j ~= p && j ~= q
                u = A(p, j) * c - A(q, j) * s;
                v = A(p, j) * s + A(q, j) * c;
                A(p, j) = u;
                A(q, j) = v;
                A(j, p) = u;
                A(j, q) = v;
            end
        end
        
        u = c^2 * A(p, p) - 2 * c * s * A(p, q) + s^2 * A(q, q);
        v = s^2 * A(p, p) + 2 * c * s * A(p, q) + c^2 * A(q, q);
        
        A(p, p) = u;
        A(q, q) = v;
        A(p, q) = 0;
        A(q, p) = 0;
    end
    
    lambda = diag(A);
end

function [cond] = condp(A, p)
    cond = normap(A, p) * normap(inv(A), p);
end

function [x] = GaussPivTot(A, b)
    %stim din start ca matricea este patratica
    n = size(A,1);
    %extindem matricea
    A = [A b];
    index = (1:n);
    
    for k = 1:n-1
        %alegem ca pivot elementul curent a_pm cu valoarea absoluta cea mai
        %mare din submatricea (a_ij)i,j=[k,...,n]
        a_pm = 0;
        p = 0;
        m = 0;
        for i = k : n
            for j = k : n
                if abs(a_pm) < abs(A(i,j))
                    a_pm = abs(A(i,j));
                    p = i;
                    m = j;
                end
            end
        end
        if a_pm == 0
            fprintf("Sistem incompatibil sau compatibil nedeterminat.\n");
            x = -1;
            return;
        end
        if p ~= k
            A([p k], :) = A([k p], :);
        end
        if m ~= k
            A(:, [k m]) = A(:, [m k]);
            aux = index(k);
            index(k) = index(m);
            index(m) = aux;
        end
        for l = k+1 : n
            m_lk = A(l, k) / A(k, k);
            A(l, :) = A(l, :) - m_lk.*A(k, :);
        end
    end
    if A(n, n) == 0
        fprintf("Sistem incompatibil sau compabitil nedeterminat.\n");
        x = -1;
        return;
    end
    %am obtinut o matrice superior triunghiulara si putem aplica
    %substitutia descendenta
    y = SubsDesc(A(1:n, 1:n), A(1:n, n+1));
    
    for i = 1 : n
        x(index(i)) = y(i);
    end
end

function [x] = SubsDesc(A, b)
    n = size(A, 1);
    x(n) = b(n) / A(n, n);
    k = n - 1;
    while k > 0
        sum = 0;
        
        for j = k+1 : n
            sum = sum + A(k, j)*x(j);
        end
        
        x(k) = (b(k) - sum) / A(k,k);
        k = k-1;
    end
end

%%
%Exercitiul 4
function [x_aprox, N] = MetJacobi(A, a, epsilon)
    n = size(A, 1);
    I = eye(n);
    q = norm(I-A, inf);
    if q >= 1
        disp("Metoda Jacobi nu asigura convergenta");
        x_aprox = 0;
        N = 0;
        return;
    end
    x(1:n, 1) = 0;%x la pasul precedent (k-1)
    k = 1;
    B = I-A;
    b = a;
    cond = 1;
    
    while cond ~= 0
        k = k + 1;
        x(:, k) = B * x(:, k-1) + b;
        
        if (q^k / (1-q)) * norm(x(:, 2) - x(:, 1), inf) < epsilon
            cond = 0;
        end
    end
    
    x_aprox = x(:, k);
    N = k - 1;
end

function [x_aprox, N] = MetJacobiDDL(A, a, epsilon)
    n = size(A, 1);
    
    for i = 1:n
        if abs(A(i, i)) <= sum(abs(A(i, :))) - abs(A(i, i))
            disp("Matricea nu este diagon dominanta pe linii");
            
            x_aprox = 0;
            N = -1;
            
            return;
        end
    end
    
    x(1:n, 1) = 0;
    k = 1;
    
    b = zeros(n, 1);
    B = zeros(n, n);
    
    for i = 1:n
        for j = 1:n
            if i == j
                B(i, j) = 0;
            else
                B(i, j) = -A(i, j) / A(i, i);
            end
        end
        b(i) = a(i) / A(i, i);
    end
    
    q = normap(B, inf);
    
    cond = 1;
    
    while cond ~= 0
        k = k+1;
        x(:, k) = B * x(:, k-1) + b;
        
        if q^k / (1-q) * norm(x(:, 2) - x(:, 1), inf) < epsilon
            cond = 0;
        end
    end
    
    x_aprox = x(:, k);
    N = k-1;
end

function [x_aprox, N] = MetJacobiR(A, a, epsilon)
    n = size(A, 1);

    lambda = MetJacobiValProprii(A, epsilon);
    lambda = sort(lambda);
    
    sigma_O = 2 / (lambda(n) + lambda(1));
    q_O = (lambda(n) - lambda(1)) / (lambda(n) + lambda(1));
    
    b = zeros(n, 1);
    B = zeros(n, n);
    
    for i = 1:n
        for j = 1:n
            if i == j
                B(i, j) = 1 - sigma_O * A(i, j);
            else
                B(i, j) = sigma_O * -A(i, j);
            end
        end
        b(i) = sigma_O * a(i);
    end
    
    x(1:n, 1) = 0;
    k = 1;
    
    cond = 1;
    
    while cond ~= 0
        k = k + 1;
        x(:, k) = B * x(:, k-1) + b;
        
        y = x(:, 2) - x(:, 1);
        
        z = dot(A*y, y);
        
        if (q_O ^ k / (1-q_O)) * z < epsilon
            cond = 0;
        end
    end
    
    x_aprox = x(:, k);
    N = k-1;
end
