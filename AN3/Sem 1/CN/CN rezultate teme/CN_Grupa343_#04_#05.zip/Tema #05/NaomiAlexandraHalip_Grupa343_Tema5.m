% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 5
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================


%%
% Ex. 1
A = [3 1 1;1 3 1;1 1 3];
[normap1] = normap(A,1);
[normap2] = normap(A,2);
[normapinf] = normap(A,'inf');
[raza] = RazaSpectrala(A); % Pentru matricea A = [3 1 1;1 3 1;1 1 3], 
% atat normele cat si raza spectrala, au aceeasi valoare
[condp1] = condp(A,1);
[condp2] = condp(A,2);
[condpinf] = condp(A,'inf'); %numarul de conditionare al matricei A relativ la 
% norma p
%%

%%
% Ex. 1
% d)
% normele si numarul de conditionare folosind functiile predefinite in
% matlab
A = [3 1 1;1 3 1;1 1 3];
norm1 = norm(A,1);
norm2 = norm(A,2);
norminf = norm(A,'inf');

cond1 = cond(A,1);
cond2 = cond(A,2);
condinf = cond(A,'inf');
%%

%%
% Ex. 2
% a)
A1 = [10 7 8 7;7 5 6 5;8 6 10 9;7 5 9 10];
b = [32;23;33;31];
x = GaussPivTot(A1,b); % Solutia sistemului A1x = b folosind GaussPivTot

% b)
bp = [32.1;22.9;33.1;30.9]; % vectrorul perturbat (bp = b + delta*b)
xp = GaussPivTot(A1,bp); % Solutia sistemului atunci cand vectorul b este 
% perturbat
% Se observa, ca atunci cand se perturba vectorul b, chiar si cu valori
% foarte mici, solutia sistemului se schiba total

% c)
[condpinf2] = condp(A1,'inf'); % numarul de conditionare al lui A1
deltax = xp - x; % il scot pe deltax din: xp = x + deltax
[normavdeltax] = normav(deltax,'inf');
[normavx] = normav(x,'inf');
m1 = normavdeltax/normavx;
deltab = bp - b; % il scot pe deltab din: bp = b + deltab
[normadeltab] = normav(deltab,'inf');
[normavb] = normav(b,'inf');
m2 = condpinf2 *(normadeltab/normavb);
% Se observa ca m1 = m2

% d)
% matricea A perturbata
Ap = [10 7 8.1 7.2;7.08 5.04 6 5;8 5.98 9.89 9;6.99 4.99 9 9.98]; 
xP = GaussPivTot(Ap,b);
% Se observa ca, daca perturbam matricea sistemului cu valori foarte mici,
% solutia sistemului se schimba total, obtinandu-se valori in modul, mult
% mai mari decat solutia initiala a sistemului
%%

%%
% Ex. 5
% 2) 
epsilon = 10^(-5);
Aa = [0.2 0.01 0;0 1 0.04;0 0.02 1]; % matricea A de la Ex. 5 pct a)
Ab = [4 1 2;0 3 1;2 4 8]; % matricea A de la Ex. 5 pct b)
Ac = [4 2 2;2 10 4;2 4 6]; % matricea A de la Ex. 5 pct c)
a = [1;2;3];
% Am verificat la Ex. 5. 1) aplicabilitatea metodelor pe matricele date
% aflu solutia aproximativa a sist. Aa*x =a aplicand MetJacobi
[xa,Na] = MetJacobi(Aa,a,epsilon);
% aflu solutia aproximativa a sist. Ab*x =a aplicand MetJacobiDDL
[xb,Nb] = MetJacobiDDL(Ab,a,epsilon);
% aflu solutia aproximativa a sist. Ac*x =a aplicand MetJacobiR
[xc,Nc] = MetJacobiR(Ac,a,epsilon);
%%

%%
% Ex. 1
% a) Functie care returneaza norma p, a matricei A
% Pentru a aela norma infinit, p='inf'
function [norma] = normap(A,p)
    [s1, s2] = sum1(A); % calculeaza suma pe linii, respectiv pe coloane 
    % pentru matricea A 
    if p == 'inf' 
        p = 0; 
    end
    switch p
        case 1
            norma = max(s1); % norma 1 a unei matrice
        case 2
            B = A'*A;
            epsilon = 10^(-4);
            [lambda] = MetodaJacobi(B,epsilon);
            norma = max(sqrt(lambda));
        case 0     % calculeaza norma infinit
            norma = max(s2); % norma infinit a unei matrice
        otherwise
            disp('Norma nedefinita!');
    end
end
%%

%%
% Ex. 1
% b)
% functie care calculeaza raza spectrala
function [raza] = RazaSpectrala(A)
    n1 = size(A);
    n = n1(1);
    epsilon = 10^(-4);
    [lambda] = MetodaJacobi(A,epsilon);
    raza = max(abs(lambda));
end
%%

%%
% Ex. 1
% c) numarul de conditionare al matricei A relativ la norma p
function [cond] = condp(A,p)
    [invA, detA] = GaussJordan(A); % apelez metoda GaussJordan pentru a 
    % calcula inversa matricei A
    a1 = normap(A,p);
    a2 = normap(invA,p);
    cond = a1*a2;
end
%%

%%
% Sume pe linii si pe coloana
% Apelez aceasta functie in normap
function [s1,s2] = sum1(A)
    n1 =size(A);
    n = n1(1);
    s1 = zeros(1,n);
    s2 = zeros(1,n);
    for i =1:n
        for j =1:n
            s1(i) = s1(i) + abs(A(i,j));
            s2(i) = s2(i) + abs(A(j,i));
        end
    end
end
%%

%%
% norma unui vector
% pentru Ex.2 c)
function [norma] = normav(x,p)
    [s1, s2] = sum2(x);
    if p == 'inf' 
        p = 0; 
    end
    switch p
        case 1
            norma = s1; % norma 1 a unei vector
        case 2
            norma = sqrt(s2);
        case 0     % calculeaza norma infinit
            norma = max(abs(x)); % norma infinit a unui vector
        otherwise
            disp('Norma nedefinita!');
    end
end
%%

%%
% Suma modulelor elementelor unui vector de tip coloana si supa patratelor
% elementelor unui vector
function [s1, s2] = sum2(x)
    n1 = size(x);
    n = n1(1);
    x = x';
    s1 = 0;
    s2 = 0;
    for i =1:n
        s1 = s1+abs(x(i));
        s2 = s2+x(i)^2;
    end
end
%%

%%
% Ex. 4
% a) MetJacobi
% Date de intrare:
% 'A' = matrice inversabila
% 'epsilon' = un scalar
% a = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox' = aproximarea solutiei sistemului de ecuatii Ax = a
% -------------------------------------------------------------------------
function [xaprox,N] = MetJacobi(A,a,epsilon)
    n1 = size(A);
    n = n1(1);
    I = eye(n);
    q = normap(I-A,'inf');
    if q >= 1
        disp('Metoda Jacobi nu asigura conv.');
    end
    x = zeros(n,1);
    k = 0;
    B = I-A;
    b = a;
    ok = 1;
    x0 = x;
    x1 = B*x +b;
    while ok == 1
        k = k+1;
        x = B*x +b;
        if ((q^k)/(1-q))*normav(x1-x0,'inf') < epsilon
            ok = 0;
        end
    end
    xaprox = x;
    N = k;
end
%%

%%
% Ex. 4
% b) Metoda Jacobi pentru matrice diagonal dominante pe linii
% Date de intrare:
% 'A' = matrice nesingulara si diagonal dominanta
% 'epsilon' = un scalar
% a = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox' = aproximarea solutiei sistemului de ecuatii Ax = a
% -------------------------------------------------------------------------
function [xaprox,N] = MetJacobiDDL(A,a,epsilon)
    n1 = size(A);
    n = n1(1);
    for i = 1:n
        if abs(A(i,i)) <= sum3(A,i)
            disp('Matr. nu este diag. dom. pe linii');
        end
    end
    x = zeros(n,1);
    x0 = x;
    k = 0;
    for i = 1:n
        for j = 1:n
            if i == j
             B(i,j) = 0;
            end
            if i ~= j
                B(i,j) = -A(i,j)/A(i,i);
            end
        end
    end
    for i = 1:n
        b(i) = A(i)/A(i,i);
    end
    b = b';
    q = normap(B,'inf');
    ok = 1;
    while ok == 1
        k = k+1;
        if k == 1
            x1 = B*x+b;
        end
        x = B*x+b;
        if ((q^k)/(1-q))*normav((x1-x0),'inf') < epsilon
            ok = 0;
        end
    end
    xaprox = x;
    N = k;
end
%%

%%
% suma modulelor elementelor unei matrice fara elem. de pe diagonala
% principala
% pentru algoritmul MetJacobiDDL de la Ex. 4
function [s] = sum3(A,i)
    n1 = size(A);
    n = n1(1);
    s = 0;
    for j =1:n
        if i ~= j
            s = s+abs(A(i,j));
        end
    end
end
%%

%%
% Ex. 4
% c) Metoda Jacobi relaxata
% Date de intrare:
% 'A' = matrice simetrica si pozitiv definita
% 'epsilon' = un scalar
% a = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox' = aproximarea solutiei sistemului de ecuatii Ax = a
% -------------------------------------------------------------------------
function [xaprox,N] = MetJacobiR(A,a,epsilon)
    n1 = size(A);
    n = n1(1);
    lambda = MetodaJacobi(A,epsilon); % valorile proprii ale matrice A
    sigmaO = 2/(lambda(n)+lambda(1));
    qO = (lambda(n)-lambda(1))/(lambda(n)+lambda(1));
    for i =1:n
        for j = 1:n
            if i == j
                B(i,j) = 1 - sigmaO*A(i,j);
            end
            if i ~= j
                B(i,j) = -sigmaO*A(i,j);
            end
        end
    end
    for i =1:n
       b(i) = sigmaO*a(i);
    end
    b = b';
    x = zeros(n,1);
    x0 = x;
    k = 0;
    ok = 1;
    while ok == 1
        k = k+1;
        if k == 1
            x1 = B*x +b;
        end
        x = B*x+b;
        if ((qO^k)/(1-qO))*sum4(A,x1-x0) < epsilon
            ok = 0;
        end
    end
    xaprox = x;
    N = k;
end
%%

%%
% functie care ma ajuta sa calculez norma A, a unui vector
% folosita in Metoda Jacobi relaxata
function [s] = sum4(A,x)
    [m1,m2] =size(x);
    if m1 > m2   % inseamna ca e vector de tip coloana
        x = x'; % x trebuie sa fie vecrtor de tip linie
    end
    n1 = size(A);
    n = n1(1);
    s = 0;
    for i =1:n
        for j =1:n
            s = s+A(i,j)*x(j)*x(i);
        end
    end
end
%%


% Mai jos am pus metodele implementate in temele anterioare pe care
% le-am folosit si in aceasta tema
%%
% Metoda Jacobi de aproximare a valorilor proprii
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matrice simetrica
% 'epsilon' = un scalar
% -------------------------------------------------------------------------
% Date de iesire:
% 'lambda' = vectorul valorilor proprii ale matricei A
% -------------------------------------------------------------------------
function [lambda] = MetodaJacobi(A,epsilon)
    n1 = size(A);
    n = n1(1);
    B = zeros(n);
    while Mod(A) >= epsilon
        for i =1:n
            for j = i+1:n
                B(i,j) = A(i,j);
            end
        end
        [p, q] = find(abs(B)==max(max(abs(B))));
        p = p(1);
        q = q(1);
        if A(p,q) == A(q,q)
            teta = pi/4;
        else
            teta = 1/2 *atan(2*A(p,q)/(A(q,q)-A(p,p)));
        end
        c = cos(teta);
        s = sin(teta);
        for j =1:n
            if (j ~= p) & (j ~= q)
                u = A(p,j)*c -A(q,j)*s;
                v = A(p,j)*s +A(q,j)*c;
                A(p,j) = u;
                A(q,j) = v;
                A(j,p) = u;
                A(j,q) = v;
            end
        end
        u = (c^2)*A(p,p) -2*c*s*A(p,q)+(s^2)*A(q,q);
        v = (s^2)*A(p,p) +2*c*s*A(p,q)+(c^2)*A(q,q);
        A(p,p) = u;
        A(q,q) = v;
        A(p,q) = 0;
        A(q,p) = 0;
    end
    for i =1:n
        lambda(i) = A(i,i);
    end
    lambda = lambda';
end
%%

%%
% fumctie construita pentru a putea calcula modulul matricei A, asa cum 
% este descris in Cursul#4 la pagina 7
% |A| = sqrt(suma(aij^2)), i,j=1:n si i!=j
% functia este folosita in MetodaJacobi
function [s] = Mod(A)
    n1 = size(A);
    n = n1(1);
    s = 0;
    for i = 1:n
        for j = 1:n
            if i ~= j
                s = s +(A(i,j))^2;
            end
        end
    end
    s = sqrt(s);
end
%%



%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'invA' = o matrice, care reprezinta inversa matricei A
% 'detA' = un scalar, rezprezentand determinantul matricei A
% -------------------------------------------------------------------------

function [invA, detA] = GaussJordan(A)
    n1 = size(A);
    n = n1(1);
    invA = eye(n);
    for i = 1:n
        E = InterschLin(eye(n,1),i,1);
        invA(:,i) = GaussPivPart(A,E); % GaussPivPart intoarce ca rezultat
        % un vector de tip coloana
    end  
    % folosesc o portiune din GaussPivPart pentru a aduce matricea A la o
    % matrice superior triunghiulara. Astfel determinantul devine produsul
    % elementelor de pe diagonala principala
    for k = 1:n-1
        % cu ajutorul functiei predefinite 'find' gasesc indicele la care
        % se afla valoarea maxima
        y = find(abs(A(k:n,k))==max(max(abs(A(k:n,k)))));
        p = y(1) +(k-1); % indicele primului elem max de pe coloana k 
        if p ~= k
            A = InterschLin(A, p, k); % 'InterschLin'-functie implementata 
            % intr-un fisier de tip function
        end
        for l = k+1:n
            m(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - m(l, k)*A(k,:);
        end
    end
    detA = 1;
    % Calculez determinantul
    for i =1:n
        detA = detA *A(i,i);
    end
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = o matrice
% 'k' = indicele uneia dintre liniile ce urmeaza a fi interschimbate
% 'p' = indicele celeilalte linii ce urmeaz a fi interschimbata
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = matricea A, in care sunt interschimbate liniile k cu p
% -------------------------------------------------------------------------

function [x] = InterschLin(A, k, p)
    n1 = size(A);
    n = n1(1); 
    % folosim o matrice identitate de dimensiunea matricei A
    I = eye(n);
    I(k, k) = 0;
    I(p, p) = 0;
    I(p, k) = 1;
    I(k, p) = 1;
    A = I * A;  %interschimbam linia p cu linia k, din matricea A
    x = A;
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b, obtinuta prin metoda Gauss cu pivotare
% partiala
% -------------------------------------------------------------------------


function [x] = GaussPivPart(A, b)
    A = [A,b];
    n1 = size(A);
    n = n1(1);
    for k = 1:n-1
        % cu ajutorul functiei predefinite 'find' gasesc indicele la care
        % se afla valoarea maxima
        y = find(abs(A(k:n,k))==max(max(abs(A(k:n,k)))));
        p = y(1) +(k-1); % indicele primului elem max de pe coloana k 
        if A(p, k) == 0
           disp('Sistem incompatibil sa compatibil nedeterminat');
           break;
        end
        if p ~= k
            A = InterschLin(A, p, k); % 'InterschLin'-functie implementata 
            % intr-un fisier de tip function
        end
        for l = k+1:n
            m(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - m(l, k)*A(k,:);
        end
    end
    if A(n, n) == 0
        disp('Sistem incompatibil sau compatibil nedeterminat');
    end
    x = SubsDesc(A, A(:,n+1));
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b
% -------------------------------------------------------------------------

function [x] = SubsDesc(A, b)
    n1 = size(A);
    n = n1(1); %numarul de linii al matricei A
    x(n) = (1/A(n,n)) *b(n);
    k = n - 1;
    while k > 0
        % Suma(k,A,x) este o functie construita petru a calcula suma de la
        % j=k+1 pana la n din akj*xj
        x(k) = (1/A(k,k)) *(b(k) -Suma(k,A,x)); 
        k = k - 1;
    end
    x = x';
end
%%

%%
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b, obtinuta prin metoda Gauss cu pivotare
% totala
% -------------------------------------------------------------------------


function [x] = GaussPivTot(A, b)
    A = [A,b];
    n1 = size(A);
    n = n1(1);
    for i =1:n
        index(i) = i;
    end
    for k = 1:n-1
        B = [A(:,k:n)]; % selectez coloanele de la k la n
        B = [B(k:n,:)]; % selectez liniile de la k la n
        % gasesc indicii elementului maxim cu ajutorul functiei predefinite
        % 'find'
        [u, v] = find(abs(B)==max(max(abs(B))));
        p = u(1) +(k-1); % indicele de pe linii al primului elem max 
        m = v(1) +(k-1); % indicele de pe coloana al primului element max
        if A(p, m) == 0
            disp('Sistem incompatibil sau compatibil nedeteminat');
            break;
        end
        if p ~= k
            A = InterschLin(A, p, k);
        end
        if m ~= k
            A = InterschCol(A, m, k); %interschimbam coloanele m si k cu 
            % ajutorul functiei 'InterschCol', implementata intr-un fisier de tip function
            % interschimbam indicii nec.
            aux = index(m);
            index(m) = index(k);
            index(k) = aux;
        end
        for l = k+1:n
            t(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - t(l, k)*A(k,:);
        end
    end
    if A(n, n) == 0
        disp('Sistem incompatibil sau compatibil nedeterminat');
    end
    y = SubsDesc(A, A(:,n+1));
    for i = 1:n
        x(index(i)) = y(i);
    end
    x = x';
end
%%

%%
% Date de intrare:
% 'A' = o matrice
% 'k' = indicele uneia dintre coloanele ce urmeaza a fi interschimbate
% 'p' = indicele celeilalte coloane ce urmeaz a fi interschimbata
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = matricea A, in care sunt interschimbate coloanele k cu p
% -------------------------------------------------------------------------

function [x] = InterschCol(A, k, p)
    n1 = size(A);
    n = max(n1); 
    %folosim o matrice identitate de dimensiunea matricei A
    I = eye(n);
    I(k, k) = 0;
    I(p, p) = 0;
    I(p, k) = 1;
    I(k, p) = 1;
    A = A * I;  %interschimbam linia p cu linia k, din matricea A
    x = A;
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'k' = indicele unei pozitii in matrice
% 'A' = o matrice
% 'x' = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 's' = suma de la i=k+1 pana la n din Aki*xi
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

%functie creata pentru a putea construi met SubsDesc
function s = Suma(k, A, x)
    n = size(A);
    s = 0;
    for i = k+1:n
        s = s + A(k,i) *x(i);
    end
end
%%