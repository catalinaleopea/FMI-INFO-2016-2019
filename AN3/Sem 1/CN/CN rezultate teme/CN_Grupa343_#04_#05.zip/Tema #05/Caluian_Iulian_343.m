% Caluian Iulian, 343 , Calcul numeric, tema 5
% Ai uitat sa pui si functia subsDesc + argumentari lipsa
% Total: 8.5/10
%%
%Ex. 1
X = [3 1 1 ; 1 3 1 ; 1 1 3];
% subpunct a:
n = normap(X,1);
nML = norm(X,1); %norma calculata cu functia matlab
disp(['norma 1: ' int2str(n) ' ; ']);
disp(['norma 1(Matlab): ' int2str(nML) ' ; ']);
n = normap(X,2);
nML = norm(X); %norma calculata cu functia matlab
disp(['norma 2: ' int2str(n) ' ; ']);
disp(['norma 2(Matlab): ' int2str(nML) ' ; ']);
n = normap(X,-1);
nML = norm(X,Inf); %norma calculata cu functia matlab
disp(['norma inf: ' int2str(n) ' ; ']);
disp(['norma inf(Matlab): ' int2str(nML) ' ; ']);

% subpunct b (raza spectrala):
epsi = 10^(-4);
lam = metJacobi(X,epsi);
disp(['Valorii proprii: ' mat2str(lam) ' ; ']);
raz = max(abs(lam));
disp(['Raza spectrala este: ' int2str(raz) ' ; ']);


% subpunct c
nrcond = condp(X,1);
nrcondML = cond(X,1); %norma calculata cu functia matlab
disp(['Numar de conditionare la norma 1: ' int2str(nrcond) ' ; ']);
disp(['Numar de conditionare la norma 1(Matlab): ' int2str(nrcondML) ' ; ']);
nrcond = condp(X,2);
nrcondML = cond(X,2); %norma calculata cu functia matlab
disp(['Numar de conditionare la norma 2: ' int2str(nrcond) ' ; ']);
disp(['Numar de conditionare la norma 2(Matlab): ' int2str(nrcondML) ' ; ']);
nrcond = condp(X,-1);
nrcondML = cond(X,Inf); %norma calculata cu functia matlab
disp(['Numar de conditionare la norma inf: ' int2str(nrcond) ' ; ']);
disp(['Numar de conditionare la norma inf(Matlab): ' int2str(nrcondML) ' ; ']);

% subpunct d - deja implementat pentru a compara.

%% EX 2
disp('Ex2: ');
A = [ 10 7 8 7; 
       7 5 6 5;
       8 6 10 9;
       7 5 9 10];
Apert = [10 7 8.1 7.2;
        7.08 5.04 6 5;
        8 5.98 9.89 9;
      6.99 4.99 9 9.98];
    
 b = [32 23 33 31];
 bpert = [32.1 22.9 33.1 30.9];
 x = [1 1 1 1];
 
 % sub a
 sol = GaussPivTot(A,b);
disp(['Solutia sistemului este: ' mat2str(sol) ' ; ']);
% sub b

 solpert = GaussPivTot(A,bpert);
disp(['Solutia sistemului perturbat este: ' mat2str(solpert) ' ; ']);
% sub c
nrcond = condp(A,-1);
disp(['Numar de conditionare la norma inf: ' int2str(nrcond) ' ; ']);

xpert = solpert-x;

nxpert = normap(xpert,-1);
nx = normap(x,-1);
nbpert = norm(bpert,-1);
nb = normap(b,-1);

disp(['norma(xperturbat) / norma(x) = ' num2str(nxpert) '/' num2str(nx) ' = ' num2str(nxpert/nx)]);
disp(['nr.Cond(A) * norma(bperturbat) / norma(b) = ' num2str(nrcond) '*' num2str(nbpert) '/' num2str(nb) ' = ' num2str(nrcond*nbpert/nb)]);
%A doua marime este mai mare.

% sub d
 solpert = GaussPivTot(Apert,b);
 disp(['Solutia sistemului perturbat este: ' mat2str(solpert) ' ; ']);

%% Ex 5 (cu functii Ex4)
A = [0.2 0.01 0;
     0   1    0.04;
     0   0.02 1   ];
 
epsi = 10^(-5);
a = [1 2 3];
[xaprox,nrPasi] = MetJacobi(A,a,epsi);
disp(['Solutia sistemului este: ' mat2str(xaprox) ' ; ']);

A2 = [4 1 2;
     0 3 1;
     2 4 8];
 
epsi = 10^(-5);
a = [1 2 3];
[xaprox,nrPasi] = MetJacobiDDL(A2,a,epsi);
disp(['Solutia sistemului este: ' mat2str(xaprox) ' ; ']);

A3 = [4 2 2;
     2 10 4;
     2 4 6];
 
epsi = 10^(-5);
a = [1 2 3];
[xaprox,nrPasi] = MetJacobiRel(A3,a,epsi);
disp(['Solutia sistemului este: ' mat2str(xaprox) ' ; ']);
A3*xaprox

 
 





function [norma] = normap(A,p)
norma = 0;
if p == 1
    norma = max(sum(abs(A)));
elseif p==2
    epsi = 10^(-4);
    lam = metJacobi((A'*A),epsi);
    norma = max(sqrt(lam));
elseif p== -1
    norma = max(sum(abs(A),2));
else
    disp('Invalid p');
    norma = 0;
end
end

function [cond] = condp(A,p)
    invA = inv(A);
    cond = normap(A,p)*normap(invA,p);
end


function [xaprox,N] = MetJacobi(A,a,epsi)
a = a(:); % rescriere ca matrice coloana
[~,n] = size(A);
I = eye(n);
q = normap(I-A,-1);

if q >=1
    disp('Metoda Jacobi nu asigura conv.');
    return;
end
x0=zeros(n,1);
x1=zeros(n,1);
xk=zeros(n,1);
k=0;
B = I-A;
b = a;
while 1
    k = k+1;
    xk = B*xk + b;
    if k == 1
        x1 = xk;
    end
    if (q^k)/(1-q)*normap(x1-x0,-1) < epsi
        break;
    end
end
xaprox = xk;
N = k;
end

function [xaprox,N] = MetJacobiDDL(A,a,epsi)
a = a(:); % rescriere ca matrice coloana
[~,n] = size(A);
I = eye(n);

for i = 1:n
    suma = sum(abs(A(i,:)));
    suma = suma - abs(A(i,i));
    
    if abs(A(i,i)) <= suma
        disp('Matricea nu este diagonal dominanta pe linii');
        return;
    end
end

x0=zeros(n,1);
x1=zeros(n,1);
xk=zeros(n,1);
b =zeros(n,1);
k=0;

AUX = A.*I - A;
for i = 1:n
    AUX(i,:) = AUX(i,:) / A(i,i);
    b(i) = a(i)/A(i,i);
end
B = AUX;
q = normap(B,-1);
while 1
    k = k+1;
    xk = B*xk + b;
    if k == 1
        x1 = xk;
    end
    if (q^k)/(1-q)*normap(x1-x0,-1) < epsi
        break;
    end
end
xaprox = xk;
N = k;
end


function [xaprox,N] = MetJacobiRel(A,a,epsi)
a = a(:); % rescriere ca matrice coloana
[~,n] = size(A);
I = eye(n);

h = metJacobi(A,epsi);
h1 = min(h);
hn = max(h);
s0 = 2 / (hn + h1);

q0 = (hn - h1)/ (hn+h1);
B = I - s0*A;
b = s0*a;

x0=zeros(n,1);
x1=zeros(n,1);
xk=zeros(n,1);
k=0;

while 1
    k = k+1;
    xk = B*xk + b;
    if k == 1
        x1 = xk;
    end
    if (q0^k)/(1-q0)*normap(x1-x0,-1) < epsi
        break;
    end
end
xaprox = xk;
N = k;
end

%functii vechi:
function h = metJacobi(A,epsi)
%in h vom aveam valorile proprii ale matricii A
[~,n] = size(A);
h = zeros(n,1);

toleranta = 0;
for i = 1:n
    for j = 1:n
        if i ~= j
            toleranta = toleranta + A(i,j)*A(i,j);
        end
    end
end


while toleranta >= epsi
    p = 1;
    q = 2;
    for i = 1:n
        for j = i+1:n
            if abs(A(i,j)) > abs(A(p,q))
                p = i;
                q = j;
            end
        end
    end
    
    
    if A(p,p) == A(q,q)
        th = pi/4;
    else
        th = 1/2 * atan(2 * A(p,q) / (A(q,q) - A(p,p) ) );
    end
    c = cos(th);
    s = sin(th);
    for j = 1:n
        if j ~=p && j~= q
            u = A(p,j)*c - A(q,j)*s;
            v = A(p,j)*s + A(q,j)*c;
            A(p,j) = u;
            A(q,j) = v;
            A(j,p) = u;
            A(j,q) = v;
        end
    end
    u = c*c*A(p,p) - 2*c*s*A(p,q) + s*s*A(q,q);
    v = s*s*A(p,p) + 2*c*s*A(p,q) + c*c*A(q,q);
    A(p,p) = u;
    A(q,q) = v;
    A(p,q) = 0;
    A(q,p) = 0;

    
    toleranta = 0;
    for i = 1:n
        for j = 1:n
            if i ~= j
                toleranta = toleranta + A(i,j)*A(i,j);
            end
        end
    end 
end

for i = 1:n
    h(i) = A(i,i);
end

end

function [x] = GaussPivTot(A,b)
%SUBSDESC Summary of this function goes here
%   Detailed explanation goes here

[~,n] = size(A);

AB = [A b(:)]; %AB este matricea extinsa.

for k = 1:(n-1)
    
    %caut p a.i. AB(p,k) sa aiba valoarea absoluta cea mai mare.
    maxim = -1;
    p = k;
    q = k;
    for i = k:n
        for j = k:n
            if maxim < abs(AB(i,j))
               maxim = abs(AB(i,j));
               p = i;
               q = j;
            end
        end
    end

    if maxim == -1
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        disp('Sistemul nu este compatibil, sau compatibil nedeterm');
        break;
    else
       % am gasit deja p-ul si q-ul
        
        
        % swap linii:
        line = AB( k, 1:(n+1));
        AB(k, 1:(n+1)) = AB(p, 1:(n+1));
        AB(p, 1:(n+1)) = line;
        
        coloana  = AB( 1:n , k);
        AB(1:n, k ) = AB( 1:n, q);
        AB(1:n, q) = coloana;
    
        for p = (k+1):n 
            %update restul liniilor pentru a face apk sa fie 0
            mpk = AB(p,k) / AB(k,k);
            AB(p, 1:(n+1)) = AB(p, 1:(n+1)) - mpk*AB(k,1:(n+1));
        end
    end
    
end

if AB(n,n) == 0
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        disp('Sistemul nu este compatibil, sau compatibil nedeterm');
end

%extrag componentele pentru a rezolva cu metoda substitutiei.
AB(1:n,1:n)
x = SubsDesc(AB(1:n,1:n),AB(1:n,n+1));


end