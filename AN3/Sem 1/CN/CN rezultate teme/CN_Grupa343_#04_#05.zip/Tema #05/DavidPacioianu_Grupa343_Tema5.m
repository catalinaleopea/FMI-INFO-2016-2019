% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------
% 9.5/10 -> Argumentari la ex.5.
%% Ex1

A = [3 1 1; 1 3 1; 1 1 3];
p = 4;

% 1.a)
disp('1.a) Normele matricei A:');
normap(A,1)
normap(A,2)
normap(A,inf)

% 1.b)
disp('1.b) Raza spectrala a matricei A:');
razaSpectrala(A)
disp(['Observam ca raza spectrala a matricei A este egala cu normele'...
    'calculate la punctul a.']);

% 1.c)
disp('1.c) Numerele de conditionare ale matricei A:');
condp(A,1)
condp(A,2)
condp(A,inf)

% 1.d)
disp('1.d) Normele si numerele de conditionare ale matricei A:');
norm(A,1)
norm(A,2)
norm(A,inf)
cond(A,1)
cond(A,2)
cond(A,inf)

%% Ex2

A = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];
b = [32 23 33 31]';
x = [1 1 1 1]';

% 2.a)
disp('2.a)');
x = gaussPivTot(A,b)

% 2.b)
disp('2.b)');
bPerturbat = [32.1 22.9 33.1 30.9]';
xPerturbat = gaussPivTot(A,bPerturbat)
disp('Observam ca solutia perturbata difera considerabil de cea initiala.');

% 2.c)
disp('2.c)');
bDelta = bPerturbat - b;
xDelta = xPerturbat - x;

xErrRelat = norm(xDelta, inf) / norm(x, inf);
bErrRelatCond = condp(A, inf) * norm(bDelta, inf) / norm(b, inf);
xErrRelat
bErrRelatCond
disp('Observam ca eroarea relativa xErr > bErrRelatCond.');

% 2.d)
disp('2.d)');
APerturbat= [10 7 8.1 7.2; 7.08 5.04 6 5; 8 5.98 9.89 9; 6.99 4.99 9 9.98];
xPerturbat = gaussPivTot(APerturbat,b);

xErrRelat = norm(xPerturbat - x, inf) / norm(x, inf);
AErrRelatCond = condp(A, inf) * norm(APerturbat, inf) / norm(A, inf);
xErrRelat
AErrRelatCond
disp('Observam ca ambele erori relative sunt foarte mari.');
disp('Sistemul initial este slab conditionat.');


%% Ex5

b = [1 2 3]';
epsilon = 10^(-5);
I = eye(3);

%%% 1.a)
disp('a) Metoda Jacobi');
A1 = [0.2 0.01 0; 0 1 0.4; 0 0.02 1];
% Norma lui B = I-A este norm(I-A1) = 0.8001, cum 0 < 0.8001 < 1 => B este 
% convergenta => putem aplica metoda Jacobi
%%% 2.a)
x = metJacobi(A1, b, epsilon)

%%% 1.b)
disp('b) Metoda Jacobi DDL');
A2 = [4 1 2; 0 3 1; 2 4 8]

% verificare?
% A2 este diagonal dominanta pe linii => putem aplica metoda Jacobi DDL
%%% 2.b)
x = metJacobiDDL(A2, b, epsilon)

%%% 1.c)
disp('c) Metoda Jacobi relaxata');
A3 = [4 2 2; 2 10 4; 2 4 6]
% A3 = A3' => matricea este simetrica (1)
% Cum ai verificat?
% a este o matrice pozitiv definita (2)
% Din (1) si (2) => putem aplica metoda Jacobi
% relaxata
%%% 2.c)
x = metJacobiR(A3, b, epsilon)

%% Functions Ex1
    function [n] = normap(A, p)
        if ismember(p, [1 2 inf]) == false
            error(['Error: Singurele norme matriceale disponibile sunt'...
                '1, 2 si Inf.']);
        end
        
        n = 0;
        if p == 1
            n = max(sum(A));
        elseif p == 2
            n = max(sqrt(eig(A'*A)));
        elseif p == Inf
            n = max(sum(A'));
        end
    end
    
    function [p] = razaSpectrala(A)
        p = max(abs(eig(A)));
    end
    
    function [k] = condp(A, p)
        k = normap(A,p) * normap(inv(A), p);
    end
    
 %% Functions Ex2       
    function [x] = gaussPivTot(A, b)
        %GAUSSPIVTOT Procedura aplica metoda lui Gauss cu pivotare totala asupra 
        %   lui A si rezolva ecuatia Ax = b folosind procedura SUBSDESC

            % Function to swap the rows of a matrix
            function M = swapRows(M,rowA,rowB)
                M([rowA rowB],:) = M([rowB rowA],:);
            end

            % Function to swap the columns of a matrix
            function M = swapColumns(M,colA,colB)
                M(:,[colA colB]) = M(:,[colB colA]);
            end

            % Function to subtract row(i) from all the rows in matrix M below
            % it, such that all elements below on column i are zero
            function M = makeZerosBelow(M, row, col)
                gaussRowMultipliers = M(row+1:end,col) / M(row,col);
                M(row+1:end,:) = M(row+1:end,:) - gaussRowMultipliers*M(row,:);
            end
        
            function x = subsDesc(A, b)
                %SUBDESC Procedura aplica metoda substitutiei descendente 
                %   x = SubsDesc(A, b), unde x este solu?tia sistemului Ax = b.

                % Verificam integritatea datelor de intrare
                [mRowsA, nColumnsA] = size(A);
                if mRowsA ~= nColumnsA
                    error('Error: Matricea nu este patratica.');
                end
                if nColumnsA ~= length(b)
                    error(['Error: Lungimea vectorului b este %d. ' ... 
                        'Era asteptat un vector de lungime %d'], length(b), nColumnsA);
                end


                % aplicam metoda substitutiei descendente 
                x = zeros(nColumnsA, 1);

                for iCol = nColumnsA:-1:1
                   partialSumAx = A(iCol, iCol+1:end) * x(iCol+1:end);
                   x(iCol) = (b(iCol) - partialSumAx) / A(iCol, iCol);
                end

            end

        [~,nColumnsA] = size(A); 
        A = [A,b];
        xOrderIndex = 1:nColumnsA;
        for iCol = 1:nColumnsA
           [maxValue,~] = max(max(abs(A(iCol:end,iCol:end-1))));
           if maxValue == 0
               error('Error: Sistemul este incompatibil sau compatibil nedet.');
           end

           [pivotRow, pivotCol] = find(abs(A(iCol:end,iCol:end-1)) == maxValue,1);
           [pivotRow, pivotCol] = deal(pivotRow + iCol - 1, pivotCol + iCol - 1);   
           if pivotRow ~= iCol
              A = swapRows(A,iCol,pivotRow); 
           end
           if pivotCol ~= iCol
              A = swapColumns(A,iCol,pivotCol); 
              xOrderIndex = swapColumns(xOrderIndex,iCol,pivotCol); 
           end

           A = makeZerosBelow(A, iCol, iCol);
        end

        b = A(:,end);
        A = A(:,1:end-1);
        x = subsDesc(A,b);
        x(xOrderIndex) = x;

    end
    
 %% Functions Ex4
    function [xAprox, N] = metJacobi(A, a, epsilon)
        I = eye(length(A));
        q = norm(I - A);
        if q >= 1
            error('Metoda Jacobi nu asigura convergenta');
        end
        k = 0;
        B = I - A;
        b = a;
        xAprox = zeros(length(A), 1);
        shouldStop = false;
        while shouldStop == false
            k = k+1;
            xAprox = B*xAprox + b;
            shouldStop = norm(b) * q^k / (1-q) <= epsilon;
        end
        N = k;
    end
    
    function [xAprox, N] = metJacobiDDL(A, a, epsilon)
        for i = 1:length(A)
            if sum(A(i,:)) - A(i, i) >= A(i, i)
                error('Matricea nu este diagonal dominanta pe linii');
            end
        end
        
        B = -(A ./ diag(A));
        B = B - diag(diag(B));
        q = norm(B, inf);
        b = a ./ diag(A);
        k = 0;
        xAprox = zeros(length(A), 1);
        shouldStop = false;
        while shouldStop == false
            k = k+1;
            xAprox = B*xAprox + b;
            shouldStop = norm(b, inf) * q^k / (1-q) <= epsilon;
        end
        N = k;
    end
    
    function [xAprox, N] = metJacobiR(A, a, epsilon)
        eigs = sort(eig(A));
        sigmaO = 2 / (eigs(1) + eigs(end));
        qO = (eigs(end) - eigs(1)) / (eigs(1) + eigs(end));
        
        I = eye(length(A));
        B = -sigmaO*A + I;
        b = a * sigmaO;
        k = 0;
        xAprox = zeros(length(A), 1);
        shouldStop = false;
        while shouldStop == false
            k = k+1;
            xAprox = B*xAprox + b;
            shouldStop = norm(b, inf) * qO^k / (1-qO) <= epsilon;
        end
        N = k;
    end


