% 9/10 -> Lipsa argumentari
function MarinoiuAndrei343Tema5()

%% Exercitiul 1,subpunctul a)

A = [3 1 1;1 3 1;1 1 3]; %% Initializam matricea

% Calculam normele utilizand functiile ce se regasesc in acest fisier
norma1 = normap(A,1);
norma2 = normap(A,2);
normainf = normap(A,inf);

% Afisam normele
disp('Norme functii construite: ');
disp(norma1);
disp(norma2);
disp(normainf);

%% Exercitiul 1,subpunctul c)

A = [3 1 1;1 3 1;1 1 3]; %% Initializam matricea

% Calculam numarul de conditionare utilizand functiile ce se regasesc in 
%acest fisier
cond1 = condp(A,1);
cond2 = condp(A,2);
condinf = condp(A,inf);

% Afisam numarul de conditionare
disp('Numar de conditionare functii construite: ');
disp(cond1);
disp(cond2);
disp(condinf);

%% Exercitiul 1,subpunctul d)

A = [3 1 1;1 3 1;1 1 3]; %% Initializam matricea

% Calculam normele utilizand functiile predefinite
n1 = norm(A,1);
n2 = norm(A,2);
ninf = norm(A,Inf);

disp('Norme functii predefinite: ');
disp(n1);
disp(n2);
disp(ninf);

% Calculam numarul de conditionare utilizand functiile predefinite
c1 = cond(A,1);
c2 = cond(A,2);
cinf = cond(A,Inf);

% Afisam numarul de conditionare
disp('Numar de conditionare functii predefinite: ');
disp(c1);
disp(c2);
disp(cinf);



%% Exercitiul 5,subpunctul 2)

% Initializam datele necesare conform cerintei
A1 = [0.2 0.01 0;0 1 0.04;0 0.02 1];
A2 = [4 1 2;0 3 1;2 4 8];
A3 = [4 2 2;2 10 4;2 4 6];
a = [1;2;3];
sigma = 1;
epsilon = 10^(-5);

% Aplicam pe rand metodele Jacobi in functie de matrice
[xaprox,N] = MetJacobi(A1,a,epsilon);
[xaprox2,N2] = MetJacobiDDL(A2,a,epsilon);
[xaprox3,N3] = MetJacobiR(A3,a,epsilon,sigma);

% Afisam rezultatul
disp('Rezultat metoda Jacobi: ');
disp(xaprox);

disp('Rezultat metoda JacobiDDL: ');
disp(xaprox2);

disp('Rezultat metoda MetJacobiR: ');
disp(xaprox3);

end

% Functie pentru a calcula norma matriciala

% Date de intrare :
% A -> matrice
% p -> Tipul normei (1,2 sau inf)

% Date de iesire :
% normap -> norma rezultata
function [normap] = normap(A,p)

% Utilizam 3 if-uri pentru a diferentia cele 3 tipuri de norme (1,2 si inf)
if(p == 1)
    max = -1; % Initializam maximul cu -1 (suma are valori pozitive)
    for j = 1:length(A) % Parcurgem elementele din matrice
        sum = 0;
        
        for i = 1:length(A)
            sum = sum + abs(A(i,j)); % Formam suma
        end
        
        if(sum > max) % Salvam suma in cazul in care aceasta este maxima
            max = sum;
        end
    end
    normap = max; % Salvam norma
end

if(p == 2)
    epsilon = 10^(-4); % Setam valoarea lui epsilon
    lambda = MetJacobi2(A' * A,epsilon); % Utilizam Met. Jacobi pentru a 
%calcula valorile proprii
    max = sqrt(lambda(1)); % Initializam max cu primul radical
    
    for i = 1:length(A) % Parcurgem valorile proprii
        if(sqrt(lambda(i)) > max) % Salvam suma in cazul in care aceasta 
%este maxima
            max = sqrt(lambda(i));
        end
    end
    normap = max; % Salvam norma
end

if(p == inf)
    max = -1; % Initializam maximul cu -1 (suma are valori pozitive)
    for i = 1:length(A) % Parcurgem elementele din matrice
        sum = 0;
        
        for j = 1:length(A)
            sum = sum + abs(A(i,j)); % Formam suma
        end
        
        if(sum > max) % Salvam suma in cazul in care aceasta este maxima
            max = sum;
        end
    end
    normap = max; % Salvam norma
end

end

% Functie pentru a calcula numarul de conditionare

% Date de intrare :
% A -> matrice
% p -> Tipul normei (1,2 sau inf)

% Date de iesire :
% condp -> numarul de conditionare rezultat
function [condp] = condp(A,p)

val1 = normap(A,p); % Calculam norma pentru A
val2 = normap(A^-1,p);  % Calculam norma pentru A^-1
condp = val1 * val2; % Calculam numarul de conditionare conform definitiei

end

% Functie pentru a calcula modulul pentru o matrice

% Date de intrare :
% A -> matrice

% Date de iesire :
% sum -> suma rezultata
function [sum] = ModulMatrice(A)

sum = 0; % Initializam suma cu 0

% Parcurgem toate elementele din matrice
for i = 1:length(A)
    for j = 1:length(A)
        if(i ~= j) % Verificam daca indicii sunt diferiti
            sum = sum + A(i,j)^2; % Formam suma conform definitiei
        end
    end
end

sum = sqrt(sum); % Aplicam radical inainte de a returna solutia

end

% Functie specifica metodei Jacobi de aprox. a valorilor proprii

% Date de intrare :
% A -> matrice
% epsilon -> toleranta

% Date de iesire :
% lambda -> vector ce contine valorile proprii

% Algoritmul este implementat dupa pseudocodul aflat in cursul 4,pagina 28.
function [lambda] = MetJacobi2(A,epsilon)

lambda = zeros(1,length(A)); % Initializam vectorul de valori cu 0
sum = ModulMatrice(A); % Calculam modulul initial pentru matrice

% Iteratiile algoritmului
while(sum > epsilon)
    p = 1;
    q = 2;
    
    for i = 1:length(A)
        for j = i+1:length(A)
            if(abs(A(i,j)) > abs(A(p,q)))
                p = i;
                q = j;
            end
        end
    end
    
    if(A(p,p) == A(q,q))
        theta = pi/4;
    else
        theta = atan((2*A(p,q)) / (A(q,q) - A(p,p)))/2;
    end
    
    c = cos(theta);
    s = sin(theta);
    
    for j = 1:length(A)
        if(j ~= p && j~= q)
            u = A(p,j) * c - A(q,j) * s;
            v = A(p,j) * s + A(q,j) * c;
            A(p,j) = u;
            A(q,j) = v;
            A(j,p) = u;
            A(j,q) = v;
        end
    end
    
    u = (c^2) * A(p,p) - 2 * c * s * A(p,q) + (s^2) * A(q,q);
    v = (s^2) * A(p,p) + 2 * c * s * A(p,q) + (c^2) * A(q,q);
    A(p,p) = u;
    A(q,q) = v;
    A(p,q) = 0;
    A(q,p) = 0;
    sum = ModulMatrice(A);
end

% Parcurgem diagonala principala pentru a retine valorile proprii
for i = 1:length(A)
    lambda(i) = A(i,i);
end

end

% Functie specifica metodei Jacobi

% Date de intrare :
% A -> matrice
% a -> matrice
% epsilon -> toleranta

% Date de iesire :
% xaprox -> solutia sistemului
% N -> pasul de oprire

% Algoritmul este implementat dupa pseudocodul aflat in cursul 5,pagina 25.
function [xaprox,N] = MetJacobi(A,a,epsilon)

I = eye(length(A)); % Formam matricea identitate in functie de A
q = norm(I - A); % Calculam norma matricei I-A

% Caz de oprire in cazul in care q >= 1
if(q >= 1)
    fprintf('Metoda Jacobi nu asigura conv.');
    N = 0;
    return;
end

% Utilizam un vector compus din valori de tip matrice pentru a calcula
%rezultatul
x(:,:,1) = zeros(length(A),1); % Initializam prima valoare din vector cu
%o matrice de n linii si o coloana cu 0
k = 1; % Initializam k
B = I - A; % Calculam matricea B
b = a; % Initializam b
cond = 1;
% Iteratiile algoritmului (cat timp conditia este adevarata se executa 
%pasii necesari)
while(cond == 1)
    k = k + 1;
    x(:,:,k) = B * x(:,:,k-1) + b;
    
    if((q^k/(1 - q)) * norm(x(:,:,2) - x(:,:,1)) >= epsilon)
        cond = 1;
    else
        cond = 0;
    end
end

xaprox = x(:,:,k); % Ultima matrice din vector reprezinta solutia
N = k; % Salvam pasul de oprire

end

% Functie specifica metodei Jacobi pentru matrice diagonal dominanta

% Date de intrare :
% A -> matrice
% a -> matrice
% epsilon -> toleranta

% Date de iesire :
% xaprox -> solutia sistemului
% N -> pasul de oprire

% Algoritmul este implementat dupa pseudocodul aflat in cursul 5,pagina 29.
function [xaprox,N] = MetJacobiDDL(A,a,epsilon)

% Verificam daca matricea este diagonal dominanta pe linii
for i = 1:length(A)
    sum = 0; % Initializam suma cu 0
    
    for j = 1:length(A) % Parcurgem elementele si construim suma
        if(i ~= j)
            sum = sum + A(i,j);
        end
    end
    
    if(abs(A(i,i)) < sum) % Verificam daca conditia este satisfacuta
        disp('Matricea nu este diag. dom. pe linii');
        return;
    end
end

% Utilizam un vector compus din valori de tip matrice pentru a calcula
%rezultatul
x(:,:,1) = zeros(length(A),1); % Initializam prima valoare din vector cu
%o matrice de n linii si o coloana cu 0
k = 1; % Initializam k

% Calculez B conform definitiei din cursul 5,pg 28
for i = 1:length(A)
    for j = 1:length(A)
        if(i == j)
            B(i,j) = 0;
        else
            B(i,j) = (-1)*(A(i,j)/A(i,i));
        end
    end
end

% Calculez matricea b utilizand a si A conform definitiei din pseudocod
for i = 1:length(A)
    b(i,:) = a(i,:) / A(i,i);
end

q = norm(B,Inf); % Calculez norma inf. a lui B
cond = 1;
% Iteratiile algoritmului (cat timp conditia este adevarata se executa 
%pasii necesari)
while(cond == 1)
    k = k + 1;
    x(:,:,k) = B * x(:,:,k-1) + b;
    
    if((q^k/(1 - q)) * norm(x(:,:,2) - x(:,:,1)) >= epsilon)
        cond = 1;
    else
        cond = 0;
    end
end

xaprox = x(:,:,k); % Ultima matrice din vector reprezinta solutia
N = k; % Salvam pasul de oprire

end

% Functie specifica metodei Jacobi relaxate

% Date de intrare :
% A -> matrice
% a -> matrice
% epsilon -> toleranta
% sigma -> parametrul de relaxare

% Date de iesire :
% xaprox -> solutia sistemului
% N -> pasul de oprire

% Algoritmul este implementat dupa pseudocodul aflat in cursul 5,pagina 36.
function [xaprox,N] = MetJacobiR(A,a,epsilon,sigma)

% Setam epsilom si calculam valorile proprii pentru matricea A
epsilon2 = 10^(-4);
lambda = MetJacobi2(A,epsilon2);

% Calculam q0 si sigma0
sigma0 = 2/(lambda(length(A)) + lambda(1));
q0 = (lambda(length(A)) - lambda(1)) / (lambda(length(A)) + lambda(1));

% Calculez B conform definitiei din cursul 5,pg 28(adaptez adaugan sigma)
for i = 1:length(A)
    for j = 1:length(A)
        if(i == j)
            B(i,j) = 0;
        else
            B(i,j) = (-1)*sigma*(A(i,j)/A(i,i));
        end
    end
end

b = sigma * a; % Formez matricea b

x(:,:,1) = zeros(length(A),1); % Initializam prima valoare din vector cu
%o matrice de n linii si o coloana cu 0
k = 1; % Initializam k
cond = 1;

% Iteratiile algoritmului (cat timp conditia este adevarata se executa 
%pasii necesari)
while(cond == 1)
    k = k + 1;
    x(:,:,k) = B * x(:,:,k-1) + b;
    
    if((q0^k/(1 - q0)) * norm(x(:,:,2) - x(:,:,1)) >= epsilon)
        cond = 1;
    else
        cond = 0;
    end
end

xaprox = x(:,:,k); % Ultima matrice din vector reprezinta solutia
N = k; % Salvez pasul de oprire

end

% Functie specifica metodei Gauss cu pivotare totala

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% x -> solutiile sistemului

% Aloritmul este implementat dupa pseudocodul aflat in cursul 2,pagina 22.

function [x] = GaussPivTot(A, b)

n = length(A); % Dimensiunea initiala a matricei (fara coloana termenilor 
%liberi)
A = [A,b]; % Adaugam coloana termenilor liberi
index = linspace(1,n,n); % Generam vectorul index cu valori de la 1 la n

% Iteratiile algoritmului
for k = 1:n - 1
    max = abs(A(k,k));
    for i = k:n
        for j = k:n
            if(abs(A(i,j)) > max)
                max = abs(A(j,k));
            end
        end
    end
    
    for p = k:n
        for m = k:n
            if(abs(A(p, m)) == max)
                break;
            end
        end
    end
    
    if(A(p,m) == 0)
        fprintf('Sistem incomp. sau sist. comp. nedet.\n');
        x = [];
        return;
    end
    
    if(p ~= k)
        aux = A(p,:);
        A(p,:) = A(k,:);
        A(k,:) = aux;
    end
    
    if(m ~= k)
        aux = A(:,m);
        A(m,:) = A(:,k);
        A(:,k) = aux;
        
        aux2 = index(m);
        index(m) = index(k);
        index(k) = aux2;
    end
    
    for l = k + 1:n
        m = A(l,k) / A(k,k);
        A(l,:) = A(l,:) - m * A(k,:);
    end
end

if(A(n,n) == 0)
    fprintf('Sistem incomp. sau sist. comp. nedet.\n');
    x = [];
    return;
end

y = SubsDesc(A(1:n,1:n), A(1:n,n+1));

for i = 1:n
    x(index(i)) = y(i);
end
  
end

% Functie specifica metodei substitutiei descendente

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% x -> solutiile sistemului

% Aloritmul este implementat dupa pseudocodul aflat in cursul 2,pagina 4.

function [x] = SubsDesc(A,b)

x(length(A)) = b(length(A)) / A(length(A),length(A)); % Aflam x(n) conform
%definitiei
k = length(A) - 1; % Initializare k

% Iteratiile algoritmului
while(k > 0)
    sum = 0;
    for j = k + 1:length(A)
        sum = sum + A(k,j) * x(j);
    end
    
    x(k) = (b(k) - sum) / A(k,k);
    k = k - 1;
end
  
end