% 1, 2 lipsa -> Total 5/10
% Ex 5
% a
A = [ 0.2 0.01 0;
      0   1    0.04;
      0   0.02 1 ];
a = [1; 2; 3];
eps = 1e-5;

[x_aprox, N] = MetJacobi(A, a, eps);

% norm(I - A) < 1, deci metoda converge.

% b
A = [4 1 2;
     0 3 1;
     2 4 8];

[x_aprox, N] = MetJacobiDDL(A, a, eps);

% Matricea e diagonal dominanta pe linii, deci metoda converge.

% c
A = [4  2 2;
     2 10 4;
     2  4 6];
sigma = 0.0025;
[x_aprox, N] = MetJacobiR(A, a, eps, sigma);