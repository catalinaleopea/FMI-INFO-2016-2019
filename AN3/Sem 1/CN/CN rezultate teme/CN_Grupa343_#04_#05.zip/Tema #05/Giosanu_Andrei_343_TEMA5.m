% Giosanu Andrei
% Grupa 343
% Discutie -> Tema identica cu a lui Dan Baciu
%ex-1

%a)
A = [3 1 1; 1 3 1; 1 1 3];
n1 = normap(A,1);
n2 = normap(A,2);
n3 = normap(A,inf);

%b)
raza = razaSpectrala(A);

%c)
c1 = condn(A,1);
c2 = condn(A,2);
c3 = condn(A,Inf);

%d)
nn1 = norm(A,1);
nn2 = norm(A,2);
nn3 = norm(A,Inf);
cc1 = cond(A,1);
cc2 = cond(A,2);
cc3 = cond(A,Inf);

%ex-2
A2 = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];
b = [32; 23; 33; 31];
X = [1; 1; 1; 1];

%a)
R = GaussPivTot(A2,b);

%b)
bp = [32.1; 22.9; 33.1; 30.9];
R2 = GaussPivTot(A2,bp);

%c)
c4 = condn(A2, Inf);
nx = normap(R, Inf);
nxp = normap(R2, Inf);
raport1 = nxp/nx;

nb = normap(b, Inf);
nbp = normap(bp,Inf);
raport2 = c4*(nbp/nb);

%d)
A3 = [10 7 8.1 7.2; 7.08 5.04 6 5; 8 5.98 9.89 9; 6.99 4.99 9 9.98];
R3 = GaussPivTot(A3, b);
R4 = GaussPivTot(A3, bp);

%ex-5
A4 = [ 0.2 0.01 0; 0 1 0.04; 0 0.02 1 ];
A5 = [4 1 2; 0 3 1; 2 4 8];
A6 = [4  2 2; 2 10 4; 2  4 6];
a = [1; 2; 3];
eps = 1e-5;

[x_aprox, N] = MetJacobi(A4, a, eps);
[x_aprox1, Ns] = MetJacobiDDL(A5, a, eps);
[x_aprox2, Nd] = MetGaussSeidel(A6, a, eps);

%ex-4
function [x_aprox, N] = MetJacobi(A, a, eps)
    x_aprox = zeros(1, size(A, 1));
    N = 0;
    I = eye(size(A));
    q = norm(I-A);
    if q >= 1
       disp('Metoda Jacobi nu asigura convergenta')
       return
    end
    
    B = I - A;
    b = a;
 
    xprec = B * zeros(size(A, 1), 1) + b;
    error = xprec;
    k = 2;
    while 1
        k = k + 1;
        xk = B * xprec + b;
        if q^k / (1 - q) * norm(error) < eps
            break
        end
        xprec = xk;
    end
    x_aprox = xprec;
    N = k;
end

function [x_aprox, N] = MetJacobiDDL(A, a, eps)
    n = size(A,1);
    x_aprox = zeros(1, n);
    N = 0;
    for i = 1:n
       if abs(A(i,i)) < sum(A(i,:)) - A(i, i)
           disp('Matricea nu este diagonal dominanta pe linii')
           return
       end
    end
    I = eye(size(A));
    B = zeros(n,n);
    for i = 1:n
        B(i, :) = I(i, :) - A(i, :) ./ A(i, i);
        a(i) = a(i) / A(i, i);
    end
    xprec = B * zeros(size(A, 1), 1) + a;
    error = norm(xprec, 2);
    k = 1;
    q = norm(B, inf);
    while 1
        xk = B * xprec + a;
        k = k+1;
        if q^k / (1 - q) * error < eps
            break;
        end
        xprec = xk;
    end
    
    x_aprox = xk;
    N = k;
end

function [x_aprox, N]=MetGaussSeidel(A, b,eps)
    n=size(A,1);
    nv=Inf; 
    N=0;
    xn = zeros(n, 1);
    while nv > eps
        x_aprox = xn;
        for i=1:n
            s = 0;
            for j=1:i-1
                s=s+A(i,j)*xn(j);
            end           
            for j=i+1:n
                s=s+A(i,j)*x_aprox(j);
            end
        xn(i)=(1/A(i,i))*(b(i)-s);
        end
        N = N+1;
        nv=norm(xn - x_aprox);
    end 
    x_aprox = xn;
end

function [rez] = normap(A,p)
if p == 1
    rez = max(sum(A));
elseif p == 2
    rez = sqrt(max(eig(A*A')));
else
    rez = max(sum(A'));
end
end

function [rez] = condn(A,p)
if p == 1
    rez = normap(A,p)*normap(A^(-1),p);
elseif p == 2
    rez = normap(A,p)*normap(A^(-1),p);
else
    rez = normap(A,p)*normap(A^(-1),p);
end
end

function [rez] = razaSpectrala(A)
val = eig(A);
max = 0;
for i=1:length(val)
    if abs(val(i)) > max
        max = abs(val(i));
    end
end
rez = max;
end

function [x] = GaussPivTot(A, B)
  A = [A, B];
  n = size(A, 1);
  xi = 1:n;
  
  for k = 1 : n - 1
    p = k;
    m = k;
    for i = k : n
      for j = k : n
        if abs(A(i, j)) > abs(A(p, m))
          p = i;
          m = j;
        end 
      end 
    end
    
    if A(p, m) == 0
      disp('Sistem incomp. sau sist. comp. nedet.');
      x = 0;
      break;
    end 
    
    if p ~= k
      A([p, k], :) = A([k, p], :);
    end 
    
    if m ~= k
      A(:, [m, k]) = A(:, [k, m]);
      xi([m, k]) = xi([k, m]);
    end 
    
    for l = k + 1 : n
      A(l, :) =A(l, :) -  A(l, k) / A(k, k) * A(k, :);
    end 
  end 
  
  if A(n, n) == 0
    disp('Sistem incomp. sau sist. comp. nedet.');
    x = 0;
  end 
  xraw = SubsDesc(A(1: n, 1: n), A(:, n + 1));
  
  for i = 1: n
    x(xi(i)) = xraw(i);
  end 
end 

function X = SubsDesc(A, B)
    n = length(B);
    X(n) = B(n) / A(n, n);
    for i=n-1:-1:1
        X(i) = (B(i) - (A(i, i + 1: n) * X(i +1: n)')) / A(i, i);
    end
end