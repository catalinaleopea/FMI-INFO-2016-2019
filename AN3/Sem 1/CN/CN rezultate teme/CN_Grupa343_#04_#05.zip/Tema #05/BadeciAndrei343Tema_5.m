%% Exercitiul 1
% Total: 2p/10p

A = [3 1 1; 1 3 1; 1 1 3];
[normap1] = normap(A, 1);
[normap2] = normap(A, 2);
[normap3] = normap(A, 0);
disp(normap1);
disp(normap2);
disp(normap3);

%% Functii
function [norma] = normap(A, p)
    if p ~= 0
        norma = norm(A, p);
    else
        norma = norm(A, Inf);
    end
end

function [xAprox, N] = MetJacobi(A, a, epsilon)
    n = length(A);
    I = eye(n);
    q = norm(I - A, Inf);
    x = zeros(n, 1);
    if q >= 1
        disp("Metoda Jacobi nu asigura conv.")
        return;
    end
    x(1) = 0;
    k = 1;
    B = I - A;
    b = a;
    ok = 1;
    while ok
        k = k + 1;
        x(k) = x(k - 1) * B + b;
        if (q^k/(1 - q)) * norm(x(2) - x(1), 1) < epsilon
            ok = 0;
        end
    end
    xAprox = x(k);
    N = k;
end