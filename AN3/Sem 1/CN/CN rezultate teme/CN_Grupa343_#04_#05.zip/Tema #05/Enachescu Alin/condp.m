% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = o matrice patratica
% 'p'       = norma pentru care sa se calculeze numarul de conditionare
% -------------------------------------------------------------------------
% Date de iesire:
% 'condp'  = numarul de conditionare in raport cu norma p
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================>

function [condp] = condp (A, p)
    condp = normap(A, p) * normap(inv(A), p);
end
