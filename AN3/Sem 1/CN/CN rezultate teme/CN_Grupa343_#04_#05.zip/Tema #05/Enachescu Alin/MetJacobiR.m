% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = o matrice simetrica si pozitiv definita
% 'a'       = un vector
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'  = solutia Ax = a
% 'N'       = iteratia la care ne oprim (data de criteriul de oprire)
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [xaprox, N] = MetJacobiR (A, a, epsilon)
    % determin parametrul optim de relaxare
    n = size(A, 1);
    e = eig(A); % valorile proprii ale lui A
    sigma = 2 / (e(n) + e(1));
    q = (e(n) - e(1)) / (e(n) + e(1));
    
    % determin pe B sigma
    B = eye(size(A));
    for i = 1 : n
        for j = 1 : n
            B(i, j) = B(i, j) - sigma * A(i, j);
        end
    end

    % determin pe b sigma
    b = a;
    for i = 1 : n
        b(i, 1) = b(i, 1) * sigma;
    end
    
    % initializez x0 si k
    k = 0;
    x_zero = zeros(size(A, 1), 1);
    
    % calculez separat pentru x1
    k = k + 1;
    x_one = B * x_zero + b;
    
    % calculez s ca fiind || x1 - x0 ||A
    s = 0;
    x = x_one - x_zero;
    for i = 1 : n
        for j = 1 : n
            s = s + A(i, j) * x(i, 1) * x(j, 1);
        end
    end
    
    if q ^ k / (1 - q) * s >= epsilon
        xaprox = x_one;
        N = k;
        return;
    end
    
    % initializez pe x(k-1) ca fiind x1
    x_k_minus_one = x1;
    
    % iteratiile algoritmului
    while true
        k = k + 1;
        x_k = B * x_k_minus_one + b;
        
        if q ^ k / (1 - q) * s >= epsilon
            break;
        end
        
        x_k_minus_one = x_k;
    end
    
    % returnez rezultatul
    xaprox = x_k;
    N = k;
end
