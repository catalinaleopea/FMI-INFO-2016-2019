% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = o matrice patratica
% 'p'       = norma care sa fie calculata
% -------------------------------------------------------------------------
% Date de iesire:
% 'normap'  = rezultatul normei p pentru matricea A
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [normap] = normap(A, p)
    if p == 1
        normap = 0;
        n = size(A, 1);
        
        for j = 1 : n
            sum = 0;
            for i = 1 : n
                sum = sum + abs(A(i, j));
            end
            if sum > normap
                normap = sum;
            end
        end
    else if p == 2
        B = transpose(A) * A;
        e = eig(B);
        n = size(e);
        
        normap = 0;
        for i = 1 : n
            tmp = sqrt(e(i));
            if tmp > normap
                normap = tmp;
            end
        end
    else
        normap = 0;
        n = size(A, 1);
        
        for i = 1 : n
            sum = 0;
            for j = 1 : n
                sum = sum + abs(A(i, j));
            end
            if sum > normap
                normap = sum;
            end
        end
    end

end % end function
