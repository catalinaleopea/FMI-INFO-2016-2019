% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Rezolv exercitiul 1si exercitiul 2
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================
% Total: 7/10
% ! Nu mai folosi 'prinf' -> 'fprintf'

%% exercitiul 1

A = [3, 1, 1; 1, 3, 1; 1, 1, 3];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% punctul a
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('punctul a\n');

n = normap(A, 1);
fprintf('cazul 1\n');
n
fprintf('\n');

n = normap(A, 2);
fprintf('cazul 2\n');
n
fprintf('\n');

n = normap(A, inf);
fprintf('cazul inf\n');
n
fprintf('\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% punctul b
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% raza spectrala este patratul normelor de la punctul a
% Nu cu functii predefinite de MATLAB. Trebuia sa cauti cu Jacobi.
fprintf('\n\n\npunctul b\n');

B = transpose(A) * A;
e = eig(B);
n = size(e);

razaSpectrala = 0;
for i = 1 : n
    if e(i) > razaSpectrala
        razaSpectrala = e(i);
    end
end
razaSpectrala
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% punctul c
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('\n\n\npunctul c\n');

c = condp(A, 1);
fprintf('cazul 1\n');
c
fprintf('\n');

c = condp(A, 2);
fprintf('cazul 2\n');
c
fprintf('\n');

c = condp(A, inf);
fprintf('cazul inf\n');
c
fprintf('\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% punctul d
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('\n\n\npunctul d\n');

n = norm(A, 1);
c = cond(A, 1);
fprintf('cazul 1\n');
n
c
fprintf('\n');

n = norm(A, 2);
c = cond(A, 2);
fprintf('cazul 2\n');
n
c
fprintf('\n');

n = norm(A, inf);
c = cond(A, inf);
fprintf('cazul inf\n');
n
c
fprintf('\n');


%% exercitiul 2

A = [
    10, 7, 8, 7;
    7, 5, 6, 5;
    8, 6, 10, 9;
    7, 5, 9, 10
];

b = [32; 23; 33; 31];

fprintf('Calculez solutia sistemului Ax = b pentru\n');
A
b

x = GaussPivTot(A, b);

fprintf('Solutia este:\n');
x
