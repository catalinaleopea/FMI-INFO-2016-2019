% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Metoda Jacobi
% Date de intrare:
% 'A'       = matricea asociata sistemului (matrice inversabila)
% 'a'       = vector de dimensiune n
% 'epsilon' = eroarea maxima dintre solutiile obtinute si solutiile reale
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'  = vectorul solutiilor sistemului
% 'N'       = numarul maxim de iteratii
% -------------------------------------------------------------------------
function [ xaprox, N ] = MetJacobi( A, a, epsilon )
n = size(A);
B = eye(n) - A;         
[q] = normap(B, 1);      %determin norma 1 a matricei I-A
if q >=1                %astfel verific daca metoda asigura convergenta
    disp('Metoda Jacobi nu asigura conv.');
    return;
end
x(:, 1) = zeros(length(a), 1);  
k = 1;
b = a;
k = k + 1;
x(:, k) = B * x(:, k-1) + b;    %cat timp inca nu am gasit o solutie 
                                %cu o eroare mai mica decat epsilon fata de
                                %solutia reala, continui iteratia
while q.^k/(1-q)*norm((x(:, 2)-x(:, 1)), 1) >= epsilon
    k = k + 1;
    x(:, k) = B*x(:, k-1) + b;
end
xaprox = x(:, k);      %xaprox preia valorile calculate in ultima iteratie
N = k;                  %iteratia la care am determinat xaprox
end

