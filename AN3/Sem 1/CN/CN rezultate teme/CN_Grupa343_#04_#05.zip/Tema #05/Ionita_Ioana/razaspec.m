% Date de intrare:
% 'A'       = matricea asociata sistemului 
% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de iesire:
% 'raza'    = raza spectrala a matricei A
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ raza ] = razaspec( A )
epsilon = 10^(-5);
[lambda] = MetJacobi(A, epsilon);   %determin valorile proprii ale 
                                    %matricei A
n = size(A);
raza = abs(lambda(1));              %caut maximul valorilor proprii   
for i = 2:n                         %considerate in valoare absoluta
    if abs(lambda(i)) > raza
        raza = abs(lambda(i));
    end
end
end

