% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Metoda Jacobi pentru matrice diagonal dominante pe linii
% Date de intrare:
% 'A'       = matricea asociata sistemului (matrice inversabila)
% 'a'       = vector de dimensiune n
% 'epsilon' = eroarea maxima dintre solutiile obtinute si solutiile reale
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'  = vectorul solutiilor sistemului
% 'N'       = numarul maxim de iteratii
% -------------------------------------------------------------------------
function [ xaprox, N ] = MetJacobiDDL( A, a, epsilon )
n = size(A);
%incep prin a verifica daca matricea este diagonal dominanta pe linii, ie
%daca valoarea absoluta a oricarui element de pe diagonala principala este 
%mai mare strict decat suma modulelor celorlalte elemente situate pe
%aceeasi linie
for i =1:n
    suma = 0;
    for j = 1:n 
        if j ~= i
            suma = suma + abs(A(i, j));
        end
    end
    if abs(A(i, i)) <= suma
        disp('Matr. nu este diag. dom. pe linii');
        break;
    end
end
x(:, 1) = zeros(length(a), 1);
k = 1;
%determin matricea B, unde B = I - D.^(-1) *A, D = diag(A)
for i = 1:n
    b(i) = a(i)/A(i, i);
    for j = 1:n
        if i == j
            B(i, j) = 0;
        else
            B(i, j) = - A(i, j) / A(i, i);
        end
    end
end
[q] = normap(B, inf);   %calculez norma infinit a lui B
k = k + 1;
x(:, k) = B * x(:, k-1) + transpose(b);
%iterez pana gasesc o solutie cat mai apropiata de cea reala
while q.^k/(1 - q) * norm((x(:, 2) - x(:, 1)), inf) >= epsilon
    k = k + 1;
    x(:, k) = B * x(:, k-1) + transpose(b);
end
xaprox = x(:, k);   %ultima iteratie imi ofera valorile cautate
N = k;      
end

