% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Metoda Jacobi relaxata
% Date de intrare:
% 'A'       = matricea asociata sistemului (matrice inversabila)
% 'a'       = vector de dimensiune n
% 'epsilon' = eroarea maxima dintre solutiile obtinute si solutiile reale
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'  = vectorul solutiilor sistemului
% 'N'       = numarul maxim de iteratii
% -------------------------------------------------------------------------
function [ xaprox, N ] = MetJacobiR( A, a, epsilon )
[lambda] = MetJacobiValProprii(A, epsilon); %determin valorile proprii
n = size(A);
lambdaMin = lambda(1);
lambdaMax = lambda(1);
for i = 1:n     %determin valoarea proprie minima si valoarea proprie maxima
    if lambda(i) > lambdaMax
        lambdaMax = lambda(i);
    end
    if lambda(i) < lambdaMin
        lambdaMin = lambda(i);
    end
end
sigmaO = 2/(lambdaMax + lambdaMin); %determin parametrul optim de relaxare
qO = (lambdaMax - lambdaMin) / (lambdaMax + lambdaMin);
I = eye(n);
for i = 1:n
    for j = 1:n
        B(i,j) = I(i,j) - sigmaO*A(i,j);
    end
end
for i = 1:n
    b(i) = sigmaO * a(i);
end
x(:,1) = zeros(length(a),1);
k = 1;
k = k + 1;
x(:,k) = B * x(:,k-1) + transpose(b);
%iterez pana gasesc o solutie cat mai apropiata de cea reala
while (qO ^ k / (1 - qO)) * normaA( A, (x(:,2) - x(:,1))) >= epsilon
    k = k + 1;
    x(:,k) = B * x(:,k-1) + transpose(b);
end
xaprox = x(:,k);
N = k;

end

