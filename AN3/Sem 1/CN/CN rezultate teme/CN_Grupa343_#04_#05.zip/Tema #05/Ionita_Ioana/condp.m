% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului 
% 'p'       = numarul normei pe care doresc sa o determin
% -------------------------------------------------------------------------
% Date de iesire:
% 'condp'    = numarul de conditionare al matricei A in raport cu norma p
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ condp ] = condp( A, p )
B = inv(A);
%numarul de conditionare reprezinta produsul dintre norma p a matricei A
%inmultita cu norma p a matricei inverse a lui A
condp = normap(A, p) * normap(B, p); 
end

