% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului 
% 'p'       = numarul normei pe care doresc sa o determin
% -------------------------------------------------------------------------
% Date de iesire:
% 'norma'    = norma obtinuta
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ norma ] = normap( A, p )
norma = 0;
n = size(A);
if p == 1           %daca doresc sa determin norma 1, aceasta este 
    for j = 1:n     %reprezentata de maximul dintre sumele elementelor de  
        suma = 0;   %pe coloane, elementele fiind luate in modul
        for i = 1:n
            suma = suma +  abs(A(i, j));
        end
        if suma > norma
            norma = suma;
        end
    end
end
if p == 2           %daca determin norma 2, aceasta este reprezentata de
    epsilon = 10^(-5);  %maximul dintre radicalii valorilor absolute,
    B = transpose(A) * A;   %valori ce apartin matricei B, unde B=A.'*A
    [ lambda ] = MetJacobi( B, epsilon );
    norma = sqrt(lambda(1));
    for i = 1:n
        if sqrt(lambda(i)) >  norma
            norma = sqrt(lambda(i));
        end
    end
end
if p == inf         %daca determin norma infinita, aceasta este reprezentata
    for i = 1:n     %de maximul dintre sumele elementelor de pe linii luate 
        suma = 0;   %in modul
        for j = 1:n
            suma = suma +  abs(A(i, j));
        end
        if suma > norma
            norma = suma;
        end
    end
end
end

