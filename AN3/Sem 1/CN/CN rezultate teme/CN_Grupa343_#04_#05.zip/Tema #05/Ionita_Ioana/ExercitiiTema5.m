%% Exercitiul 1, tema 5
% subpunctul a) normele matricei A
A = [3 1 1; 1 3 1; 1 1 3];
[norma1] = normap(A, 1);
[norma2] = normap(A, 2);  %-> Ai grija cum o calculezi
[normainf] = normap(A, inf);


%%subpunctul b) raza spectrala
[razaspectrala] = razaspec(A); % -> Nu reusesc sa rulez din cauza lui JACOBI
% raza spectrala este 5, egala cu normele calculate anterior

%subpunctul c) numarul de conditionare
[condp1] = condp(A, 1);
[condp2] = condp(A, 2);
[condpinf] = condp(A, inf);

%subpunctul d) norma si numarul de conditionare folosind functii
%predefinite
[norma11] = norm(A, 1);
[norma22] = norm(A, 2);
[normainfinf] = norm(A, inf);

[condp11] = cond(A, 1);
[condp22] = cond(A, 2);
[condpinfinf] = cond(A, inf);
%Se observa ca normele si numerele de conditionare calculate la subpunctul
%d coincid cu normele si numerele de conditionare determinate la
%subpunctele a) si c).
%% 
%Exericitul 2, tema 5
%subpunctul a
A = [10 7 8 7; 7 5 6 5; 8 6 10 9; 7 5 9 10];
b = [32; 23; 33; 31];
[x] = GaussPivTot(A, b);

%subpunctul b
bperturbat = [32.1; 22.9; 33.1; 30.9];
[xperturbat] = GaussPivTot(A, bperturbat);
[condA] = cond(A, 1);
% Mai verifica odata cum arata x si cum arata xperturbat. Eu zic ca nu este
% o perturbare mica in solutie, ci o perturbare mare.
%O mica perturbatie in datele de intrare produce
%o perturbatie destul de mica in solutia sistemului. Se observa ca numarul
%de conditionare al lui A este mult mai mare decat 1 deci sistemul este
%slab-conditionat.

%subpunctul c
[kinfinit] = cond(A, inf);
xDelta = xperturbat - x;
[normaxDelta] = norm(xDelta, inf);
[normax] = norm(x, inf);
r1 = normaxDelta/normax;

bDelta = bperturbat - b;
[normabDelta] = norm(bDelta, inf);
[normab] = norm(b, inf);
r2 = kinfinit * (normabDelta/normab);

%Se observa ca cele 2 marimi (r1 si r2) sunt egale. kinfinit este mult mai
%mare decat 1, deci sistemul este slab conditionat.

%subpunctul d
Aperturbat = [10 7 8.1 7.2; 7.08 5.04 6 5; 8 5.98 9.89 9; 6.99 4.99 9 9.98];
[xpert] = GaussPivTot(Aperturbat, b);
%Se observa faptul ca perturbatia matricei initiale cauzeaza o perturbatie
%considerabila in solutie.
%% 
%Exercitiul 5, tema 5
%subpunctul 2
%a
A1 = [0.2 0.01 0; 0 1 0.04; 0 0.02 1];
a = [1; 2; 3];
epsilon = 10^(-5);
[xaprox1, N1] = MetJacobi(A1, a, epsilon);

%b
A2 = [4 1 2; 0 3 1; 2 4 8];
[xaprox2, N2] = MetJacobiDDL(A2, a, epsilon);

%c
A3 = [4 2 2; 2 10 4; 2 4 6];
[xaprox3, N3] = MetJacobiR(A3, a, epsilon);
