% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului 
% 'x'       = vector de dimensiune n
% -------------------------------------------------------------------------
% Date de iesire:
% 'norma'    = norma obtinuta
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [norma] = normaA(A, x)
n = size(A,1);
suma = 0;
for i = 1:n
    for j = 1:n
    suma = suma + A(i,j) * x(j) * x(i);
    end
end
norma = suma;
end
