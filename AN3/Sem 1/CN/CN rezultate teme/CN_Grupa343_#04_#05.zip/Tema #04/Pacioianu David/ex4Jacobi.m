% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------
    % Compute the eigenvalues of matrix M using Jacobi's algorithm
    function [lambdas] = ex4Jacobi(M, epsilon)
        if M' ~= M
            error('Error: Matricea nu este simetrica.');
        end
        [nRowsM,~] = size(M);
        lambdas = zeros(1,nRowsM); 
        while matMod(M - diag(diag(M))) > epsilon
            [~,p,q] = matMax(abs(M - diag(diag(M))));
            theta = pi / 4;
            if M(p,p) ~= M(q,q)
                theta = 1/2 * atan(2*M(p,q)/(M(p,p)-M(q,q)));
            end
            c = cos(theta);
            s = sin(theta);
            for j=1:nRowsM 
                if (j ~= p) && (j ~= q) 
                    u=M(p,j)*c - M(q,j)*s; 
                    v=M(p,j)*s + M(q,j)*c; 
                    M(p,j)=u; 
                    M(q,j)=v;
                    M(j,p)=u;
                    M(j,q)=v;
                end
            end
            u = M(p,p)*c^2 - 2*c*s*M(p,q) + M(q,q)*s^2;
            v = M(p,p)*s^2 + 2*c*s*M(p,q) + M(q,q)*c^2;
            M(p,p) = u;
            M(q,q) = v;
            M(p,q) = 0;
            M(q,p) = 0;
        end
        lambdas = diag(M);
    end
    
    % Compute the mod of matrix M
    function [x] = matMod(M)
        x = sum(sum(M.^2));
    end
    
    % Compute the mod of matrix M
    function [val,i,j] = matMax(M)
        [val, idx] = max(M);
        [val, j] = max(val);
        i = idx(j);
    end

