% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------
% 1 -> 7, ai 10, cu mentiunea ca la 4 ai rezultat usor diferit fata de
% restul. De la syms este posibil sa pierzi precizie.
% Total: 70/70 i.e. 10/10
disp('Factorizarea QR Givens');

A = [1 1 0; 1 0 1; 0 1 1];
b = [1 2 5]';

[Q, R] = factQRGivens(A)
x = subsDesc(R, Q'*b)

    % Compute the QR factorization of matrix M using Givens rotations
    function [Q,R] = factQRGivens(M)
        [nRowsM,~] = size(M);
        Q = eye(nRowsM);
        
        for i = 1:nRowsM
            for j = i+1:nRowsM
                denom = sqrt(M(i,i)^2 + M(j,i)^2);
                c = M(i,i) / denom;
                s = M(j,i) / denom;
                Rot = eye(nRowsM);
                Rot(i,i) = c;
                Rot(i,j) = s;
                Rot(j,i) = -s;
                Rot(j,j) = c;
                M = Rot * M;   
                Q = Rot * Q;
            end
        end
        R = M;
        Q = Q';
    end
    
    %Procedura aplica metoda substitutiei descendente 
    %   x = SubsDesc(A, b), unde x este solutia sistemului Ax = b.
    function x = subsDesc(A, b)
        % Verificam integritatea datelor de intrare
        [mRowsA, nColumnsA] = size(A);
        if mRowsA ~= nColumnsA
            error('Error: Matricea nu este patratica.');
        end
        if nColumnsA ~= length(b)
            error(['Error: Lungimea vectorului b este %d. ' ... 
                'Era asteptat un vector de lungime %d'], length(b), nColumnsA);
        end

        % aplicam metoda substitutiei descendente 
        x = zeros(nColumnsA, 1);

        for iCol = nColumnsA:-1:1
           partialSumAx = A(iCol, iCol+1:end) * x(iCol+1:end);
           x(iCol) = (b(iCol) - partialSumAx) / A(iCol, iCol);
        end
    end
    

