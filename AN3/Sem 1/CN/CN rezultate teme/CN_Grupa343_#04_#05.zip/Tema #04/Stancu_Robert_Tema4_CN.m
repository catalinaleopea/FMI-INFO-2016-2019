%%
%Autor: Stancu Robert Gabriel
%Grupa: 343
%%
%=================================== Ex 2 =================================

A = [1 1 0; 1 0 1; 0 1 1];
b = [1;2;5];

[Q,R,x] = MetodaGivens(A,b);

disp('Matricea Q rezultata este: ')
Q

disp('Matricea R rezultata este: ')
R

disp('Solutia x este: ')
x


%%
%=================================== Ex 4 =================================

A = [3 1 1; 1 3 1; 1 1 3];

epsilon = 10^(-4);

lambda = MetodaJacobi(A,epsilon);

disp('Valorile proprii ale matricei A sunt: ')
lambda


%%
function [lambda] = MetodaJacobi(A,epsilon)

% Calculam modulul matricei A dupa formula de la curs
modul = A.*~eye(size(A));
modul = modul .^2;
modul = sum(sum(modul));

[~,n] = size(A);

while modul >= epsilon
        p = 1;
        q = 2;
        maximum = abs(A(1,2));
        
    for i = 1:n - 1
        for j = i + 1:n
            if maximum < abs(A(i,j))
                p = i;
                q = j;
                maximum = abs(A(i,j));
            end
        end
    end
    
    if A(p,p) == A(q,q)
        theta = pi/4;
    else
        theta = 1 / 2 * atan(2 * A(p,q) / (A(q,q) - A(p,p)));
    end
    
    c = cos(theta);
    s = sin(theta);
    
    for j = 1:n
        if j ~= p && j ~= q
            u = A(p,j) * c - A(q,j) * s;
            v = A(p,j) * s + A(q,j) * c;
            A(p,j) = u;
            A(q,j) = v;
            A(j,p) = u;
            A(j,q) = v; 
        end
    end      
    
    u = c ^ 2 * A(p,p) - 2 * c * s * A(p,q) + s ^ 2 * A(q,q);
    v = s ^ 2 * A(p,p) + 2 * c * s * A(p,q) + c ^ 2 * A(q,q);
    
    A(p,p) = u;
    A(q,q) = v;
    A(p,q) = 0;
    A(q,p) = 0;
    
    modul = A.*~eye(size(A));
    modul = modul .^2;
    modul = sum(sum(modul));

    
end

lambda = diag(A);

end


function [Q,R,x] = MetodaGivens(A,b)

[n,~] = size(A);

Q = eye(n);

for i = 1:n
   for j = i+1:n 
       sigma = sqrt(A(i,i)^2 + A(j,i)^2);
       c = A(i,i) / sigma;
       s = A(j,i) / sigma;
       
       for l = 1:n
           u = c * A(i, l) + s * + A(j, l);
           v = - s * A(i, l) + c * A(j, l);
           A(i,l) = u;
           A(j,l) = v;
           u = c * Q(i,l) + s * Q(j,l);
           v = - s * Q(i,l) + s * Q(j,l);
           Q(i,l) = u;
           Q(j,l) = v;
       end
       
       u = c * b(i) + s * b(j);
       v = - s * b(i) + c * b(j);
       b(i) = u;
       b(j) = v;
   end

end

R = A;
Q = Q';

x = SubsDesc(R,b);
end

function x = SubsDesc(A,b)

[n, ~] = size(A);

x(n) = (1/A(n,n)) * b(n);

k = n - 1;


while k > 0
    
   product = sum(A(k,k+1:n) .* x(k+1:n));
                                                                       
   x(k) = (1/A(k,k)) * (b(k) - product);
   k = k - 1;
end


end
