% Am implementat algoritmul Metodei Jacobi descris in cursul 4 pag 28-29
% metoda primeste matricea A si o eroare maximala epsilon si returneaza
% aproximarea valorilor proprii lambda
function [lambda] = MetJacobi(A,epsilon)
n = length(A); % pastram dimensiunea lui A
lambda = zeros(1,n); % prealocam lambda
% :)
if ~issymmetric(A) % verificam daca A este simterica
    error('Matricea nu este symetrica');
end
while 1
    % initializam modA cu 0 pentru a calcula suma conform definitiei II.10
    % din curs pag 28
    modA = 0;
    for i = 1:n % calculam suma conform definitiei
        for j = 1:n
            if i == j
                continue
            end
            modA = modA + A(i,j)^2;
        end
    end
    % pastram in modA radicalul de ordin 2 al sumei calculate anterior
    modA = sqrt(modA);
    if modA < epsilon % daca modA este mai mic decat eroarea oprim metoda
        break
    end
    
    maxA = 0; % incepem cu o valoare minima in cautarea indicilor
    % gasim indicii
    for k = 1:n
        for o = 1:n
            %varificam daca conditiile sunt indeplinite conform
            %algoritmului
            if k == o || k >= o
                continue
            end
            if abs(maxA) < abs(A(k,o))
                maxA = A(k,o); % pastram noul maxim gasit
                p = k; q = o; % pastram in p linia si in q coloana
            end
        end
    end

    % pastram in omega valoarea conform algoritmului
    if A(p,p) == A(q,q)
        omega = pi/4;
    else
        omega = 1/2*atan((2*A(p,q))/A(q,q)-A(p,p));
    end
    c = cos(omega); % pastram in c cos de omega
    s = sin(omega); % pastram in s cos de omega
    for j = 1:n % parcurgem dimensiunea lui A
        % pastram  valorile conform algoritmului in A daca j!= p,q
        if j ~= p && j ~= q 
            u = A(p,j)*c - A(q,j)*s;
            v = A(p,j)*s + A(q,j)*c;
            A(p,j) = u;
            A(q,j) = v;
            A(j,p) = u;
            A(j,q) = v;
        end
    end
    u = c^2 * A(p,p) - 2*c*s*A(p,q) + s^2*A(q,q); %pastram in u val lui app
    v = s^2*A(p,p) + 2*c*s*A(p,q) + c^2*A(q,q); %pastram in v val lui aqq
    A(p,p) = u; % pastram in app valoarea calculata anterior in u
    A(q,q) = v; % pastram in aqq valoarea calculata anterior in v
    A(p,q) = 0; % setam apq la 0 conform algoritmului
    A(q,p) = 0; % setam aqp la 0 conform algoritmului
    
end

for i = 1:n % parcurgem dimensiunea lui A
    lambda(i) = A(i,i); % pastram in lambda aproximarile gasite
end
end

