%% Atentie pe viitor la cum denumesti fiserele. Nu ai voie cu spatii intre 
% cuvinte sau sa incepi cu cifra sau sa folosesti operatori aritmetici etc
% Totodata, te rog sa pui sectiuni cu '%%' de acum inainte. Acum am pus eu

%%
% Tema 4
%% Ex 2
A = [1 1 0;1 0 1;0 1 1];
b = [1;2;5];

[Q,R,x] = Givens(A,b)

%% Ex 4
A1 = [3 1 1;1 3 1;1 1 3];
epsilon = 10^-4;

lambda = MetJacobi(A1,epsilon)

%% Ex 6 -> Iese mult mai usor cu definitia unei matrice pozitiv definite,
% i.e. cu produsul scalar. 
% folosim A de la exercitiul 4
det(A1)
% acest determinant este mai mare ca 0,  avand determinantul > 0
% stim sigur ca aceasta matrice este nesingulara, A are inversa

% Conform definitiei unei matrice pozitive definite (regula lui Sylvester)
% o matrice este pozitiv definita daca are pe toate rangurile determinantii
% mai mari ca 0 este pozitiv definita, daca este pozitiv definita inseamna
% ca orice vector x cu transpusa xT (x nu contine 0) au produsul xT*A*x >
% 0. Daca consideram transpusa lui A (AT) rezultatul produsului a 2 vectori
% rezulta ca AT * A > 0 adica AT * A pozitiv definita
