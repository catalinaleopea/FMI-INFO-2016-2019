%Am implementat algoritmul conform indicatiilor din cursul 4 de la pag
%18-19 functia primind ca date de intrare o matrice A si o matricea b,
%rezultatele sistemului A. Returnand matricea Q, R si solutiile x conform
%ecuatiei A*x = b
function [Q,R,x] = Givens(A,b)
n = length(A); % pastram dimesniunea lui A
Q = eye(n); % initializam Q cu In

for i = 1:n % parcurgem cu i dimensiunea lui A
    % pornim un j cu 1 mai mare decat i, evitam elementele de pe diagonala
    % si de sub diagonala
    for j = i+1:n
        % pastram in alpha valorile indicate de algoritm
        alpha = sqrt(A(i,i)^2+A(j,i)^2);
        c = A(i,i)/alpha;
        s = A(j,i)/alpha;
        for l = 1:n % la fiecare pas parcurgem din nou dimensiunea lui A
            % pastram in u valorile conform algoritmului
            u = c*A(i,l) + s*A(j,l); % in u valoarea lui ail
            v = -s*A(i,l) + c*A(j,l); % in v valoarea lui ajl
            A(i,l) = u; % atribuim lui ail valoarea calculata anterior in u
            A(j,l) = v; % atribuim lui ajl valoarea calculata anterior in v
            u = c*Q(i,l) + s*Q(j,l); % pastram in u valoarea lui qil
            v = -s*Q(i,l) + c*Q(j,l); % pastram in v valoarea lui qjl
            Q(i,l) = u; % atribuim lui qil valoarea calculata anterior in u
            Q(j,l) = v; % atribuim lui qjl valoarea calculata anterior in v
        end
        u = c*b(i) + s*b(j); % atribuim lui u valoarea lui bi
        v = -s*b(i) + c*b(j); % atribuim lui v valoarea lui bj
        b(i) = u; % atribuim lui bi valoarea calculata anterior in u
        b(j) = v; % atribuim lui bj valoarea calculata anterior in v
    end
end
% atribuim lui R pe A si lui Q transpusa calculata anterior 
% conform algoritmului
R = A; Q = Q';
% calculam x utilizand Substitutia Descendenta pe R si b calculate anterior
x = SubsDesc(R,b);
end


