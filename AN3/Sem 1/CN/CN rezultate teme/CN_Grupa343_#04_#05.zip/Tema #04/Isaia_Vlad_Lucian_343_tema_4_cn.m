%% exercitiul 2
%construim matricea sistemului
A = [1 1 0;
     1 0 1;
     0 1 1];
 
b = [1;
     2;
     5];
%aplicam metoda Givens pe matrice
[Q, R, x] = MetGivens(A, b);
%afisam solutiile
disp(x);
%% exercitiul 4 -> Nu obtii ce trebuie i.e. ~ [2 5 2]
%construim matricea sistemului
A = [3 1 1;
     1 3 1;
     1 1 3];
%stabilim un epsilon oricat de mic
epsilon = 10^(-4);
%aplicam metoda Jacobi pe matrice cu epsilonul stabilit
lambda = MetJacobi(A, epsilon);
%si am obtinut in lambda valoriile proprii ale matricii
%si le afisam
disp(lambda);
%%
%Metoda Givens
function [Q, R, x] = MetGivens(A, b)
    n = size(A, 1);
    
    Q = eye(n);
    
    for i = 1 : n
        for j = i+1 : n
            sigma = sqrt(A(i, i)^2 + A(j, i)^2);
            c = A(i, i) / sigma;
            s = A(j, i) / sigma;
            
            for l = 1 : n
                u = c * A(i, l) + s * A(j, l);
                v = -s * A(i, l) + c * A(j, l);
                A(i, l) = u;
                A(j, l) = v;
                u = c * Q(i, l) + s * Q(j, l);
                v = -s * Q(i, l) + c * Q(j, l);
                Q(i, l) = u;
                Q(j, l) = v;
            end
            
            u = c * b(i) + s * b(j);
            v = -s * b(i) + c * b(j);
            b(i) = u;
            b(j) = v;
        end
    end
    
    R = A;
    Q = transpose(Q);
    
    x = SubsDesc(R, b);
end

%Substitutia descendenta
function [x] = SubsDesc(A, b)
    n = size(b, 1);
    x(n) = b(n) / A(n, n);
    k = n-1;
    
    while k > 0
        sum = 0;
        
        for i = k+1 : n
            sum = sum + A(k, i)*x(i);
        end
        
        x(k) = (b(k) - sum) / A(k,k);
        k = k-1;
    end
end

%Metoda Jacobi
function [lambda] = MetJacobi(A, epsilon)
    n = size(A, 1);

    while det(A) >= epsilon
       	maximum = max(max(A));
        [p, q] = find(A == maximum);
        p = p(1);
        q = q(1);
        
        theta = 0;
        
        if A(p, p) == A(q, q)
            theta = pi / 4;
        else
            theta = arctan(2 * A(p, q) / (A(q, q) - A(p, p)));
        end
        
        c = cos(theta);
        s = sin(theta);
        
        for j = 1 : n
            if j ~= p && j ~= q
                u = A(p, j) * c - A(q, j) * s;
                v = A(p, j) * s + A(q, j) * c;
                A(p, j) = u;
                A(q, j) = v;
                A(j, p) = u;
                A(j, q) = v;
            end
        end
        
        u = c^2 * A(p, p) - 2 * c * s * A(p, q) + s^2 * A(q, q);
        v = s^2 * A(p, p) + 2 * c * s * A(p, q) + c^2 * A(q, q);
        
        A(p, p) = u;
        A(q, q) = v;
        A(p, q) = 0;
        A(q, p) = 0;
    end
    
    lambda = diag(A);
end