%% Rezultate.
% 1. -
% 2. 10
% 3. -
% 4. 5/10
% 5, 6, 7 -> 0
% Total: 15/70 i.e. ~2.5/10 :( 

%% Exercitiul 2

A = [1 1 0; 1 0 1; 0 1 1];
b = [1; 2; 5];

[Q, R, x] = MetGivens(A, b);
disp(Q);
disp(R);
disp(x);

%% Exercitiul 3 (Ex. 4 in fapt)-> Metoda 'itereaza' la Inf
A = [3 1 1; 1 3 1; 1 1 3];
epsilon = 10^(-4);

[alpha] = MetJacobiAprox(A, epsilon);
disp(alpha);

%% functii

% Am aplicat metoda Givens din curs
function [Q, R, x] = MetGivens(A, b)
    n = length(A);
    Q = eye(n);
    for i = 1 : n
        for j = i + 1 : n
            o = sqrt(A(i, i)^2 + A(j, i)^2);
            c = A(i, i) / o;
            s = A(j ,i) / o;
            for l = 1 : n
                u = c * A(i, l) + s * A(j, l);
                v = -s * A(i, l) + c * A(j, l);
                A(i, l) = u;
                A(j, l) = v;
                u = c * Q(i, l);
                v = -s * Q(i, l) + c * Q(j, l);
                Q(i, l) = u;
                Q(j, l) = v;
            end
            u = c * b(i) + s * b(j);
            v = -s * b(i) + c * b(j);
            b(i) = u;
            b(j) = v;
        end
    end
    R = A;
    Q = Q';
    x = SubsDesc(R, b);
end

function [x] = SubsDesc(A, b)
    n = length(A);
    x(n) = 1/A(n, n) * b(n);
    k = n - 1;
    while k > 0
        suma = 0;
        for j = k + 1:n
            suma = suma + A (k, j)*x(j);
        end
        x(k) = 1/A(k,k) * (b(k)-suma);
        k = k - 1;
    end
end

% Am aplicat metoda Jacobi de aproximare din curs
% Este o problema la calcularea modulului matricii A

function [alpha] =  MetJacobiAprox(A, epsilon)
    max = -1;
    n = length(A);
    modulA = 0;
    for i = 1 : n
        for j = 1 : n
            if i ~= j
                modulA = modulA + sqrt(A(i, j).^2);
            end
        end
    end
    while modulA >= epsilon
        for i = 1 : n
            for j = 1 : n
                if abs(A(i, j)) > max
                    max = abs(A(i, j));
                    p = i;
                    q = j;
                end
            end
        end
        if A(p, p) == A(q, q)
            o = pi/4;
        else
            o = 1/2 * atan((2 * A(p, q)) / (A(q, q) - A(p, p)));
        end
        c = cos(o);
        s = sin(o);
        for j = 1 : n
            if j ~= p && j ~= q
                u = A(p, j) * c - A(q, j) * s;
                v = A(p, j) * s + A(1, j) * c;
                A(p, j) = u;
                A(q, j) = v;
                A(j, p) = u;
                A(j, q) = v;
            end
        end
        u = c^2 * A(p, p) - 2*c*s*A(p, q) + s^2 * A(q, q);
        v = s^2 * A(p, p) + 2*c*s*A(p, q) + c^2 * A(q, q);
        A(p, p) = u;
        A(q, q) = v;
        A(p, q) = 0;
        A(q, p) = 0;
        for i = 1 : n
            for j = 1 : n
                if i ~= j
                    modulA = modulA + sqrt(A(i, j)^2);
                end
            end
        end
    end
    for i = 1 : n
        alpha(i) = A(i, i);
    end
end
