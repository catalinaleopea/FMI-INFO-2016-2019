% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 4
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

%%
% Ex. 2
% Rezolv exercitiul 2 apeland MetGivens pentu matricea A si vectorul b
% de la Ex. 1
A = [1 1 0;1 0 1;0 1 1];
b = [1;2;5];
[Q,R,x] = MetGivens(A,b);
%%

%%
% Ex. 4
% Rezolv exercitiul 4 apeland MetJacobi pentru matricea A de la Ex. 3 si
% epsilon = 10^(-4)
A1 = [3 1 1;1 3 1;1 1 3];
% A2 = [17 -2 3*sqrt(3);-2 8 2*sqrt(3);3*sqrt(3) 2*sqrt(3) 11];
epsilon = 10^(-4);
[lambda] = MetJacobi(A1,epsilon);
%%

%%
% Metoda Givens
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'Q' = martice ortogonala
% 'R' = matrice
% 'x' = solutia sistemului Ax = b, obtinuta prin metoda Givens 
% -------------------------------------------------------------------------
function [Q,R,x] = MetGivens(A,b)
    n1 = size(A);
    n = n1(1);
    Q = eye(n);
    
    for i =1:n
        for j =i+1:n
            sigma  = sqrt((A(i,i))^2+(A(j,i))^2);
            c = A(i,i)/sigma;
            s = A(j,i)/sigma;
            for l = 1:n
                u = c*A(i,l) +s*A(j,l);
                v = (-s)*A(i,l) +c*A(j,l);
                A(i,l) = u;
                A(j,l) = v;
                u = c*Q(i,l) +s*Q(j,l);
                v = (-s)*Q(i,l) +c*Q(j,l);
                Q(i,l) = u;
                Q(j,l) = v;
            end
             u = c*b(i) +s*b(j);
             v = (-s)*b(i) +c*b(j);
             b(i) = u;
             b(j) = v;
        end
    end
    R = A;
    Q = Q';
    x = SubsDesc(R,b);
end

%%


%%
% Metoda Jacobi
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matrice simetrica
% 'epsilon' = un scalar
% -------------------------------------------------------------------------
% Date de iesire:
% 'lambda' = vectorul valorilor proprii ale matricei A
% -------------------------------------------------------------------------
function [lambda] = MetJacobi(A,epsilon)
    n1 = size(A);
    n = n1(1);
    B = zeros(n);
    while Mod(A) >= epsilon
        for i =1:n
            for j = i+1:n
                B(i,j) = A(i,j);
            end
        end
        [p, q] = find(abs(B)==max(max(abs(B))));
        p = p(1);
        q = q(1);
        if A(p,q) == A(q,q)
            teta = pi/4;
        else
            teta = 1/2 *atan(2*A(p,q)/(A(q,q)-A(p,p)));
        end
        c = cos(teta);
        s = sin(teta);
        for j =1:n
            if (j ~= p) & (j ~= q)
                u = A(p,j)*c -A(q,j)*s;
                v = A(p,j)*s +A(q,j)*c;
                A(p,j) = u;
                A(q,j) = v;
                A(j,p) = u;
                A(j,q) = v;
            end
        end
        u = (c^2)*A(p,p) -2*c*s*A(p,q)+(s^2)*A(q,q);
        v = (s^2)*A(p,p) +2*c*s*A(p,q)+(c^2)*A(q,q);
        A(p,p) = u;
        A(q,q) = v;
        A(p,q) = 0;
        A(q,p) = 0;
    end
    for i =1:n
        lambda(i) = A(i,i);
    end
    lambda = lambda';
end
%%

%%
% fumctie construita pentru a putea calcula modulul matricei A, asa cum 
% este descris in Cursul#4 la pagina 7
% |A| = sqrt(suma(aij^2)), i,j=1:n si i!=j
% functia este folosita in MetJacobi
function [s] = Mod(A)
    n1 = size(A);
    n = n1(1);
    s = 0;
    for i = 1:n
        for j = 1:n
            if i ~= j
                s = s +(A(i,j))^2;
            end
        end
    end
    s = sqrt(s);
end
%%

% Mai jos am pus functiile implementate in laboratoarele anterioare si pe
% care le-am folosit
%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b
% -------------------------------------------------------------------------

function [x] = SubsDesc(A, b)
    n1 = size(A);
    n = n1(1); %numarul de linii al matricei A
    x(n) = (1/A(n,n)) *b(n);
    k = n - 1;
    while k > 0
        % Suma(k,A,x) este o functie construita petru a calcula suma de la
        % j=k+1 pana la n din akj*xj
        x(k) = (1/A(k,k)) *(b(k) -Suma(k,A,x)); 
        k = k - 1;
    end
    x = x';
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'k' = indicele unei pozitii in matrice
% 'A' = o matrice
% 'x' = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 's' = suma de la i=k+1 pana la n din Aki*xi
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

%functie creata pentru a putea construi met SubsDesc
function s = Suma(k, A, x)
    n = size(A);
    s = 0;
    for i = k+1:n
        s = s + A(k,i) *x(i);
    end
end
%%
