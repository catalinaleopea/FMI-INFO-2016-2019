% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea formata din coeficientii necunoscutelor din sistem
% 'b'       = un vector format din valorile de dupa egal
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = solutia sistemlui, Ax = b
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [x] = SubsDesc(A, b)
  % lungimea vectorului b ca sa stiu cate iteratii trebuie sa fac
  n = length(b);

  % initializez pe xn
  x(n) = b(n) / A(n, n);
  
  % iterez de la n la 1 ca sa aplic ecuatia descris de algoritm
  k = n - 1;
  while k > 0
    % initializez suma cu 0
    sum = 0;
    
    % caculez suma de la j = k + 1 la n de A(k,j) * x(j)
    for j = k + 1 : n
      sum = sum + A(k,j) * x(j);
    end % end for

    % calculez xk ca fiind (1 / Akk) * (bk - suma de la j = k + 1 la n de
    % A(k,j) * x(j))
    x(k) = 1 / A(k,k) * (b(k) - sum);

    % decrementez pe k pentru a trece la urmatorul element
    k = k - 1;
  end % end while
end % end function
