% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% 1. Apelez metoda Givens pentru exercitiul 1
% 2. Apelez metoda Jacobi pentru exercitiul 3
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================
% Sa pui exercitiile cu sectiuni de acum inainte
% 1. -
% 2. 10
% 3. -
% 4. 10
% 5, 6, 7 -> 0
% Total: 20/70 i.e. ~3/10

%% exercitiul 1 (adica ex.2.)
% initializez A cu matricea A de la exercitiul 1
A = [1, 1, 0; 1, 0, 1; 0, 1, 1];
% initializez b cu b-ul de la exercitiul 1
b = [1, 2, 5];

fprintf('Metoda Givens pentru:\n');
A
b
fprintf('\n');

% apelez metoda Givens
[Q, R, x] = MetodaGivens(A, b);

% afisez output-ul
Q
R
x

%% exercitiul 2 (adica ex.4.)
A = [3, 1, 1; 1, 3, 1; 1, 1, 3];
epsilon = 1e-4;

fprintf('Metoda Jacobi pentru:\n');
A
fprintf('\n');

lambda = MetodaJacobi(A, epsilon);

lambda
