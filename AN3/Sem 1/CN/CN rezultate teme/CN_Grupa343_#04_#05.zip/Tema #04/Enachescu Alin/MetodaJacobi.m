% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = o matrice simetrica
% 'epsilon' = eroarea maxima
% -------------------------------------------------------------------------
% Date de iesire:
% 'lambda'  = valorile proprii ale matricei A
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [lambda] = MetodaJacobi(A, epsilon)
  n = size(A, 1);
  
  % initializez lambda cu zerouri
  lambda(1) = 0;
  
  % iteratiile algoritmului
  while true
    finish = true;
    for i = 1 : n
      for j = 1 : n
        if i != j && A(i, j) >= epsilon
          finish = false;
          break;
        end %end if
      end % end for
    end % end for

    if finish == true
      break;
    end % end if
    
    % calculez max Aij unde 1 <= i < j <= n
    p = 1;
    q = 2;
    tmpMax = A(1, 2);
    for i = 1 : n
      for j = i + 1 : n
        if A(i, j) > tmpMax
          p = i;
          q = j;
          tmpMax = A(i, j);
        end % end if
      end % end for
    end % end for
    
    t = 0;
    if A(p, p) == A(q, q)
      t = pi / 4;
    else
      t = 0.5 * atan((2 * A(p, q)) / (A(q, q) - A(p, p)));
    end % end if
    
    c = cos(t);
    s = sin(t);
    
    for j = 1 : n
      if j != p && j != q
        u = A(p, j) * c - A(q, j) * s;
        v = A(p, j) * s + A(q, j) * c;
        A(p, j) = u;
        A(q, j) = v;
        A(j, p) = u;
        A(j, q) = v;
      end % end if
    end % end for
    
  u = (c ^ 2) * A(p, p) - 2 * c * s * A(p, q) + (s ^ 2) * A(q, q);
  v = (s ^ 2) * A(p, p) + 2 * c * s * A(p, q) + (c ^ 2) * A(q, q);
  A(p, p) = u;
  A(q, q) = v;
  A(p, q) = 0;
  A(q, p) = 0;

  end % end while

  % copiez diagonala principala din A in vectorul lambda
  for i = 1 : n
    lambda(i) = A(i, i);
  end % end for
end % end function
