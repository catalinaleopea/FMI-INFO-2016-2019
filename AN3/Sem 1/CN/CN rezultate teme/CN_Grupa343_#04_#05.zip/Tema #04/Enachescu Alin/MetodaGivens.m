% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea formata din coeficientii necunoscutelor din sistem
% 'b'       = un vector format din valorile de dupa egal
% -------------------------------------------------------------------------
% Date de iesire:
% 'Q'    = matricea ortogonala
% 'R'    = matricea superior triunghiulara
% 'x'    = solutia sistemului, Ax = b
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [Q, R, x] = MetodaGivens(A, b)
  n = size(A, 1);

  % initializez pe Q cu In
  Q = eye(n);

  % initializez pe R si x cu zerouri
  R = zeros(n);
  x = zeros(size(b));
  
  for i = 1 : n
    for j = i + 1 : n
      % calculez sigma ca fiind radical din suma patratelor lui Aii si Aji
      sigma = sqrt(A(i, i) ^ 2 + A(j, i) ^ 2);
      
      % calculez pe c ca fiind raportul dintre Aii si sigma
      c = A(i, i) / sigma;
      
      % calculez pe s ca fiind raportul dintre Aji si sigma
      s = A(j, i) / sigma;
      
      for l = 1 : n
        % updatez pe A(i, l) si A(j, l) asa cum e descris in algoritm
        u = c * A(i, l) + s * A(j, l);
        v = -s * A(i, l) + c * A(j, l);
        A(i, l) = u;
        A(j, l) = v;
        
        % updatez pe Q(i, l) si Q(j, l) asa cum e descris in algoritm
        u = c * Q(i, l) + s * Q(j, l);
        v = -s * Q(i, l) + c * Q(j, l);
        Q(i, l) = u;
        Q(j, l) = v;
      end % end for
      
      % updatez pe bi si bj cum e descris in algoritm
      u = c * b(i) + s * b(j);
      v = -s * b(i) + c * b(j);
      b(i) = u;
      b(j) = v;
      
    end % end for
  end % end for
  
  R = A;
  Q = transpose(Q);
  
  x = SubsDesc(R, b);

end % end function
