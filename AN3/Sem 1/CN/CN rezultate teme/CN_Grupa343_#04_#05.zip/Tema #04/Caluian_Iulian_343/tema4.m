% Tema 4 - Caluian Iulian 343 - CN - 2018
% 1. -
% 2. 10
% 3. -
% 4. 10
% 5, 6, 7 -> 0
% Total: 20/70 i.e. ~3/10

%% Ex 2 -> Apelai pentru datele A1, B1. Mai multa atentie data viitoare! 
A1 = [1 2 0;
    0 1 1;
    1 0 1];
b1 = [1 1 0];

A = [1 1 0;
     1 0 1;
     0 1 1];
b = [1 2 5];

[Q,R,x] = metGivens(A,b);
Q
R
x

%% Ex 4

A = [ 3 1 1 ;
      1 3 1;
      1 1 3];
  
  A2 = [17 -2 3*sqrt(3);
      -2 8 2 * sqrt(3);
      3*sqrt(3) 2*sqrt(3) 11];

epsi = 10^(-4);

lam = metJacobi(A,epsi);

lam



%%
function [Q,R,x] = metGivens(A,b)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[~,n] = size(A);
Q = eye(n);
for i = 1:n
    for j = i+1:n
        sig = sqrt(A(i,i)^2 + A(j,i)^2);
        c = A(i,i)/sig;
        s = A(j,i)/sig;
        for l = 1:n 
            u = c*A(i,l) + s*A(j,l);
            v = -s*A(i,l) + c*A(j,l);
            A(i,l) = u;
            A(j,l) = v;
            u = c*Q(i,l) + s*Q(j,l);
            v = -s*Q(i,l) + c*Q(j,l);
            Q(i,l) = u;
            Q(j,l) = v;
        end
        u = c*b(i) + s*b(j);
        v = -s*b(i) + c*b(j);
        b(i) = u;
        b(j) = v;
    end
end
R = A;
Q = Q';
x = SubsDesc(R,b);
end


function h = metJacobi(A,epsi)
[~,n] = size(A);
h = zeros(n,1);

toleranta = 0;
for i = 1:n
    for j = 1:n
        if i ~= j
            toleranta = toleranta + A(i,j)*A(i,j);
        end
    end
end


while toleranta >= epsi
    p = 1;
    q = 2;
    for i = 1:n
        for j = i+1:n
            if abs(A(i,j)) > abs(A(p,q))
                p = i;
                q = j;
            end
        end
    end
    
    
    if A(p,p) == A(q,q)
        th = pi/4;
    else
        th = 1/2 * atan(2 * A(p,q) / (A(q,q) - A(p,p) ) );
    end
    c = cos(th);
    s = sin(th);
    for j = 1:n
        if j ~=p && j~= q
            u = A(p,j)*c - A(q,j)*s;
            v = A(p,j)*s + A(q,j)*c;
            A(p,j) = u;
            A(q,j) = v;
            A(j,p) = u;
            A(j,q) = v;
        end
    end
    u = c*c*A(p,p) - 2*c*s*A(p,q) + s*s*A(q,q);
    v = s*s*A(p,p) + 2*c*s*A(p,q) + c*c*A(q,q);
    A(p,p) = u;
    A(q,q) = v;
    A(p,q) = 0;
    A(q,p) = 0;

    
    toleranta = 0;
    for i = 1:n
        for j = 1:n
            if i ~= j
                toleranta = toleranta + A(i,j)*A(i,j);
            end
        end
    end 
end

for i = 1:n
    h(i) = A(i,i);
end

end


