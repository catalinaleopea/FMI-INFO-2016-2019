%  Lina Cristian 343 - Tema 4
% 1. 10
% 2. 10
% 3. 4 -> Nu l-ai terminat
% 4. 10
% Restul -> 0
% Total: 34/70 i.e. ~5/10


%% Exercitiul 2
A = [1 1 0; 1 0 1; 0 1 1];
b = [1; 2; 5];
[Q, R, x] = MetGivens(A, b);
disp(Q); disp(R); disp(x);

%% Exercitiul 4
A = [3 1 1; 1 3 1; 1 1 3]; epsilon = 10^(-4);
[lmd] = MetJacobi(A, epsilon);
disp(lmd);

%% Functii
function [Q,R,x] = MetGivens(A,b)
    n = length(A); Q = eye(n);
    for i = 1:n 
        for j = i+1:n
            t = sqrt(A(i,i).^2 + A(j,i).^2);
            c = A(i,i)/t; s = A(j,i)/t;
            for l = 1:n
                u = c*A(i,l) + s*A(j,l);
                v = (-1)*s*A(i,l) + c*A(j,l);
                %fprintf('u1 = %.2f ; v1 = %.2f \n',u,v);
                A(i,l) = u; A(j,l) = v;
                u = c*Q(i,l) + s*Q(j,l);
                v = (-1)*s*Q(i,l) + c*Q(j,l);
                %fprintf('u2 = %.2f ; v2 = %.2f \n',u,v);
                Q(i,l) = u; Q(j,l) = v;
                %fprintf('sigma = %.2f ; c = %.2f ; s = %.2f; \n',t,c,s);
                %fprintf('i = %d ; j = %d; l = %d \n',i,j,l);
                %disp(A); disp(Q);
            end
            u = c*b(i) + s*b(j);
            v = (-1)*s*b(i) + c*b(j);
            %fprintf('u3 = %.2f ; v3 = %.2f \n',u,v);
            b(i) = u; b(j) = v;
            %disp(b);
        end
    end
    R = A; Q = Q';
    disp(b);
    x = SubsDesc(R,b);
end

function [x] = SubsDesc(A,b)
    % avem matricea superior triunghiulara a cu solutiile b
    n = length(A);
    x = zeros(n,1);
    % calculam xn
    x(n) = 1/A(n,n)*b(n);
    k = n - 1;
    % continua algoritmul ca cel descris in curs
    while(k>0)
       sum = 0;
       for j = k+1 : n
           sum = sum + A(k,j)*x(j);
       end
       x(k) = 1/A(k,k)*(b(k)-sum);
       k = k - 1;
    end
end

function [modA] = ModA(A)
    modA = 0; n = length(A);
    for i = 1:n      
        for j = 1:n     
            if(i~=j)       
                modA = modA + A(i,j)*A(i,j);      
            end
        end
    end
end

function [lmd] = MetJacobi(A, epsilon)
    n = length(A); 
    lmd = zeros(n,1);
    % calculam modulul matricei
    modA = ModA(A);
    while modA >= epsilon
       maxim = 0;
       for i = 1:n-1
          for j = i+1:n
              if abs(A(i,j)) > maxim
                  maxim = abs(A(i,j));
                  p = i; q = j;
              end
          end
       end
       if (A(p,p) == A(q,q))
           t = pi/4;
       else
           t = 1/2 * atan(2 * A(p,q) / (A(q,q) - A(p,p)));
       end
       c = cos(t); s = sin(t);
       for j = 1:n
           if (j~=p && j~=q)
              u = A(p,j)*c-A(q,j)*s;
              v = A(p,j)*s+A(q,j)*c;
              A(p,j) = u; A(q,j) = v; A(j,p) = u; A(j,q) = v;
           end
       end
       u = c.^2*A(p,p) - 2*c*s*A(p,q) + s.^2*A(q,q);
       v = s.^2*A(p,p) + 2*c*s*A(p,q) + c.^2*A(q,q);
       A(p,p) = u; A(q,q) = v; A(p,q) = 0; A(q,p) = 0;
       modA = ModA(A);
    end
    for i = 1:n
        lmd(i) = A(i,i);
    end
end

