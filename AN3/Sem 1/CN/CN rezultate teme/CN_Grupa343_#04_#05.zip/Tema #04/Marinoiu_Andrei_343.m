% Tema 4 Marinoiu Andrei Gr. 343
% 2. 10
% 4. 10
% Restul -> 0
% Total: 20/70 i.e. ~3/10
% Sa pui exercitiile cu sectiuni de acum inainte, te rog.
function Marinoiu_Andrei_343()

% Exercitiul 2
% Initializam datele conform enuntului
A = [1 1 0;1 0 1;0 1 1];
b = [1 2 5];

[Q,R,x] = MetGivens(A,b'); % Apelam functia specifica metodei Givens

% Afisam rezultatul
disp(Q);
disp(R);
disp(x);

% Exercitiul 4
% Initializam datele conform enuntului
B = [3 1 1;1 3 1;1 1 3];
epsilon = 10^(-4);

lambda = MetJacobi(B,epsilon); % Apelam functia specifica metodei Jacobi

% Afisam rezultatul
disp(lambda);

end

% Functie pentru a calcula modulul pentru o matrice

% Date de intrare :
% A -> matrice

% Date de iesire :
% sum -> suma rezultata
function [sum] = ModulMatrice(A)

sum = 0; % Initializam suma cu 0

% Parcurgem toate elementele din matrice
for i = 1:length(A)
    for j = 1:length(A)
        if(i ~= j) % Verificam daca indicii sunt diferiti
            sum = sum + A(i,j)^2; % Formam suma conform definitiei
        end
    end
end

sum = sqrt(sum); % Aplicam radical inainte de a returna solutia

end

% Functie specifica metodei Jacobi de aprox. a valorilor proprii

% Date de intrare :
% A -> matrice
% epsilon -> toleranta

% Date de iesire :
% lambda -> vector ce contine valorile proprii

% Algoritmul este implementat dupa pseudocodul aflat in cursul 4,pagina 28.
function [lambda] = MetJacobi(A,epsilon)

lambda = zeros(1,length(A)); % Initializam vectorul de valori cu 0
sum = ModulMatrice(A); % Calculam modulul initial pentru matrice

% Iteratiile algoritmului
while(sum > epsilon)
    p = 1;
    q = 2;
    
    for i = 1:length(A)
        for j = i+1:length(A)
            if(abs(A(i,j)) > abs(A(p,q)))
                p = i;
                q = j;
            end
        end
    end
    
    if(A(p,p) == A(q,q))
        theta = pi/4;
    else
        theta = atan((2*A(p,q)) / (A(q,q) - A(p,p)))/2;
    end
    
    c = cos(theta);
    s = sin(theta);
    
    for j = 1:length(A)
        if(j ~= p && j~= q)
            u = A(p,j) * c - A(q,j) * s;
            v = A(p,j) * s + A(q,j) * c;
            A(p,j) = u;
            A(q,j) = v;
            A(j,p) = u;
            A(j,q) = v;
        end
    end
    
    u = (c^2) * A(p,p) - 2 * c * s * A(p,q) + (s^2) * A(q,q);
    v = (s^2) * A(p,p) + 2 * c * s * A(p,q) + (c^2) * A(q,q);
    A(p,p) = u;
    A(q,q) = v;
    A(p,q) = 0;
    A(q,p) = 0;
    sum = ModulMatrice(A);
end

% Parcurgem diagonala principala pentru a retine valorile proprii
for i = 1:length(A)
    lambda(i) = A(i,i);
end

end

% Functie specifica metodei Givens

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% Q -> matricea ortogonala
% R -> matricea de rotatie
% x -> solutia

% Algoritmul este implementat dupa pseudocodul aflat in cursul 4,pagina 18.
function [Q,R,x] = MetGivens(A,b)

Q = eye(length(A)); % Initializam matricea ortogonala cu matricea 
%identitate

% Iteratiile algrotimului
for i = 1:length(A)
    for j = i + 1:length(A)
        sigma = sqrt(A(i,i)^2 + A(j,i)^2);
        c = A(i,i) / sigma;
        s = A(j,i) / sigma;
        
        for l = 1:length(A)
            u = c * A(i,l) + s * A(j,l);
            v = (-s) * A(i,l) + c * A(j,l);
            A(i,l) = u;
            A(j,l) = v;
            u = c * Q(i,l) + s * Q(j,l);
            v = (-s) * Q(i,l) + c * Q(j,l);
            Q(i,l) = u;
            Q(j,l) = v;
        end
        
        u = c * b(i,1) + s * b(j,1);
        v = (-s) * b(i,1) + c * b(j,1);
        b(i,1) = u;
        b(j,1) = v;
    end
end

R = A;
Q = Q'; % Calculam transpusa pentru matricea ortogonala
x = SubsDesc(R,b); % Apelam metoda substitutiei descendente

end

% Functie specifica metodei substitutiei descendente

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% x -> solutiile sistemului

% Algoritmul este implementat dupa pseudocodul aflat in cursul 2,pagina 4.
function [x] = SubsDesc(A,b)

x = zeros(length(A),1); % Initializam matricea de 3 linii si o coloana cu 0
x(length(A)) = b(length(A)) / A(length(A),length(A)); % Aflam x(n) conform
%definitiei
k = length(A) - 1; % Initializare k

% Iteratiile algoritmului
while(k > 0)
    sum = 0;
    
    for j = k + 1:length(A)
        sum = sum + A(k,j) * x(j);
    end
    
    x(k) = (b(k) - sum) / A(k,k);
    k = k - 1;
end
  
end