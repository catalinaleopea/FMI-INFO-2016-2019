function [AT] = transpMat(A)

[n,~]=size(A);
AT = zeros(n);

for i=1:n
    AT(i,:) = A(:,i);
end
end

