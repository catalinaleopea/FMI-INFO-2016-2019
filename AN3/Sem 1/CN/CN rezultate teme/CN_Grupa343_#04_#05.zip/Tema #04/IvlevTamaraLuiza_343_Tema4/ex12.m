%%Exercititul 1 & 2
% Exercitiul 1 trebuia facut manual.
% Apreciez ca ai creat o functie care transpune o matrice,  insa in matlab
% este suficient sa pui un apostrof dupa matrice si face acelasi lucru.
% Exemplu Atranspusa = A'
clear;

A = [1 1 0;
     1 0 1;
     0 1 1]; %Initierea matricei A
b = [1 2 5]; %Initiere vector B

% Atunci cand apelezi o functie, trebuie sa te asiguri ca intorci la
% rezultate toate valorile. Asa cum ai apelat tu, intoarce doar prima
% valoare din functie. Ar fi trebuit sa o apelezi asa:
% [Q,R,x] = descompunereQR(A,b)
% disp(Q)
% disp(R)
% disp(x)
% Bineinteles cu mesaje la consola inainte de fiecare afisare
Solutie = descompunereQR(A,b);
disp(Solutie);

Solutie2 = metGivens(A,b);
disp(Solutie2);