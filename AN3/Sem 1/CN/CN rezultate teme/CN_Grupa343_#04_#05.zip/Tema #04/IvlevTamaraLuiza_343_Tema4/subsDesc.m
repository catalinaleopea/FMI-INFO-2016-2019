function [x] = subsDesc(A,b) %A este o matrice, b un vector, iar x solutia

%Metoda substitutiei descendente (curs 2)
[n,~]=size(A);

x(n) = 1/A(n,n) * b(n);
k = n-1;

while k > 0
    nec1 = 0;
    for j = k+1:n
        nec1 = nec1 + A(k,j)*x(j);
    end
    x(k) = 1/A(k,k) * (b(k) - nec1);
    k = k-1;
end

end

