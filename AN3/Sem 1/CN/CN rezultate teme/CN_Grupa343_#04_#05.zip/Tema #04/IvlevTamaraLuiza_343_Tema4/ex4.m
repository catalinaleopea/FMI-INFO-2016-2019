%Rezolvarea exercitiului 4
% Rezultatele intoarse nu sunt bune din pacate.
% 2. 6
% 4. 5
% Restul -> 0
% Total: 11/70 i.e. ~2/10
clear;

A = [3 1 1;
     1 3 1;
     1 1 3]; %Initierea matricei A

Solutie = metJacobi(A,10^-4);
disp(Solutie);