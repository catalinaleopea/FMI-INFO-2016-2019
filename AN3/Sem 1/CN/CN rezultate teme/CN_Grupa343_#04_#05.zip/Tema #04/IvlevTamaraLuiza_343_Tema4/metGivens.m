function [Q,R,x] = metGivens(A,b) %unde Q,R,A matrici
                                  %iar b, x vectori
                                  
%Metoda Givens implementata dupa algoritmul din curs

[n,~]=size(A);

Q = eye(n);

for i = 1:n
    for j = i+1:n
        sigma = sqrt(A(i,i)*A(i,i) + A(j,i)*A(j,i));
        c = A(i,i) / sigma;
        s = A(j,i) / sigma;
        
        for l = 1:n
            u = c*A(i,l) + s*A(j,l);
            v = (-1)*s*A(i,l) + c*A(j,l);
            A(i,l) = u;
            A(j,l) = v;
            u = c*Q(i,l) + s*Q(j,l);
            v = (-1)*s*Q(i,l) + c*Q(j,l);
            Q(i,l) = u;
            Q(j,l) = v;
        end
        
        u = c*b(i) + s*b(j);
        v = (-1)*s*b(i) + c*b(j);
        b(i) = u;
        b(j) = v;
    end
end
R = A;
Q = transpMat(Q);
x = subsDesc(R,b);
end

