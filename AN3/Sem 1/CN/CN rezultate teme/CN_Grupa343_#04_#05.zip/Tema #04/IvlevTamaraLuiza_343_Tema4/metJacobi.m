function [lambda] = metJacobi(A,Epsilon)

%Metoda Jacobi implementata dupa algoritmul din cursul 4
%aproximare a valorilor proprii

[n,~]=size(A);
lambda = zeros(1,n);

modMat = modulMatrice(A);

while modMat >= Epsilon
    nrmax = A(1,1);
    p = 1;
    q = 1;
    for i = 1:n
        for j = i:n
            if ( abs(A(i,j)) > abs(nrmax))
                p = i;
                q = j;
                nrmax = A(i,j);
            end
        end
    end
    
    if ( A(p,p) == A(q,q) )
        theta = pi / 4;
    else
        theta = 1/2 * atan (2*A(p,q)/(A(q,q)-A(p,p)));
    end
    
    c = cos(theta);
    s = sin(theta);
    
    for j = 1:n
        if j ~= p && j~=q
            u = A(p,j)*c - A(q,j)*s;
            v = A(p,j)*s + A(q,j)*c;
            A(p,j) = u;
            A(q,j) = v;
            A(j,p) = u;
            A(j,q) = v;
        end
    end
    
    u = c*c*A(p,p) - 2*c*s*A(p,q) + s*s*A(q,q);
    v = s*s*A(p,p) + 2*c*s*A(p,q) + c*c*A(q,q);
    A(p,p) = u;
    A(q,q) = v;
    A(p,q) = 0;
    A(q,p) = 0;

modMat = modulMatrice(A);
end

for i = 1:n
    lambda(i) = A(i,i);
end

end

function [modMat] = modulMatrice(Mat)
  
[m,~]=size(Mat);
suma = 0;
for i = 1:m
    for j = 1:m
        if( i ~= j)
            suma = suma + Mat(i,j)*Mat(i,j);
        end
    end
end
modMat = suma;
end

