function [Q,R,x] = descompunereQR(A,b) %unde Q,R,A matrici
                                       %iar b, x vectori
                                       
%functia de descompunere QR, implementata dupa pseudocodul din curs
[n,~]=size(A);
Q = zeros(n);

nec = 0;
for i = 1:n
    nec = nec + A(i,1)*A(i,1);
end
R(1,1) = sqrt (nec);

for i = 1:n
    Q(i,1) = A(i,1) / R(1,1);
end

for j = 2:n
    var0 = 0;
    for s = 1:n
        var0 = var0 + Q(s,1)*A(s,j);
    end
    R(1,j) = var0;
end

for k = 2:n
    var1 = 0;
    for i = 1:n
        var1 = var1 + A(i,k)*A(i,k);
    end
    
    var2 = 0;
    for s = 1:k-1
        var2 = var2 + R(s,k)*R(s,k);
    end
    R(k,k) = sqrt(var1 - var2);

    for i = 1:n
        var3 = 0;
        for s = 1:k-1
            var3 = var3 + Q(i,s)*R(s,k);
        end
    Q(i,k) = 1/R(k,k) * (A(i,k) - var3);
    end
    
    for j = k+1:n
        var4 = 0;
        for s=1:n
            var4 = var4 + Q(s,k)*A(s,j);
        end
    R(k,j) = var4;
    end
    
end

QT = transpMat(Q);
x = subsDesc(R,QT.*b);
end


