% Sa pui exercitiile cu sectiuni de acum (i.e. cu %% )
% 1 -> 5. ai 10
% 6, 7 -> 0
% Total: 50/70 i.e. ~7,2/10

%%Givens 

A=[1 1 0;
1 0 1;
0 1 1];
B=[1 2 5] ;
[Q,R,X]=Givens(A,B) 


% A=[3 1 1;
% 1 3 1;
% 1 1 3];
% e=10^(-4);
% L=Jacobi(A,e)

function [Q,R,X]=Givens(A,B) 
[m,n]=size(A); 
Q=eye(m); 
for i=1:m 
    for j=i+1:m 
        o=sqrt(A(i,i)*A(i,i)+A(j,i)*A(j,i));
        c=A(i,i)/o; 
        s=A(j,i)/o; 
        for l=1:n 
            u=c*A(i,l)+s*A(j,l); 
            v=(-s)*A(i,l)+c*A(j,l); 
            A(i,l)=u; 
            A(j,l)=v; 
            u=c*Q(i,l)+s*Q(j,l); 
            v=(-s)*Q(i,l)+c*Q(j,l); 
            Q(i,l)=u; 
            Q(j,l)=v; 
        end 
        u=c*B(i)+s*B(j); 
        v=(-s)*B(i)+c*B(j); 
        B(i)=u; 
        B(j)=v; 
    end
end
R=A; 
Q=transpose(Q); 
X=SubsDesc(R,B); 
end 

function [L]=Jacobi(A,e) 
[m,n]=size(A);
while ModulMatrice(A)>=e  
    max=-1; 
    p=0; 
    q=0;
    for i=1:m-1  
        for j=i+1:m 
            if abs(A(i,j))>max 
                p=i;q=j;max=abs(A(i,j)); 
            end
        end
    end
    if(A(p,p)==A(q,q)) 
        o=pi/4; 
    else 
        o=1/2*atan(2*A(p,q)/(A(q,q)-A(p,p))); 
    end 
    c=cos(o); 
    s=sin(o); 
    for j=1:m 
        if j~=p && j~=q 
            u=A(p,j)*c-A(q,j)*s; 
            v=A(p,j)*s+A(q,j)*c; 
            A(p,j)=u; 
            A(q,j)=v; 
            A(j,p)=u; 
            A(j,q)=v; 
        end 
    end 
    u=c*c*A(p,p)-2*c*s*A(p,q)+s*s*A(q,q);  
    v=s*s*A(p,p)+2*c*s*A(p,q)+c*c*A(q,q);
    A(p,p)=u; 
    A(q,q)=v; 
    A(p,q)=0; 
    A(q,p)=0; 
    
end   
for i=1:m
    L(i)=A(i,i);
end
end

function [M]=ModulMatrice(A)  
[m,n]=size(A);  
M=0;
for i=1:m 
    for j=1:m 
        if i~=j 
            M=M+A(i,j)*A(i,j); 
        end 
    end
end
M=sqrt(M);
end
