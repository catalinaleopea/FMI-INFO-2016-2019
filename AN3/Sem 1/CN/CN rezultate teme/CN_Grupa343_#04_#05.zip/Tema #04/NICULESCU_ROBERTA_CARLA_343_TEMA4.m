%%
%Exercitiul 2.
A = [1 1 0; 1 0 1; 0 1 1];
b = [1 2 5].';
[Q, R, x] = MetGivens(A, b);
disp('Factorizarea QR prin Metoda Givens:');
disp('Q: ');
disp(Q);
disp('R: ');
disp(R);
disp('Solutia x a sistemului: ');
disp(x);
%%

%%
%Exercitiul 4
A = [3 1 1; 1 3 1; 1 1 3];
epsilon = 10.^(-4);
[lambda] = MetJacobi(A, epsilon);
disp('Valorile proprii ale matricei A, folosind Jacobi: ');
disp(lambda);
%%


%Metoda Jacobi de aproximare a valorilor proprii
%primeste ca param o matrice A si eroarea de aproximare epsilon
%intoarce ca rezultat un vector-coloana cu valorile proprii aproximate cu
%epsilon
function [lambda] = MetJacobi(A, epsilon)
n = size(A,1); 
lambda = zeros(n,1);
%calculam modulul matricei A, conform formulei date in cursul 4
modulA = ModulMatrice(A);

while modulA >= epsilon
   maxim = 0;
   for lin = 1:n-1
      for col = lin+1:n
          if abs(A(lin, col)) > maxim
              maxim = abs(A(lin, col));
              p = lin;
              q = col;
          end
      end
   end
   
   if A(p, p) == A(q, q)
       theta = pi/4;
   else
       theta = 1/2 * atan(2 * A(p,q) / (A(q,q) - A(p,p)));
   end
   
   c = cos(theta);
   s = sin(theta);
   
   for jind = 1:n
       if jind~=p && jind~=q
          u = A(p,jind)*c-A(q,jind)*s;
          v = A(p,jind)*s+A(q,jind)*c;
          A(p,jind) = u;
          A(q,jind) = v;
          A(jind,p) = u;
          A(jind,q) = v;
       end
   end
   u = c.^2*A(p,p)-2*c*s*A(p,q)+s.^2*A(q,q);
   v = s.^2*A(p,p)+2*c*s*A(p,q)+c.^2*A(q,q);
   A(p,p) = u;
   A(q,q) = v;
   A(p,q) = 0;
   A(q,p) = 0;
   modulA = ModulMatrice(A);
end
for ind = 1:n
    lambda(ind) = A(ind,ind);
end
end

%functie care primeste ca parametru o matrice A si intoarce ca rezultat
%modulul sau, calculat conform formulei din cursul 4.
function m = ModulMatrice(A)    
suma = 0;   
n = size(A,1);  
for i = 1:n      
    for j = 1:n     
        if i~=j       
            suma = suma + A(i,j)*A(i,j);      
        end
    end
end
m = sqrt(suma); 
end


%Metoda Substitutiei Descendente - pt rezolvarea unui sistem de ecuatii
%superior-triunghiular
function [x] = SubsDesc(A,b)
    n = length(b); % calculez in n dimensiunea matricei patratice A, care este 
                   % egala cu dimensiunea vectorului b
    x(n) = (1/A(n,n)) * b(n); % sistemul se va rezolva conform algoritmului 
                              % de jos in sus; am calculat necunoscuta x(n)
    %parcurgem fiecare ecuatie de jos in sus, incepand cu penultima
    k = n-1; 
    
    while k>0 
        %calculam x(k) conform formulei din algoritm 
        S1 = 0;
        for ind = k+1:n
            S1 = S1 + A(k,ind)*x(ind);
        end
        x(k) = (1/A(k,k))*(b(k) - S1);
        k = k-1;
    end
end

%functie Exercitiu.2.
%Date de intrare: matricea A asociata sistemului de ecuatii liniare si 
                % vectorul-coloana b al termenilor liberi;
%Date de iesire: se returneaza factorizarea QR a matricei A prin metoda 
                % Givens si solutia x a sistemului de ecuatii; 
                %R = matrice superior-triunghiulara obtinuta din A prin
                   % aplicarea succesiva de rotatii Givens
                %Q = matrice ortogonala 
%------------------------------------------------------------------------
function [Q,R,x] = MetGivens(A,b)
n = size (A,1); %dimensiunea matricei patratice A
Q = eye(n); %initializare Q cu In
for lin = 1:n 
    for col = lin+1:n
        ipotenuza = sqrt(A(lin, lin).^2 + A(col, lin).^2);
        c = A(lin, lin) / ipotenuza; %calculam cos(theta)
        s = A(col, lin) / ipotenuza; %calculam sin(theta)
        for p = 1:n
            u = c*A(lin, p) + s*A(col, p);
            v = (-1)*s*A(lin, p) + c*A(col, p);
            A(lin, p) = u;
            A(col, p) = v;
            u = c*Q(lin, p) + s*Q(col, p);
            v = (-1)*s*Q(lin, p) + c*Q(col, p);
            Q(lin, p) = u;
            Q(col, p) = v;
        end
        u = c*b(lin) + s*b(col);
        v = (-1)*s*b(lin) + c*b(col);
        b(lin) = u;
        b(col) = v;
    end
end
R = A; 
Q = Q.';
x = SubsDesc(R,b);
end

%functie exercitiul 4
