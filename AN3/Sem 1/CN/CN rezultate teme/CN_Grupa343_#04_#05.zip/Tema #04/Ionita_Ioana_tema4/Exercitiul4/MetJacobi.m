% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului (simetrica si pozitiv definita)
% epsilon   = eroarea maxima dintre valorile proprii numerice si cele
% exacte
% -------------------------------------------------------------------------
% Date de iesire:
% 'lambda'    = vectorul valorilor proprii 
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ lambda ] = MetJacobi( A, epsilon )
n = size(A);
%calculez "modulul" matricei A (radical din suma patratelor elementelor
%care nu se afla pe diagonala principala)
modul = 0;
for i = 1:n 
    for j = 1:n
        if i ~= j
            modul = modul + A(i, j).^2;
        end
    end
end
modul = sqrt(modul);
while modul >= epsilon  %cat timp modulul este mai mare decat eroarea
    maxim = abs(A(1, 2));   %caut maximul in valoare absoluta 
    p = 1;                  %de sub diagonala principala
    q = 2;
    for i = 1:n
        for j = i+1:n
            if abs(A(i, j)) > maxim
                maxim = abs(A(i, j));
                p = i;
                q = j;
            end
        end
    end
    if A(p, p) == A(q, q)   %unghiul "teta" este pi/4 in acest caz
        teta = pi/4;
    else
        teta = 0.5 * atan(2*A(p, q)/(A(q, q) - A(p, p)));
    end
    % se calculeaza noua matrice A obtinuta in urma rotatiei (p, q)
    c = cos(teta);
    s = sin(teta);
    for j = 1:n
        if j ~=p && j~=q
            u = A(p, j) * c - A(q, j) * s;
            v = A(p, j) * s + A(q, j) * c;
            A(p, j) = u;
            A(q, j) = v;
            A(j, p) = u;
            A(j, q) = v;
        end
    end
    u = c.^2 * A(p, p) - 2*c*s*A(p, q) + s.^2*A(q, q);
    v = s.^2 * A(p, p) + 2*c*s*A(p, q) + c.^2 *A(q, q);
    A(p, p) = u;
    A(q, q) = v;
    A(p, q) = 0;
    A(q, p) = 0;
    %recalculez "modulul" lui A, pentru a vedea daca mai continui
    %iteratiile, sau am obtinut deja valorile proprii
    modul = 0;
    for i = 1:n 
        for j = 1:n
            if i ~= j
                modul = modul + A(i, j).^2;
            end
        end
    end
    modul = sqrt(modul);
end
for i=1:n
    lambda(i) = A(i, i); %valorile proprii se afla pe diagonala principala
                         %a matricei A
end

end

