% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Calculeaza descompunerea QR a matricei A, cat si solutia sistemului
% Ax = b, folosindu-se de cele 2 matrice calculate, Q si R
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
A = [1 1 0; 1 0 1; 0 1 1];  %matricea sistemului
b = [1; 2; 5];              %vectorul coloana
[Q, R, x] = MetGivens (A, b);