% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului 
% 'b'       = vector coloana reprezentand termenul din dreapta in cadrul
% sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = vectorul solutiilor sistemului
% 'Q'    = matrice ortogonala
% 'R'    = matrice superior triunghiulara (A = QR) 
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ Q, R, x ] = MetGivens( A, b )
n = length(b);      
Q = eye(n);     %initializez matricea ortogonala cu matricea identitate
for i = 1:n
    for j = i+1:n
        sigma = sqrt(A(i, i).^2 + A(j, i).^2);
        c = A(i, i)/sigma;  %determin cosinusul si sinusul corespunzatoare
        s = A(j, i)/sigma;  %matricei de rotatie R
        for l = 1:n     %actualizez matricea A (efectuand rotatia)
            u = c * A(i, l) + s * A(j, l);
            v = (-1) * s * A(i, l) + c * A(j, l);
            A(i, l) = u;
            A(j, l) = v;
            %actualizez si matricea Q care reprezinta produsul matricelor
            %de rotatie care se aplica asupra matricei A
            u = c * Q(i, l) + s * Q(j, l);
            v = (-1) * s * Q(i, l) + c * Q(j, l);
            Q(i, l) = u;
            Q(j, l) = v;
        end
        %actualizez si vectorul coloana b pentru a corespunde sistemului
        % Rx = b, deci voi calcula Q.'*b
        u = c * b(i) + s * b(j);
        v = (-1) * s * b(i) + c * b(j);
        b(i) = u;   
        b(j) = v;
    end
end
R = A;
Q = Q.';
%aplic metoda substitutiei descendente stiind ca matricea R este superior
%triunghiulara
x = SubsDesc(R, b);
end

