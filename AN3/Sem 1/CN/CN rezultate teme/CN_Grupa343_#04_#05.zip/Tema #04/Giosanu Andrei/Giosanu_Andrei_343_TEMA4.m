% Giosanu Andrei
% Grupa 343
% Sa pui sectiuni si exercitiilor (am pus eu acum).
% 1. 10
% 2. 10
% 3. 10
% 4. 10
% 5. 10
% 6. 5/10
% 7. 4/10
% Total: 59/70 i.e. ~8.5/10
%% ex-2
A = [1 1 0;1 0 1;0 1 1];
b = [1;2;5];
[q,r] = qr(A);
[Q,R,X] = QR(A,b);

%% ex-4
A = [3 1 1; 1 3 1; 1 1 3];
e = 10^(-4);
L = Jacobi(A, e);

%%
function[Q, R, X] = QR(A, b)
n = length(A);
Q = eye(n);
for i = 1: n-1
    for j = i + 1: n
        c = A(i,i)/sqrt(A(i,i)^2 + A(j,i)^2);
        s = A(j,i)/sqrt(A(i,i)^2 + A(j,i)^2);
        L =  A(i,:);
        A(i,:) = A(i,:)*c + A(j,:)*s;
        A(j,:) = L * s*(-1) + A(j,:)*c;
        LQ = Q(i,:);
        Q(i,:) = Q(i,:)*c + Q(j,:)*s;
        Q(j,:) =  LQ*s*(-1) + Q(j,:)*c;
    end
end
R = A;
Q = Q';
X = SubsDesc(R, Q'*b);
end

%%
function X = SubsDesc(A, B)
    n = length(B);
    X(n) = B(n) / A(n, n);
    for i=n-1:-1:1
        X(i) = (B(i) - (A(i, i + 1: n) * X(i +1: n)')) / A(i, i);
    end
end


%%
function [L] = Jacobi(A, e)
max = e;
n = length(A);
while max >= e
max = 0;
for i = 1:n
    for j = 1:n
        if j > i && max < abs(A(i,j))
            max = abs(A(i,j));
            p = i;
            q = j;
        end
    end
end 

  if p == q
      teta = pi/4;
  else
      teta = (1/2)*atan(2*A(p, q)/(A(q, q) - A(p, p)));
  end
  c = cos(teta);
  s = sin(teta);
  for j = 1:n
      if j ~= p && j ~= q
          u = A(p, j) * c - A(q, j) * s;
          v = A(p, j) * s + A(q, j) * c;
          A(p, j) = u;
          A(q, j) = v;
          A(j, p) = u;
          A(j, q) = v;
      end
  end
  u = c^2 * A(p, p) - 2 * c * s* A(p, q) + s^2 * A(q, q);
  v = s^2 * A(p, p) + 2 * c * s* A(p, q) + c^2 * A(q, q);
  A(p, p) = u;
  A(q, q) = v;
  A(p, q) = 0;
  A(q, p) = 0;
end
for i = 1:n
    L(i) = A(i, i);
end
end