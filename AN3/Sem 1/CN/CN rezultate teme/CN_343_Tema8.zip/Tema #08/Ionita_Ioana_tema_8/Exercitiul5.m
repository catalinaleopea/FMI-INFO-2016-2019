%subpunctul 2
syms x;
f = @(x)sin(x);
N = 3;
A = -pi/2;
B = pi/2;
X = linspace(A, B, N+1);
Y = f(X);

%Metoda Neville
xValori = linspace(A, B, 100);
yNeville = zeros(1, length(xValori));
for i=1:length(xValori)
    yNeville(i) = MetNeville(X, Y, xValori(i));
end
figure(1);
plot(X, Y, 'o', 'MarkerFaceColor', 'b');
hold on;
plot(xValori, yNeville, '--r');
hold off;
figure(2);
%size(xNeville)
%size(yNeville)
plot(xValori, abs(f(xValori) - yNeville));

%Metoda Newton cu diferente divizate
yNDD = zeros(1, length(xValori));
for i=1:length(xValori)
    yNDD(i) = MetNDD(X, Y, xValori(i));
end
figure(3);
plot(X, Y, 'o', 'MarkerFaceColor', 'r');
hold on;
plot(xValori, yNDD, '--b');
hold off;
figure(4);
plot(xValori, abs(f(xValori) - yNDD));

%Metoda Hermite
fderivat = @(x)cos(x);
z = fderivat(X);
yHermite = zeros(1, length(xValori) - 1);
for i=1:length(xValori)
    yHermite(i) = MetHermite(X, Y, z, xValori(i));
end
figure(5);
plot(X, Y, 'o', 'MarkerFaceColor', 'g');
hold on;
plot(xValori, yHermite, '--r');
hold off;
figure(6);
plot(xValori, abs(f(xValori) - yHermite), '--b');
figure(7);
plot (X, z,'o', 'MarkerFaceColor', 'b');
hold on;
plot (xValori(1:length(xValori)-1), diff(yHermite)./diff(xValori));