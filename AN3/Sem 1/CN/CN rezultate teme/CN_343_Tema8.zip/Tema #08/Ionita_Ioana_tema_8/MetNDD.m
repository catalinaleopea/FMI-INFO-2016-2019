function [ y ] = MetNDD( X, Y, x )

n = length(X) - 1;
Q = zeros(n+1, n+1);
%calculez Q, stiind ca pe prima coloana a matricei am exact valorile
%functiei f, pe care le am retinute in Y
for i=1:n+1
    Q(i, 1) = Y(i);
end
for i=2:n+1
    for j=2:i
        Q(i, j) = (Q(i, j-1) - Q(i-1, j-1))/(X(i) - X(i-j+1));
    end
end
y = 0;
suma = 0;
for k = 2:n+1
    produs = 1;
    for j = 1:k-1
        produs = produs * (x - X(j));
    end
    suma = suma + Q(k, k) * produs;
end
y = Q(1, 1) + suma;
end

