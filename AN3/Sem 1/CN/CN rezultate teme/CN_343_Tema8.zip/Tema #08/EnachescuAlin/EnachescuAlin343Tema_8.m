% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Rezolv exercitiul 4 i.e. ex.5
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

% Eroarea se masoara in valoare absoluta i.e. in modul! 
% Total: 3/10



% datele problemei
f = @(x) sin(x)
a = -pi / 2;
b = pi / 2;
n = 3;

% Nodurile de interpolare echidistante
X = linspace(a, b, (n + 1));
% Valorile lui f in nodurile de interpolare
Y = f(X);
% Diviziunea in baza careia se construiesc graficele
x = linspace(a, b, 100);

%Vectorul PN reprezinta valorile polinomului Lagrange
for i = 1 : length(x)
   PN(i) = MetNeville(X, Y, x(i));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% exercitiul 4.2 - reprezint graficul functie f pe intervalul [a, b],
%                - X, Y si Pn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
hold on
plot(x, PN, 'k', 'Linewidth', 3);
xlabel('x')
ylabel('y')
grid on
plot(x, f(x), '--r', 'Linewidth', 2);
plot(X, Y, '--k', 'LineWidth', 2);
title('f si Pn')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% exercitiul 4.3 - reprezint grafic eroarea interpolarii %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hold off
figure(2)
plot(x, f(x) - PN, 'k', 'Linewidth', 3)
title('Eroarea interpolarii')
xlabel('x')
ylabel('f(x)-Pn(x)')
grid on
