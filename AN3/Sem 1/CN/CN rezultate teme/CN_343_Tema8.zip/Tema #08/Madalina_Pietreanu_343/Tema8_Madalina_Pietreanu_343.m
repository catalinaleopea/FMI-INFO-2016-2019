%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMA 8                                                                  %
% - Madalina Pietreanu, grupa 343                                         %
% - acest fisier reprezinta implementarile anumitor exercitii din tema 8  %
% - exercitiile care se rezolvau "manual" se gasesc in folderul "Papers"  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Apreciez ca iti dai silinta! Mai ai greseli de calcul si in tema scrisa.
% Vezi la colegele tale, Ionita, Halip/ Niculescu pentru ajutor
% Total: 7/10

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% % % Error in Tema8_Madalina_Pietreanu_343 (line 54)
% % % YHermite = subs(y3,x,Xgraf);
% % %  
% % % Error using subs
% % % Expected input number 1, S, to be one of these types:
% % % 
% % % sym
% % % 
% % % Instead its type was function_handle.
% % % 
% % % Error in sym/subs (line 60)
% % % validateattributes(F, {'sym'}, {}, 'subs', 'S', 1);
% % % 
% % % Error in Tema8_Madalina_Pietreanu_343 (line 102)
% % % evalPctH = subs(y,x,pct);





close all;
clear all;

% 1)
% pregatirea datelor
syms x y1 y2 y3;
f = @(x) sin(x);
df = matlabFunction(diff(f(x),x));
n = 3;
a = -pi/2;
b = pi/2;
X = linspace(a,b,n+1);
Y = f(X);
Z = df(X);

y1 = MetNeville(X,Y);
y2 = MetNewtonDD(X,Y);
[y3,dy3] = MetHermite(X,Y,Z);

% 2)
Xgraf = linspace(a,b);
Ygraf = f(Xgraf);

% metoda Neville
%%% Cauta documentatia pentru subs!!
YNev = subs(y1,x,Xgraf);
figure(1);
title('Neville');
plot(Xgraf,Ygraf,'-r');
hold on;
plot(Xgraf,YNev,'-b');
hold off;

% metoda NewtonDD
%%% Cauta documentatia pentru subs!!
YNewton = subs(y2,x,Xgraf);
figure(2);
title('NewtonDD');
plot(Xgraf,Ygraf,'-r');
hold on;
plot(Xgraf,YNewton,'-b');
hold off;

% metoda Hermite
% arata ciudat rau; am gresit eu sau e normal sa arate asa graficul?
% NU ruleaza codul pana aici, din pacate!
YHermite = subs(y3,x,Xgraf);
figure(3);
title('Hermite');
plot(Xgraf,Ygraf,'-r');
hold on;
plot(Xgraf,YHermite,'-b');
hold off;

% derivata functiei vs. derivata polinomului Hermite
dYHermite = subs(dy3,x,Xgraf);
dXgraf = df(Xgraf);
figure(4);
title('Derivata functiei vs. derivata polinomului Hermite');
plot(Xgraf,dXgraf,'-r');
hold on;
plot(Xgraf,dYHermite,'-b');
hold off;

% 3)
% Neville
errNeville = @(x) abs(f - y1);
YerrNeville = subs(errNeville, x, Xgraf);
figure(5);
title('Eroare Neville');
plot(Xgraf,YerrNeville,'-r');

% Newton
errNewton = @(x) abs(f - y2);
YerrNewton = subs(errNewton, x, Xgraf);
figure(6);
title('Eroare Newton')
plot(Xgraf,YerrNewton,'-b');

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
close all;
% % % 
% % % Error using subs
% % % Expected input number 1, S, to be one of these types:
% % % 
% % % sym
% % % 
% % % Instead its type was function_handle.
% % % 
% % % Error in sym/subs (line 60)
% % % validateattributes(F, {'sym'}, {}, 'subs', 'S', 1);
% % % 
% % % Error in Tema8_Madalina_Pietreanu_343 (line 124)
% % % evalPctH = subs(y,x,pct);

syms x;
f = @(x) 3 .* x .* exp(x) - exp(2 .* x);
df = matlabFunction(diff(f(x),x));
pct = 1.03;
X = [1 1.05];
Y = f(X);
Z = df(X);
[y,dy] = MetHermite(X,Y,Z);

evalPctF = f(pct);
% !!!!!!!!!!!!
evalPctH = subs(y,x,pct);

disp('Aproximarea lui f(1.03):');
disp(double(evalPctH));
err = abs(evalPctF - evalPctH);
disp('Eroarea:');
disp(double(err));

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUNCTII %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA NEVILLE                                                          %
% - aceasta functie calculeaza polinomul Lagrange Pn cu ajutorul          %
%           conform algoritmului prezentat in cursul 8                    %
% - INPUT:  X - multimea nodurilor de interpolare, |X| = n+1              %
%           Y - multimea punctelor yi, unde yi = f(xi)                    %
% - OUTPUT: y - Pn(x)                                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [y] = MetNeville(X,Y)
    
    n = length(X);
    Q = zeros(n,n,'sym');
    Q(:,1) = Y'; % prima coloana din matrice, unde Pi = f(xi)
    
    % calculez si restul elementelor din matrice
    syms x
    for i = 2 : n
        for j = 2 : i
            Q(i,j) = ( (x - X(i-j+1))*Q(i,j-1) - (x - X(i))*Q(i-1,j-1) )/...
                ( X(i) - X(i-j+1) );
        end
    end
    
    % Pn este chiar ultimul element din matrice     
    y = Q(n,n);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA NEWTON CU DIFERENTE DIVIZATE                                     %
% - aceasta functie calculeaza polinomul Lagrange Pn cu ajutorul          %
%           diferentelor divizate conform algoritmului prezentat in       %
%           cursul 8                                                      %
% - INPUT:  X - multimea nodurilor de interpolare, |X| = n+1              %
%           Y - multimea punctelor yi, unde yi = f(xi)                    %
% - OUTPUT: y - Pn(x)                                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [y] = MetNewtonDD(X,Y)
    
    n = length(X);
    Q = zeros(n,n);
    Q(:,1) = Y'; % prima coloana din matrice, unde Pi = f(xi)
    
    % calculez si restul elementelor conform algoritmului
    for i = 2 : n
        for j = 2 : i
            Q(i,j) = (Q(i,j-1) - Q(i-1,j-1)) / (X(i) - X(i-j+1));
        end
    end
    
    % calclulez Pn
    syms x
    y = Q(1,1);
    for i = 2 : n
        aux = 1;
        for k = 1 : i - 1
            aux = aux * (x - X(k));
        end
        y = y + Q(i,i) * aux;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA HERMITE                                                          %
% - aceasta functie calculeaza polinomul de interpolare Hermite H cu      %
%           diferente divizate conform algoritmului prezentat in cursul 9 %
% - INPUT:  X - multimea nodurilor de interpolare, |X| = n+1              %
%           Y - multimea punctelor yi, unde yi = f(xi)                    %
% - OUTPUT: y - H(x)                                                      %
%           z - H'(x)                                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [y,z] = MetHermite(X,Y,Z)

    n = length(X);
    
    % formez vectorul Xbar dubland fiecare element in parte
    % [a1 a2 ... an] => [a1 a1 a2 a2 ... an an]
    Xbar = zeros(1,2*n);
    for i = 1 : n
        Xbar(2*i-1) = X(i);
        Xbar(2*i) = X(i);
    end
    
    % fac acelasi lucru si cu Ybar, ca sa imi fie mai usor la calcule
    Ybar = zeros(1,2*n);
    for i = 1 : n
        Ybar(2*i-1) = Y(i);
        Ybar(2*i) = Y(i);
    end
    
    Q = zeros(2*n,2*n);
    
    % prima coloana
    Q(:,1) = Ybar;
    
    % a doua coloana
    for i = 1 : n
        Q(2*i,2) = Z(i);
    end
    
    % restul matricii
    for i = 2 : n
        Q(2*i-1,2) = ( Q(2*i-1,1) - Q(2*i-2,1) ) /...
            ( Xbar(2*i-1) - Xbar(2*i-2) );
    end
    
    for i = 3 : 2*n
        for j = 3 : i
            Q(i,j) = ( Q(i,j-1) - Q(i-1,j-1) ) / ( Xbar(i) - Xbar(i-j+1) );
        end
    end
    
    % determin polinomul Hermite conform algoritmului din cursul 9
    syms x
    y = Q(1,1);
    for i = 2 : 2*n
        aux = 1;
        for k = 2 : 2*n
            aux = aux * (x - Xbar(k));
        end
        y = y + Q(i,i) * aux;
    end
    
    y = matlabFunction(y, 'var', {x});
    
    % derivata polinomului Hermite
    z = matlabFunction(diff(y(x),x));

end
