% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 8
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% ====================
% Total: 9/10

%%
% Ex. 5. 2)
f = @(x) sin(x);
n = 3;
a = -pi/2;
b = pi/2;

figure(1);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--b');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = zeros(n+1,1);
X = linspace(a,b,n+1); 
X(1) = a;
X(n+1) = b;
for i=1:n+1
    Y(i) = f(X(i));
end
plot(X,Y,'--r');
hold on
Pn = MetNeville(X,Y,z);
plot(Pn,'--g');
legend('functia f(x)=sin(x)','perechile (Xi,Yi), i=1:n+1','Polinoml Pn obtinut prin MetNeville');

syms x
figure(2);
df = diff(f(x)); % derivata functiei f
h = fplot(df,[a b],'-b'); % plotez graficul derivatei functiei f
xlim([-2 2]);
ylim([-2 2]);
legend('derivata functiei f(x)=sin(x)');

% df1 = @(x) cos(x);
% for i=1:n+1
%     Z(i) = df1(X(i));
% end
% PnH = MetHermite(X,Y,Z,x);
% plot(PnH,'--m');
% legend('derivata functiei f(x)=sin(x)', 'derivata polinomului Hermie');

% Ex. 5. 3)
figure(3);
E = abs(f(z)-Pn);
plot(E,'--r');
legend('Eroarea E=|f-Pn|');
%%

%%
function [y] = MetNeville(X,Y,x)
    n1 = size(X);
    n = n1(1) -1;
    Q = zeros(n+1);
    for i=1:n+1
        Q(i,1) = Y(i);
    end
    for i = 2:n+1
        for j = 2:i
            Q(i,j) = ((x-X(i-j+1))*Q(i,j-1)-(x-X(i))*Q(i-1,j-1))/(X(i)-X(i-j+1));
        end
    end
    Pn = Q(n+1,n+1);
    y = Pn;
end
%%

%%
function [y] = MetNDD(X,Y,x)
    n1 = size(X);
    n = n1(1) -1;
    Q = zeros(n+1);
    for i=1:n+1
        Q(i,1) = Y(i);
    end
    for i = 2:n+1
        for j = 2:i
            Q(i,j) = (Q(i,j-1)-Q(i-1,j-1))/(X(i)-X(i-j+1));
        end
    end
    Pn = Q(1,1) + sum(Q,X,x,n);
    y = Pn;
end
%%

%%
function [y] = MetHermite(X,Y,Z,x)
    n1 = size(X);
    n = n1(1) -1;
    Q = zeros(n+1);
    for i=1:n+1
        Ln(i) = fctIntLag(X,x,n,i);
    end
    for i=1:n+1
        dLn(i) = diff(Ln(i));
    end
    for i=1:n+1
        Hn(i) = (Ln(i)).^2*(1-dLn(i)*(x-X(i)));
    end
    for i=1:n+1
        Kn(i) = (Ln(i)).^2*(x-X(i));
    end
    y = sum2(Hn,Kn,x,n,Y,Z);
end
%%

%%
% fuctie implementata pentru a fii folosita in MetHermite
function [s] = sum2(Hn,Kn,x,n,Y,Z)
    s = 0;
    for k = 1:n+1
        s = s + (Hn(k)*Y(k)+Kn(k)*Z(k));
    end
end
%%

%%
% fuctie implementata pentru a fii folosita in MetHermite
function [s] = sum3(Hn,Kn,x,n,Y,Z)
    s = 0;
    for k = 1:n+1
        s = s + (Hn(k)*Y(k)+Kn(k)*Z(k));
    end
end
%%

%%
% fuctie implementata pentru a fii folosita in MetHermite
function [Lnk] = fctIntLag(X,x,n,k)
    p1 = 1;
    p2 = 1;
    for i=1:n+1
        if i~= k
            p1 = p1*(x-X(i));
            p2 = p2*(X(k)-X(i));
        end
    end
    Lnk = p1/p2;
end
%%

%%
% fuctie implementata pentru a fii folosita in MetNDD
function [s] = sum(Q,X,x,n)
    s = 0;
    p = 1;
    for k = 2:n+1
        p = p *(x -X(k-1));
        s = s + Q(k,k)*p;
    end
end
%%