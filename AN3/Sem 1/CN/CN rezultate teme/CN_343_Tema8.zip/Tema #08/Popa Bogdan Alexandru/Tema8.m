% 1. 8
% 2. 2
% 3. 10
% 4. 10
% 5. 10
% 6. 8

% Total: 48/60 i.e. 8/10


% Tema 8

%% Ex 1
% Nu afli polinomul de interpolare, din pacate. Ce calculezi tu este
% valoarea punctuala a polinomului. Puteai face simbolic daca tot ai facut
% in MATLAB.
% Eroarea este bine calculata!

f = @(x) sin(x); % formam functia sin(x)
a = -pi / 2; b = pi / 2; % intervalul pe care este definita functia
n = 2; % gradul polinomului
x_grafic = linspace(a,b,3); % intervalul din enunt
x_calcul = linspace(a,b,n+1)'; % diviziunea functiei
y_calcul = f(x_calcul); % valoarea functiei in punctele din x_calcul

for i = 1:3 % pastram si afisam pentru fiecare metoda rezultatul obtinut
    metNev = MetNeville(x_calcul,y_calcul,x_grafic(i))
    metNew = MetNDD(x_calcul,y_calcul,x_grafic(i))
end

% pastram si afisam erorile obtinute pentru fiecare metoda
e_1_nev = abs(MetNeville(x_calcul,y_calcul,pi/6) - f(pi/6))
e_1_new = abs(MetNDD(x_calcul,y_calcul,pi/6) - f(pi/6))

% se poate observa ca cele doua erori sunt egale

%% Ex 2 -> nope! Faci interpolare si evaluezi polinomul in x = 1/2
f1 = @(x) 3.^x; % pastram functia din cerinta
a1 = -2; b1 = 2; % capetele intervalului
rad3 = sqrt(3); % numarul cu care comparam
x1_grafic = linspace(a1,b1,5); % diviziunea din cerinta
x1_calcul = linspace(a1,b1,5)'; % diviziunea din cerinta
y1_calcul = f1(x1_calcul); % valoarea lui f in punctele din diviziune

% cautam o aproximare cuprinsa intre 1 si 2,
% deoarece 1 < sqrt(3) < 2
for i = 1:length(x1_grafic) 
    y = MetNeville(x1_calcul,y1_calcul,x1_grafic(i));
    if y > rad3
        break;
    end
    rasp = y; % pastram raspunsul
end

fprintf('Aproximarea lui sqrt(3) folosind metoda Neville este %f\n',rasp);

%% Ex 3,4 au fost rezolvate manual si se regasesc in Tema 8.pdf

%% Ex 5
% 1)
    % Rezolvarea se regaseste in fisierele MetNeville.m, MetNDD.m, 
    % MetHermite.m
% 2)
f2 = @(x) sin(x); % formam functia sin(x)
a2 = -pi / 2; b2 = pi / 2; % intervalul pe care este definita functia
n = 3; % n al polinomului conform cerintei

figure(1); % initiem figura

subplot(3, 1, 1); % includem graficul in figura
% apelam Display pentru a rezolva cerinta in cazul metodei Neville
[x_nev,e_nev] = Display(n, a2, b2, false, f2, @MetNeville, "Metoda Neville");

subplot(3, 1, 2); % includem graficul in figura
% apelam Display pentru a rezolva cerinta in cazul metodei Newton cu
% diferente divizate
[x_new,e_new] = Display(n, a2, b2, false, f2, @MetNDD, "Metoda NDD");

subplot(3, 1, 3); % includem graficul in figura
% apelam Display pentru a rezolva cerinta in cazul metodei Hermite
[x_h,e_h,z] = Display(n, a2, b2, true, f2, @MetHermite, "Metoda Hermite");


xlabel("x");
xlabel("y");

figure(2) % initiem figura

syms x
f2_simb = f2(x); % pastram simbolic functia f2
deriv_inter = diff(f2_simb); % calculam derivata lui f2_simb
deriv = matlabFunction(deriv_inter); % pastram functia handle deriv_inter
f2_deriv = deriv(x_h); % pastram derivata lui f

plot(x_h,f2_deriv,'r-'); % realizam graficul derivatei lui f
hold on
plot(x_h,z,'g--'); % realizam graficul derivatei lui f prin metoda Hermite
legend('f derivat','derivata Hermite')
title('Comparatia celor 2 derivate')
%3)
figure(3); % initiem figura

subplot(3, 1, 1); % includem graficul in figura
% realizam graficul erorii in metoda Neville
plot(x_nev, e_nev, 'r-');
title("Metoda Neville");

subplot(3, 1, 2); % includem graficul in figura
% realizam graficul erorii in metoda Newton cu diferente divizate
plot(x_new, e_new, 'r-');
title("Metoda NDD");

subplot(3, 1, 3); % includem graficul in figura
% realizam graficul erorii in metoda Hermite
plot(x_h, e_h, 'r-');
title("Metoda Hermite");

%% Ex 6 Mai atent aici! Reciteste cursul.
f3 = @(x,e) 3.*x.*e.^(x)-e.^(2.*x); % pastram functia
x1 = 1; x2 = 1.05; % cele 2 noduri

% !!!!!! x_calcul = linspace(x1,x2,3); % diviziunea pe cele 2 noduri
y_calcul = f3(x_calcul,eps); % valorile lui f in divizune

syms x e
f_simb = f3(x,e); % pastram simbolic functia f3
z_inter = diff(f_simb); % calculam simbolic derivata
z_func = matlabFunction(z_inter); % pastram functia handle
z_calcul = z_func(x_calcul,eps); % pastram derivata lui f3

% obtinem aproximarea lui f(1.03)
[y_h3,~] = MetHermite(x_calcul,y_calcul,z_calcul,1.03);
e_1_h = abs(f3(1.03,eps)-y_h3); % calculam eroarea
fprintf('Aproximarea lui f(1.03) folosind metoda Hermite este %f ',y_h3);
fprintf('cu eroarea %f\n',e_1_h);