% Tema 3 Popa Bogdan Alexandru Grupa 343
% In aceasta tema au fost abordate exercitiile 1,2,3,4,5,6,7
% Dintre care exercitiile 3,6 au fost efectuate manual

% Ex1

% Vom folosi pentru aflarea determinantului metoda de triangulare
% prezentata in algoritmul Gauss cu pivotare partiala din cursul 2, astfel,
% tinand cont de optiunea prezenta in enuntul exercitiului,
% obtinem un sistem compatibil cu cel reprezentat de matricea A.
% Diagonala principala a acestui sisteam reprezinta termenii produsului al
% carui rezultat va intoarce determinantul lui A (conform regulii
% lui Sarus orice alt produs pe diagonalele matricei extinse A este egal cu
% 0 inafara de produsul de pe diagonala principala).

% Pentru aflarea inversei am folosit ca punct de plecare ecuatia A*A^(-1) =
% A^(-1)*A = In, unde In este matricea identitate cu n linii si n coloane.
% Astfel, aplicand transformari elementare pe A am obtinut inversa ei (cum
% este prezentat in metoda de la Ex2).

% Ex2

% Pentru rezolvarea acestui exercitiu am folosit metoda GaussJordan
A = [4,2,2;
     2,10,4;
     2,4,6]; % matricea A
 bT = [12 30 10]; % transpusa lui b

[invA,detA] = GaussJordan(A);

% Conform metodei lui Gauss-Jordan din cursul 3 pag.5 pentru A*x = b
% x = A^(-1) * b
x = invA * bT.';

% Ex5 si Ex4(in metoda FactCholesky)

% Pentru rezolvarea acestui exercitiu am folosit metoda FactLU si metoda
% SubsAsc

A1 = [0 1 1;
      2 1 5;
      4 2 1];
b1 = [3;5;1];


[L,U,x1] = FactLU(A1,b1);

% Ex7

% Pentru rezolvarea acestei probleme am folosit metoda FactCholesky

A2 = [1 2 3;
      2 5 8;
      3 8 14];
b2 = [-5 -14 -25];

[x2,L2] = FactCholesky(A2,b2.');