% functia primeste ca date de intrare o matrice A 
% si o matrice b, iar rezultatul sistemului A*x = b este pastrat in x,
% conform algoritmului din cursul 2 pag.4
function [x] = SubsDesc(A, b)
  n = length(A); %lungimea lui A
  % pastram pe pozitia n a lui x valorile conform algoritmului din curs
  x(n) = 1/A(n, n) * b(n); 
  k = n - 1; % incepem de la n - 1 parcurgerea
  while k > 0 % pornim o ciclare pana la primul element
    s = 0; % in variabila s pastram suma conform algoritmului din curs
    for j = k + 1:n
      % adaugam elementele in suma conform algoritmului
      s = s + A(k, j) * x(j);
    end 
    x(k) = 1 / A(k, k) * (b(k) - s); % calculam urmatorul x
    k = k - 1; % trecem la un k inferior pentru a ajunge la cazul de oprire
  end 
end 