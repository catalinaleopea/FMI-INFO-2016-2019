% functia primeste ca date de intrare o matrice A si o matrice b
% iar rezultatul sistemului A*x = b este pastrat in x si odata calculate
% matricele L si U acestea sunt pastrate in L respectiv U
function [L, U,x] = FactLU(A,b)
n = length(A); % pastram dimensiunea matricei A

% predefinim dimensiunile datelor de iesire
L = eye(n);
U = zeros(n);
x = zeros(n, 1);

% aplicam cele doua metode mentionate in Ex4 (Gauss fara pivotare si cu
% pivotare partiala) pentru calcularea lui L
for k = 1: n - 1 % parcurgem elementele lui A
    p = k; % pastram pasul curent si il folosim conform algoritmului
    while A(p, k) == 0 && p <= n % sarim peste elementele nule
        p = p + 1;
    end
    if p == n + 1
        % afisam un mesaj daca p nu a fost gasit
        error('Sistem incompatibil sau sistem compatibil nedeterminat');
        % oprim rularea
    end
    
    
    for i = k : n % cautam maximul de pe coloana k
        if abs(A(i, k)) > abs(A(p, k))
            p = i;
        end
    end
    
    if A(p, k) == 0
        % afisam o eroare mesaj daca p nu a fost gasit (max A = 0)
        error('Sistem incompatibil sau sistem compatibil nedeterminat');
        % in acest caz vom opri cautarea
    end
    
    if p ~= k
        A([p, k], :) = A([k, p], :); % schimbam linia p cu linia k din A
        if k > 1
            % schimbam elementele p,k-1 cu k,k-1 din L
            L([p,k],k-1) = L([k,p],k-1);
        end
        b([p,k],:) = b([k,p],:); %(interschimb si elementele din b)
    end
    
        % facem transformarile elemnetare pentru a obtine un sistem compatibil
    % cu cel initial
    for i = k + 1 : n
      L(i,k) = A(i, k) / A(k, k);
      A(i, :) = A(i,:) - (A(i, k) / A(k, k) * A(k, :));
    end
end
% A rezultat este U conform teoriei din cursul 3 de la pag.11
U = A; % pastram valoarea lui A in U

% cautam solutiile conform teoriei de la pag. 7 din cursul 3
y = SubsAsc(L, b); % aplicam substitutia ascendenta pe L,
% aceasta fiind inferior triunghiulara
x = SubsDesc(U, y); % aplicam substitutia descendenta pe U,
% aceasta fiind superior triunghiulara
end

