% functia primeste ca date de intrare o matrice A 
% si o matrice b, iar rezultatul sistemului A*x = b este pastrat in x
% precum si matricea L, conform algoritmului din cursul 3 pag.18-20
function [x, L] = FactCholesky(A, b)
if A(1, 1) <= 0
% in cazul in care avem 0 pe prima pozitie afisam o eroare si oprim rularea
    error("A nu este pozitiv definita!");
end

n = length(b); % pastram dimensiunea lui A
L = zeros(n); % predefinim dimensiunea matricei L

% pastram L11 pentru a fi folosit in calculul primei coloane conform
% algoritmului
L(1, 1) = sqrt(A(1, 1));
% calculam prima coloana a lui L conform teoriei de la pag. 17 din cursul 3
for i = 2 : n
    L(i, 1) = A(i, 1) / L(1, 1);
end

% calculam restul elementelor lui L conform teoriei de la pag. 18

for k = 2 : n % calculam prima data elementele de pe diagonala principala
    sum = 0; % pastram suma in sum
    for s = 1 : (k - 1) % calculam suma conform algoritmului
        sum = sum + L(k, s) ^ 2;
    end
    % pastram in alpha elementul obtinut conform algoritmului
    alpha = A(k, k) - sum;
    if alpha <= 0 % in caz ca alpha este 0 afisam o eroare si oprim rularea
        error("A nu este pozitiv definita!");
    end
    % atribuim lui Lkk valoarea obtinuta conform algoritmului
    L(k, k) = sqrt(alpha);
    for i = (k + 1) : n % calculam restul elementelor
        sum = 0; % pastram suma in sum
        for s = 1 : (k - 1) % calculam suma conform algoritmului
            sum = sum + L(i, s) * L(k, s);
        end
        % pastram pe pozitiile i,k ale matricei L valorile obtinute conform
        % algoritmului
        L(i, k) = 1 / L(k, k) * (A(i, k) - sum); 
    end
end

% aplicam substitutia ascendenta pe L conform algoritmului
y = SubsAsc(L, b);
% aplicam substitutia descendenta pe transpusa lui L conform algoritmului
x = SubsDesc(L', y);
end

