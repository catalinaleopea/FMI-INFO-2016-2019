% functia primeste ca date de intrare o matrice A 
% si o matrice b, iar rezultatul sistemului A*x = b este pastrat in x,
% conform algoritmului din cursul 3 pag.4
function [x] = SubsAsc(A, b)
  n = length(b); % lungimea lui A
  x = zeros(n, 1); % dam o dimensiune cu valori provizorii lui x
  x(1) = 1 / A(1,1) * b(1); % initializam primul x conform algoritmului
  for k = 2 : n % parcurgem elementele lui A incepand de la al doilea
    % pastram suma produsului fiecarui element de pe linia k si coloana j
    % cu solutiile coloanelor <= cu k-1
    s = 0; % initializam suma cu 0
    for j = 1 : (k - 1)
      % realizam suma mentionata anterior
      s = s + A(k, j) * x(j);
    end
    % pentru fiecare k <= n pastram solutia conform algoritmului
    x(k) = 1 / A(k, k) * (b(k) - s); 
  end
end