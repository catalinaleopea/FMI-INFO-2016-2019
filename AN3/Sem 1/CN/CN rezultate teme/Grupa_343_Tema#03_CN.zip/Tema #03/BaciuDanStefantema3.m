%%Ex 2
A = [ 4 2 2; 2 10 4; 2 4 6];
[invA, det] = GaussJordan(A);


function [invA, detA] = GaussJordan(A)
N = length(A);
A=[A, eye(N)];
detA = 1;
for i = 1:N
    p = 0;
   for j = i:N
       if A(j, i) ~= 0
           p = j;
           break;
       end
   end
   if p == 0
       disp("Matricea nu corespunde");
       return;
   end
   if i ~= p
       A([i p], :) = A([p i], :);
       detA = detA * (-1);
   end
   detA = detA * A(i, i);
   A(i, :) = A(i, :)/A(i, i);
   
   for j = 1:N
       if i ~= j
           A(j, :) = A(j, :) - A(j, i) * A(i, :);
       end
   end
end
invA = A(:, N+1: 2*N);
end

%%Ex 5
A1 = [0 1 1; 2 1 5; 4 2 1];
B1 = [3; 5; 1];
[L1, U1, X1] = factLU(A1, B1);

function[L,U,X] = factLU(A, B)
    N = length(A);
    U = A;
    L = eye(N);
    P = eye(N);
    for k = 1:N
        p = 0;
        for j = k:N
            if A(j, k) ~= 0
                p = j;
                break;
            end
        end
        if p ~= k
            A([p k], :) = A([k p], :);
            U([p k], :) = U([k p], :);
            P([p k], :) = P([k p], :);
        end
        if k >= 2
            L([p k], 1:k -1) = L([k p], 1:k-1);
        end
        for l = k+1:N
            L(l, k) = U(l, k) / U(k, k);
            U(l, :) = U(l, :) - L(l, k) * U(k, :);
        end
    end 
    y = SubsAsc(L, P * B);
    X = SubsDesc(U, y);
end

function X = SubsAsc(A, b)
    n = length(b);
    X(1) = b(1) / A(1, 1);
    for i = 2:n
        X(i) = (b(i) - (A(i, 1:i - 1) * X(1:i - 1)')) / A(i, i);
    end
end

function X = SubsDesc(A, b)
    n = length(b);
    X(n) = b(n) / A(n, n);
    for i=n-1:-1:1
        X(i) = (b(i) - (A(i, i + 1: n) * X(i +1: n)')) / A(i, i);
    end
end

%%Ex 7
A2 = [1 2 3; 2 5 8; 3 8 14];
b2 = [-5; -14; -25];
[X2, L2] = FactCholesky(A2, b2);

function[x, L] = FactCholesky(A, b)
    alfa = A(1, 1);
    n = length(b);
    L(1, 1) = sqrt(A(1, 1));
    if ~isequal(A', A)
        disp('A nu este simetrica');
        x = [];
        L = [];
        return;
    end
    if alfa <= 0
        disp('A nu este pozitiv definita');
        x = [];
        L = [];
        return;
    end
    for i=2:n
        L(i, 1) = A(i, 1) / L(1, 1);
    end
    for k=2:n
        alfa = A(k, k) - sum(L(k, 1: k-1) .^ 2);
        if alfa < 0
            disp('A nu este pozitiv definita');
            x = [];
            L = [];
            return;
        end
        L(k, k) = sqrt(alfa);
        for i=k+1:n
            L(i, k) = (1 / L(k, k)) * (A(i, k) - L(i, 1: k - 1) * L(k, 1: k - 1)');
        end
    end
    y = SubsAsc(L, b);
    x = SubsDesc(L', y);
end