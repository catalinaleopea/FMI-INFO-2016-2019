% 1. 10
% 2. 10
% 3. 10*
% 4. 10
% 5. 8/10 -> Gresesti L-ul
% 6. 10
% 7. 10
% Total: 68/70 i.e. 9.71/10
% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------

disp('Gauss-Jordan');

A = [4 2 2; 2 10 4; 2 4 6];
[invA, detA] = gaussJordan(A)

b = [12 30 10]';
x = invA*b

    % Function to swap the rows of a matrix
    function M = swapRows(M,rowA,rowB)
        M([rowA rowB],:) = M([rowB rowA],:);
    end

    % Function to subtract row(i) from all the elements in matrix M below 
    % row i such that all elements below on column i are zero
    function M = makeZerosBelow(M, row, col)
        gaussRowMultipliers = M(row+1:end,col) / M(row,col);
        M(row+1:end,:) = M(row+1:end,:) - gaussRowMultipliers*M(row,:);
    end

    % Function to turn M into an upper triangular matrix using Gaussian 
    % Elimination
    function [M, nSwaps] = gaussPivPart(M)
        [nRowsM,~] = size(M); 
        nSwaps = 0;
        for iRow = 1:nRowsM
           [maxValueCol,~] = max(abs(M(iRow:end,iRow)));
           if maxValueCol == 0
               error('Error: Matricea nu este inversabila');
           end
           pivotRow = find(abs(M(iRow:end,iRow) == maxValueCol), 1) + iRow-1;
           if pivotRow ~= iRow
              M = swapRows(M,iRow,pivotRow); 
              nSwaps = nSwaps + 1;
           end
           M = makeZerosBelow(M, iRow, iRow);
        end
    end
    
    % Function to turn M into an upper triangular matrix using Gaussian 
    % Elimination
    function [M] = gaussFaraPiv(M)
        [nRowsM,~] = size(M); 
        for iRow = 1:nRowsM
           pivotRow = find(M(iRow:end,iRow), 1) + iRow-1;
           if isempty(pivotRow) == true
               error('Error: Matricea nu este inversabila');
           end
           if pivotRow ~= iRow
              M = swapRows(M,iRow,pivotRow); 
              nSwaps = nSwaps + 1;
           end
           M = makeZerosBelow(M, iRow, iRow);
        end
    end
    
    function [A] = flipDiagonal(A)
        A = flip(fliplr(A));
    end
        
    % Compute inv(A) and det(A) using the Gauss-Jordan Elimination
    function [invA,detA] = gaussJordan(A)
        [nRowsA,nColumnsA] = size(A);

        AI = [A, eye(nRowsA)];
        [upperAI, nSwaps] = gaussPivPart(AI);
        upperA = upperAI(:,1:nColumnsA);
        upperI = upperAI(:,nColumnsA+1:end);

        diagAI = gaussFaraPiv([flipDiagonal(upperA),flipDiagonal(upperI)]);
        diagA = flipDiagonal(diagAI(:,1:nColumnsA));
        diagI = flipDiagonal(diagAI(:,nColumnsA+1:end));

        detA = (-1)^nSwaps;
        for i = 1:nRowsA
            detA = detA * diagA(i,i);
            diagI(i,:) = diagI(i,:) / diagA(i,i); 
        end

        invA = diagI;

    end

