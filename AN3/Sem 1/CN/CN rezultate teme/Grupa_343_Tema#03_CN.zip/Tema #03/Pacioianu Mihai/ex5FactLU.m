% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------
    
 A = [ 0 1 1; 2 1 5; 4 2 1];
 b = [3 5 1]';
 [L, U, x] = factLU(A, b)

    %Procedura aplica metoda substitutiei ascendente 
    %   x = SubsAsc(A, b), unde x este solutia sistemului Ax = b.
    function x = subsAsc(A, b)
        [mRowsA, nColumnsA] = size(A);
        if mRowsA ~= nColumnsA
            error('Error: Matricea nu este patratica.');
        end
        if istril(A) == false
            error('Error: Matricea nu este inferior triunghiulara.');
        end
        if nColumnsA ~= length(b)
            error(['Error: Lungimea vectorului b este %d. ' ... 
                'Era asteptat un vector de lungime %d'], length(b), nColumnsA);
        end

        % aplicam metoda substitutiei ascendente 
        x = zeros(nColumnsA, 1);

        for iCol = 1:nColumnsA
           partialSumAx = A(iCol, 1:iCol-1) * x(1:iCol-1);
           x(iCol) = (b(iCol) - partialSumAx) / A(iCol, iCol);
        end
    end
    
    %Procedura aplica metoda substitutiei descendente 
    %   x = SubsDesc(A, b), unde x este solutia sistemului Ax = b.
    function x = subsDesc(A, b)
        % Verificam integritatea datelor de intrare
        [mRowsA, nColumnsA] = size(A);
        if mRowsA ~= nColumnsA
            error('Error: Matricea nu este patratica.');
        end
        if istriu(A) == false
            error('Error: Matricea nu este superior triunghiulara.');
        end
        if nColumnsA ~= length(b)
            error(['Error: Lungimea vectorului b este %d. ' ... 
                'Era asteptat un vector de lungime %d'], length(b), nColumnsA);
        end

        % aplicam metoda substitutiei descendente 
        x = zeros(nColumnsA, 1);

        for iCol = nColumnsA:-1:1
           partialSumAx = A(iCol, iCol+1:end) * x(iCol+1:end);
           x(iCol) = (b(iCol) - partialSumAx) / A(iCol, iCol);
        end
    end
    
        % Function to swap the rows of a matrix
    function M = swapRows(M,rowA,rowB)
        M([rowA rowB],:) = M([rowB rowA],:);
    end

    %Procedura aplica metoda factorizarii LU 
    %[L,U,x] = factLU(A,b), unde x este solutia sistemului Ax = b si A = LU
    function [L,U,x] = factLU(A, b)
        [nRowsM,~] = size(A); 
%         for i = 1:nRowsM
%             if det(A(1:i,1:i)) == 0
%                 error("Error: Nu se poate aplica factorizarea LU");
%             end
%         end
        
        L = eye(nRowsM);
        P = eye(nRowsM);
        for iRow = 1:nRowsM-1
           pivotRow = find(A(iRow:end,iRow), 1) + iRow-1;
           if isempty(pivotRow) == true
               error('Error: Matricea nu este inversabila');
           end
           
           if pivotRow ~= iRow
              A = swapRows(A,iRow,pivotRow); 
              P = swapRows(P,iRow,pivotRow);
              if iRow > 1
                L(:,1:iRow-1) = swapRows(L(:,1:iRow-1),iRow,pivotRow); 
              end
           end
           
           gaussRowMultipliers = A(iRow+1:end,iRow) / A(iRow,iRow);
           L(iRow+1:end, iRow) = gaussRowMultipliers;
           A(iRow+1:end,:) = A(iRow+1:end,:)-gaussRowMultipliers*A(iRow,:);
        end
                
        U = A;
        y = subsAsc(L, P*b);
        x = subsDesc(U, y);
        L = P*L;
    end