% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------
    
 A = [1 2 3; 2 5 8; 3 8 14];
 b = [-5 -14 -25]';
 [x, L] = factCholesky(A, b)

    %Procedura aplica metoda substitutiei ascendente 
    %   x = SubsAsc(A, b), unde x este solutia sistemului Ax = b.
    function x = subsAsc(A, b)
        [mRowsA, nColumnsA] = size(A);
        if mRowsA ~= nColumnsA
            error('Error: Matricea nu este patratica.');
        end
        if istril(A) == false
            error('Error: Matricea nu este inferior triunghiulara.');
        end
        if nColumnsA ~= length(b)
            error(['Error: Lungimea vectorului b este %d. ' ... 
                'Era asteptat un vector de lungime %d'], length(b), nColumnsA);
        end

        % aplicam metoda substitutiei ascendente 
        x = zeros(nColumnsA, 1);

        for iCol = 1:nColumnsA
           partialSumAx = A(iCol, 1:iCol-1) * x(1:iCol-1);
           x(iCol) = (b(iCol) - partialSumAx) / A(iCol, iCol);
        end
    end

    %Procedura aplica metoda substitutiei descendente 
    %   x = SubsDesc(A, b), unde x este solutia sistemului Ax = b.
    function x = subsDesc(A, b)
        % Verificam integritatea datelor de intrare
        [mRowsA, nColumnsA] = size(A);
        if mRowsA ~= nColumnsA
            error('Error: Matricea nu este patratica.');
        end
        if istriu(A) == false
            error('Error: Matricea nu este superior triunghiulara.');
        end
        if nColumnsA ~= length(b)
            error(['Error: Lungimea vectorului b este %d. ' ... 
                'Era asteptat un vector de lungime %d'], length(b), nColumnsA);
        end

        % aplicam metoda substitutiei descendente 
        x = zeros(nColumnsA, 1);

        for iCol = nColumnsA:-1:1
           partialSumAx = A(iCol, iCol+1:end) * x(iCol+1:end);
           x(iCol) = (b(iCol) - partialSumAx) / A(iCol, iCol);
        end
    end
    
    %Procedura aplica metoda factorizarii Cholesky 
    %[x,L] = factCholesky(A,b), unde x este sol sistemului Ax = b si A=LL^T
    function [x,L] = factCholesky(A, b)
        [nRowsM,mColsM] = size(A); 
         for i = 1:nRowsM
             if det(A(1:i,1:i)) == 0
                 error("Error: Matricea nu este pozitiv definita");
            end
         end
        
        L = zeros(nRowsM, mColsM);
        L(1,1) = sqrt(A(1,1));
        for i = 2:nRowsM
            L(i,1) = A(i,1) / L(1,1);
        end
        for k = 2:nRowsM
            c = A(k,k) - sum(L(k, 1:k-1).^2);
            if c <= 0
               error('Error: Matricea nu este pozitiv definita');
            end
            L(k,k) = sqrt(c);
            for i = k+1:nRowsM
                L(i,k) = (A(i,k) - sum(L(i,1:k-1).*L(k,1:k-1))) / L(k,k);
            end
        end
        
        y = subsAsc(L,b);
        x = subsDesc(L',y);
    end