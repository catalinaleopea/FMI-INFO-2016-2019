%%
%Exercitiul 1.
A = [2 1 1; 3 2 1; 2 1 2];
[invA, detA] = GaussJordan(A); 
disp('Matricea A: ');
disp(A);
disp('Inversa matricei A: ');
disp(invA);
fprintf('Determinantul matricei A: %d', detA);
%%

%%
%Exercitiul 2
A = [4 2 2; 2 10 4; 2 4 6];
b = [12,30,10].'; %b este vectorul termenilor liberi 
[invA, detA] = GaussJordan(A); %apelam procedura GaussJordan de la exercitiul 1 
                       %pentru matricea data
%matricea A are det nenul => (Ax = b <=> x = invA * b)
x = invA * b;   
disp('Coloana necunoscutelor x este: ');
disp(x);
%%

%%
%Exercitiul 5- Apel Gauss Fara Pivotare
A = [0 1 1;2 1 5;4 2 1];
b =[3 5 1].';
[L, U, x] = FactLU(A,b);
disp('Factorizare LU cu Gauss fara pivotare si rezolvarea sistemului:');
disp('L: ');
disp(L);
disp('U: ');
disp(U);
disp('Solutia x a sistemului: ');
disp(x);
%%

%%
%Exercitiul 5- Apel Gauss cu Pivotare Partiala
A = [0 1 1;2 1 5;4 2 1];
b =[3 5 1].';
[L, U, x] = FactorizareLUPivPart(A,b);
disp('Factorizare LU cu Gauss cu pivotare partiala si rezolvarea sistemului:');
disp('L: ');
disp(L);
disp('U: ');
disp(U);
disp('Solutia x a sistemului: ');
disp(x);
%%

%%
%Exercitiul 7
A = [1 2 3; 2 5 8; 3 8 14];
b = [-5 -14 -25].';
[x,L] = FactCholesky(A,b);
disp('L: ');
disp(L);
disp('Solutia sistemului Ax=b: ');
disp(x);
%%


%Functia de la exercitiul 1
function [invA, detA] = GaussJordan(A)    
[m,n] = size(A); %m este nr de linii ale matricei A, iar n nr de coloane
%verificam ca matricea A sa fie patratica 
if m~=n 
    error('Matricea A trebuie sa fie patratica');
end
nrInterschimbari = 0; %numarul interschimbarilor de linii in matrice, nr 
                      %necesar in calculul determinantului 
I = eye(n); %definim matricea identitate I de dimensiune n x n    
A = [A I];  %alipim matricea I in continuarea matricei A
%[A | I] => [I | invA] dupa un sir de operatii efectuate 
%modificam metoda Gauss cu Pivotare Partiala; vrem sa o folosim doar ca sa 
%transformam matricea A in superior-triunghiulara
for k=1:n-1 %luam fiecare coloana din A, pana la penultima    
    %pivotul ales pe coloana k va fi elementul cu valoarea absoluta cea mai
    %mare de pe coloana respectiva, aflat sub sau pe diagonala principala a
    %matricei A
    max = abs(A(k,k));        
    p =k; %presupunem ca elem cu valoare maxima in modul se gaseste pe linia k
          %(diagonala principala, coloana fiind tot k)    
    for j=k:n            
        if abs(A(j,k))>max               
            max = abs(A(j,k));                
            p=j;            
        end
    end
    if p~=k %daca elem cautat nu e pe diag principala, ci pe linia p, atunci
            %interschimbam liniile p si k
        A([p,k],:) = A([k,p],:); 
        nrInterschimbari = nrInterschimbari+1;
    end
    for l=k+1:n %transformam toate elementele de sub pivot in 0          
        m(l,k)=A(l,k)/A(k,k);            
        A(l,:) = A(l,:) - m(l,k)*A(k,:);        
    end
end

%determinantul matricei A in forma superior-triunghiulara este egal cu 
%(-1)^nrinterschimbari*produsul elem de pe diag principala
detA = (-1).^nrInterschimbari;
for k=1:n
    detA = detA * A(k,k);
end

%transformam toate elementele de pe diagonala principala sa fie egale cu 1
for k=1:n 
    if A(k,k) ~= 1
        A(k, :) = A(k,:) * 1/A(k,k);
    end
end

%transformam matricea A in inferior-triunghiulara, doar cu operatii
%elementare(fara interschimbare de linii)
for k=n:-1:2
    for l=k-1:-1:1 %transformam toate elementele de deasupra pivotului in 0          
        if A(l,k) ~= 0
            A(l,:) = A(l,:) - A(l,k)*A(k,:);  
        end
    end
end

invA = A(:, n+1:2*n);
end


%Metoda Substitutiei Ascendente - pt rezolvarea unui sistem de ecuatii
%inferior-triunghiular
function [x] = SubsAsc(A, b)    
x(1) = (1/A(1,1))*b(1);    
n = size (A,1);    
for k = 2:n        
    s = 0;        
    for j = 1:(k-1)           
        s = s + A(k,j)*x(j);      
    end
    x(k) = (1/A(k,k))*(b(k)-s);   
end
end

%Metoda Substitutiei Descendente - pt rezolvarea unui sistem de ecuatii
%superior-triunghiular
function [x] = SubsDesc(A,b)
    n = length(b); % calculez in n dimensiunea matricei patratice A, care este 
                   % egala cu dimensiunea vectorului b
    x(n) = (1/A(n,n)) * b(n); % sistemul se va rezolva conform algoritmului 
                              % de jos in sus; am calculat necunoscuta x(n)
    %parcurgem fiecare ecuatie de jos in sus, incepand cu penultima
    k = n-1; 
    
    while k>0 
        %calculam x(k) conform formulei din algoritm 
        S1 = 0;
        for ind = k+1:n
            S1 = S1 + A(k,ind)*x(ind);
        end
        x(k) = (1/A(k,k))*(b(k) - S1);
        k = k-1;
    end
end

%Ex.4.: functie de factorizare LU cu metoda Gauss fara pivotare +rezolvare 
%sistem
function [L, U, x] = FactLU(A,b)    
n = size(A,1); %aflam dimensiunea matricei patratice A  
L = eye(n); %initializam matricea inferior-triunghiulara L cu matricea 
            %identitate de dimensiune n
for k = 1:n-1 %pentru fiecare coloana din matrice(in afara de penultima)
              %cautam primul element nenul pentru a-l alege ca pivot 
    p = 0;        
    for c=k:n            
        if A(c,k) ~= 0                
            p = c;                
            break;           
        end
    end
    if p == 0            
        fprintf('Sist incomp sau sist comp nedet.');            
        return;        
    end
    if p ~= k  %daca elementul nenul cautat de pe coloana k nu se gaseste 
               %pe diagonala principala, atunci interschimbam liniile p si
               %k
        A([p,k],:) = A([k,p],:);            
        if k>1 %interschimbam elementele corespunzatoare din matricea 
               %inferior triunghiulara L
            L([p,k],[1:k-1]) = L([k,p],[1:k-1]);            
        end
        b([p,k])=b([k,p]); %interschimbam cele doua linii p si k si in 
                           %cadrul matricei termenilor liberi
    end
    %transformam toate elementele din A de sub pivotul A(k,k) 
    %in 0
    for l = k+1:n 
        m(l,k) = A(l,k) / A(k,k);             
        A(l,:) = A(l,:) - m(l,k)*A(k,:);            
        L(l,k) = m(l,k); %adaugam in matricea L pe pozitia (l,k) factorul
                         %m(l,k) calculat
    end
end
U = A; %matricea A a fost transformata in matricea superior-triunghiulara U
if A(n,n) == 0        
    fprintf ('Sistem incomp sau sist comp nedet.');        
    return;    
end
%produsul matricelor L si U are ca rezultat o matrice A' echivalenta cu 
%matricea initiala A, obtinuta prin interschimbare de linii;
%sistemul Ax = b devine A' * x = b, unde b este o coloana transformata fata 
%de b initial(prin interschimbare de linii simultane cu interschimbarile din A)
%<=> L*U*x = b 
%Notam produsul Ux = y si rezolvam mai intai sistemul de ecuatii inferior-
%triunghiular L*y = b, prin aplicarea metodei substitutiei ascendente 
y = SubsAsc(L, b);  
%rezolvam sistemul de ecuatii superior-triunghiular U*x = y, aplicand
%metoda substitutiei descendente 
x = SubsDesc(U, y); 
end

%Ex.4.: functie de factorizare LU cu metoda Gauss cu pivotare partiala 
%+rezolvare sistem
function [L, U, x] = FactorizareLUPivPart(A,b)    
n = size(A,1);    
L = eye(n);    
Aext = [A b];    
for k = 1:n-1        
    p = k;        
    max = abs(Aext(k,k));        
    for c=k+1:n           
        if abs(Aext(c,k)) > max               
            max = abs(Aext(c,k));             
            p=c;            
        end
    end
    if max == 0     
        fprintf('Sist incomp sau sist comp nedet.');          
        return;     
    end
    if p ~= k       
        Aext([p,k],:) = Aext([k,p],:);          
        if k>1              
            L([p,k],[1:k-1]) = L([k,p],[1:k-1]);      
        end
        b([p,k])=b([k,p]);     
    end
    for l = k+1:n     
        m(l,k) = Aext(l,k) / Aext(k,k);       
        Aext(l,:) = Aext(l,:) - m(l,k)*Aext(k,:);    
        L(l,k) = m(l,k);       
    end
end
U = Aext(1:n,1:n);  
if Aext(n,n) == 0     
    fprintf ('Sistem incomp sau sist comp nedet.');    
    return;   
end
y = SubsAsc(L, b);    
x = SubsDesc(U, y); 
end


function [x,L] = FactCholesky(A,b)    
n = length(b);    
L = zeros(n);
    alfa = A(1,1);    
    if alfa <= 0      
        fprintf('A nu este pozitiv definita');    
        return;  
    end
    L(1,1) = sqrt(A(1,1));  
    for i = 2: n    
        L(i,1) = A(i,1)/L(1,1);   
    end
    %Calculam fiecare element L(k,k) de pe diagonala principala, 
    %folosindu-ne de expresia lui A(k,k) 
    for k=2:n      
        suma = 0;     
        for s = 1:k-1     
            suma = suma + L(k,s)^2;  
        end
        alfa = A(k,k) - suma;  
        %alfa calculat pentru fiecare k trebuie sa fie >0 pt ca A sa fie 
        %pozitiv definita!
        if alfa <= 0         
            fprintf(' A nu este pozitiv definita');         
            return;       
        end
        L(k,k) = sqrt(alfa); 
        %calculam toate elementele lui L de sub L(k,k) pe coloana k, pt toti k
        for i = k+1:n        
            suma = 0;           
            for s = 1: k-1            
                suma = suma + L(i,s)*L(k,s);      
            end
            L(i,k) = 1/L(k,k) * (A(i,k) - suma);     
        end
    end
    %Conform metodei de factorizare Cholesky, A = L * L'
    %Sistemul Ax=b devine LL'x = b; notam L'*x = y
    %Rezolvam sistemul L*y = b cu metoda substitutiei ascendente
    y = SubsAsc(L,b);   
    %Rezolvam sistemul L'*x = y cu metoda substitutiei descendente
    x = SubsDesc(transpose(L),y);
end
