%% Rezultate
% 1. 5/10
% 2,4,5, 7 -> 10
% 3. -
% 6. - 
% Total: 45/70 i.e. ~6,5/10

%% Exercitiul 1 -> 5/10 

% Neclar explicat.
% Calculul determinantului?
% 
% Concatenam matricea A cu I (matricea identitate) si calculam inversa.
% Aplicam transformari elementare astfel incat A sa devina matricea
% identitate, iar I sa devina inversa matricei. Facem mB intB A superior
% triunghiulara cu Gauss pivotare partiala din tema 2, iar apoi facem A
% inferior triunghilara. La final, facem elementele de pe diagonala
% principala 1

%% Exercitiul 2 10/10

A = [4 2 2; 2 10 4; 2 4 6];
b = [12; 30; 10];
[InvA, detA] = MetGaussJordan(A);
x = InvA * b;
disp(InvA);
disp(detA);
disp(x);

%% Exercitiul 4 + 5 -> 10/10
% Pune mesaje la consola de acum inainte, te rog.

A = [0 1 1; 2 1 5; 4 2 1];
b = [3; 5; 1];

[L1, U1, x1] = FactLUGaussFaraPiv(A, b);
[L2, U2, x2] = FactLUGaussPivPart(A, b);
disp(L1);
disp(U1);
disp(x1);
disp(L2);
disp(U2);
disp(x2);

%% Exercitiul 7 10/10

A = [1 2 3; 2 5 8; 3 8 14];
b = [-5; -14; -25];
[x, L] = FactCholesky(A, b);
disp(L);
disp(x);

%% Functiile

function [InvA, detA] = MetGaussJordan(A)
    n = length(A);
    I = eye(n);
    [B] = GaussPivPart(A, I);
    % formam matricea inferior triunghiulara
    for j = 2 : n
       for i = 1 : j-1
           if B(i, j) ~= 0
               m = B(i, j)/B(j, j);
               B(i, :) = B(i, :) - m*B(j, :);
            end
        end
    end
    detA = 1; 
    for i = 1 : n
       detA = detA * B(i, i);
       % modificam diagonala principala astfel incat sa aiba 1 dupa ce
       % facem determinantul
       m = 1 ./ B(i, i);
       B(i, :) = B(i, :) .* m;
    end
    % iau doar matricea A initiala, nu matricea concatenata cu I
    InvA = B(1 : n, n + 1 : 2*n);
end

function [A] = GaussFaraPiv(A,b)
    B = [A, b];
    n = length(b);
    for k = 1 : n-1
        p = k;
        while B(p, k) == 0 && p <= n
            p = p + 1;
        end
        if p == n + 1
            disp("Sistem incompatibil sau compatibil nedeterminat");
            break;
        end
        if p ~= k %swap
            aux = B(k, :);
            B(k, :) = B(p, :);
            B(p, :) = aux;
        end
        for l = k + 1 : n
          if B(l, k) ~= 0
            m = B(l, k)/B(k, k);
            B(l, :) = B(l, :) - m*B(k, :); 
          end
        end
    end
    if(B(n, n) == 0)
        disp("Sistem incompatibil sau compatibil nedeterminat");
    end
    % returnam matricea
    A = B;
end

function [A] = GaussPivPart(A, b)
    B = [A, b];
    n = length(b);
    for k = 1 : n-1
        p = k;
        for i = k : n
            if abs(B(i, k)) > abs(B(p, k))
                p = i;
            end
        end
        if B(p, k) == 0
            disp("Sistem incompatibil sau compatibil nedeterminat");
        end
        if p ~= k %swap
            aux = B(k, :);
            B(k, :) = B(p, :);
            B(p, :) = aux;
        end
        for l = k + 1 : n
          if B(l, k) ~= 0
            m = B(l, k)/B(k, k);
            B(l, :) = B(l, :) - m*B(k, :); 
          end
        end
    end
    if B(n, n) == 0
       disp("Sistem incompatibil sau compatibil nedeterminat");
    end
    % returnam matricea
    A = B;
end

function [x] = SubsAsc(A, b)
    n = length(A);
    x = zeros(n,1);
    x(1) = 1/A(1, 1) * b(1);
    for k = 2 : n
       suma = 0;
       for j = 1 : k - 1
           suma = suma + A(k, j)*x(j);
       end
       x(k) = 1/A(k, k)*(b(k) - suma);
    end
end

function [x] = SubsDesc(A, b)
    n = length(A);
    x(n) = 1/A(n, n) * b(n);
    k = n - 1;
    while k > 0
        suma = 0;
        for j = k + 1:n
            suma = suma + A (k, j)*x(j);
        end
        x(k) = 1/A(k,k) * (b(k)-suma);
        k = k - 1;
    end
end

function [L, U, x] = FactLUGaussFaraPiv(A, b)
    B = A;
    n = length(b);
    L = eye(n);
    for k = 1 : n-1
       for p = k : n
          if B(p,k) ~= 0
             break; 
          end
       end
       if(B(p, k) == 0)
        disp("Sistem incompatibil sau compatibil nedeterminat");
           break;
       end
        if p ~= k %swap
            aux = B(k, :);
            B(k, :) = B(p, :);
            B(p, :) = aux;
           % daca k > 1 interschimbam si valoriile in L
           if(k > 1)
               L([k,p],1:k-1) = L([p,k],1:k-1); 
           end
           % interschimbam valorile in b
           b([k,p],:) = b([p,k],:);
       end
       for l = k + 1 : n
          if B(l, k) ~= 0
            m = B(l, k)/B(k, k);
            % actualizam valoarea corespunzatoare in L
            L(l, k) = m;
            B(l,:) = B(l,:) - m*B(k,:); 
          end          
       end
    end
    if B(n, n) == 0
        disp("Sistem incompatibil sau compatibil nedeterminat");
    end
    U = B;
    [y] = SubsAsc(L,b);
    [x] = SubsDesc(U,y);
end

function [L,U,x] = FactLUGaussPivPart(A,b)
    B = A;
    n = length(b);
    L = eye(n);
    for k = 1 : n-1
        p = k;
        for i = k : n
            if abs(B(i, k)) > abs(B(p, k))
                p = i;
            end
        end
        if B(p, k) == 0
            disp("Sistem incompatibil sau compatibil nedeterminat");
        end
        if p ~= k
            aux = B(k, :);
            B(k, :) = B(p, :);
            B(p, :) = aux;
           % daca k>1 interschimbam si valoriile in L
           if(k > 1)
               L([k, p], 1: k - 1) = L([p, k], 1 : k - 1);
           end
           % interschimbam valorile in b
           b([k, p], :) = b([p, k], :);
       end
       for l = k + 1 : n
          if(B(l, k) ~= 0)
            m = B(l, k)/B(k, k);
            L(l, k) = m;
            B(l, :) = B(l, :) - m*B(k, :); 
          end          
       end
    end
    if B(n, n) == 0
        disp("Sistem incompatibil sau compatibil nedeterminat");
    end
    U = B;
    [y] = SubsAsc(L,b);
    [x] = SubsDesc(U,y);
end


function [x, L] = FactCholesky(A,b)
    % urmarim pasii din curs
    n = length(A);
    first = A(1,1);
    if first <= 0
       disp("A nu este pozitiv definita");
       return;
    end
    L = eye(n);
    for i = 2 : n
       L(i, 1) = A(i, 1)/L(1, 1); 
    end
    for k = 2 : n
       suma = 0;
       for s = 1 : k-1
          suma = suma + L(k, s)^2; 
       end
       first = A(k,k) - suma;
       if first <= 0
           disp("A nu este pozitiv definita");
           return;
       end
       L(k, k) = sqrt(first);
       for i = k + 1 : n
           % calculam sumaa elementelor precedente de pe linie
           suma = 0;
           for s = 1:k-1
              suma = suma + L(i, s)*L(k, s); 
           end
           L(i, k) = 1/L(k, k)*(A(i, k) - suma);
       end
    end
    [y] = SubsAsc(L,b);
    [x] = SubsDesc(L',y);
end
