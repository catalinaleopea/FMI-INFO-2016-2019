% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 3
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================
%% Nu ruleaza! -> 1/10
% Rezolv Ex.2 apeland procedura GaussJordan
A = [4 2 2; 2 10 4; 2 4 6];
b = [12; 30; 10];
% Pentru a rezolva sistemul Ax = b, folosind metoda GaussJordan, il scriem
% pe x ca fiind, x = invA *b
[invA, detA] = GaussJordan(A);
x = invA *b;   % Solutia sistemului de la Ex. 2

%%

%% Nu ruleaza! -> 8/10 pentru subsASc si subsDesc
% Rezolv Ex. 5, apeland procedura FactLU pentru sistemul de la Ex. 3
A = [0 1 1;2 1 5;4 2 1];
b = [3;5;1];
[L,U,y] = FactLU(A, b);
%%

%% Nu ruleaza! -> 1/10
% Rezolv Ex. 7, apeland procedura FactCholesky pentru sistemul de la Ex. 6
A = [1 2 3;2 5 8;3 8 14];
b = [-5;-14;-25];
[z,L] = FactCholesky(A, b);
%%

%%
% Metoda Gauss-Jordan
% Ex. 2
% Pentru a calcula inversa matricei, trebuie sa rezolv n sisteme de forma
% Ax(k) = e(k), unde e(k) este vectorul coloana care are pe poz k, 1, si in
% rest 0
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'invA' = o matrice, care reprezinta inversa matricei A
% 'detA' = un scalar, rezprezentand determinantul matricei A
% -------------------------------------------------------------------------

function [invA, detA] = GaussJordan(A)
    n1 = size(A);
    n = n1(1);
    invA = eye(n);
    for i = 1:n
        E = InterschLin(eye(n,1),i,1);
        invA(:,i) = GaussPivPart(A,E); % GaussPivPart intoarce ca rezultat
        % un vector de tip coloana
    end  
    % folosesc o portiune din GaussPivPart pentru a aduce matricea A la o
    % matrice superior triunghiulara. Astfel determinantul devine produsul
    % elementelor de pe diagonala principala
    for k = 1:n-1
        % cu ajutorul functiei predefinite 'find' gasesc indicele la care
        % se afla valoarea maxima
        y = find(abs(A(k:n,k))==max(max(abs(A(k:n,k)))));
        p = y(1) +(k-1); % indicele primului elem max de pe coloana k 
        if p ~= k
            A = InterschLin(A, p, k); % 'InterschLin'-functie implementata 
            % intr-un fisier de tip function
        end
        for l = k+1:n
            m(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - m(l, k)*A(k,:);
        end
    end
    detA = 1;
    % Calculez determinantul
    for i =1:n
        detA = detA *A(i,i);
    end
end
%%

%%
% functie implementata pentru a fi folosita in metoda SubsAsc de la Ex. 5
% -------------------------------------------------------------------------
% Date de intrare:
% 'k' = indicele unei pozitii in matrice
% 'A' = o matrice
% 'x' = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 's' = suma de la j=1 pana la k-1 din Akj*xj
% -------------------------------------------------------------------------
function s = Sum(k,A,x)
    s = 0;
    for j =1:k-1
        s = s + (A(k,j)*x(j));
    end
end
%%

%%
% Am implementat metoda SubsAsc conform algoritmului din Cursul#3, pagina 1 
% si apeland functia Sum implementata mai sus 
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea sistemului
% 'b' = vectorul coloana cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax = b
% -------------------------------------------------------------------------
% Ex. 5
% a)
function [x] = SubsAsc(A,b)
 n1 = size(A);
    n = n1(1); %numarul de linii al matricei A
    x(1) = (1/A(1,1)) *b(1);
    for k =2:n
        x(k) = (1/A(k,k)) *(b(k) - Sum(k,A,x));
    end
    x = x';
end

%%

%%
% Ex. 5
% b) FactLU - procedura in care gasesc factorizarea LU a matricei A si
% rezolv sistemul Ax = b
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea sistemului
% 'b' = vectorul coloana cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax = b, (LUx=b)
% 'L' = matricea inferior triunghiulara
% 'U' = matricea superior triunghiulara
% -------------------------------------------------------------------------
function [L,U,x] = FactLU(A,b)
    n1 = size(A);
    n = n1(1);
    L = eye(n);
    U = eye(n);
    B = [A];
    % folosesc iteratiile metodei Gauss fara pivotare pentru a-mi construi
    % matricele L si U
    for k = 1:n-1
        % caut cel mai mic p, pentru care A(p, k) !=0
        y = find(A(k:n,k)~=0); % gaseste elementele de  pe col k din A 
        % diferite de 0
        p = y(1) +(k-1); % indicele liniei primului element nenul 
        if p ~= k
           A = InterschLin(A, p, k);
           b = InterschLin(b, p, k);
        end
        for l = k+1:n
            m(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - m(l, k)*A(k,:);
        end
    end
    
    % construiesc matricele L si U, conform explicatiilor din Cursul#3,
    % pagina 2
    for i = 1:n
        for j =1:n
            if i > j
                L(i,j) = m(i,j);
            end
            if i <= j
                U(i,j) = A(i,j);
            end
        end
    end
    % Avand calculate matricele L si U, aduc sistemul Ax = b, la un sistem
    % de forma LUx = b care se reduce la a rezolva sistemele Ux = y si
    % Ly = b; acestea fiind sisteme superior, respectiv inferior
    % triungiulare, se rezolva folosind procedurile SubsDesc si SubsAsc
    y = SubsAsc(L,b);
    x = SubsDesc(U,y);
end
%%

%%
% Pentru Factorizarea Cholesky de la Ex. 7
function s = Sum2(L,k)
    s = 0;
    for i =1:k-1
        s = s + L(k,i)*L(k,i);
    end
end
%%

%%
% Pentru Factorizarea Cholesky de la Ex. 7
function s = Sum3(L,k,i)
    s = 0;
    for j =1:k-1
        s = s + (L(i,j)*L(k,j));
    end
end
%%

%%
% Ex. 7 Factorizarea Cholesky
% Am rezolvat exercitiul construind procedura FactCholesky, conform
% algoritmului din Cursul#3, pagina 5
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea sistemului
% 'b' = vectorul coloana cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax = b
% 'L' = matricea inferior triunghiulara
% -------------------------------------------------------------------------
function [x, L] = FactCholesky(A,b)
    alfa = A(1,1);
    n1 = size(A);
    n = n1(1);
    L = eye(n);
    if alfa <= 0
        disp("A nu este pozitiv definita");
    end
    L(1,1) = sqrt(alfa);
    for i =1:n
        L(i,1) = A(i,1)/L(1,1);
    end
    for k =2:n
        alfa = A(k,k) -Sum2(L,k);
        if alfa <= 0
            disp("A nu este pozitiv definita");
        end
        L(k,k) = sqrt(alfa);
        for i =k+1:n
            L(i,k) = (1/L(k,k)) *(A(i,k) - Sum3(L,k,i));
        end
    end
    y = SubsAsc(L, b);
    x = SubsDesc(L', y);
    end

%%

%%
% Mai jos am pus functiile implementate in temele anterioare si pe care
% le-am apelat si la aceasta tema


% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = o matrice
% 'k' = indicele uneia dintre liniile ce urmeaza a fi interschimbate
% 'p' = indicele celeilalte linii ce urmeaz a fi interschimbata
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = matricea A, in care sunt interschimbate liniile k cu p
% -------------------------------------------------------------------------

function [x] = InterschLin(A, k, p)
    n1 = size(A);
    n = n1(1); 
    % folosim o matrice identitate de dimensiunea matricei A
    I = eye(n);
    I(k, k) = 0;
    I(p, p) = 0;
    I(p, k) = 1;
    I(k, p) = 1;
    A = I * A;  %interschimbam linia p cu linia k, din matricea A
    x = A;
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b, obtinuta prin metoda Gauss cu pivotare
% partiala
% -------------------------------------------------------------------------


function [x] = GaussPivPart(A, b)
    A = [A,b];
    n1 = size(A);
    n = n1(1);
    for k = 1:n-1
        % cu ajutorul functiei predefinite 'find' gasesc indicele la care
        % se afla valoarea maxima
        y = find(abs(A(k:n,k))==max(max(abs(A(k:n,k)))));
        p = y(1) +(k-1); % indicele primului elem max de pe coloana k 
        if A(p, k) == 0
           disp('Sistem incompatibil sa compatibil nedeterminat');
           break;
        end
        if p ~= k
            A = InterschLin(A, p, k); % 'InterschLin'-functie implementata 
            % intr-un fisier de tip function
        end
        for l = k+1:n
            m(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - m(l, k)*A(k,:);
        end
    end
    if A(n, n) == 0
        disp('Sistem incompatibil sau compatibil nedeterminat');
    end
    % apelez metoda 'SubscDesc', implementata intr-un fisier de tip
    % function
    x = SubsDesc(A, A(:,n+1));
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b
% -------------------------------------------------------------------------

function [x] = SubsDesc(A, b)
    n1 = size(A);
    n = n1(1); %numarul de linii al matricei A
    x(n) = (1/A(n,n)) *b(n);
    k = n - 1;
    while k > 0
        % Suma(k,A,x) este o functie construita petru a calcula suma de la
        % j=k+1 pana la n din akj*xj
        x(k) = (1/A(k,k)) *(b(k) -Suma(k,A,x)); 
        k = k - 1;
    end
    x = x';
end
%%