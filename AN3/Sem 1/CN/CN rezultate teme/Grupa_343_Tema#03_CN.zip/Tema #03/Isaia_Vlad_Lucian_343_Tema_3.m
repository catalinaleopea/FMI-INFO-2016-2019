%% Rezultate
% 1. 10
% 2. 10
% 3. -
% 4. 10
% 5. 10
% 6. 8/10 -> c?
% 7. 10
% Total: 58/70 i.e. 8,28/10 
%%
%Exercitiul 1
%{
    1. Concatenam A cu I, matricea identitate, in noua matrice AI
    2. Aplicam Gauss cu pivotare partiala pe AI ca si cum am aplica-o pe A,
    doar pe liniile si coloanele de la 1 la n
    3. Astfel in matricea A din AI se obtine o matrice superior
    triunghiulara
    4. Aplicam transformari elementare matricii AI similiare cu cele din Gauss care
    transforma matricea A in matricea identitate I si matricea I in A^-1
%}

%%
%Exercitiul 2
A = [4 2 2;
     2 10 4;
     2 4 6];
b = [12;
     30;
     10];
[InvA,detA] = GaussJordan(A);
disp("Inversa lui A:");
disp(InvA);
disp("Determinantul lui A:");
disp(detA);
% Ax = b => prin inmultire la stanga cu A^(-1) => x = A^(-1) * b;
x = InvA * b;
disp(x);

%%
%Exercitiul 4
%{
    1. Aplicam Gauss fara pivotare sau cu pivotare partiala pe matricea A
    2. La fiecare pas factorul folosit pentru a elimina numere din matrice
    (Li = Li - m_ij * Lj, m_ij fiind factorul) este atribuit matricii L in
    locul respectiv: linia i, coloana j
    3. Astfel am obtinut matricea L iar matricea A a devenit U.
    4. Aplicam substitutia ascendenta pe L si b rezultand in y
    5. Aplicam substitutia descendenta pe U si y rezultand x, solutiile
    sistemului Ax = b
%}
%%
%Exercitiul 5
%b)
A = [0 1 1;
     2 1 5;
     4 2 1];

b = [3;
     5;
     1];
%L - matricea inferior triunghiulara
%U - matricea superior triunghiulara
%astfel incat LU = A
[L, U, x_gfp] = FactLUGaussFaraPiv(A, b);
[L, U, x_gpp] = FactLUGaussPivPart(A, b);
disp("Solutiile utilizand gauss fara pivotare");
disp(x_gfp);
disp("Solutiile utilizand gauss cu pivotare partiala");
disp(x_gpp);

%%
%Exercitiul 7

A = [1 2 3;
     2 5 8;
     3 8 14];
 
b = [-5;
     -14
     -25];

[x, L] = FactCholesky(A, b);

disp("Matricea L:");
disp(L);

disp("Solutiile sunt:");
disp(x);
%%
%2
function [InvA, detA] = GaussJordan(A)
    n = size(A,1);
    I = eye(n);
    AI = GaussPivPart(A, I);
    %transformari elementare pentru a transforma A in inferior
    %triunghiulara: o sa aiba elemente numai pe diagonala, care vor fi
    %transformate in 1 iar in I va rezulta matricea A^(-1)
    for k = 2 : n
        for l = 1 : k-1
            if AI(l,k) ~= 0
                m_lk = AI(l, k) / AI(k, k);
                AI(l, :) = AI(l, :) - m_lk * AI(k, :);
            end
        end
    end
    
    detA = 1;
    
    for i = 1 : n
        detA = detA * AI(i,i);
        m = 1 / AI(i,i);
        AI(i, :) = AI(i, :) * m;
    end
    
    InvA = AI(1:n, n+1 : 2*n);
end
%modificat ca sa returneze doar matricea modificata
function A_sup_tr = GaussPivPart(A, b)
    %stim din start ca matricea este patratica
    n = size(A,1);
    %extindem matricea
    A = [A b];
    
    for k = 1 : n-1
        a_pk = 0;
        p = 0;
        %alegem pivotul corespunzator coloanei k cu valoarea absoluta cea
        %mai mare de pe aceasta coloana, aflat sub sau pe diagonala
        %principala a matricii curente A
        for j = k : n
            if abs(a_pk) < abs(A(j,k))
                a_pk = A(j,k);
                p = j;
            end
        end
        if(a_pk == 0)
            fprintf("Sistem incompatibil sau compatibil nedeterminat.\n");
            x = -1;
            return;
        end
        if p ~= k
            A([p k], :) = A([k p], :);
        end
        
        for l = k+1 : n
            m_lk = A(l, k) / A(k, k);
            A(l, :) = A(l, :) - m_lk * A(k, :);
        end
    end
    if A(n, n) == 0
        fprintf("Sistem incompatibil sau compatibil nedeterminat\n");
        x = -1;
        return;
    end
    %am obtinut o matrice superior triunghiulara si putem aplica
    A_sup_tr = A;
end

%5
%a)
function x = SubsAsc(A, b)
    x(1) = b(1) / A(1,1);
    
    n = size(A, 1);
    
    for k = 2 : n
        sum = 0;
        for j = 1 : k-1
            sum = sum + A(k,j) * x(j);
        end
        x(k) = (b(k) - sum) / A(k,k);
    end
end

function [x] = SubsDesc(A, b)
    n = size(b, 2);
    x(n) = b(n) / A(n, n);
    k = n-1;
    while k > 0
        sum = 0;
        for i = k+1 : n
            sum = sum + A(k, i)*x(i);
        end
        x(k) = (b(k) - sum) / A(k,k);
        k = k-1;
    end
end

%b)
function [L, U, x] = FactLUGaussFaraPiv(A, b)
    x = 0;
    n = size(A,1);
    L = eye(n);
    for k = 1 : n-1
        %cautam primul element diferit de 0 de pe coloana k
        p = 0;
        
        for p = k : n
            if A(p, k) ~= 0
                break; 
            end
        end
       
        if A(p, k) == 0
            fprintf("sistem incompatibil sau sistem compatibil nedeterminat.\n");
            x = -1;
            return;
        end
        
        if p ~= k
            %interschimbam linia p cu linia k
            A([p k],:) = A([k p],:);
            %facem la fel si in L daca este cazul
            if k > 1
                L([p k], 1:k-1) = L([k p], 1:k-1);
            end
	    %interschimbam si in coloana b
            b([p k], :) = b([k p], :);
        end
        for l = k+1 : n
            %eliminam elementele de pe coloana k sub pivot
            m_lk = A(l, k) / A(k, k);
	    %actualizam matricea L cu elementul m_lk
            L(l, k) = m_lk;
            A(l, :) = A(l, :) - m_lk * A(k, :);
        end
    end
    
    U = A;
    
    y = SubsAsc(L, b);
    x = SubsDesc(U, y);
end

function [L, U, x] = FactLUGaussPivPart(A, b)
    x = 0;
    %stim din start ca matricea este patratica
    n = size(A,1);
    
    L = eye(n);
    
    for k = 1 : n-1
        a_pk = 0;
        p = 0;
        %alegem pivotul corespunzator coloanei k cu valoarea absoluta cea
        %mai mare de pe aceasta coloana, aflat sub sau pe diagonala
        %principala a matricii curente A
        for j = k : n
            if abs(a_pk) < abs(A(j,k))
                a_pk = A(j,k);
                p = j;
            end
        end
        if(a_pk == 0)
            fprintf("Sistem incompatibil sau compatibil nedeterminat.\n");
            x = -1;
            return;
        end
	%interschimbam liniile p si k
        if p ~= k
            A([p k], :) = A([k p], :);

            if(k > 1)
               L([p k], 1:k-1) = L([k p], 1:k-1);
            end
            
            b([p k], :) = b([k p], :);
        end
        
        for l = k+1 : n
            m_lk = A(l, k) / A(k, k);
	    %actualizam matricea L cu elementul m_lk
            L(l,k) = m_lk;
            A(l, :) = A(l, :) - m_lk * A(k, :);
        end
    end
    
    U = A;
    
    y = SubsAsc(L, b);
    x = SubsDesc(U, y);
end

%7
function [x, L] = FactCholesky(A, b)
    alpha = A(1,1);
    
    if alpha <= 0
        fprintf("A nu este pozitiv definita");
        x = 0;
        L = 0;
        return;
    end
    
    L(1,1) = sqrt(A(1,1));
   
    n = size(A, 1);
    
    for i = 2 : n
        L(i,1) = A(i,1) / L(1,1);
    end
    
    for k = 2 : n
        sum = 0;
        
        for s = 1 : k-1
            sum = sum + L(k,s)^2;
        end
        
        alpha = A(k,k) - sum;
        
        if alpha <= 0
            x = 0;
            L = 0;
            fprintf("A nu este pozitiv definita");
            return;
        end
        
        L(k,k) = sqrt(alpha);
        
        for i = k+1 : n
            sum = 0;
            
            for s = 1 : k-1
                sum = sum + L(i,s) * L(k,s);
            end
            
            L(i,k) = (A(i,k) - sum) / L(k,k);
        end
    end
    
    y = SubsAsc(L, b);
    x = SubsDesc(transpose(L), y);
end