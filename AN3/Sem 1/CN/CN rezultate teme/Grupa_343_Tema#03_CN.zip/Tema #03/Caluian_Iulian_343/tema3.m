%% Rezultate
% 1. - Lene?
% 2. 10
% 3. - Lene?
% 4. - Lene?
% 5. 10
% 6. - Lene?
% 7. 10
% Total -> 30/70 i.e. ~4,5/10 :(
%%
%% EX.2 -> Mesaje la consola de acum inainte, te rog. Este o ciorba cand rulez
%      10/10 
A = [4 2 2;
    2 10 4;
    2 4 6];

[invA,detA] = GaussJordan(A);
invA
detA
det(A)
invA * A
clear;

%% EX.5 -> 10/10 
A = [ 0 1 1 ;
     2 1 5;
     4 2 1];

 b = [3 5 1];
 
 FactLU(A,b);
 
 
 %% EX. 7 -> 10/10 
A = [ 1 2 3;
     2 5 8;
     3 8 14];

 b = [-5 -14 -25];
 
 FactLU(A,b);
