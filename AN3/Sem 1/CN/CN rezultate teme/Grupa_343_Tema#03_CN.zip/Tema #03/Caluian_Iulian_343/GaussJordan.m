function [invA,detA] = GaussJordan(A)
%GAUSSJORDAN Summary of this function goes here
%   Detailed explanation goes here

[~,n] = size(A);
invA = zeros(n,n);
%Calculam inversa coloana cu coloana
for i = 1:n
   e = zeros(n,1);
   e(i) = 1;
   xi = GaussFaraPiv(A,e); %coloana i din inversa
   invA(i,1:n) = xi;
end


%Calculam determinant prin transformarea matricii in matrice superior
%triunghiulara.
AB = A;
detA = 1;
for k = 1:(n-1)
   
    m = AB(k:n,k); % selectez valorile urmatoare de pe coloana
    mEl = find( m ~= 0); % gasesc elementele nenule 
    if isempty(mEl)
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        print('Sistemul nu este compatibil, sau compatibil nedeterm');
        break;
    else
        p = mEl(1) + k - 1;
        % p - prima pozitie unde nu e nul akl => primul element din mEl 
        % care indica un index + (k-l) cate pozitii anterioare in matrice avem pe coloana=>
        % pentru a rezulta linia in matrice
        
        % swap linii:
        line = AB( k, 1:n);
        AB(k, 1:n) = AB(p, 1:n);
        AB(p, 1:n) = line;
        if p ~= k 
            detA = detA * -1;
        end
    
        for p = (k+1):n 
            %update restul liniilor pentru a face apk sa fie 0
            mpk = AB(p,k) / AB(k,k);
            AB(p, 1:n) = AB(p, 1:n) - mpk*AB(k,1:n);
        end
    end
    
    detA = detA * AB(k,k);
    
end

detA = detA * AB(n,n);



end

