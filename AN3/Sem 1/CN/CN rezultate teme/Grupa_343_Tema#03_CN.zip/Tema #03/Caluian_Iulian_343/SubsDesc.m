function [x] = SubsDesc(A,b)
%SUBSDESC Summary of this function goes here
%   Metoda substitutiei descendente:

[~,n] = size(A);
x = zeros(n,1);
x(n) = b(n)/A(n,n); % calculam x(n)

for i = (n-1):-1:1
    ac = A(i,(i+1):n);
    ac = ac(:); 
    % iau coef lui x(i+1)..x(n) in ac
    x(i) = 1 / A(i,i) * (b(i) - sum( ac .* x((i+1):n) ));
    % calculam pe rand x(i) 
    % cu formula din curs avand deja calculate x(i+1)..x(n)
end

end

