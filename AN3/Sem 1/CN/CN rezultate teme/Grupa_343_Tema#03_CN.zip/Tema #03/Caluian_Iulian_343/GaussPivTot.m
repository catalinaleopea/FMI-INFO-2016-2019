function [x] = GaussPivTot(A,b)
%SUBSDESC Summary of this function goes here
%   Detailed explanation goes here

[~,n] = size(A);

AB = [A b(:)]; %AB este matricea extinsa.

for k = 1:(n-1)
    
    %caut p a.i. AB(p,k) sa aiba valoarea absoluta cea mai mare.
    maxim = -1;
    p = k;
    q = k;
    for i = k:n
        for j = k:n
            if maxim < abs(AB(i,j))
               maxim = abs(AB(i,j));
               p = i;
               q = j;
            end
        end
    end

    if maxim == -1
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        disp('Sistemul nu este compatibil, sau compatibil nedeterm');
        break;
    else
       % am gasit deja p-ul si q-ul
        
        
        % swap linii:
        line = AB( k, 1:(n+1));
        AB(k, 1:(n+1)) = AB(p, 1:(n+1));
        AB(p, 1:(n+1)) = line;
        
        coloana  = AB( 1:n , k);
        AB(1:n, k ) = AB( 1:n, q);
        AB(1:n, q) = coloana;
    
        for p = (k+1):n 
            %update restul liniilor pentru a face apk sa fie 0
            mpk = AB(p,k) / AB(k,k);
            AB(p, 1:(n+1)) = AB(p, 1:(n+1)) - mpk*AB(k,1:(n+1));
        end
    end
    
end

if AB(n,n) == 0
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        disp('Sistemul nu este compatibil, sau compatibil nedeterm');
end

%extrag componentele pentru a rezolva cu metoda substitutiei.
AB(1:n,1:n)
x = SubsDesc(AB(1:n,1:n),AB(1:n,n+1));


end