function [L,U,x] = FactLU(A,b)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


[~,n] = size(A);

BB = b(:);
L = eye(n);
U = A; % matrice care in urma rularii for-ului urmator va deveni superior triunghiulara.

for k = 1:(n-1)
   
    m = U(k:n,k); % selectez valorile urmatoare de pe coloana
    mEl = find( m ~= 0); % gasesc elementele nenule 
    if isempty(mEl)
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        print('Sistemul nu este compatibil, sau compatibil nedeterm');
        break;
    else
        p = mEl(1) + k - 1;
        % p - prima pozitie unde nu e nul akl => primul element din mEl 
        % care indica un index + (k-l) cate pozitii anterioare in matrice avem pe coloana=>
        % pentru a rezulta linia in matrice
        
        % swap linii:
        line = U( k, 1:n);
        U(k, 1:n) = U(p, 1:n);
        U(p, 1:n) = line;
       
        if p ~= k && k>1
            lin = L(p,1:(k-1));
            L(p,1:(k-1)) = L(k,1:(k-1));
            L(k,1:(k-1)) = lin;
        end
        
        aux = BB(p);
        BB(p) = BB(k);
        BB(k) = aux;
    
        for p = (k+1):n 
            %update restul liniilor pentru a face apk sa fie 0
            mpk = U(p,k) / U(k,k);
            L(p,k) = mpk;
            U(p, 1:n) = U(p, 1:n) - mpk*U(k,1:n);
        end
    end
    
end

y = SubsAsc(L,BB);
x = SubsDesc(U,y);
y
x

end

