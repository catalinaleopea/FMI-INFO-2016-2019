function [x] = SubsAsc(A,b)
%SUBSDESC Summary of this function goes here
%   Metoda substitutiei ascendente:

[~,n] = size(A);
x = zeros(n,1);
x(1) = b(1)/A(1,1); % calculam x(1)

for i = 2:1:n
    ac = A(i,1:(i-1));
    ac = ac(:); 
    % iau coef lui x(i+1)..x(n) in ac
    x(i) = 1 / A(i,i) * (b(i) - sum( ac .* x(1:(i-1)) ));
    % calculam pe rand x(i) 
    % cu formula din curs avand deja calculate x(i+1)..x(n)
end

end


