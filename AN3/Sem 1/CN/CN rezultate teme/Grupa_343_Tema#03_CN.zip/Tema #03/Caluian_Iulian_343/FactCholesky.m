function [x,L] = FactCholesky(A,b)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


[~,n] = size(A);

BB = b(:);

L = zeros(n);
alpha = A(1,1);
if alpha <= 0 
    disp(['A nu este pozitiv definita']);
    return;
end

L(1,1) = sqrt(A(1,1));
for i = 2:n
    L(i,1) = A(i,1)/L(1,1);
end


for k = 2:n
    alpha = A(k,k) - sum( L(k, 1:(k-1)) .^ (2) ) ; %C3 (11)
    alpha
    if alpha <= 0 
        disp(['A nu este pozitiv definita']);
        return;
    end
    L(k,k) = sqrt(alpha);
    
    for i = k+1 : n
        L(i,k)  = 1 / L(k,k) * ( A(i,k) - sum( L(i,1:(k-1)) .* L(k,1:(k-1)) )); %C3 (12)
    end
end

%L * L' * x = BB => L * y = BB => L' * x = y
y = SubsAsc(L,BB); 
x = SubsDesc(L',y);
y
x

end

