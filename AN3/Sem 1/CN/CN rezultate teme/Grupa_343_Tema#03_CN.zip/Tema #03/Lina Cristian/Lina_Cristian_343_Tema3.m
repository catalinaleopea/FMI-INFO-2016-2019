%% Rezultate
% 1. 10
% 2. 10
% 3. 10
% 4. 10
% 5. 10
% 6. 10
% 7. 10
% Total: 70/70 i.e. 10/10
%%

% Lina Cristian - 343 - Tema 3

%% Exercitiul 1

% Algoritmul propus consta in a extinde matricea A cu matricea identitate,
% iar calcularea inversei consta in aplicarea unor transformari elementare
% astfel incat matricea A sa devina matrice identitate, iar partea extinsa
% sa devina astfel inversa matricei (AI = IA). Transform mai intai in
% matrice superior triunghiulara cu Gauss Pivot Partial, apoi ma ocup sa
% transform iin matrice inferior triunghiulara, iar apoi ma ocup de
% valorile de pe diagonala principala sa devina 1.


%% Exercitiul 2

A = [4 2 2; 2 10 4; 2 4 6];
b = [12; 30; 10];
[InvA,detA] = MetGaussJordan(A);
disp(InvA);
disp(detA);
% Calculam solutia Ax = b => x = A^(-1) * b
x = InvA * b;
disp(x);

%% Exercitiul 3 - pe foaie

%% Exercitiul 4 + 5 -> Pune si tu mesaje la consola, te rog.

A = [0 1 1; 2 1 5; 4 2 1];
b = [3; 5; 1];

% Am modificat algoritmele GaussFaraPiv si GaussPivPart astfel incat sa
% construiasca atat L cat si U si sa rezolve sistemul

[L1,U1,x1] = FactLUGaussFaraPiv(A,b);
[L2,U2,x2] = FactLUGaussPivPart(A,b);
disp(L1); disp(U1); disp(x1);
disp(L2); disp(U2); disp(x2);

%% Exercitiul 6 - pe foaie

%% Exercitiul 7

A = [1 2 3; 2 5 8; 3 8 14];
b = [-5; -14; -25];
[x,L] = FactCholesky(A,b);
 disp(L); disp(x);

%% Functii

function [x,L] = FactCholesky(A,b)
    n = length(A);
    % luam primul element din matrice si testam daca este pozitiv
    alpha = A(1,1);
    if(alpha <= 0)
       disp('A nu este pozitiv definita');
       return;
    end
    % pregatim matricea L
    L = eye(n);
    % calculam prima coloana
    for i = 2:n
       L(i,1) = A(i,1)/L(1,1); 
    end
    % pentru celelalte coloane
    for k = 2:n
       % calculam suma elementelor precedente de pe linie
       sum = 0;
       for s = 1:k-1
          sum = sum + L(k,s)^2; 
       end
       % calculam elementul de pe diagonala principala de pe coloana k
       alpha = A(k,k) - sum;
       if(alpha <= 0)
           disp('A nu este pozitiv definita');
           return;
       end
       L(k,k) = sqrt(alpha);
       % calculam celelalte elemente de pe coloana k de sub diagonala
       % principala
       for i = k+1:n
           % calculam suma elementelor precedente de pe linie
           sum = 0;
           for s = 1:k-1
              sum = sum + L(i,s)*L(k,s); 
           end
           L(i,k) = 1/L(k,k)*(A(i,k)-sum);
       end
    end
    [y] = SubsAsc(L,b);
    [x] = SubsDesc(L',y);
end

function [x] = SubsAsc(A,b)
    % avem matricea inferior triunghiulara A cu solutiile b
    n = length(A);
    x = zeros(n,1);
    k = 1;
    % calculam x1
    x(k) = 1/A(k,k)*b(k);
    for k = 2:n
       sum = 0;
       for j = 1 : k-1
           sum = sum + A(k,j)*x(j);
       end
       x(k) = 1/A(k,k)*(b(k)-sum);
    end
end

function [x] = SubsDesc(A,b)
    % avem matricea superior triunghiulara a cu solutiile b
    n = length(A);
    x = zeros(n,1);
    % calculam xn
    x(n) = 1/A(n,n)*b(n);
    k = n - 1;
    % continua algoritmul ca cel descris in curs
    while(k>0)
       sum = 0;
       for j = k+1 : n
           sum = sum + A(k,j)*x(j);
       end
       x(k) = 1/A(k,k)*(b(k)-sum);
       k = k - 1;
    end
end

function [L,U,x] = FactLUGaussFaraPiv(A,b)
    % concatenam coloana b la matricea a (mat. extinsa)
    AE = A;
    % nr de linii a matricei
    n = length(b);
    % pregatim L
    L = eye(n);
    for k = 1 : n-1
       % cautam pe coloana primul p dif de 0
       for p = k : n
          if(AE(p,k) ~= 0)
             break; 
          end
       end
       if(AE(p,k) == 0)
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
       end
       if(p ~= k)
           % interschimbam liniile
           AE([k,p],:) = AE([p,k],:);
           % daca k>1 interschimbam si valoriile in L
           if(k > 1)
               L([k,p],1:k-1) = L([p,k],1:k-1);
           end
           % interschimbam valorile in b
           b([k,p],:) = b([p,k],:);
       end
       for l = k + 1 : n
          if(AE(l,k) ~= 0)
            m = AE(l,k)/AE(k,k);
            % actualizam valoarea corespunzatoare in L
            L(l,k) = m;
            AE(l,:) = AE(l,:) - m*AE(k,:); 
          end          
       end
    end
    if(AE(n,n) == 0)
       disp('Sistem incop. sau sistem comp. nedet.');
    end
    U = AE;
    [y] = SubsAsc(L,b);
    [x] = SubsDesc(U,y);
end

function [L,U,x] = FactLUGaussPivPart(A,b)
    % concatenam coloana b la matricea a (mat. extinsa)
    AE = A;
    % nr de linii a matricei
    n = length(b);
    % pregatim L
    L = eye(n);
    for k = 1 : n-1
       % initializam maximul cu val min absoluta de pe coloana
       maxim = min(abs(AE(k:n,k)))-1;
       ind = 0;
       % cautam valoarea maxima abosluta de pe coloana k
       for p = k : n
          if(abs(AE(p,k)) > maxim)
             maxim = abs(AE(p,k));
             ind = p;
          end
       end
       if(ind == 0)
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
       end
       if(ind ~= k)
           % interschimbam liniile
           AE([k,ind],:) = AE([ind,k],:);
           % daca k>1 interschimbam si valoriile in L
           if(k > 1)
               L([k,ind],1:k-1) = L([ind,k],1:k-1);
           end
           % interschimbam valorile in b
           b([k,ind],:) = b([ind,k],:);
       end
       for l = k + 1 : n
          if(AE(l,k) ~= 0)
            m = AE(l,k)/AE(k,k);
            % actualizam valoarea corespunzatoare in L
            L(l,k) = m;
            AE(l,:) = AE(l,:) - m*AE(k,:); 
          end          
       end
    end
    if(AE(n,n) == 0)
       disp('Sistem incop. sau sistem comp. nedet.');
    end
    U=AE;
    [y] = SubsAsc(L,b);
    [x] = SubsDesc(U,y);
end

function [InvA,detA] = MetGaussJordan(A)
    n = length(A);
    I = eye(n);
    % apelam Gauss cu piv part pt a elimina elem de sub diagonala princ
    % functia e modificata pentur a returna matricea sup. tr. si nu solutiile
    [AI] = GaussPivPart(A,I);
    % efectual transformari elementare pentru a forma mat inf triunghiulara
    for j = 2 : n
       for i = 1 : j-1
           if(AI(i,j) ~= 0)
               m = AI(i,j)/AI(j,j);
               AI(i,:) = AI(i,:) - m*AI(j,:);
            end
        end
    end
    % la final transformam diagoala principala in valori de 1, inmultind cu
    % inversul elementului respectiv
    % in acelasi timp calculam si determinantul care e produsul elementelor
    % de pe diagonala principala
    detA = 1;
    for i = 1:n
       detA = detA * AI(i,i);
       m = 1 ./ AI(i,i);
       AI(i,:) = AI(i,:) .* m;
    end
    % preiau partea extinsa a matricei (unde a fost identitatea initial,
    % acum este inversa)
    InvA = AI(1:n, n+1:2*n);
end

function [A] = GaussPivPart(A,b)
    % concatenam coloana b la matricea a (mat. extinsa)
    ae = [A, b];
    % nr de linii a matricei
    n = length(b);
    % implementarea propriu-zisa a algoritmului descris in curs
    for k = 1 : n-1
       % initializam maximul cu val min absoluta de pe coloana
       maxim = min(abs(ae(k:n,k)))-1;
       ind = 0;
       % cautam valoarea maxima abosluta de pe coloana k
       for p = k : n
          if(abs(ae(p,k)) > maxim)
             maxim = abs(ae(p,k));
             ind = p;
          end
       end
       if(ind == 0)
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
       end
       if(ind ~= k)
           % interschimbam liniile
           ae([k,ind],:) = ae([ind,k],:);
       end
       for l = k + 1 : n
          if(ae(l,k) ~= 0)
            m = ae(l,k)/ae(k,k);
            ae(l,:) = ae(l,:) - m*ae(k,:); 
          end          
       end
    end
    if(ae(n,n) == 0)
       disp('Sistem incop. sau sistem comp. nedet.');
    end
    A = ae;
end

function [A] = GaussFaraPiv(A,b)
    % concatenam coloana b la matricea a (mat. extinsa)
    AE = [A, b];
    % nr de linii a matricei
    n = length(b);
    % implementarea propriu-zisa a algoritmului descris in curs
    for k = 1 : n-1
       % cautam pe coloana primul p dif de 0
       for p = k : n
          if(AE(p,k) ~= 0)
             break; 
          end
       end
       if(AE(p,k) == 0)
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
       end
       if(p ~= k)
           % interschimbam liniile
           AE([k,p],:) = AE([p,k],:);
       end
       for l = k + 1 : n
          if(AE(l,k) ~= 0)
            m = AE(l,k)/AE(k,k);
            AE(l,:) = AE(l,:) - m*AE(k,:); 
          end          
       end
    end
    if(AE(n,n) == 0)
       disp('Sistem incop. sau sistem comp. nedet.');
    end
    A = AE;
end