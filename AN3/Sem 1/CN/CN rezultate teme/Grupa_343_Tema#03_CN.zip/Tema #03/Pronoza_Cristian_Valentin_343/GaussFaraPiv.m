function [RetA,RetInvA] = GaussFaraPiv(A,InvA) 
[m,n]=size(A); 
for k=1:m  
    I=find(A(k:m,k),1);  %cautarea unui element nenul pe coloana curenta
    I=I+k-1;
    if(k~=I) 
        A([k,I],:) = A([I,k],:); %pozitionarea pivotului 
        InvA([k,I],:) = InvA([I,k],:);
    end
    
    for l=k+1:m  
        M=A(l,k)/A(k,k); 
        A(l,:)=A(l,:)-M*A(k,:); 
        InvA(l,:)=InvA(l,:)-M*InvA(k,:);
    end %calcularea valoriilor pentru coeficientii liniilor de sub pivot
end 

RetA=A; 
RetInvA=InvA;
end

