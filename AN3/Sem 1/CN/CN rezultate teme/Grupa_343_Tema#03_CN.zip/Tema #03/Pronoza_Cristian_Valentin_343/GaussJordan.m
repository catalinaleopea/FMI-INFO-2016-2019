function [InvA,DetA] = GaussJordan(A) 
[m,n]=size(A); 
I=eye(m);
[A,InvA]=GaussFaraPiv(A,I);
[A,InvA]=TopZeros(A,InvA);  
 

if n>m
fprintf("Solutiile ecuatiei sunt:\n");  
for i=1:m  
    fprintf("X%d=%f\n",i,A(i,n)/A(i,i));
end 
end%in cazul transmiterii matricei unui sistem de ecuatii se vor afisa solutiile.

DiagA=diag(A); 
DetA=prod(DiagA); 
for k=1:m 
    InvA(k,:)=InvA(k,:)*(1/A(k,k));
end
end

