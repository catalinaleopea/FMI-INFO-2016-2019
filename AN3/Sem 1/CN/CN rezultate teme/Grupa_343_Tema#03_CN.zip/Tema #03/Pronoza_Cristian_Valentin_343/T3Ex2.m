% 1. 10
% 2. 10
% 3. 10
% 4. 10
% 5. 10
% 6. 10
% 7. 10
% Total: 70/70 i.e. 10/10 :)

A=[
    4 2 2 %12
    ;
    2 10 4 %30 
    ; 
    2 4 6 %10
    ]; 
%Pentru afisarea solutiei sistemului se va transmite o matrice 3x4, altfel
%una 3x3.
[InvA,DetA]=GaussJordan(A)