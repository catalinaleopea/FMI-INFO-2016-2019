function [X,L] = FactCholesky(A,b)
if A(1,1)<=0 
    error("Nu exista factorizare");
end  %test primul minor
[m,n]=size(A);
L(1,1)=sqrt(A(1,1));

for i=2:n  
    L(i,1)=A(i,1)/L(1,1);%calculeaza elementele de pe prima coloana
end

for k=2:n  
    alfa=A(k,k)-sum(L(k,1:k-1).*L(k,1:k-1)); 
    if alfa<=0  
        error("Nu exista factorizare"); 
    end %testeaza ceilalti minori
    L(k,k)=sqrt(alfa); 
    for i=k-1:n 
        L(i,k)=(1/L(k,k))*(A(i,k)-sum(L(i,1:k-1).*L(k,1:k-1))); 
    end
end%calculeaza matricea L
y=SubsAsc(L,b); %rezolva sistemul.
X=SubsDesc(transpose(L),y);
