A=[
    1 2 3; 
    2 5 8; 
    3 8 14 
    ]; 
b=[-5 -14 -25]; 
[X,L]=FactCholesky(A,b)