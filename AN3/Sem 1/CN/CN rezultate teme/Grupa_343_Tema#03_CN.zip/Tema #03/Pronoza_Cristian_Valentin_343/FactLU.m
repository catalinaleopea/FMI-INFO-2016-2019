function [L,U,X] = FactLU(A,b)  

[m,n]=size(A);  
L=eye(m);
for i=1:m 
    permutareb(i)=i; %tine minte interschimbarile de linii
    permutareL(i)=i; 
end
for i=1:m  
    max=A(i,i);  
    for j=i:m  
        if A(j,i)>max 
            max=A(j,i); 
            Imax=j; 
            Jmax=i;
        end
    end %cauta pivot pentru gauss
    if max>A(i,i)   
        A([i,Imax],:) = A([Imax,i],:); 
        aux=permutareb(i); 
        permutareb(i)=permutareb(Imax); 
        permutareb(Imax)=aux; 
        if i>1 
            aux=permutareL(i); 
            permutareL(i)=permutareL(Imax); 
            permutareL(Imax)=aux;
        end
    end  %interschimba linii in A, marcheaza interschimbarile relevante in vectorii de permutare
    for k=i+1:m   
        coef=A(k,i)/A(i,i);
        L(k,i)=coef; 
        A(k,:)=A(k,:)-coef*A(i,:); 
    end %transformari elementare pentru obtinerea de zero-uri sub diag. principala
    
end 
U=A; 
Lnepermutat=L;
for i=2:m  
    minimum=min(i, permutareL(i)); 
    L(i,1:minimum-1)=Lnepermutat(permutareL(i),1:minimum-1); 
    
end   %permuta liniile in matricea L(tot ce e sub diag principala)
bnepermutat=b;
for i=1:m 
    b(i)=bnepermutat(permutareb(i));
end %permuta vectorul de elemente libere B
y=SubsAsc(L,b); 
X=SubsDesc(U,y);%rezolva sistemul de ecuatii
