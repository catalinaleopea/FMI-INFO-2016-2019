function [X] = SubsAsc(A,b)
[m,n]=size(A);  
X(1)=1/A(1,1)*b(1); 
for k=2:n
    X(k)=1/A(k,k) *( b(k) - sum( A(k,1:k-1) .* X(1:k-1) ) );  
    %Calculeaza solutia unui sistem de forma triunghiulara subsituind in
    %ecuatii solutiile anterioare pana la calcularea tuturor solutiilor.
end
end

