function [RetA,RetInvA] = TopZeros(A,InvA)
[m,n]=size(A); 
for l=m:-1:2
    for k=l-1:-1:1 
        coef=A(k,l)/A(l,l); 
        A(k,:)=A(k,:)-coef*A(l,:); 
        InvA(k,:)=InvA(k,:)-coef*InvA(l,:);
    end %parcurge fiecare linie de deasupra pivotului curent si calculeaza zero-urile
end %parcurge fiecare pivot exceptand primul( nu are zero-uri deasupra)
RetA=A; 
RetInvA=InvA; 
end

