%%

% ============================== Exercitiul 1 =============================

% Descrierea Algoritmului:
% Bordam oare?
% 1. Bordam matricea A cu matricea identitate, si aplicam fiecare
% tranformare pe intreaga matrice

% bun
% 2. Aplicam Metoda Gauss fara pivotare/Cu Pivotare Partiala tinand cont
% de fiecare data cand interschimbam o linie, multiplicand determinantul cu
% -1

% si mai bun
% 3. Calculam determinantul ca fiind produsul elementelor de pe diagonala
% principala inmultit cu semnul determinantului

% Neclar, insa + 5 , inteleg ce faci.
% 4. Transformam elementele de pe diagonala principala in pivoti cu
% valoarea 1 si tranformam elementele de deasupra diagonalei principale in
% 0 prin transformari elementare(Adunari/Scaderi de linii)

% 5. In submatricea din stanga vom avea ca rezultat matricea identitate iar
% in dreapta vom avea ca rezultat inversa matricei A


%%

%=============================== Exercitiul 2 =============================


A = [4 2 2;2 10 4; 2 4 6];

[invA,detA] = GaussJordan(A);

disp('Inversa matricei A este: ');
% pune si tu 'disp(A)' sau pune tot mesajul cu 'fprintf'. Valabil si mai
% jos
invA

disp('Determinantul matricei A este: ');
detA

b = [12;30;10];

x = invA * b;

disp('Solutia ecuatiei Ax = b este: ');

x

%%
% =========================== Exercitiul 4 ================================

% Descrierea algoritmului
% 1. Initializam matricea L cu I(matricea identitate)
% 2. Aplicam metoda Gauss fara pivotare, cu o  modificare: 
% la fiecare pas, vom stoca in matricea L elementele de sub diagonala 
% principala, impartite la pivot
% 
% 3. In urma aplicarii algoritmului, matricea U va fi egala cu matricea Ae
%(matricea rezultata)
% 4. Aplicam substitutia ascendenta pentru sistemul Uy = b
% 5. Aplicam substitutia descendenta pentru sistemul Lx = y

%% 

%============================ Exercitiul 5 ================================

A = [0 1 1; 2 1 5; 4 2 1];
b = [3;5;1];

[L,U,x] = FactLU(A,b);

disp('Matricea L');
L

disp('Matricea U');
U

disp('Solutia ecuatiei Ax = b este: ');

x

%%

%============================ Exercitiul 7 ================================

A = [1 2 3; 2 5 8; 3 8 14];
b = [-5;-14;-25];

[x,L] = FactCholesky(A,b);

disp('Matricea rezultata L este: ')

L

disp('Solutia sistemului este: ')

x

%%

function [invA,detA] = GaussJordan(A)

[n,~] = size(A);

% De ce o hard-codezi? -> eye(n) (dinamic)
Ae = [A eye(3,3)];
determinant = 1;

for k = 1:n-1
    
   [maxim,index] = max(abs(Ae(k:n,k) ~= 0)); % Cautam maximul pe linia curenta 
   
   if maxim == 0
      fprintf('Sistem incompatibil / Sistem compatibil nedet\n');
      x = infinity; % x = Inf
      return %Oprim algoritmul
   end
   
   index = index + k - 1;
   
   if index ~= k
       Ae([k index],:) = Ae([index k],:); % Interschimbam liniile
       determinant = determinant * (-1);
   end
   
   for l = k+1:n
      factor = Ae(l,k) / Ae(k,k); % Calculam raportul pentru a transforma
                                  % elementele de sub diagonala principala
                                  % in 0
                                  
      Ae(l,:) = Ae(l,:) - factor * Ae(k,:); 
   end
  
end

determinant = determinant * prod(diag(Ae));


for k = n:-1:1
   Ae(k,:) = Ae(k,:) / Ae(k,k);
     
   for l = k-1:-1:1
      factor = Ae(l,k) * Ae(k,k);
      
      Ae(l,:) = Ae(l,:) - factor * Ae(k,:);
   end
end

detA = determinant;
invA = Ae(1:n,n+1:end);

end
%%
function x = SubsAsc(A,b)

[n, ~] = size(A); % Dimensiunea matricei A

x(1) = (1/A(1,1)) * b(1); % Aflam elementul xn

k = 2;

% Iteratiile algorimtului

while k <= n  
   product = sum(A(k,1:k-1) .* x(1:k-1)); % Calculam suma din
                                          % produsul scalar 
                                                                             
   x(k) = (1/A(k,k)) * (b(k) - product); % Aflam x(k)
   k = k + 1;
end


end
%%
function [L,U,x] = FactLU(A,b)

infinity = inf(1);

[n, ~] = size(A); % Dimensiunea matricei A

Ae = A;

L = eye(n);

p = zeros(1,n - 1);

for k = 1:n-1
    
   [maxim,index] = max(Ae(k:n,k) ~= 0); % Cautam maximul pe linia curenta 
   
   if maxim == 0
      fprintf('Sistem incompatibil / Sistem compatibil nedet\n');
      x = infinity;
      return %Oprim algoritmul
   end
   
   index = index + k - 1; % Incrementam indicele liniei deoarece
                          % Submatricea va avea linii de la 1 la k
   
   if index ~= k
       Ae([k index],:) = Ae([index k],:); % Interschimbam liniile
       b([k index],:) = b([index k]);
   end
   
   p(k) = index;
   
   for i = k+1:n
        L(i,k) = Ae(i,k) / Ae(k,k);
   end
   
   for l = k+1:n
      factor = Ae(l,k) / Ae(k,k); % Calculam raportul pentru a transforma
                                  % elementele de sub diagonala principala
                                  % in 0
                                  
      Ae(l,:) = Ae(l,:) - factor * Ae(k,:); 
   end
   
end

if Ae(n,n) == 0
    fprintf('Sistem incompatibil sau sist comp nedet\n');
    x = infinity;
    return;
end

U = Ae;

y = SubsAsc(L,b);
x = SubsDesc(U,y);

end
%%
function [x,L] = FactCholesky(A,b)

[n,~] = size(A);

if(A(1,1) <= 0)
    disp('A nu este pozitiv definita')
    x = -1;
    L = -1;
    return;
end

L = zeros(size(A));

L(1,1) = sqrt(A(1,1));

L(2:end,1) = A(2:end,1) / L(1,1);

for k = 2:n
    
    alfa = A(k,k) - sum(L(k,1:k-1).^2);
    
    if alfa <= 0
        disp('A nu este pozitiv definita');
        x = -1;
        L = -1;
        return
    end
    
    L(k,k) = sqrt(alfa);
    
    for i = k+1:n
        L(i,k) = (A(i,k) - sum(L(i,1:k-1) * L(k,1:k-1))) / L(k,k); 
    end
     
end

y = SubsAsc(L,b);
x = SubsDesc(L',y);

end




