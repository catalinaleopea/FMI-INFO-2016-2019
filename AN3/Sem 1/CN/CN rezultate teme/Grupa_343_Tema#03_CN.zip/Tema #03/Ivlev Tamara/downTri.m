function [MatriceDown] = downTri(Matrice)
%downTri nu interschimba randuri. upTri se executa prima
[n,~] = size(Matrice);
for col = 1:n
    if ( Matrice(col,col) == 0)
        disp("Matricea nu are forma triunghiulara inferioara");
    end
    
    for lin = col-1:-1:1
        if( Matrice(lin,col)~= 0 ) %evitam impartirea la 0
            factor = -1 * Matrice(lin,col) / Matrice(col,col);
            Matrice(lin,:) = Matrice(lin,:) + factor * Matrice(col,:);
        end
    end          
end
MatriceDown = Matrice;
end

