% 1. 10
% 2. 10
% 3. -
% 4. -
% 5. -
% 6. 8
% 7. 8
% Total: 36/70 i.e. 5.14/10

% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Foloseste Gauss Jordan pentru a calcula inversa si determinantul 
% matricei A
% =========================================================================
clear;

A = [1   1   4   1;
     2   2  10   6;
     3   9  21  17;
     5  11  29  23]; %Initierea matricei A
 
InvA = gjMatInv(A);
disp ("Inversa lui A este: ");
disp (InvA);

DetA = gjDet(A);
disp ("Determinantul lui A este: ");
disp (DetA);
