function [MatriceUp] = upTri(Matrice)

[n,~] = size(Matrice);
for col = 1:n
    if ( Matrice(col,col) == 0)
        for lin = col+1:n
            if ( Matrice(lin,col)~= 0 )
                aux = Matrice(lin,:);
                Matrice(lin,:) = Matrice(col,:);
                Matrice(col,:) = aux;
                break;
            end
        end
        if( Matrice(col,col) == 0)
            disp("Matricea nu are forma triunghiulara superioara");
        end
    end
    
    for lin = col+1:n
        if( Matrice(lin,col)~= 0 )
            factor = -1 * Matrice(lin,col) / Matrice(col,col);
            Matrice(lin,:) = Matrice(lin,:) + factor * Matrice(col,:);
        end
    end          
end
MatriceUp = Matrice;
end

