function [Det] = gjDet(Matrice)
MatUp = upTri(Matrice);
[n,~] = size(Matrice); 
Det = 1;
for col = 1:n
    Det = Det * MatUp(col,col);
end
Det = Det * -1;
end

