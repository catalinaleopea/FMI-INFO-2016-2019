% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Rezolvare ex 2
% =========================================================================
clear;

A = [4  2 2;
     2 10 4;
     2  4 6]; %Initierea matricei A
b = [12 30 10]; %Initiere vector B
 
[invA, detA] = GaussJordan(A);
disp ("Inversa lui A este: ");
disp (invA);

disp ("Determinantul lui A este: ");
disp (detA);

Solutie = gjRezolvareSistem(A,b);
disp("Solutia sistemului este vectorul: ");
disp(Solutie);
