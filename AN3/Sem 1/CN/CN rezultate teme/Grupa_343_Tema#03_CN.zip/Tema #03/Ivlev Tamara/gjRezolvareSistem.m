function [Solutie] = gjRezolvareSistem(A,b)

[n,~] = size(A);
AExt = zeros(n, n+1);

for lin=1:n
    AExt(lin,:) = [A(lin,:) b(lin)];
end
AExt = upTri(AExt);
AExt = downTri(AExt);

Solutie = zeros(n,1);
for lin=1:n
%matricea mea ar putea avea ca pivoti nr oarecare, care nu sunt 1, asa ca
%impartim fiecare linie prin pivotul sau
    AExt(lin,:) = AExt(lin,:) / AExt(lin,lin);
    Solutie(lin) = AExt(lin,n+1);
end
end


