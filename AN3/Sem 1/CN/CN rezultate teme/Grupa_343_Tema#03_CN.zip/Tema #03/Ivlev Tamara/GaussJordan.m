function [invA, detA] = GaussJordan(A)

invA = gjMatInv (A);
detA = gjDet (A);

end

