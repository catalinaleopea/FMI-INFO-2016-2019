function [MatInv] = gjMatInv(Matrice)
[n,~] = size(Matrice);
I = eye(n);
MatExt = zeros(n, 2*n);

for lin=1:n
    MatExt(lin,:) = [Matrice(lin,:) I(lin,:)];
end
MatExt = upTri(MatExt);
MatExt = downTri(MatExt);

MatInv = zeros(n);
for lin=1:n
%matricea mea ar putea avea ca pivoti nr oarecare, care nu sunt 1, asa ca
%impartim fiecare linie prin pivotul sau
    MatExt(lin,:) = MatExt(lin,:) / MatExt(lin,lin);
    MatInv(lin,:) = MatExt(lin,n+1:n*2);
end
end

