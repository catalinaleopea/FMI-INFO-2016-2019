function [vectX,L] = factCholesky(A,b)

[n,~]=size(A);
%verific daca A=AT
AT = transpMat(A);
if(AT == A)
    %verific daca A este pozitiv definita
    % Nu asa -> cu criteriul lui Sylvester
    for i=1:n
        if(A(i,i)<0)
            disp("Nu este pozitiv definita");
            return;
        end
    end
    
    L = zeros (n);
    for k=1:n
        x = 0;
        for s=1:k-1
            x = x + L(k,s)*L(k,s);
        end
        L(k,k) = sqrt (A(k,k) - x);
        
        for i=k+1:n
            y = 0;
            for s=1:k-1
                y = y + L(i,s)*L(k,s);
            end
            L(i,k) = 1/L(k,k) *(A(i,k) - y);
        end
    end
    
    vectY = zeros (1,n);
    for i=1:n
        sum = 0;
        for j=1:i-1
            sum = sum + L(i,j)*vectY(j);
        end
        vectY(i) = (b(i) - sum) / L(i,i);
    end
    
    LT = transpMat(L);
    vectX = zeros (1,n);
    for i=n:-1:1
        sum = 0;
        for j=i+1:n
            sum = sum + LT(i,j)*vectX(j);
        end
        vectX(i) = (vectY(i) - sum) / LT(i,i);
    end
end
end

