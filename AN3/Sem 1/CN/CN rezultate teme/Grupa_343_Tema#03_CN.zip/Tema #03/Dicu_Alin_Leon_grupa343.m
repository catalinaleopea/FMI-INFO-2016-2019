% 1. 10
% 2. 7
% restul = 0
% Total: 17/70 i.e. ~2.5/10

%tema 3 - Dicu Alin-Leon - grupa 343

% Atentie ca 'tipa' dupa ce redenumesti fisierul, cum ar fi in acest caz.
% % % function Tema3
% % %     %ca sa nu imi mai tipe ca nu are functia Tema3 xD
% % %     Exercitiul2;
% % % end

%Exercitiul 1 10/10

%Daca primesc matricea A si concatenez langa ea matricea identitate.Apoi
%aplic gauss cu pivotare partiala pentru a face in matricea superior
%triunghiulara ( ca sa fac tot 0 sub diagonala principala ) si apoi aplic
%tranformari elementare sa fac 0 deasupra diagonalei principale.
%Ca sa pot sa fac 1 pe matricea curenta,practic inmultesc linia cu 
%1/elem(l,l). Daca am avut ca input A si eu am setat ca  
%b = eye(n) => A*x=b => x = A^(-1) xD

%

%Exercitiul 2 -> 7/10 Nu pot sa punctez si aplicarea metodei pentru ca nu 
% rezolvi nimic, ci doar initiezi o matrice si un vector :(.

function Exercitiul2
    A = [4 2 2;2 10 4;2 4 6];
    b = [12;30;10];
end

%

%Metode ajutatoare

%Metoda Gauss-Jordan

function [InvA,detA] = MetGaussJordan(A)
    n = length(A);
    I = eye(n);
    %facem cum am explicat la ex1
    [AI] = GaussPivotarePartiala(A,I);
    %transformarile necesare pentru a forma matricea inferior triunghiulara
    for j = 2 : n
       for i = 1 : j-1
           if(AI(i,j) ~= 0)
               m = AI(i,j)/AI(j,j);
               AI(i,:) = AI(i,:) - m*AI(j,:);
            end
        end
    end
    %finally,tot ce mai trebuie sa facem este sa facem 1 pe diagonala
    %principala,dar si calculam determinatul
    %Cine e determinantul? Mpai din moment ce avem peste tot mai putin pe
    %diagonala princiapala valori nule, atunci determinatul,indiferent de
    %dimensiunea matricii este fix produsul elementelor de pe diagonala
    %principala
    detA = 1;
    for i = 1 : n
        detA = detA * AI(i,i);
        m = 1. / AI(i,i);
        AI(i,:) = AI(i,:) .* m;
    end
    %inversa este partea dreapta a matricii extinse,am explicat la EX1
    InvA = AI(1:n, n+1:2*n);
end

%

%Metoda Gauss Fara pivotare ( Pentru Ex1 )

function [A] = GaussFaraPivotare(A,b)
    ab = [A,b];
    n = length(b);
    for k = 1 : n-1
        i = 0;
        for p = k : n-1
           if(ab(p,k) ~= 0)
               i = 1;
               break;
           end
        end
        if(i == 0)
           %nu a fost gasit
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
        end
        if(p ~= k)
            %interschimb liniile ( linia p cu linia k )
            ab([k,p],:) = ab([p,k],:);
        end
        for l = k+1 : n-1
           mlk = ab(l,k) / ab(k,k);
           ab(l,:) = ab(l,:) - mlk*ab(k,:);
        end
    end
    A = ab;
end

%

%Gauss Pivotare Partiala ( Pentru Ex 1 )

function [A] = GaussPivotarePartiala(A,b)
    %Matricea extinsa
    ab = [A,b];
    for k = 1 : length(b) - 1
        %Determinam primul indice
        i = 0;
        max = min(abs(ab(k:n,k))) - 1;
        for p = k : length(b)
           if(abs(ab(p,k)) > max)
               max = abs(ab(p,k));
               i = 0;
           end
        end
        %acum avem maximul in valoare absoluta de pe coloana k,aflat sub
        %diagonala principala a matricii A
        if(i == 0)
            %conform cursului
            disp('Sistem incop. sau sistem comp. nedet.');
            break;
        end
        if(p ~= k)
            % Li <-> Lk (unde max = a(p,k))
            ab([k,i],:) = ab([i,k],:);
        end
        for l = k+1 : n
           %Facem 0 sub diagonala principala
           mlk = ab(l,k)/ab(k,k);
           ab(l,:) = ab(l,:) - mlk*ab(k,:); 
        end
    end
    if(ab(length(b),length(b)) == 0)
        %conform cursului
        disp('Sistem incop. sau sistem comp. nedet.');
    end
    A = ab;
end

%