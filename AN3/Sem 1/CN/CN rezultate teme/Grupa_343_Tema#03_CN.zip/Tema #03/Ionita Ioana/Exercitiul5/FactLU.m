% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului
% 'b'       = vector coloana reprezentand termenul din dreapta in cadrul
% sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% L         = matrice inferior triunghiulara
% U         = matrice superior triunghiulara
% x         = vectorul solutiilor sistemului
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ L, U, x ] = FactLU( A, b )
n = length(b);          % dimensiunea vectorului b
% initializez matricea L cu matricea identitate, deoarece L are pe 
% diagonala principala 1, iar sub diagonala urmeaza sa calculez 
% raporturile de forma m(l, k) = A(l, k)/A(k, k)
L = eye(n);             
for k = 1:n-1
    maxim = A(k, k);    % initializez maximul 
    p = k;              % retin linia pe care se afla maximul
    for j = k+1:n       % caut maximul sub linia k, pe coloana k
        if abs(A(j, k)) > maxim
            maxim = abs(A(j, k));   %actualizez maximul si indicele acestuia
            p = j;
        end
    end
    if maxim == 0       
        disp ('Sistem incompatibil sau sistem compatibil nedeterminat.');
        break;
    end
    if p ~= k          % daca maximul nu se afla pe linia k
        aux = A(p, :);  %interschimb cele 2 linii
        A(p, :) = A(k, :);
        A(k, :) = aux;
        aux = b(p);
        b(p) = b(k);
        b(k) = aux;
    % in matricea L interschimb elementele de sub diagonala principala 
    % (doar acolo am valori) a i sa corespunda cu interschimbarile
    % efectuate in matricea A 
        if k > 1        
            for r = 1:k-1
                aux = L(p, r);
                L(p, r) = L(k, r);
                L(k, r) = aux;
            end
        end
    end
    for l = k+1:n
        L(l, k) = A(l, k)/A(k, k);      %initializez L(l, k)
        A(l, :) = A(l, :) - A(l, k)/A(k, k)*A(k, :);
    end
end
if A(n, n) == 0
    disp('Sistem incompatibil sau sistem compatibil nedeterminat');
end
U = A;              %primele n coloane din A formeaza o matrice superior
                    %triunghiulara, a carei valoare o preia U
y = SubsAsc(L, b);
x = SubsDesc(U, y);
end

