% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Calculeaza matricea inferior triunghiulara, L, si pe cea superior
% triunghiulara, U, al caror produs il reprezinta matricea A, cat si 
% solutia sistemului Ax = b
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================

A = [0 1 1; 2 1 5; 4 2 1];
b = [3; 5; 1];
[L, U, x] = FactLU(A, b);