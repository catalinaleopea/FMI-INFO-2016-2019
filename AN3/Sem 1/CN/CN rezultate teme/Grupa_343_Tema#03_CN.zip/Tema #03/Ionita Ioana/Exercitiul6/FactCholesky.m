% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului (simetrica si pozitiv definita)
% 'b'       = vector coloana reprezentand termenul din dreapta in cadrul
% sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = vectorul solutiilor sistemului
% 'L'    = matrice inferior triunghiulara, L*L.' reprezentand scrierea 
% matricei A ca produs de matrice inferior si matrice superior
% triunghiulara
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ x, L ] = FactCholesky( A, b )
if A(1, 1) <=0              %daca primul minor principal nu e strict
                            %pozitiv, matricea nu e pozitiv definita
    disp('A nu este pozitiv definita'); 
    return;
end
n = size(b);
L(1, 1) = sqrt(A(1, 1));    %la inmultirea matricei L cu transpusa ei, 
                            %elementul de pe pozitia(1, 1) va ramane pe loc
                            %astfel, valoarea sa poate fi determinata
                            %direct
for i = 2:n     
    L(i, 1) = A(i, 1)/L(1, 1);  %prima linie din L contine doar L(1, 1)
                                %deci determin trepta toate elementele
end                             %care au fost inmultite cu L(1, 1)
%restul elementelor din matrice le calculez pe baza celor stiute si 
%inlocuind in ecuatiile obtinute prin inmultirea lui L cu transpusa ei
%si egaland cu elementele matricei A
for k = 2:n                     
   suma = 0;                    
   for s = 1:k-1                
       suma = suma + L(k, s).^2;
   end
   alfa = A(k, k) - suma;
   if alfa<=0           
       disp('A nu este pozitiv definita');
       break;
   end
   L(k, k) = sqrt(alfa);    
   for i = k+1:n
       suma = 0;
       for s = 1:k-1
           suma = suma + L(i, s)*L(k, s);
       end
       L(i, k) = 1/L(k, k)*(A(i, k) - suma);
   end
end
%inlocuind LL.' in Ax = b, se obtine LL.'x = b
%notez L.'x = y si obtin Ly = b, deci voi calcula mai intai y aplicand
%metoda substitutiei ascendente, si determin x din L.'x = y aplicand
%metoda substitutiei descendente
y = SubsAsc(L, b);
x = SubsDesc(L.', y);
end

