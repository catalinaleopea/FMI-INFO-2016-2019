% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului(inferior triunghiulara)
% 'b'       = vector coloana reprezentand termenul din dreapta in cadrul
% sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = vectorul solutiilor sistemului
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [ x ] = SubsAsc( A, b )
n = length(b);  
x(1) = b(1)/A(1, 1);        %plec de la prima ecuatie, unde singura 
                            %necunoscuta este x(1)
k = 2;                      
while k<=n                  %calculez treptat necunoscutele de sus in jos
    sum = 0;                %pot calcula aceasta suma, stiind x1,...xk-1
    for j = 1:k-1           
        sum = sum + A(k,j)*x(j);
    end 
    x(k) = 1/A(k, k)*(b(k)-sum); %scazand suma, am iar o ecuatie cu o     
    k = k+1;                     %singura necunoscuta si trebuie doar sa 
end                              %impart la coeficientul A(k, k) pentru a-l
                                 %afla pe xk
end