% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% invA      = inversa matricei A
% detA      = determinantul matricei A
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================

function [ invA, detA ] = GaussJordan( A )
n = size(A);        %dimensiunea matricei A
I = eye(n);         %matricea identitate de aceeasi dimensiune cu A
A = [A I];          %matricea extinsa formata din A si I

for k =1:n-1        %aplic metoda Gauss fara pivotare
    max = abs(A(k,k));  %initializez maximul
    p = k;              
    for j = k:n
        if abs(A(j, k)) > max   %daca gasesc alt maxim, retin pozitia si
            max = abs(A(j, k)); %valoarea acestuia
            p = j;
        end
    end
    if p ~= k                   %se interschimba linia p cu linia k
        A([p, k], :) = A([k ,p], :); %astfel vad si ce modificari am in
    end                             %matricea initiala I (ultimele n coloane
                                    %din matricea extinsa)
    for l = k+1:n
        m(l, k) = A(l, k) / A(k, k);
        A(l, :) = A(l, :) - m(l, k)*A(k, :);
    end
end
for i  = 1:n                   %aplic metoda substitutiei descendente pentru
                               %fiecare necunoscuta a sistemului
    x(i, :) = SubsDesc(A(:, 1:n), A(:, (n+i)));
end
invA = x;
detA = 1;
for i = 1:n         %stiu ca matricea A este acum superior triunghiulara,
                    %deci determinantul este reprezentat de produsul    
                    %valorilor de pe diagonala principala
    detA = detA * A(i, i);
end
end

