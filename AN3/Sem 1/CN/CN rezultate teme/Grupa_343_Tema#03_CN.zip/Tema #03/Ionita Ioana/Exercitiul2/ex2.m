% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Calculeaza inversa si determinantul unei matrice A date, apoi rezolva
% ecuatia Ax = b, folosind metoda GaussJordan.
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================

A = [4 2 2; 2 10 4; 2 4 6];
[invA, detA] = GaussJordan(A);      %apelarea metodei GaussJordan
b = [12; 30; 10];
x = invA * b;
