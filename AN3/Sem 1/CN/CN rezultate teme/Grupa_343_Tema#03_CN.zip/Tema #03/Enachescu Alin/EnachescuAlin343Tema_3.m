% 1. -
% 2. -
% 3. 4 :( Din pacate, admite factorizare LU. Nu ai pregatit matricea A bine
% 4. -
% 5. 10
% 6. 10
% 7. -
% Total: 24/30 i.e. ~3.5/10
% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% 1. Apelez FactLU pentru exercitiul 3 punctul b
% 2. Apelez FactCholesky pentru exercitiul 6 punctul c
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

% exercitiul 3 punctul b
% initializez matricea A cu coeficientii necunoscutelor din sistem
A = [0, 1, 1; 2,1, 5; 4, 2, 1];
% initializez vectorul b cu valorile de dupa egal
b = [3, 5, 1];

fprintf('FactLU pentru:\n');
A
b
fprintf('\n');

% apelez FactLU
[L, U, x] = FactLU(A, b);

% afisez output-ul
L
U
x

% exercitiul 6 punctul c
% initializez A cu matricea A de la exercitiul 6
A = [1, 2, 3; 2, 5, 8; 3, 8, 14];
% initializez b cu b-ul definit la exercitiul 6 punctul c
b = [-5, -14, -28];

fprintf('FactCholesky pentru:\n');
A
b
fprintf('\n');

% apelez FactCholesky
[x, L] = FactCholesky(A, b);

% afisez output-ul
x
L
