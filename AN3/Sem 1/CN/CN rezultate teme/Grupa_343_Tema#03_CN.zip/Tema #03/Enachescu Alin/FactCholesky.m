% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea formata din coeficientii necunoscutelor din sistem
% 'b'       = un vector format din valorile de dupa egal
% -------------------------------------------------------------------------
% Date de iesire:
% 'L'    = matricea inferior triunghiulara
% 'U'    = matricea superior triunghiulara
% 'x'    = solutia sistemului, Ax = b
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [x, L] = FactCholesky(A, b)

    % ordinul matricei
    n = size(A, 1);
    
    % initializez pe x si L cu zerouri
    x = zeros(size(b));
    L = zeros(n);
    
    % initializez pe alpha ca fiind A(1,1)
    alpha = A(1, 1);
    
    % daca alpha nu este strict pozitiv atunci initializez pe L si x cu
    % zerouri si ies din functie
    if alpha <= 0
        L = zeros(n);
        x = zeros(size(b));
        fprintf('A nu este pozitiv definita');
        return
    end % end if
    
    % initializez pe L(1,1) cu radical din alpha
    L(1,1) = sqrt(alpha);
    
    % initializez prima coloana din L (incepand cu linia a doua) cu
    % raportul dintre A(i,1) si L(1,1)
    for i = 2 : n
        L(i, 1) = A(i, 1) / L(1, 1);
    end % end for
    
    % iterez si prin celelalte coloane
    for k = 2:n
       
        % calculez suma elementelor de pe linia si k si situate sub diagonala
        % principala ridicate la patrat
        sum = 0;
        for s = 1: k-1
            sum = sum + L(k, s)^2;
        end % end for
        
        % initializez pe alpha ca fiind diferenta dintre elementul de pe
        % diagonala principala de pe linia k si suma calculata mai sus
        alpha = A(k, k) - sum; 
        
        % daca alpha nu este strict pozitiv atunci initializez pe L si x
        % cu zerouri si ies din functie
        if alpha <= 0
            L = zeros(n);
            x = zeros(size(b));
            fprintf('A nu este pozitiv definita');
            return
        end % end if
        
        % initializez elementul situat pe diagonala principala a linie k
        % ca fiind radical din alpha
        L(k, k) = sqrt(alpha);
        
        % iterez prin fiecare element situat sub diagonala principala de pe
        % coloana k
        for i = k + 1 : n
        
            % calculez suma de la s = 1 la k - 1 din L(i,s) * L(k,s)
            sum = 0;
            for s = 1 : k - 1
                sum = sum + L(i, s) * L(k, s);
            end % end for
            
            % initializez al i-lea element de pe coloana k ca fiind
            % (A(i,k) - sum) / L(k,k)
            L(i, k) = (1 / L(k, k)) * (A(i, k) - sum);
            
        end % end for
        
    end % end for
    
    % calculez pe y folosind substitutia ascendenta
    y = SubsAsc(L, b);
    
    % calculez pe x folosind substitutia descendenta
    x = SubsDesc(L.', y);

end % end function
