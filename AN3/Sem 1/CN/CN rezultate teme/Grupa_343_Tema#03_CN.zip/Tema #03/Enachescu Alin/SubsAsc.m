% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea formata din coeficientii necunoscutelor din sistem
% 'b'       = un vector format din valorile de dupa egal
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = solutia sistemlui, Ax = b
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [x] = SubsAsc(A, b)
  % lungimea vectorului b ca sa stiu cate iteratii trebuie sa fac
  n = length(b);
  % initializez pe x1
  x(1) = b(1) / A(1,1);
  
  % iterez de la 2 la n ca sa aplic ecuatia descris de algoritm
  k = 2;
  while k <= n
    % initializez suma cu 0
    sum = 0;

    % caculez suma de la j = 1 la k - 1 de A(k,j) * x(j)
    for j = 1 : k - 1
      sum = sum + A(k,j) * x(j);
    end % end for

    % calculez xk ca fiind (1 / Akk) * (bk - suma de la j = 1 la k-1 de
    % A(k,j) * x(j))
    x(k) = 1 / A(k,k) * (b(k) - sum);

    % incrementez pe k pentru a trece la urmatorul element
    k = k + 1;
  end % end while
end % end function