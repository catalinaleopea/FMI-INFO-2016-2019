% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea formata din coeficientii necunoscutelor din sistem
% 'b'       = un vector format din valorile de dupa egal
% -------------------------------------------------------------------------
% Date de iesire:
% 'L'    = matricea inferior triunghiulara
% 'U'    = matricea superior triunghiulara
% 'x'    = solutia sistemului, Ax = b
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [L, U, x] = FactLU(A, b)
    % calculez ordinul matricei
    n = size(A, 1);
    
    % initializez L, U si x cu zerouri
    L = zeros(n);
    U = zeros(n);
    x = zeros(size(b));
    
    % copiez prima linie din A in U
    U(1,:) = A(1,:);
    
    % daca U(1,1) e 0 atunci A nu admite factorizare LU si returnez
    % L, U si x initializate cu zerouri
    if U(1,1) == 0
        fprintf('A nu admite factorizare LU\n');
        L = zeros(n);
        U = zeros(n);
        x = zeros(size(b));
        return
    end % end if

    % initializez coloana 1 a lui L
    for i = 1 : n
        % initializez al i-lea numar de pe coloana 1 a lui L cu raportul dintre
        % al i-lea numar de pe coloana 1 a lui A si elementul U(1,1)
        L(i,1) = A(i, 1) / U(1, 1);
    end % end for

    % iterez pentru a initializa si restul elementelor
    for k = 2 : n

        % initializez elementele din U de deasupra diagonalei principale
        % dar care sunt situate intre coloanele k si n si pe linia j
        for j = k : n
            % calculez suma din produsul elementelor de pe linia k din matricea
            % L si elementelor de pe coloana j din matricea U
            sum = 0;
            for s = 1 : k - 1
                sum = sum + L(k, s) * U(s, j);
            end % end for
            
            % initializez pe U(k,j) ca fiind A(k,j) - sum
            U(k,j) = A(k,j) - sum;
        end % end for
        
        % daca U(k,k) e 0 atunci A nu admite factorizare LU si returnez
        % L, U si x initializate cu zerouri
        if U(k,k) == 0
            fprintf('A nu admite factorizare LU\n');
            L = zeros(n);
            U = zeros(n);
            x = zeros(size(b));
            return
        end % end if
        
        % initializez elementele din L de sub diagonala principala
        % dar care sunt situate intre liniile k si n dar pe coloana j
        for i = k : n
            % calculez suma din produsul elementelor de pe linia i din matricea
            % L si elementelor de pe coloana k din matricea U
            sum = 0;
            for s = 1 : k - 1
                sum = sum + L(i, s) * U(s, k);
            end % end for
            
            % initializez pe L(i,k) ca fiind (A(i,k) - sum) / U(k,k)
            L(i, k) = (1 / U(k, k)) * (A(i, k) - sum);
        end % end for

    end % end for
    
    % calculez pe y folosind substitutia ascendenta
    y = SubsAsc(L, b);
    
    % calculez pe x folosind substitutia descendenta
    x = SubsDesc(U, y);

end % end function
