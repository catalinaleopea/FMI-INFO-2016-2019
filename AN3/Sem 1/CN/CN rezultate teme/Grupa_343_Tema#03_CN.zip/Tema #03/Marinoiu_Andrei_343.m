% 5. 7/10
% 7. 10
% Restul: 0
% Total: 17/70 i.e. ~2.5/10
% Tema 3 Marinoiu Andrei Gr. 343
% Exercitiul 7
function Marinoiu_Andrei_343()

% Initializam datele conform enuntului
A = [1 2 3;2 5 8;3 8 14];
b = [-5 -14 -25];

[x,L] = FactCholesky(A,b'); % Apelam functia specifica metodei Cholesky

disp(x); % Afisare solutie
disp(L); % Afisare matrice inferior triunghiulara

end

% Functie specifica metodei Cholesky

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% x -> solutia sistemului
% L -> matrice inferior triunghiulara

% Algoritmul este implementat dupa pseudocodul aflat in cursul 3,pagina 18.
function [x,L] = FactCholesky(A,b)

alfa = A(1,1);

% Verificam daca prima componenta de pe diagonala princiapal este pozitiva
if(alfa <= 0)
    fprintf("A nu este pozitiv definita!");
    return;
end
  
L = zeros(length(A)); % Initializam o matrice de n x n cu 0
L(1,1) = sqrt(A(1,1)); % Calculam primul element din matricea inferior
%triunghiulara

% Calculam restul elementelor de pe coloana 1 din matricea inferior
%triunghiulara
for i = 2:length(A)
    L(i,1) = A(i,1) / L(1,1);
end

% Iteratiile algoritmului
for k = 2:length(A)
    sum = 0;
    
    for s = 1:(k - 1)
      sum = sum + L(k,s) ^ 2;
    end
    
    alfa = A(k,k) - sum;
    
    if(alfa <= 0)
      fprintf("A nu este pozitiv definita!");
      return;
    end
    
    L(k,k) = sqrt(alfa);
    
    for i = (k + 1):length(A)
      sum = 0;
      
      for s = 1:(k - 1)
        sum = sum + L(i,s) * L(k,s);
      end
      
      L(i,k) = (A(i,k) - sum) / L(k,k);
    end
end
  
y = SubsAsc(L,b);
x = SubsDesc(L',y);
  
end

% Functie specifica metodei substitutiei ascendente (Ex. 5,subpunctul a)

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% x -> solutiile sistemului

% Algoritmul este implementat dupa pseudocodul aflat in cursul 3,pagina 4.
function [x] = SubsAsc(A,b)

x = zeros(length(A),1); % Initializam matricea de 3 linii si o coloana cu 0
x(1) = b(1) / A(1,1); % Aflam x(1) conform %definitiei

% Iteratiile algoritmului
for k = 2:length(A)
    sum = 0;
    
    for j = 1:(k - 1)
        sum = sum + A(k,j) * x(j);
    end
    
    x(k) = (b(k) - sum) / A(k,k);
end

end


% Functie specifica metodei substitutiei descendente

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% x -> solutiile sistemului

% Algoritmul este implementat dupa pseudocodul aflat in cursul 2,pagina 4.
function [x] = SubsDesc(A,b)

x = zeros(length(A),1); % Initializam matricea de 3 linii si o coloana cu 0
x(length(A)) = b(length(A)) / A(length(A),length(A)); % Aflam x(n) conform
%definitiei
k = length(A) - 1; % Initializare k

% Iteratiile algoritmului
while(k > 0)
    sum = 0;
    
    for j = k + 1:length(A)
        sum = sum + A(k,j) * x(j);
    end
    
    x(k) = (b(k) - sum) / A(k,k);
    k = k - 1;
end
  
end