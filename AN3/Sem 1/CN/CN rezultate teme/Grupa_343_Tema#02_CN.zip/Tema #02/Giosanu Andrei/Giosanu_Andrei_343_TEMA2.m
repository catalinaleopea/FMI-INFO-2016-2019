% Giosanu Andrei
% Grupa 343
% ----------
% Codul este bunicel, insa pe viitor te rog sa pui si mesaje la consola cu
% fprintf. 
% 1. -
% 2. 10/10
% 3. 9/10 -> Comparatia de la c.?
% Total: 19/30 i.e. 6.33/10

A=[0 1 1; 2 1 5; 4 2 1];
% Poti declara direct vector linie si apoi sa il transpui in coloana
% B = [3 5 1]';
B= [3; 5; 1];
A1 = [0 1 -2; 1 -1 1; 1 0 -1];
B1 = [4; 6; 2];
A2 = [10.^(-20) 1; 1 1];
B2 = [1; 2];
A3 = [1 10.^20; 1 1];
B3 =[10.^20; 2];

%ex-3
%b)

X1 = GaussFaraPiv(A,B);
X2 = GaussPivPart(A,B);
X3 = GaussPivTot(A,B);
X4 = GaussFaraPiv(A1,B1);
X5 = GaussPivPart(A1,B1);
X6 = GaussPivTot(A1,B1);

%c)
X7 = GaussFaraPiv(A2,B2);
X8 = GaussPivPart(A2,B2);
X9 = GaussPivPart(A3,B3);
X10 = GaussPivTot(A3,B3);

%ex-2
function X = subsDesc(A, B)
N = length(B);
X(N) = B(N)/A(N,N);
for i=N-1:-1:1
    % Bun
    X(i) = (B(i) - sum(A(i,i+1:N).*X(i+1:N)))/A(i,i);
end
end

%ex-3 
%a)
function [ X ] = GaussFaraPiv(A,B)
% Virgula nu este necesara
A = [A,B];
N= length(B);
for k = 1:N-1
    p = -1;
    for i=k:N
        if A(i,k) ~= 0
            p = i;
            break;
        end
    end
    if p == -1
        disp('Sistemul este incompatibil sau compatibil nedeterminat');
        X = 0;
        return;
    elseif p ~= k
        % Bun
        A([k,p],:) = A([p,k],:);
    end
    for i=k+1:N
        A(i,:) = A(i,:) -  (A(i,k)/A(k,k))*A(k,:);
    end
end
if A(N,N) == 0
    % :) -> Poate e rau! 
    disp('Sistemul nu este bun');
    X = 0;
    return;
end
B = A(:,N+1);
A(:,N+1) =[];
X = subsDesc(A,B);

end

function [ X ] = GaussPivPart(A,B)
A = [A,B];
N= length(B);
for k = 1:N-1
    p = -1;
    vmax = max(abs(A(k:N,k)));
    for i=k:N
        if abs(A(i,k)) ==  vmax
            p = i;
            break;
        end
    end
    if vmax == 0
        disp('Sistemul este incompatibil sau compatibil nedeterminat');
        X = 0;
        return;
    elseif p ~= k
        A([k,p],:) = A([p,k],:);
    end
    for i=k+1:N
        A(i,:) = A(i,:) -  (A(i,k)/A(k,k))*A(k,:);
    end
end
if A(N,N) == 0
    disp('Sistemul nu este bun');
    X = 0;
    return;
end
B = A(:,N+1);
A(:,N+1) =[];
X = subsDesc(A,B);
end

function [x] = GaussPivTot(A, B)
  A = [A, B];
  n = size(A, 1);
  xi = 1:n;
  
  for k = 1 : n - 1
    p = k;
    m = k;
    for i = k : n
      for j = k : n
        if abs(A(i, j)) > abs(A(p, m))
          p = i;
          m = j;
        end 
      end 
    end
    
    if A(p, m) == 0
      disp('Sistem incompatibil sau sistem compatibil nedeterminat');
      x = 0;
      break;
    end 
    
    if p ~= k
      A([p, k], :) = A([k, p], :);
    end 
    
    if m ~= k
      A(:, [m, k]) = A(:, [k, m]);
      xi([m, k]) = xi([k, m]);
    end 
    
    for l = k + 1 : n
      A(l, :) =A(l, :) -  A(l, k) / A(k, k) * A(k, :);
    end 
  end 
  if A(n, n) == 0
    disp('Sistem incompatibil sau sistem compatibil nedeterminat');
    x = 0;
  end 
  xraw = subsDesc(A(1: n, 1: n), A(:, n + 1));
  for i = 1: n
    x(xi(i)) = xraw(i);
  end 
end 