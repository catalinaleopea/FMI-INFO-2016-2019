function [X] = SubsDesc(A,b)
[m,n]=size(A);  
X(n)=1/A(m,m)*b(m); 
k=n-1; 
while k>0 
    X(k)=1/A(k,k) *( b(k) - sum( A(k,k+1:m) .* X(k+1:m) ) ); 
    %calcularea solutiei curente prin inmultirea necunoscutelor deja
    %calculate la coeficientii acestora, scaderea acestei sume din termenul
    %liber si impartirea la coeficientul necunoscutei actuale: 
    %b(k) - termen liber de pe linia k 
    %A(k,k+1:m) coeficientii necunoscutelor de pe linia actuala 
    %X(k+1:m) - necunoscutele calculate la pasii anteriori 
    %A(k,k) - coeficientul necunoscute actuale
    k=k-1;
end
end

