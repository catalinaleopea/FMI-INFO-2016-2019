% O explicatie aproape de adevar. 
A=[ 
    10^-20 1; 
    1 1; 
    ]; 
b=[1 2]; 
X=GaussFaraPiv(A,b) 
X=GaussPivPart(A,b) 

%Rezultatele difera din cauza comportamentului algoritmilor la valori
%extreme:  

%Gauss fara pivot va folosi drept pivot epsilon, valoare extrem de mica si
%va determina o impartire la acesta (epsilon) ce va genera o valoare extrem
%de mare si predispusa la erori. 
%Gauss cu pivot partial va seleta coeficientul 1 drept fiind pivot la
%primul pas si va evita folosirea lui epsilon in calcule de magnitudine
%mica, fapt ce va duce la o aproximare catre 1 si va evita erorile.

A=[
    1 10^20;  
    1 1 
    ];
b=[10^20,2]; 
X=GaussPivPart(A,b)
X=GaussPivTot(A,b) 

%!
%Gauss cu pivot partial nu foloseste C drept pivot, consecinta ce duce la o
%situatie in care C*(2-C)/(1-c)se aproximeaza la C, fapt ce duce la
%determinarea lui X1 ca fiind 0.

%Gauss cu pivot total utilizeaza alta strategie de calcul( foloseste C
%drept pivot), fapt ce faciliteaza calcularea lui (2-C)/(1-C) si
%aproximarea acestuia la 1; acest fapt duce la determinarea lui X1 ca fiind
%(C-1)/C care este aproximat la 1.

    