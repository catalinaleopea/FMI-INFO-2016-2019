function [X] = GaussPivTot(A,b) 
X=0;
b=reshape(b,length(b),1);
A=[A b];  
[m,n]=size(A); 
% Spune-i direct permutation = 1:n
for i=1:m 
    permutation(i)=i; %memoreaza ordinea necunoscutelor pentru refacerea ulterioara a acesteia.
end 
for k=1:m-1    
      
    max=0;
    for q=k:m 
        for p=k:m  
            if abs(A(q,p))>max 
                II=q;
                JJ=p;
                max=abs(A(q,p)) ;
            end
        end
    end   %for ce determina maximum din submatricea aferenta pasului curent
    if max==0  
        fprintf("Sistem incompatibil sau compatibil nedeterminat");   
        return;
    end  
        
    if k~=II
        A([k,II],:) = A([II,k],:); 
    end  %interschimbare de linii
    
    if k~=JJ  
        A(:,[k,JJ]) = A(:,[JJ,k]);   
        aux=permutation(k);
        permutation(k)=permutation(JJ) ;
        permutation(JJ)=aux;
    end  %interschimbare de coloane si memorarea schimbarilor in permutare
    
    for l=k+1:m  
        M=A(l,k)/A(k,k); 
        A(l,:)=A(l,:)-M*A(k,:);
    end  %calculul valorilor liniilor de sub pivot in vederea obtinerii de zero-uri
end 

if A(m,m)==0 
   fprintf("Sistem incompatibil sau compatibil nedeterminat");   
   return;
end  

unpermutedX=SubsDesc(A(1:m,1:m),A(:,n))  ;
 % Spune-i direct x([permutation]) = unpermutedX;
for i=1:m  
    X(permutation(i))=unpermutedX(i);%refacerea ordinii necunoscutelor
end
