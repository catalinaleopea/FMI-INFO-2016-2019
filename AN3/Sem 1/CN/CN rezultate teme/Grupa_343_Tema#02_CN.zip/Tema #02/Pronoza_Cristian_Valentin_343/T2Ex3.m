% Bun, insa pune si tu mesaje la consola data viitoare cu fprintf
% 1. 10/10
% 2. 10/10
% 3. 10/10
% Total 30/30 i.e. 10/10
A=[ 
    0 1 1;  
    2 1 5; 
    4 2 1 
    ];
b=[3 5 1]; 
X=GaussFaraPiv(A,b) 
X=GaussPivPart(A,b) 
X=GaussPivTot(A,b)
    

A=[ 
    0 1 -2;  
    1 -1 1; 
    1 0 -1 
    ];
b=[4 6 2]; 
X=GaussFaraPiv(A,b) 
X=GaussPivPart(A,b) 
X=GaussPivTot(A,b) 

