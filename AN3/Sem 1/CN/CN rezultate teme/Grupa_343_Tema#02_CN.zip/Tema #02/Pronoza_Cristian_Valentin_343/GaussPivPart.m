function [X] = GaussPivPart(A,b) 
X=0;
b=reshape(b,length(b),1);
A=[A b];  
[m,n]=size(A); 
for k=1:m-1   
    [MAX,I]=max(abs(A(k:m,k)));  %determinarea maximului de sub pivot
    if isempty(I) 
        fprintf("Sistem incompatibil sau compatibil nedeterminat"); 
        return;
    end  
    I=I+k-1;
    if(k~=I) 
        A([k,I],:) = A([I,k],:); %interschimbarea de linii in vederea pozitionarii pivotului
    end
    
    for l=k+1:m  
        M=A(l,k)/A(k,k); 
        A(l,:)=A(l,:)-M*A(k,:);%calcularea valorilor coeficientilor de sub pivot
    end 
end 

if A(m,m)==0 
    fprintf("Sistem incompatibil sau compatibil nedeterminat");   
    return;
end  
X=SubsDesc(A(1:m,1:m),A(:,n));

end

