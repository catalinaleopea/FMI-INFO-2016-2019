% ! 
% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matrice superior triunghiulara
% 'b'       = componentele din coloana suplimentara a matricei extinse
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = solutiile sistemului liniar Ax = b
% -------------------------------------------------------------------------
% Author: Ionut Dragut, 2018
% =========================================================================

function [x] = SubsDesc(A, b)

        % In MATLAB sintaxa este n = size(A,1)
        % In GaussFaraPiv ai facut bine...
  n     = size(A)(1);           % numarul de necunoscute
  x(n)  = 1 / A(n,n) * b(n);    % primul pas al algoritmului
  k     = n - 1;  
 
% -------------------------------------------------------------------------
%                           Iteratiile algoritmului
% -------------------------------------------------------------------------

  while k > 0
      suma = 0;
      
      for j = k + 1 : n
          % += nu merge din pacate in MATLAB. Da un 'help +=' in Comand
          % Window pentru documentatie
        suma += A(k, j) * x(j);
      end % for
      
      x(k) = 1/A(k, k) * (b(k) - suma);
      k = k - 1;
  end % while
  
end % function