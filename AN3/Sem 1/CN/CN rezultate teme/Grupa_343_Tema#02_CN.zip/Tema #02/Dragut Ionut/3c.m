% ! Idem 3b
% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Calculeaza solutiile a 2 sisteme liniare folosind metodele de eliminare:
%  - Gauss fara pivotare
%  - Gauss cu pivotare partiala
%  - Gauss cu pivotare totala
% -------------------------------------------------------------------------
% Author: Ionut Dragut, 2018
% =========================================================================

e = 10^-20;
A1 = [e 1;
      1 1];
b1 = [1 2];

C = 10^20;
A2 = [1 C;
      1 1];
b2 = [C 2];

xFaraPivot  = GaussFaraPiv(A1, b1)
xPivPart1   = GaussPivPart(A1, b1)

xPivPart2   = GaussPivPart(A2, b2)
xPivTotal   = GaussPivTotal(A2, b2)

