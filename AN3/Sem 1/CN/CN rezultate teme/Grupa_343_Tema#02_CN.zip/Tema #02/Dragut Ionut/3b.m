% Din pacate ai codat folosind sintaxe din C++ si nu pot rula codul in
% MATLAB. Atentie ca sunt diferente. Apreciez ca te-ai straduit insa nu pot
% puncta cod care nu ruleaza. Cauta sa parcurgi tutorialul de pe MATHWORKS
% pe care l-am trimis sefului de grupa. Ai acolo basic-urile necesare.
% 1. 10/10
% 2. 5/10 -> C++ ~= MATLAB
% 3. 3/10 -> Idem 2.
% Total 18/30 i.e. 6/10

% !Denumirea fisierelor nu se face incepand cu cifra sau cu operatori
% aritmetici. Cauta cum anume se denumesc fisierele in MATLAB
% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Calculeaza solutiile a 2 sisteme liniare folosind metodele de eliminare:
%  - Gauss fara pivotare
%  - Gauss cu pivotare partiala
%  - Gauss cu pivotare totala
% -------------------------------------------------------------------------
% Author: Ionut Dragut, 2018
% =========================================================================

A1 = [0 1 1;
      2 1 5;
      4 2 1];
      
b1 = [3 5 1];

A2 = [0 1 -2; 
      1 -1 1;
      1 0 -1];
        
b2 = [4 6 2];

xFaraPivot1 = GaussFaraPiv(A1, b1)
xFaraPivot2 = GaussFaraPiv(A2, b2)

xPivotPart1 = GaussPivPart(A1, b1)
xPivotPart2 = GaussPivPart(A2, b2)

xPivotTotal1 = GaussPivTotal(A1, b1)
xPivotTotal2 = GaussPivTotal(A2, b2)



