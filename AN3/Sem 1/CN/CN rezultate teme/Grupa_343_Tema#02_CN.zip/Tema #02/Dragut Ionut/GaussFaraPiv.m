% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului liniar
% 'b'       = componentele din coloana suplimentara a matricei extinse
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = solutiile sistemului liniar Ax = b
% -------------------------------------------------------------------------
% Author: Ionut Dragut, 2018
% =========================================================================

function [x] = GaussFaraPiv(A, b)

  n = size(A, 1); % Asa :)
  A(:, n + 1) = b;  % extindem matricea
  
% -------------------------------------------------------------------------
%                           Iteratiile algoritmului
% -------------------------------------------------------------------------

  for k = 1: n - 1
    p = k;
    % In MATLAB '&' este '&&'
    while p <= n & A(p, k) == 0  % Se caut?? primul p cu k ??? p ??? n cu A(p, k) nenul
      p += 1;
    end % while
    
    if p == n + 1   % Nu am gasit pivot
      disp('Sistem incomp. sau sist. comp. nedet.');
      break
    end % if
    
    % != -> ~=
    if p != k   % Interschimbam liniile p si k
      A([p, k], :) = A([k, p], :);
    end % if
    
    for l = k + 1 : n   % Eliminam termenii de sub pivot
      mlk = A(l, k) / A(k, k);
      % Cauta Documentatia in Command Window -> help -=
      A(l, :) -= mlk * A(k, :);   
    end % for
  end % for
  
  if A(n, n) == 0
    disp('Sistem incomp. sau sist. comp. nedet.');
    x = [];
  else
    x = SubsDesc(A(:, 1:n), A(:, n+1));
  end % if

end; % function
