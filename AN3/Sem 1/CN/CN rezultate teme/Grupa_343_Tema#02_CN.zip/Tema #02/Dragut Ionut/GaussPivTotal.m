% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului liniar
% 'b'       = componentele din coloana suplimentara a matricei extinse
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = solutiile sistemului liniar Ax = b
% -------------------------------------------------------------------------
% Author: Ionut Dragut, 2018
% =========================================================================

function [x] = GaussPivTotal(A, b)

  n = size(A, 1);
  A(:, n + 1) = b;  % extindem matricea
  xindex = 1:n;     % pentru renumerotarea necunoscutelor
  
% -------------------------------------------------------------------------
%                           Iteratiile algoritmului
% -------------------------------------------------------------------------

  for k = 1: n - 1
    p = k;
    m = k;
    for i = k : n
      for j = k : n
        if abs(A(i, j)) > abs(A(p, m)) % Cautam pivotul cu valoarea absoluta cea mai mare in submatrice
          p = i;
          m = j;
        end % if
      end % for
    end % for
    
    if p == n + 1   % Nu am gasit pivot
      disp('Sistem incomp. sau sist. comp. nedet.');
      break
    end % if
    
    if p != k   % Interschimbam liniile p si k
      A([p, k], :) = A([k, p], :);
    end % if
    
    if m != k   % Interschimbam coloanele si retinem pozitia necunoscutelor
      A(:, [m, k]) = A(:, [k, m]);
      xindex([m, k]) = xindex([k, m]);
    end % if;
    
    for l = k + 1 : n   % Eliminam termenii de sub pivot
      mlk = A(l, k) / A(k, k);
      A(l, :) -= mlk * A(k, :);   
    end % for
  end % for
  
  if A(n, n) == 0
    disp('Sistem incomp. sau sist. comp. nedet.');
    x = [];
  else
    y = SubsDesc(A(:, 1:n), A(:, n+1));
    
    for i = 1 : n
      x(xindex(i)) = y(i);  % Renumerotam necunoscutele
    end % for 
  end % if

end; % function
