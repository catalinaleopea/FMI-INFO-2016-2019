% b
%   1
A = [0 1 1;2 1 5;4 2 1]; % pastram matricea 3x3 conform cerintei
b = [3;5;1]; % pastram matricea de solutii

x_fara = GaussFaraPiv(A,b) % aplicam Gauss fara pivotare
x_part = GaussPivPart(A,b) % aplicam Gauss cu pivotare partiala
x_tot = GaussPivTot(A,b) % aplicam Gauss cu pivotare totala

% b
%   2
A1 = [0 1 -2;1 -1 1; 1 0 -1]; % pastram matricea 3x3 conform cerintei
b1 = [4;6;2]; % pastram matricea de solutii

x1_fara = GaussFaraPiv(A1,b1) % aplicam Gauss fara pivotare
x1_part = GaussPivPart(A1,b1) % aplicam Gauss cu pivotare partiala
x1_tot = GaussPivTot(A1,b1) % aplicam Gauss cu pivotare totala

% c
%   1
epsilon = 10^(-20); % pastram valoarea lui epsilon conform cerintei
A2 = [epsilon 1;1 1]; % pastram matricea 3x3 conform cerintei
b2 = [1;2]; % pastram matricea de solutii

x2_fara = GaussFaraPiv(A2,b2) % aplicam Gauss fara pivotare
x2_part = GaussPivPart(A2,b2) % aplicam Gauss cu pivotare partiala

r = isequal(x2_fara,x2_part) % verificam solutiile obtinute

% c
%   2
C = 10^20; % pastram valoarea lui C conform cerintei
A3 = [2 2*C;1 1]; % pastram matricea 3x3 conform cerintei
b3 = [2*C;2]; % pastram matricea de solutii

x3_fara = GaussFaraPiv(A3,b3) % aplicam Gauss fara pivotare
x3_part = GaussPivPart(A3,b3) % aplicam Gauss cu pivotare partiala
x3_tot = GaussPivTot(A3,b3) % aplicam Gauss cu pivotare totala

r1 = isequal(x3_fara,x3_part,x3_tot) % verificam solutiile obtinute
