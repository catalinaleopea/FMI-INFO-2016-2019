% dam functiei datele de intrare o matrice A si o matrice b
% iar ca date de iesire solutia sistemului A*x = b, in variabila x, conform
% algoritmului din cursul 2 pag 12-13
function [x] = GaussPivPart(A, b)
  A(1:size(A,1),(size(A,1)+1)) = b; % extindem matricea
  n = size(A,1); % dimensiunea lui A
  
  % cautam primul p astfel incata modul de A(p,k) este maxim
  % conform algoritmului
  for k = 1 : n - 1 % parcurgem elementele lui A
    p = k; % pastram pasul curent si il folosim conform algoritmului
    for i = k : n % cautam maximul de pe coloana k
      if abs(A(i, k)) > abs(A(p, k))
        p = i;
      end
    end
    
    if A(p, k) == 0
      % afisam un mesaj daca p nu a fost gasit (max A = 0)
      fprintf('Sistem incompatibil sau sistem compatibil nedeterminat\n');
      break; % in acest caz vom opri cautarea
    end
    
     if p ~= k
      A([p, k], :) = A([k, p], :); % schimbam linia p cu linia k
     end
    
    % facem transformarile elemnetare pentru a obtine un sistem compatibil
    % cu cel initial
    for i = k + 1 : n
      A(i, :) = A(i,:) - (A(i, k) / A(k, k) * A(k, :));
    end
  end
  
  % daca obtinem in urma schimbarilor pe linia n coloana n zero inseamna ca
  % sistemul este incompatibil sau este compatibil nedeterminat si afisam
  % un mesaj corespunzator
  if A(n, n) == 0
    fprintf('Sistem incompatibil sau sistem compatibil nedeterminat\n');
  end
  % aplicam substitutia descendenta conform algoritmului
  x = SubsDesc(A(1:n, 1:n), A(:, n + 1)); 
end