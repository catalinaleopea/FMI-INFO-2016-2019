% ! 
% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului
% 'b'       = vector coloana reprezentand termenul din dreapta in cadrul
% 1. 10/10
% 2. 10/10
% 3. 10/10
% Total: 30/30 i.e. 10/10
%             sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = vectorul solutiilor sistemului
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [x] = SubsDesc(A,b)
n = length(b);              %plec de la ultima ecuatie
x(n) = b(n)/A(n,n);         %aici singura necunoscuta din stanga este x(n)
k = n-1;                    %calculez de jos in sus valoarea lui x(k)
while k>0                   
    sum = 0;                %determin suma de la n la k+1
    % Poti sa scapi de calcularea sumei si sa faci diret dintr-o linie de
    % cod jucandu-te cu produs scalar? Think about it! 
    for j = k+1:n           
        sum = sum + A(k,j)*x(j);
    end
    x(k) = 1/A(k,k)*(b(k) - sum);   %scazand suma, obtin o ecuatie cu 
                                    %unica necunoscuta x(k)
    k = k - 1;
end
