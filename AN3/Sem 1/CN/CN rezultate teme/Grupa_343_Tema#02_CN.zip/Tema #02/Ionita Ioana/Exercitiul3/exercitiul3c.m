% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Calculeaza solutiile sistemelor de la exercitiul 1, folosind pe rand
% metoda Gauss fara pivotare, metoda Gauss cu pivotare partiala si metoda
% Gauss cu pivotare totala.
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================

epsilon = 10^(-20);         
A1 = [ epsilon 1; 1 1];
b1 = [1 ; 2];

C = 10^20;
A2 = [1 C; 1 1];
b2 = [C; 2];

%Metoda Gauss fara pivotare
[x11] = GaussFaraPiv(A1, b1);

%Metoda Gauss cu pivotare partiala
[x12] = GaussPivPart(A1, b1);
[x21] = GaussPivPart(A2, b2);

%Metoda Gauss cu pivotare totala
[x22] = GaussPivTot(A2, b2);

