% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului
% 'b'       = vector coloana reprezentand termenul din dreapta in cadrul
% sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = vectorul solutiilor sistemului
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [x] = GaussPivTot( A, b )
C = [A b];                  %matricea extinsa a sistemului
n = length(b);              %numarul ecuatiilor sistemului
index = 1:n;                
for k = 1:n-1 
    maxim = abs(C(k, k));        %initializez maximul 
    p = k;                  %indicele de pe coloana unde se afla maximul
    m = k;
    for j = k:n
        for r = k:n
            if abs(C(j, r))> maxim   %compar cu maximul curent
                maxim = abs(C(j, r)); %caut maximul in submatrice
                p = j;
                m = r;
            end
        end
    end
    if maxim == 0           %nu exista C(p, m) diferit de 0
        disp('Sist. incomp. sau sist. comp. nedet.');
        break;
    end
    if p ~= k               %efectuez interschimbarea liniilor p si k
        aux = C(p, :);
        C(p, :) = C(k, :);
        C(k, :) = aux;
    end
    if m ~=k                %efectuez interschimbarea coloanelor m si k
        aux = C(:, m);
        C(:, m) = C(:, k);
        C(:, k) = aux;
        y = index(m);       %retin ca trebuie schimbati si indecsii 
        index(m) = index(k);
        index(k) = y;
    end
    for l = k+1:n           %din linia l scad m(l, k)*linia k pentru a face
                            %zerouri
        C(l,:) = C(l,:) - C(l,k)/C(k,k)*C(k,:);
    end
end
if C(n, n) == 0
    disp('Sistem incomp. sau sist. comp. nedet.');
end
y = SubsDesc(C(1:n, 1:n), C(1:n, n+1));
for i=1:n                   %necunoscutele sunt returnate in y, dar in
                            %ordinea din index
    x(index(i)) = y(i);
end
end

