% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Calculeaza solutiile sistemelor de la exercitiul 1, folosind pe rand
% metoda Gauss fara pivotare, metoda Gauss cu pivotare partiala si metoda
% Gauss cu pivotare totala.
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
% Este bun codul insa pune si tu mesaje la consola cu fprintf. Imi este si
% mie mult mai usor sa corectez asa. :)

A1 = [0 1 1; 2 1 5; 4 2 1];      %matricea sistemului
% Poti declara direct vector linie si apoi sa il transpui cu ' 
b1 = [3; 5; 1];                  %vectorul coloana

A2 = [ 0 1 -2; 1 -1 1; 1 0 -1];
% Idem
b2 = [4; 6; 2];

%Metoda Gauss fara pivotare

[x11] = GaussFaraPiv(A1, b1);
[x21] = GaussFaraPiv(A2, b2);

%Metoda Gauss cu pivotare partiala
[x12] = GaussPivPart(A1, b1);
[x22] = GaussPivPart(A2, b2);

%Metoda Gauss cu pivotare totala
[x13] = GaussPivTot(A1, b1);
[x23] = GaussPivTot(A2, b2);