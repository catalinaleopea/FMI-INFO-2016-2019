% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului
% 'b'       = vector coloana reprezentand termenul din dreapta in cadrul
% sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = vectorul solutiilor sistemului
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [x] = GaussFaraPiv( A, b )
C = [A b];                  %matricea extinsa a sistemului
n = length(b);              %numarul ecuatiilor sistemului
for k = 1:n-1 
    p = 0;
    for j = k:n
        if C(j, k) ~=0   	%caut primul element nenul
            p = j;
            break;
        end
    end
    if p == 0               %nu exista C(p, k) diferit de 0
        disp('Sist. incomp. sau sist. comp. nedet.');
        break;
    end
    if p ~= k               %efectuez interschimbarea liniilor p si k
        aux = C(p, :);
        C(p, :) = C(k, :);
        C(k, :) = aux;
    end
    for l = k+1:n           %din linia l scad m(l, k)*linia k pentru a face
                            %zerouri
        C(l,:) = C(l,:) - C(l,k)/C(k,k)*C(k,:);
    end
end
if C(n, n) == 0
    disp('Sistem incomp. sau sist. comp. nedet.');
end
x = SubsDesc(C(1:n, 1:n), C(1:n, n+1));
end

