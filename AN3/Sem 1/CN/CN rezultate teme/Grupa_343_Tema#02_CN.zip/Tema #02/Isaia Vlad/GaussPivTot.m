function x = GaussPivTot(A, b)
    %stim din start ca matricea este patratica
    n = size(A,1);
    %extindem matricea
    A = [A b];
    index = linspace(1, n, n);
    a_pm = 0;
    p = 0;
    m = 0;
    for k = 1:n-1
        %alegem ca pivot elementul curent a_pm cu valoarea absoluta cea mai
        %mare din submatricea (a_ij)i,j=[k,...,n]
        for i = k : n
            for j = k : n
                if abs(a_pm) < abs(A(i,j))
                    a_pm = A(i,j);
                    p = i;
                    m = j;
                end
            end
        end
        if a_pm == 0
            fprintf("Sistem incompatibil sau compatibil nedeterminat.\n");
            x = -1;
            return;
        end
        if p ~= k
            A([p k], :) = A([k p], :);
        end
        if m ~= k
            A(:, [m k]) = A(:, [k m]);
            aux = index(k);
            index(k) = index(m);
            index(m) = aux;
        end
        for l = k+1 : n
            m_lk = A(l, k) / A(k, k);
            A(l, :) = A(l, :) - m_lk*A(k, :);
        end
    end
    if A(n, n) == 0
        fprintf("Sistem incompatibil sau compabitil nedeterminat.\n");
        x = -1;
        return;
    end
    %am obtinut o matrice superior triunghiulara si putem aplica
    %substitutia descendenta
    y = SubsDesc(A(1:n, 1:n), A(1:n, n+1));
    for i = 1 : n
        x(index(i)) = y(i);
    end
end

