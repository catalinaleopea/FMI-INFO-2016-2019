% Nu merge bine! Atente la find. Cred ca acolo este bug-ul. Vezi
% documentatia pentru find.
function x = GaussFaraPiv(A, b)
    %stim din start ca matricea este patratica
    n = size(A,1);
    %extindem matricea
    A = [A b];

    for k = 1 : n-1
        %cautam primul element diferit de 0
        indices = find(A(:, k));
        p = min(indices);
        
        if p == 0
            fprintf("sistem incompatibil sau sistem compatibil nedeterminat.\n");
            x = -1;
            return;
        end
        
        if p ~= k
            %interschimbam linia p cu linia k
            A([p k],:) = A([k p],:);
        end
        
        for l = k+1 : n
            %eliminam elementele de pe coloana k sub pivot
            m_lk = A(l, k) / A(k, k);
            A(l, :) = A(l, :) - m_lk * A(k, :);
        end
    end
    disp(A)
    
    if A(n, n) == 0
        fprintf("Sistem incompatibil sau sistem compatibil nedeterminat.\n");
        x = -1;
        return;
    end
    %am obtinut matricea superior triunghiulara sa ca putem sa aplicam
    %substitutia descendenta
    x = SubsDesc(A(1:n, 1:n), A(1:n, n+1));
end
