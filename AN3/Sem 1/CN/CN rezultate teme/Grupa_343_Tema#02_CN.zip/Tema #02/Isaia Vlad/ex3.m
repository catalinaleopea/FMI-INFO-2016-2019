% 1. -      pacat ca nu ai trimis si ex. 1. :( 
% 2. 10/10
% 3. 8/10
% Total: 18/30 i.e. 6
%subpunctul b
%definim matricea sistemului
A = [0 1 1
     2 1 5
     4 2 1];
%definim extensia sistemului
b = [3;
     5;
     1];

fprintf("Solutiile primului sistemul de la Ex. 1 aflate cu metodele:\n");
AfisareSolutii(A, b);
%definim matricea sistemului si extensia lui
A = [0 1 -2
     1 -1 1
     1 0 -1];
b = [4
     6
     2];

fprintf("Solutiile celui de-al doilea sistem de la Ex. 1 aflate cu metodele:\n");
AfisareSolutii(A, b);

%c
%(2)
%stabilim un epsilon extrem de mic
epsilon = 10^(-20);
%definim matricea sistemului si extensia lui
A = [epsilon 1;
     1 1];
b = [1;
     2];
 
fprintf("Solutiile primului sistem de la subpunctul c:\n");
%apelam metodele gauss cerute si afisam solutiile date de
%acestea
x = GaussFaraPiv(A, b);
fprintf("Gauss fara pivotare:\n");
fprintf("%f\n", x);

x = GaussPivPart(A, b);
fprintf("Gauss cu pivotare partiala:\n");
fprintf("%f\n", x);

%(3)
%definim variabila C foarte mare
C = 10^20;
%definim matricea sistemului si extensia lui
A = [1 C;
     1 1];
b = [C;
     2];

fprintf("Solutiile celui de-al doilea sistem de la subpunctul c:\n");
%apelam metodele Gauss cerute si afisam solutiile date de acestea
x = GaussPivPart(A, b);
fprintf("Gauss cu pivotare partiala:\n");
fprintf("%f\n", x);

x = GaussPivTot(A, b);
fprintf("Gauss cu pivotare totala:\n");
fprintf("%f\n", x);