%ex2
% E bine, dar te rog sa comentezi codul de acum inainte. 
% Totodata, poti sa calculezi suma direct, folosind produs scalar? Astfel
% reusesti sa scapi de acel for
function [x] = SubsDesc(A, b)
    n = size(b, 1);
    x(n) = b(n) / A(n, n);
    k = n-1;
    while k > 0
        sum = 0;
        for i = k+1 : n
            sum = sum + A(k, i)*x(i);
        end
        x(k) = (b(k) - sum) / A(k,k);
        k = k-1;
    end
end
