function x = GaussPivPart(A, b)
    %stim din start ca matricea este patratica
    n = size(A,1);
    %extindem matricea
    A = [A b];
    
    for k = 1 : n-1
        a_pk = 0;
        p = 0;
        %alegem pivotul corespunzator coloanei k cu valoarea absoluta cea
        %mai mare de pe aceasta coloana, aflat sub sau pe diagonala
        %principala a matricii curente A
        for j = k : n
            if abs(a_pk) < abs(A(j,k))
                a_pk = A(j,k);
                p = j;
            end
        end
        if(a_pk == 0)
            fprintf("Sistem incompatibil sau compatibil nedeterminat.\n");
            x = -1;
            return;
        end
        if p ~= k
            A([p k], :) = A([k p], :);
        end
        
        for l = k+1 : n
            m_lk = A(l, k) / A(k, k);
            A(l, :) = A(l, :) - m_lk * A(k, :);
        end
    end
    if A(n, n) == 0
        fprintf("Sistem incompatibil sau compatibil nedeterminat\n");
        x = -1;
        return;
    end
    %am obtinut o matrice superior triunghiulara si putem aplica
    %substitutia descendenta
    x = SubsDesc(A(1:n, 1:n), A(1:n, n+1));
end

