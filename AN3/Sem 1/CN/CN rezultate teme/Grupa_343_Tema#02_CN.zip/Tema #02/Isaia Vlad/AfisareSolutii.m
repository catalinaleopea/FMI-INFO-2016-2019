function AfisareSolutii(A, b)
    %apelam fiecare metoda Gauss si afisam rezultatul ei
    fprintf("Gauss fara pivotare:\n");
    x = GaussFaraPiv(A, b);
    fprintf("%f\n", x);
    fprintf("Gauss cu pivotare partiala:\n");
    x = GaussPivPart(A, b);
    fprintf("%f\n", x);
    fprintf("Gauss cu pivotare totala:\n");
    x = GaussPivTot(A, b);
    fprintf("%f\n", x);
end