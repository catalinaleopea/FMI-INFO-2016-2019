% ! 
% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = o matrice de n x n reprezentand matricea sistemului de rezolvat
% 'b'       = o matrice de n x 1 reprezentand a doua parte a sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = solutia sistemului dat rezolvat prin metoda substitutiei
% descendente
% -------------------------------------------------------------------------
% Implementare pseudo-cod curs #2, pag.12
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
function [x] = GaussPivPart(A,b)
    n = size(A,1);
    A = [A, b];
    
    for k=1:n-1
       p = k;
       for i=k+1:n
           if abs(A(i,k)) > abs(A(p,k))
               p = i; % alegem ca pivot elementul cu valoare absoluta cea mai mare de pe coloana respectiva sub sau pe diagonala principala
           end
       end
       
       if A(p,k) == 0
           disp('Sistem incomp. sau sist. comp. nedet.');
           break;
       end
       % NOOOOOOOOO
       % Fara AUX! 
       % Use A([l_p l_k], :) = A([l_k l_p], :) instead! :)
       if p ~= k % interschimbare
           aux = A(k,:);
           A(k,:) = A(p,:);
           A(p,:) = aux;
       end
       
       for l=k+1:n % aplicam transformarile de linii conform algoritmului
           A(l,:) = A(l,:) - (A(l,k)/A(k,k))*A(k,:);
       end
    end

    if A(n,n) == 0
        disp('Sistem incomp. sau sist. comp. nedet.');
    end
    
    x = SubsDesc(A(:,1:n),A(:,n+1)); % rezolvarea sistemului
end

