% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = o matrice de n x n reprezentand matricea sistemului de rezolvat
% 'b'       = o matrice de n x 1 reprezentand a doua parte a sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = solutia sistemului dat rezolvat prin metoda substitutiei dupa ce
%           s-a format matricea superior triunghiulara
% descendente
% -------------------------------------------------------------------------
% Implementare pseudo-cod curs #2, pag.6
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
function [x] = GaussFaraPiv(A,b)
    n = size(A,1);
    A = [A, b]; % matricea extinsa a sistemului
    
    for k=1:n-1
       found = false;
       for i=k:n
           if A(i,k) ~= 0
               p = i;
               found = true;
               break;
           end
       end
       
       if ~found
           disp('Sistem incomp. sau sist. comp. nedet.');
           break;
       end
       
       if p ~= k % interschimbam liniile
           aux = A(k,:);
           A(k,:) = A(p,:);
           A(p,:) = aux;
       end
       
       for l=k+1:n % aplicam transformarile conform algoritmului
           A(l,:) = A(l,:) - (A(l,k)/A(k,k))*A(k,:);
       end
    end

    if A(n,n) == 0
        disp('Sistem incomp. sau sist. comp. nedet.');
    end
    
    x = SubsDesc(A(:,1:n),A(:,n+1)); % rezolvarea sistemului folosind metoda substitutiei descendente
end

