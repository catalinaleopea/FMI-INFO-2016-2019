% 1. -   Q: De ce nu faci si tema scrisa?
% 2. 10/10
% 3. 9/10 -> Discutia de la c.?
% Total: 19/30 i.e. 6.33/10 :(
% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Rezolvare exercitiu 3, tema 2
% a) GaussFaraPiv, GaussPivPart si GaussPivTot sunt in fisiere functie
% separate
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================

% b)
% Nu ai nevoie de separare cu virgule pentru vectori. Doar ; pentru linii
A1 = [0,1,1;2,1,5;4,2,1];
% Poti sa ii spui b1  = [3 5 1]' -> cu transpusa
b1 = [3;5;1];

x1_FaraPivot = GaussFaraPiv(A1, b1);
x1_PivotPart = GaussPivPart(A1, b1);
x1_PivotTotal = GaussPivTot(A1, b1);

disp('Primul sistem A1');
disp('Fara pivotare');
disp(x1_FaraPivot);
disp('Pivotare partiala');
disp(x1_PivotPart);
disp('Pivotare totala');
disp(x1_PivotTotal);


A2 = [0,1,-2;1,-1,1;1,0,-1];
b2 = [4;6;2];


disp('Al doilea sistem A2');
x2_FaraPivot = GaussFaraPiv(A2, b2);
x2_PivotPart = GaussPivPart(A2, b2);
x2_PivotTotal = GaussPivTot(A2, b2);

% c)

eps = 10^(-20);
C = 10^20;

A3 = [eps,1;1,1];
b3 = [1;2];

A4 = [1,C;1,1];
b4 = [C;2];

x3_FaraPivot = GaussFaraPiv(A3,b3);
x3_PivotPart = GaussPivPart(A3,b3);

x4_PivotPart = GaussPivPart(A4,b4);
x4_PivotTotal = GaussPivTot(A4,b4);

disp('Sistemul A3');
disp('Fara Pivotare');
disp(x3_FaraPivot);
disp('Pivotare partiala');
disp(x3_PivotPart);

disp('Sistemul A4');
disp('Pivotare partiala');
disp(x4_PivotPart);
disp('Pivotare totala');
disp(x4_PivotTotal);