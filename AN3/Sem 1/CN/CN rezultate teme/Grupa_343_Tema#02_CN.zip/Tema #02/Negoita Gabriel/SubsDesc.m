% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = o matrice de n x n reprezentand matricea sistemului de rezolvat
% 'b'       = o matrice de n x 1 reprezentand a doua parte a sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = solutia sistemului dat rezolvat prin metoda substitutiei
% descendente
% -------------------------------------------------------------------------
% Implementare pseudo-cod curs #2, pag.4
% -------------------------------------------------------------------------
% Author: Negoita Gabriel-Claudiu, 2018
% =========================================================================
function [x] = SubsDesc(A,b)
    n = size(A,1); % dimensiunea matricei
    x = ones(n,1); % vectorul de dimensiune n x 1 asemenea lui 'b' la inceput doar cu 1
    
    x(n) = 1/A(n,n)*b(n);
    
    for i=n-1:-1:1 % echivalent cu while din curs unde k din curs = i din cod
        sum = 0; % suma pe linii deasupra diagonalei principale
        for j=i+1:n
            sum = sum + A(i,j)*x(j);
        end
        
        x(i) = 1/A(i,i)*(b(i)-sum); % rezultatul conform algoritmului
    end
    
end

