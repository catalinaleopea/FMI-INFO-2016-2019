% ! 
% Include sectiuni cu '%%' data viitoare, te rog. Totodata pune si mesaje
% la consola cu fprintf ca sa stiu si eu ce faci acolo. Altfel vad doar
% multe variabile cu rezultate pe acolo...
% 1. -
% 2. 10/10
% 3. 9/10
% Total> 19/30 i.e. 6.33/10

%% 3%b

A1 = [0 1 1;2 1 5;4 2 1];
b1 = [3; 5; 1];
x11 = GaussFaraPiv(A1,b1)
x12 = GaussPivPart(A1,b1)
x13 = GaussPivTotal(A1,b1)

A2 = [0 1 -2;1 -1 1;1 0 -1];
b2 = [4;6;2];
x21 = GaussFaraPiv(A2,b2)
x22 = GaussPivPart(A2,b2)
x23 = GaussPivTotal(A2,b2)

%% 3c
eps = 10^(-20);
A1 = [eps 1;1 1];
b1 = [1 ;2];
z11 = GaussFaraPiv(A1,b1)
z12 = GaussPivPart(A1,b1)
%metoda cu pivotare partiala ne duce mai aproape de solutia corecta,eroarea
%fiind mult mai mica decat prin metoda fara pivotare,pentru ca metoda cu
%pivotare paritala face abstractie de termeni foarte mici,alegand maximul
%coloanei
C = 10^20;
A2 = [1 C;1 1];
b2 = [C;1];
z21 = GaussFaraPiv(A2,b2)
z22 = GaussPivTotal(A2,b2)
%% 2
function [x] = subsDesc(A,b)
N = length(b);
x(N) = b(N)/A(N,N);
% poti folosi si i = flipr(N-1:1)
for i = N-1:-1:1
    %x(i) = (b(i) - sum(A(i,i+1:N).*x(i+1)))/A(i,i);
    sum = 0;
    for j=i+1:N
        sum = sum + A(i,j)*x(j);
    end
    sum = b(i) - sum;
    x(i) = sum/A(i,i);
end
end
%2

function [x] = GaussFaraPiv(A,b)
A = [A,b];
n = length(b);
for k = 1 : n-1
    p = -1;
    for i=k:n
        if A(k,i) ~= 0
            p = i;
            break;
        end
    end
    % ';' Nu este necesar
    if p == -1;
        disp('not ok');
        x = 0;
        return;
    elseif p ~= k
        A([k p],:) = A([p k],:);
    end
    for i=k+1:n
    A(i,:) = A(i,:) - (A(i,k)/A(k,k))*A(k,:);
    end
end
if A(n,n) == 0
    x = 0;
    disp('not ok');
    return;
end
b = A(:,n+1);
A(:,n+1) = [];
x = subsDesc(A,b);
end

function [x] = GaussPivPart(A,b)
A = [A,b];
n = length(b);
for k = 1 : n-1
    vmax = max(abs(A(k:n,k)));
    for i=k:n
        if abs(A(i,k)) == vmax
            p = i;
            break;
        end
    end
    if vmax == 0
        disp('not ok');
        x = 0;
        return;
    elseif p ~= k
        A([k p],:) = A([p k],:);
    end
    for i=k+1:n
    A(i,:) = A(i,:) - (A(i,k)/A(k,k))*A(k,:);
    end
end
if A(n,n) == 0
    x = 0;
    disp('not ok');
    return;
end
b = A(:,n+1);
A(:,n+1) = [];
x = subsDesc(A,b);
end

function [xaprox] = GaussPivTotal(A,b)
n = size(A,1);
A = [A b];
index = 1:n;
for k=1:n-1
    p = -1;
    m = -1;
    maxA = max(max(abs(A(k:n,k:n))));
    for i = k:n
        for j = k:n
            if abs(A(i,j)) == maxA
                p = i;
                m = j;
            end
        end
    end
    if A(p,m) == 0 || (p == -1 && m == -1)
        % use 'disp'
         display('sistem incompatibil sau compatibil nedetermina');
         xaprox = 0;
         return;
    end
    if p ~= k
         A([k p],:) = A([p k],:);
    end
    if m ~= k
       
       A(:,[m k]) = A(:,[k m]);
       aux = index(m);
       index(m) = index(k);
       index(k) = aux;
    end
    for l = k+1:n
        aux = A(l,k)/A(k,k);
        A(l,:) = A(l,:) - aux.*A(k,:);
    end
end
    if(A(n,n) == 0)
        % use 'disp'
        display('...');
        xaprox = 0;
        return;
    end
    b = A(:,n+1);
    A(:,n+1) = [];
    y = subsDesc(A,b);
    for i=1:n
        xaprox(index(i)) = y(i);
    end
end
    
