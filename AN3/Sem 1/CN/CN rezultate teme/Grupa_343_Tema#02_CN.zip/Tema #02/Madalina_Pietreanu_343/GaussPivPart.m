%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA GAUSS CU PIVOTARE PARTIALA                                       %
% - functia de mai jos transforma matricea A asociata unui sistem liniar  %
%           independent intr-o matrice superior triunghiulara B folosind  %
%           metoda Gauss cu pivotare partiala                             %
% - dupa obtinerea acestei noi matrici, se calculeaza solutia ecuatiei    %
%        Bx = b prin metoda substitutiei descendente                      %
% - implemetarea acestei metode se bazeaza pe pseudocodul din cursul 2    %
%                                                                         %
% INPUT:  - A => matricea asociata sistemului                             %
%         - b => ultima coloana din matricea A extinsa                    %
% OUTPUT: - x => solutia sistemului Bx = b                                %                                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [x] = GaussPivPart(A,b)
    
    B = [A, b']; % matricea extinsa
    lenb = length(b); % nu e eficient sa apelezi de fiecare data length(b)

    % fiecare pivot de pe fiecare linie i trebuie sa fie elementul cu
    % valoarea absoluta cea mai mare de pe "subcoloana" sa (adica sub pivot
    % sa existe numai valori mai mici decat el)
    
    for i = 1 : lenb - 1
        greatest = abs(B(i,i));
        greatestIndex = i;
        for j = i + 1 : lenb
            if (abs(B(i,j) > greatest))
                greatest = B(i,j);
                greatestIndex = j;
            end
        end
        
        if (greatest == 0)
            disp('Sistemul nu este compatibil determinat');
                x = -1;
                return
        end
        
        if (greatestIndex ~= i)
             B([i j], :) = B([j i],:);
        end
    end
    
    % de aici in jos, restul algoritmului este la fel ca la ceilalti 2
    
    for i = 2 : lenb % parcurg liniile; voi numi linia i linia curenta
        for j  = 1 : i - 1   % parcurg liniile de deasupra liniei curente
                             % pentru a forma 0-uri sub DP
                             
            if (B(i,j) == 0) % daca am deja 0, sar peste
                continue;
            end
            
            % ca sa fac 0 pe pozitia B(i,j), voi scade din linia i linia j
            % aferenta pivotului de desupra lui B(i,j) inmultita cu 
            % raportul dintre elementul B(i,j) si pivotul de deasupra lui
            % fac acest lucru ca sa obtin 0 pe pozitia (i,j)
            m = B(i,j)/B(j,j);
            B(i,:) = B(i,:) - m * B(j,:);
        end
    end
    
    if (B(lenb-1,lenb-1) == 0)
        disp('Sistemul nu este compatibil determinat');
        x = -1;
        return
    end
        
    
    %disp(B)              % matricea extinsa noua - afisare in consola
    
    b = B(:,lenb + 1);    % actualizez solutiile ecuatiilor din sistem cu 
                          % noile valori obtinute prin procesarea matricii
                          % extinse
                          
    B = B(:,1:lenb);      % elimin ultima coloana din matricea extinsa
    
    %disp(B)              % matricea noua (superior triunghiulara) - 
                          % afisare in consola
                          
    disp('Gauss cu pivotare partiala:');
    
    x = SubsDesc(B,b);    % aplic metoda substitutiei descendente pe noua
                          % matrice pentru a obtine solutia sistemului

end

