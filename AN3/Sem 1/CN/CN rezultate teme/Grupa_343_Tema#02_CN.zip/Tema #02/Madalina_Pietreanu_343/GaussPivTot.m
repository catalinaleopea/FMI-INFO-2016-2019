% ! 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA GAUSS CU PIVOTARE TOTALA                                         %
% - functia de mai jos transforma matricea A asociata unui sistem liniar  %
%           independent intr-o matrice superior triunghiulara B folosind  %
%           metoda Gauss cu pivotare toatala                              %
% - dupa obtinerea acestei noi matrici, se calculeaza solutia ecuatiei    %
%        Bx = b prin metoda substitutiei descendente                      %
% - implemetarea acestei metode se bazeaza pe pseudocodul din cursul 2    %
%                                                                         %
% INPUT:  - A => matricea asociata sistemului                             %
%         - b => ultima coloana din matricea A extinsa                    %
% OUTPUT: - x => solutia sistemului Bx = b                                %                                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [y] = GaussPivTot(A,b)
    
    B = [A, b']; % matricea extinsa
    lenb = length(b);
    % ! Spune-i direct index = 1:n -> much faster and Ok.
    index = ones(1,lenb); % matricea de indecsi ai necunoscutelor
    for i = 2 : lenb
        index(i) = index(i) * i;
    end
    
    for k = 1 : lenb - 1
        greatest = abs(B(k,k));
        greatestP = k;
        greatestM = k;
        %parcurg submatricea "generata" de elementul B(k,k)
        for p = k : lenb
            for m = k : lenb
                if (abs(B(p,m)) > greatest)
                    greatest = abs(B(p,m));
                    greatestP = p;
                    greatestM = m;
                end
            end
        end
            
        if (greatest == 0)
            disp('Sistemul nu este compatibil determinat');
            y = -1;
            return
        end
            
        if (k ~= greatestP)
            % interschimb liniile
            B([greatestP k], :) = B([k greatestP],:); 
        end
            
        if (k ~= greatestM)
            % interschimb coloanele
            B(:,[greatestM k]) = B(:,[k greatestM]);  
                
            aux = index(greatestM);      % interschimb indicii
            index(greatestM) = index(k); % necunoscutelor pentru ca am
            index(k) = aux;              % interschimbat coloanele
                
        end
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i = 2 : lenb % parcurg liniile; voi numi linia i linia curenta
        for j  = 1 : i - 1   % parcurg liniile de deasupra liniei curente
                             % pentru a forma 0-uri sub DP
                             
            if (B(i,j) == 0) % daca am deja 0, sar peste
                continue;
            end
            
            % ca sa fac 0 pe pozitia B(i,j), voi scade din linia i linia j
            % aferenta pivotului de desupra lui B(i,j) inmultita cu 
            % raportul dintre elementul B(i,j) si pivotul de deasupra lui
            % fac acest lucru ca sa obtin 0 pe pozitia (i,j)
            m = B(i,j)/B(j,j);
            B(i,:) = B(i,:) - m * B(j,:);
        end
    end
    
    if (B(lenb-1,lenb-1) == 0)
        disp('Sistemul nu este compatibil determinat');
        y = -1;
        return
    end
        
    
    %disp(B)              % matricea extinsa noua - afisare in consola
    
    b = B(:,lenb + 1);    % actualizez solutiile ecuatiilor din sistem cu 
                          % noile valori obtinute prin procesarea matricii
                          % extinse
                          
    B = B(:,1:lenb);      % elimin ultima coloana din matricea extinsa
    
    %disp(B)              % matricea noua (superior triunghiulara) - 
                          % afisare in consola
                          
    disp('Gauss cu pivotare totala:');
    
    x = SubsDesc(B,b);    % aplic metoda substitutiei descendente pe noua
                          % matrice pentru a obtine solutia sistemului
                          
    if (x == -1)
        y = -1;
        return
    end
                          
    % din cauza interschimbarilor de coloane, solutiile din x sunt 
    % amestecate; trebuie repuse in ordine cu ajutorul matricii de indecsi
    
    % Spune-i direct -> y(index) = x; MATLAB face automat asa si scapi de
    % for
    y = zeros(1,lenb);
    for i = 1 : lenb
        y(index(i)) = x(i);
    end
end

