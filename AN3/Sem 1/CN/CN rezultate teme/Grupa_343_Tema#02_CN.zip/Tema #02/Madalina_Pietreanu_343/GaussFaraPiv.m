%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA GAUSS FARA PIVOTARE                                              %
% - functia de mai jos transforma matricea A asociata unui sistem liniar  %
%           independent intr-o matrice superior triunghiulara B folosind  %
%           metoda Gauss fara pivotare                                    %
% - dupa obtinerea acestei noi matrici, se calculeaza solutia ecuatiei    %
%        Bx = b prin metoda substitutiei descendente                      %
% - implemetarea acestei metode se bazeaza pe pseudocodul din cursul 2    %
%                                                                         %
% INPUT:  - A => matricea asociata sistemului                             %
%         - b => ultima coloana din matricea A extinsa                    %
% OUTPUT: - x => solutia sistemului Bx = b                                %                                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [x] = GaussFaraPiv(A,b)
    
    B = [A, b']; %matricea extinsa
    lenb = length(b);

    % trebuie sa ne asiguram ca pe DP avem elemente nenule
    % interschimbam linii convenabil
    for i = 1 : lenb
        if B(i,i) == 0 % am gasit o linie cu 0 pe DP; trebuie inlocuita cu
                       % prima linie cu element nenul de sub "pivotul" 
                       % liniei vizate; daca nu gasesc o astfel de linie
                       % inseamna ca sistemul meu nu este compatibil
                       % determinat si ca nu pot continua algoritmul
            found = 0; % o variabila booleana care determina daca am gasit
                       % o linie cu care sa pot face interschimbarea
            for j = i + 1 : lenb
                if B(j,i) ~= 0
                    B([i j], :) = B([j i],:); % am gasit linia si 
                                              % interschimb
                    found = 1;
                    break;
                end
            end
            if (found == 0)
                disp('Sistemul nu este compatibil determinat');
                x = -1;
                return
            end
        end
    end
    
    for i = 2 : lenb % parcurg liniile; voi numi linia i linia curenta
        for j  = 1 : i - 1   % parcurg liniile de deasupra liniei curente
                             % pentru a forma 0-uri sub DP
                             
            if (B(i,j) == 0) % daca am deja 0, sar peste
                continue;
            end
            
            % ca sa fac 0 pe pozitia B(i,j), voi scade din linia i linia j
            % aferenta pivotului de desupra lui B(i,j) inmultita cu 
            % raportul dintre elementul B(i,j) si pivotul de deasupra lui
            % fac acest lucru ca sa obtin 0 pe pozitia (i,j)
            m = B(i,j)/B(j,j);
            B(i,:) = B(i,:) - m * B(j,:);
        end
    end
    
    if (B(lenb-1,lenb-1) == 0)
        disp('Sistemul nu este compatibil determinat');
        x = -1;
        return
    end
        
    
    %disp(B)              % matricea extinsa noua - afisare in consola
    
    b = B(:,lenb + 1);    % actualizez solutiile ecuatiilor din sistem cu 
                          % noile valori obtinute prin procesarea matricii
                          % extinse
                          
    B = B(:,1:lenb);      % elimin ultima coloana din matricea extinsa
    
    %disp(B)              % matricea noua (superior triunghiulara) - 
                          % afisare in consola
                          
    disp('Gauss fara pivotare:');
    
    x = SubsDesc(B,b);    % aplic metoda substitutiei descendente pe noua
                          % matrice pentru a obtine solutia sistemului

end

