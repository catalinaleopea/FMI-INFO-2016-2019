% 1. -  -> De ce nu trimiti?
% 2. 10/10
% 3. 8/10 -> Mici probleme + discutia de la c.?
% Total: 18/30 i.e. 6/10
% Creeaza sectiuni pentr exercitii de acum inainte. Acestea se creeaza cu
% sintaxa '%%'. Am modificat eu acum.
% Undeva la sfarsit nu merge bine ce ai facut. Apreciez insa efortul tau.
% Ai grija ca poti coda mult mai simplu. Te complici prea tare.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMA 2                                                                  %
% Madalina Pietreanu, grupa 343                                           %
% - acest fisier reprezinta functia "parent" din care se vor apela toate  %
%       celelalte fisiere exN.m, unde N corespunde numarului exercitiului %
% - detalii despre implementari se gasesc in fisierele .m asociate        %
%         exercitiilor                                                    %
% - fisierele 'dataX.m' contin seturi de date de intrare pentru exercitii %                                                
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % - implementarea se gaseste in fisierul 'SubsDesc.m'
% % incarcam date din fisierul 'data.m' in workspace
data2;
x = SubsDesc(A,b);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% a) - implementarile se gasesc in fisierele 'GaussFaraPiv.m', 
%      'GaussPivPart.m' si 'GaussPivTot.m'

% b) % Pune cu mesaje la consola data viitoare pentru ca eu vad doar ultima
% valoare atribuita lui x. 
data1a;
disp('Date din fisierul data1a:');
% Mesaj la consola
x = GaussFaraPiv(A,b);
% Mesaj la consola
x = GaussPivPart(A,b);
% Mesaj la consola
x = GaussPivTot(A,b);
disp('Solutia dupa rearanjaraea necunoscutelor');
disp(x);
%%
data1b;
disp('Date din fisierul data1b:');
x = GaussFaraPiv(A,b);
x = GaussPivPart(A,b);
x = GaussPivTot(A,b);
if (x ~= -1)
    disp('Solutia dupa rearanjaraea necunoscutelor');
    disp(x);
end

%% c)
data3a;
disp('Date din fisierul data3a:')
x1a = GaussPivPart(A,b);
x2a = GaussPivTot(A,b);
if (x2a ~= -1)
    disp('Solutia dupa rearanjaraea necunoscutelor');
    disp(x2a);
end
%% Undeva gresesti. Pivotarea partiala nu trebuia sa dea solutia corecta
data3b;
disp('Date din fisierul data3b:')
x1b = GaussPivPart(A,b);
x2b = GaussPivTot(A,b);
if (x2b ~= -1)
    disp('Solutia dupa rearanjaraea necunoscutelor');
    disp(x2b);
end