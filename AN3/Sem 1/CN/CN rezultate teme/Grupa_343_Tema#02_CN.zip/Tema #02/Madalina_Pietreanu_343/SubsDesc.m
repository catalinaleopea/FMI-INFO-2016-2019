% ! 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA SUBSTITUTIEI DESCENDENTE                                         %
% - functia de mai jos calculeaza solutiile ecuatiei Ax = b folosind      %
%           metoda substitutiei descendente                               %
% - implemetarea acestei metode se bazeaza pe pseudocodul din cursul 2    %
%                                                                         %
% INPUT:  - A => matricea superior triunghiulara asociata sistemului      %
%         - b => ultima coloana din matricea A extinsa                    %
% OUTPUT: - x => solutia sistemului Ax = b                                %                                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [x] = SubsDesc(A,b)
    
    n = length(A);  % aflu dimensiunea matricii
    
    if (A(n,n) == 0)
        disp('Sistemul nu este compatibil determinat');
        % Returneaza si tu un vector null sau infinit
        x = -1;
        return
    end
      % ./ si .* nu este neaparat necesar aici, lucrand la sigur doar cu
      % scalari
    x(n) = (1 ./ A(n,n)) .* b(n); % solutia de pe ultima linie
    k = n - 1;
    
    while k >= 1
        % introduc in ecuatie necunoscutele aflate deja si le inmultesc cu
        % scalarii corespunzatori lor      
        aux = 0;
        for i = k + 1 : n
            aux = aux + (A(k,i) .* x(i));
        end
        
        % acum aflu x-ul de la pasul curent folosindu-ma de aux
        x(k) = (1 ./ A(k,k)) .* (b(k) - aux);
        
        k = k - 1;
    end
    
    disp('Solutia sistemului: ');
    disp(x);
    
end

