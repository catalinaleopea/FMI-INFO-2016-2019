% 1. 4/10 -> Gasesti balarii in afara de primul
% 2. 10/10
% 3. 5/10 -> Nu ruleaza
% Total: 19/20 i.e. 

% Atentie la denumirea fisierelor! 
% Nu ruleaza. Vezi cum anume functioneaza size in GaussFaraPiv
% Index in position 2 exceeds array bounds (must not exceed 3).
% 
% Error in GaussFaraPiv (line 23)
%   if A(n, n) == 0
% Apelarea procedurilor pentru primul sistem de ecuatii

A=[0,1,1;2,1,5;4,2,1]; 
b=[3,5,1];

[x] =GaussFaraPiv(A, b);
[y] =GaussPivPart(A, b);
[z] =GaussPivTot(A, b);

 %Apelarea procedurilor pentru al doilea sistem de ecuatii
A1=[0,1,-2;1,-1,1;1,0,-1]; 
b1=[4,6,2];

[x1] =GaussFaraPiv(A1, b1);
[y1] =GaussPivPart(A1, b1);
[z1] =GaussPivTot(A1, b1);