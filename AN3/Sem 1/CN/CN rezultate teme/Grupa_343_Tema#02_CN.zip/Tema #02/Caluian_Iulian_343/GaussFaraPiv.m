function [x] = GaussFaraPiv(A,b)
%SUBSDESC Summary of this function goes here
%   Detailed explanation goes here

[~,n] = size(A);
% :)
AB = [A b(:)]; %AB este matricea extinsa.

% parantezele nu-s necesare
for k = 1:(n-1)
   
    m = AB(k:n,k); % selectez valorile urmatoare de pe coloana
    mEl = find( m ~= 0); % gasesc elementele nenule 
    if isempty(mEl)
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        print('Sistemul nu este compatibil, sau compatibil nedeterm');
        break;
    else
        p = mEl(1) + k - 1;
        % p - prima pozitie unde nu e nul akl => primul element din mEl 
        % care indica un index + (k-l) cate pozitii anterioare in matrice avem pe coloana=>
        % pentru a rezulta linia in matrice
        
        % swap linii:
        % Swap-ul de linii merge facut mai elegant in MATLAB
        % AB([line_i linej], :) = AB([line_j line_i], :)
        line = AB( k, 1:(n+1));
        AB(k, 1:(n+1)) = AB(p, 1:(n+1));
        AB(p, 1:(n+1)) = line;
    
        for p = (k+1):n 
            %update restul liniilor pentru a face apk sa fie 0
            mpk = AB(p,k) / AB(k,k);
            AB(p, 1:(n+1)) = AB(p, 1:(n+1)) - mpk*AB(k,1:(n+1));
        end
    end
    
end

if AB(n,n) == 0
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        disp('Sistemul nu este compatibil, sau compatibil nedeterm');
end

%extrag componentele pentru a rezolva cu metoda substitutiei.
AB(1:n, 1:n)
x = SubsDesc(AB(1:n,1:n),AB(1:n,n+1));


end