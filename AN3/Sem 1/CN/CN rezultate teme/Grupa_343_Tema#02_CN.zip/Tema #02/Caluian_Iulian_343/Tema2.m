% Pune si tu sectiuni data viitoare pentru fiecare exercitiu
% Observatia de la 3 c ?
% 1. -
% 2. 10/10
% 3. 9/10
% Total 19/30 i.e. 6.33/10

A = [ 2, 1, 5;
    0 1 1;
    0 0 -9];

 
A1 = [0 1 1;
      2 1 5;
      4 2 1];
b1 = [3 5 1];  

A2 = [0 1 -2;
      1 -1 1;
      1 0 -1];
b2 = [4 6 2];  

x = GaussFaraPiv(A1,b1);
x = GaussPivPart(A1,b1);
x = GaussPivTot(A1,b1);
%x = SubsDesc(A,b);

y = GaussFaraPiv(A2,b2);
y = GaussPivPart(A2,b2);
y = GaussPivTot(A2,b2);

epsi = 10^(-20);
A3 = [epsi 1;
       1 1 ];
b3 = [1 2];

z1 = GaussFaraPiv(A3,b3)
z2 = GaussPivPart(A3,b3)
z3 = GaussPivTot(A3,b3)

C = 10^(20);
A4 = [ 1 C;
       1 1 ];
b4 = [C 2];

w1 = GaussFaraPiv(A4,b4)
w2 = GaussPivPart(A4,b4)
w3 = GaussPivTot(A4,b4)
