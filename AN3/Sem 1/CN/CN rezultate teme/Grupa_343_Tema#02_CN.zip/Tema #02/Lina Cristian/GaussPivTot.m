function [x] = GaussPivTot(a,b)
    % concatenam coloana b la matricea a (mat. extinsa)
    ae = [a, b];
    % nr de linii a matricei
    n = length(b);
    % formam vectorul de indexi
    index = ones(n,1);
    for i = 1:n
       index(i) = i; 
    end
    % implementarea propriu-zisa a algoritmului descris in curs
    for k = 1 : n-1
       % maxim va avea ca valoare initiala minimul din submatrice         
       maxim = min(min(abs(ae(k:n,:))))-1;
       ind1 = 0; ind2 = 0;
       % cautam in submatrice
       for p = k : n
           for m = k : n
               % daca gasim o valoare mai mare ca max, il actualizam
               if(abs(ae(p,m)) > maxim)
                   maxim = abs(ae(p,m));
                   ind1 = p; ind2 = m;
               end
           end          
       end
       if(ae(ind1,ind2) == 0)
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
       end
       if(ind1 ~= k)
%          % interschimbam liniile
           ae([k,ind1],:) = ae([ind1,k],:);
       end
       if(ind2 ~= k)
           % interschimbam coloanele; actualizam vec de indexi
           ae(:,[k,ind2]) = ae(:,[ind2,k]);
           ind = index(ind2);
           index(ind2) = index(k); index(k) = ind;
       end
       for l = k + 1 : n
          if(ae(l,k) ~= 0)
            m = ae(l,k)/ae(k,k);
            ae(l,:) = ae(l,:) - m*ae(k,:); 
          end          
       end
    end
    if(ae(n,n) == 0)
       disp('Sistem incop. sau sistem comp. nedet.');
    end
    [y] = SubsDesc(ae(:,1:n),ae(:,n+1));
    % ordonam rezultatul dupa vectorul de indexi
    x = zeros(length(y),1);
    for i = 1:length(y)
       x(index(i)) = y(i);
    end
end