% 1. 10/10
% 2. 10/20
% 3. 9/10 -> Discutia de la punctul c.?
% Total 29/30 i.e. 9.66
% punctul b
a1 = [0 1 1; 2 1 5; 4 2 1];
b1 = [3; 5; 1];
a2 = [0 1 -2; 1 -1 1; 1 0 -1];
b2 = [4; 6; 2];
[x1] = GaussFaraPiv(a1,b1);
disp(x1);
[x2] = GaussPivPart(a1,b1);
disp(x2);
[x3] = GaussPivTot(a1,b1);
disp(x3);
[x4] = GaussFaraPiv(a2,b2);
disp(x4);
[x5] = GaussPivPart(a2,b2);
disp(x5)
[x6] = GaussPivTot(a2,b2);
disp(x6);

% punctul c
C = 10^(-20);

a3 = [C 1; 1 1]; b3 = [1; 2];
[x7] = GaussFaraPiv(a3,b3);
disp(x7);
[x8] = GaussPivPart(a3,b3);
disp(x8); 

C = 10^20;

a4 = [1 C; 1 1]; b4 = [C; 2];
[x9] = GaussPivPart(a4,b4);
disp(x9);
[x10] = GaussPivTot(a4,b4);
disp(x10);