function [x] = GaussFaraPiv(a,b)
    % concatenam coloana b la matricea a (mat. extinsa)
    ae = [a, b];
    % nr de linii a matricei
    n = length(b);
    % implementarea propriu-zisa a algoritmului descris in curs
    for k = 1 : n-1
       % cautam pe coloana primul p dif de 0
       for p = k : n
          if(ae(p,k) ~= 0)
             break; 
          end
       end
       if(ae(p,k) == 0)
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
       end
       if(p ~= k)
           % interschimbam liniile
           ae([k,p],:) = ae([p,k],:);
       end
       for l = k + 1 : n
          if(ae(l,k) ~= 0)
            m = ae(l,k)/ae(k,k);
            ae(l,:) = ae(l,:) - m*ae(k,:); 
          end          
       end
    end
    if(ae(n,n) == 0)
       disp('Sistem incop. sau sistem comp. nedet.');
    end
    [x] = SubsDesc(ae(:,1:n),ae(:,n+1));
end