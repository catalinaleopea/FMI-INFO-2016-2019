function [x] = GaussPivPart(a,b)
    % concatenam coloana b la matricea a (mat. extinsa)
    ae = [a, b];
    % nr de linii a matricei
    n = length(b);
    % implementarea propriu-zisa a algoritmului descris in curs
    for k = 1 : n-1
       % initializam maximul cu val min absoluta de pe coloana
       maxim = min(abs(ae(k:n,k)))-1;
       ind = 0;
       % cautam valoarea maxima abosluta de pe coloana k
       for p = k : n
          if(abs(ae(p,k)) > maxim)
             maxim = abs(ae(p,k));
             ind = p;
          end
       end
       if(ind == 0)
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
       end
       if(ind ~= k)
           % interschimbam liniile
           ae([k,ind],:) = ae([ind,k],:);
       end
       for l = k + 1 : n
          if(ae(l,k) ~= 0)
            m = ae(l,k)/ae(k,k);
            ae(l,:) = ae(l,:) - m*ae(k,:); 
          end          
       end
    end
    if(ae(n,n) == 0)
       disp('Sistem incop. sau sistem comp. nedet.');
    end
    [x] = SubsDesc(ae(:,1:n),ae(:,n+1));
end