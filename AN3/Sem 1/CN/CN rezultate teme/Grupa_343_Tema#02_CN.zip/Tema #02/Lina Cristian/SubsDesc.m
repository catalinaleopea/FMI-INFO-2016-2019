% ! 
function [x] = SubsDesc(a,b)
    % avem matricea superior triunghiulara a cu solutiile b
    n = length(a);
    x = zeros(n,1);
    % calculam xn
    x(n) = 1/a(n,n)*b(n);
    k = n - 1;
    % continua algoritmul ca cel descris in curs
    %                       si 
    while(k>0)
       sum = 0;
       % Challenge: Poti sa faci substitutia descendenta dintr-o singura
       % linie de cod? Hint -> Foloseste-te de produs scalar
       for j = k+1 : n
           sum = sum + a(k,j)*x(j);
       end
       x(k) = 1/a(k,k)*(b(k)-sum);
       k = k - 1;
    end
end