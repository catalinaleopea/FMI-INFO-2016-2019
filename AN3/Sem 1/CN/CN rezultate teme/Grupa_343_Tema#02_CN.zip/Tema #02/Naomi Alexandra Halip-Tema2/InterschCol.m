% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = o matrice
% 'k' = indicele uneia dintre coloanele ce urmeaza a fi interschimbate
% 'p' = indicele celeilalte coloane ce urmeaz a fi interschimbata
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = matricea A, in care sunt interschimbate coloanele k cu p
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

function [x] = InterschCol(A, k, p)
    n1 = size(A);
    n = max(n1); 
    %folosim o matrice identitate de dimensiunea matricei A
    I = eye(n);
    I(k, k) = 0;
    I(p, p) = 0;
    I(p, k) = 1;
    I(k, p) = 1;
    A = A * I;  %interschimbam linia p cu linia k, din matricea A
    x = A;
end