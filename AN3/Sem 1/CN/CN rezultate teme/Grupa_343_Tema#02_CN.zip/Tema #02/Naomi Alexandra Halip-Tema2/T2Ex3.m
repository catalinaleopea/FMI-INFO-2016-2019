% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Rezolv sistemele de la Ex.1 si Ex.3 apeland functiile 'GaussFaraPiv1',
% 'GausssPivPart' si 'GaussPivTot'
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================


% Ex.3. b.
A1 = [0 1 1;2 1 5;4 2 1]; % matricea primului sistem
b1 = [3;5;1]; 
disp('Gauss fara pivotare pentru primul sistem: ');
x1 = GaussFaraPiv1(A1, b1)
disp('Gauss cu pivotare partiala pentru primul sistem: ');
x2 = GaussPivPart(A1, b1)
disp('Gauss cu pivotare totala pentru primul sitem: ');
x3 = GaussPivTot(A1, b1)

A2 = [0 1 -2;1 -1 1;1 0 -1]; % matricea celui de-al 2-lea sistem
b2 = [4; 6; 2];
disp('Gauss fara pivotare pentru al 2-lea sistem: ');
y1 = GaussFaraPiv1(A2, b2)
disp('Gauss cu pivotare partiala pentru al 2-lea sistem: ');
y2 = GaussPivPart(A2, b2)
disp('Gauss cu pivotare totala pentru al 2-lea sistem: ');
y3 = GaussPivTot(A2, b2)

% c.
epsilon = 10^(-20);
A3 = [epsilon 1;1 1]; % matricea celui de-al 3-lea sistem
b3 = [1; 2];
disp('Gauss fara pivotare pentru al 3-lea sistem: ');
z1 = GaussFaraPiv1(A3, b3)
disp('Gauss cu pivotare partiala pentru al 3-lea sistem: ');
z2 = GaussPivPart(A3, b3)

C = 10^20;
A4 = [1 C;1 1]; % matricea celui de-al 4-lea sistem
b4 = [C; 2];
disp('Gauss cu pivotare partiala pentru al 4-lea sistem: ');
z3 = GaussPivPart(A4, b4)
disp('Gauss cu pivotare totala pentru al 4-lea sistem: ');
z4 = GaussPivTot(A4, b4)

