% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b, obtinuta prin metoda Gauss fara pivotare
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================


function [x] = GaussFaraPiv1(A, b)
    A = [A,b];
    n1 = size(A);
    n = n1(1);
    for k = 1:n-1
        % caut cel mai mic p, pentru care A(p, k) !=0
        y = find(A(k:n,k)~=0); % gaseste elementele de  pe col k din A 
        % diferite de 0
        p = y(1) +(k-1); % indicele liniei primului element nenul 
        if p == 0 || p < k || p > n
            disp('Sistem incompatibil sau compatibil nedeterminat');
            break;
        end
        if p ~= k
           A = InterschLin(A, p, k);
        end
        for l = k+1:n
            m(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - m(l, k)*A(k,:);
        end
    end
    if A(n, n) == 0
        disp('Sistem incompatibil sau compatibil nedeterminat');
    end
    x = SubsDesc(A, A(:,n+1));
end