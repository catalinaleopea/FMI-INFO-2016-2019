% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

function [x] = SubsDesc(A, b)
    n1 = size(A);
    n = n1(1); %numarul de linii al matricei A
    x(n) = (1/A(n,n)) *b(n);
    k = n - 1;
    while k > 0
        % Suma(k,A,x) este o functie construita petru a calcula suma de la
        % j=k+1 pana la n din akj*xj
        x(k) = (1/A(k,k)) *(b(k) -Suma(k,A,x)); 
        k = k - 1;
    end
end