% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b, obtinuta prin metoda Gauss cu pivotare
% totala
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

function [x] = GaussPivTot(A, b)
    A = [A,b];
    n1 = size(A);
    n = n1(1);
    for i =1:n
        index(i) = i;
    end
    for k = 1:n-1
        B = [A(:,k:n)]; % selectez coloanele de la k la n
        B = [B(k:n,:)]; % selectez liniile de la k la n
        % gasesc indicii elementului maxim cu ajutorul functiei predefinite
        % 'find'
        [u, v] = find(abs(B)==max(max(abs(B))));
        p = u(1) +(k-1); % indicele de pe linii al primului elem max 
        m = v(1) +(k-1); % indicele de pe coloana al primului element max
        if A(p, m) == 0
            disp('Sistem incompatibil sau compatibil nedeteminat');
            break;
        end
        if p ~= k
            A = InterschLin(A, p, k);
        end
        if m ~= k
            A = InterschCol(A, m, k); %interschimbam coloanele m si k cu 
            % ajutorul functiei 'InterschCol', implementata intr-un fisier de tip function
            % interschimbam indicii nec.
            aux = index(m);
            index(m) = index(k);
            index(k) = aux;
        end
        for l = k+1:n
            t(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - t(l, k)*A(k,:);
        end
    end
    if A(n, n) == 0
        disp('Sistem incompatibil sau compatibil nedeterminat');
    end
    y = SubsDesc(A, A(:,n+1));
    for i = 1:n
        x(index(i)) = y(i);
    end
end