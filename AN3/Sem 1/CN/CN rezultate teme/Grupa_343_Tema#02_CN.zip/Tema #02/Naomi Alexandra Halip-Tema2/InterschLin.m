% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = o matrice
% 'k' = indicele uneia dintre liniile ce urmeaza a fi interschimbate
% 'p' = indicele celeilalte linii ce urmeaz a fi interschimbata
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = matricea A, in care sunt interschimbate liniile k cu p
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

function [x] = InterschLin(A, k, p)
    n1 = size(A);
    n = n1(1); 
    % folosim o matrice identitate de dimensiunea matricei A
    I = eye(n);
    I(k, k) = 0;
    I(p, p) = 0;
    I(p, k) = 1;
    I(k, p) = 1;
    A = I * A;  %interschimbam linia p cu linia k, din matricea A
    x = A;
end