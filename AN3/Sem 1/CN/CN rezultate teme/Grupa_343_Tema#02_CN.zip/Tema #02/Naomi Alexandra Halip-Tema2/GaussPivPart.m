% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b, obtinuta prin metoda Gauss cu pivotare
% partiala
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

function [x] = GaussPivPart(A, b)
    A = [A,b];
    n1 = size(A);
    n = n1(1);
    for k = 1:n-1
        % cu ajutorul functiei predefinite 'find' gasesc indicele la care
        % se afla valoarea maxima
        y = find(abs(A(k:n,k))==max(max(abs(A(k:n,k)))));
        p = y(1) +(k-1); % indicele primului elem max de pe coloana k 
        if A(p, k) == 0
           disp('Sistem incompatibil sa compatibil nedeterminat');
           break;
        end
        if p ~= k
            A = InterschLin(A, p, k); % 'InterschLin'-functie implementata 
            % intr-un fisier de tip function
        end
        for l = k+1:n
            m(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - m(l, k)*A(k,:);
        end
    end
    if A(n, n) == 0
        disp('Sistem incompatibil sau compatibil nedeterminat');
    end
    % apelez metoda 'SubscDesc', implementata intr-un fisier de tip
    % function
    x = SubsDesc(A, A(:,n+1));
end