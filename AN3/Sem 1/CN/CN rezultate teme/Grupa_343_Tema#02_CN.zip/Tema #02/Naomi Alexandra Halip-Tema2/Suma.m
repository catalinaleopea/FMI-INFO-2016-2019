% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'k' = indicele unei pozitii in matrice
% 'A' = o matrice
% 'x' = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 's' = suma de la i=k+1 pana la n din Aki*xi
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

%functie creata pentru a putea construi met SubsDesc
function s = Suma(k, A, x)
    n = size(A);
    s = 0;
    for i = k+1:n
        s = s + A(k,i) *x(i);
    end
end