% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------
% 1. 10/10
% 2. 10/10
% 3. 9/10 -> Discutia de la c.?
% Total: 29/30 + 1p Bonus = 30/30 i.e. 10/10
% Bonusul este pentru stilul 'elegant' de a coda :)

% Tema 2. Exercitiul 3.b
A1 = [0 1 1; 2 1 5; 4 2 1];
b1 = [3 5 1]';
A2 = [0 1 -2; 1 -1 1; 1 0 -1];
b2 = [4 6 2]';

disp('Solutia sistemului 1:');
disp('-- Gauss fara pivotare:');
gaussFaraPiv(A1, b1)
disp('-- Gauss cu pivotare partiala:');
gaussPivPart(A1, b1)
disp('-- Gauss cu pivotare totala:');
gaussPivTot(A1, b1)

disp('Solutia sistemului 2:');
disp('-- Gauss fara pivotare:');
gaussFaraPiv(A2, b2)
disp('-- Gauss cu pivotare partiala:');
gaussPivPart(A2, b2)
disp('-- Gauss cu pivotare totala:');
gaussPivTot(A2, b2)

% Tema 2. Exercitiul 3.b
disp('Sistemul 1:');
epsilon = 10^(-20);
Aeps = [epsilon 1; 1 1];
bEps = [1 2]';
disp('-- Gauss fara pivotare:');
gaussFaraPiv(Aeps, bEps)
disp('-- Gauss cu pivotare partiala:');
gaussPivPart(Aeps, bEps)

disp('Sistemul 2:');
C = 10^20;
AC = [1 C; 1 1];
bC = [C 2]';
disp('-- Gauss cu pivotare partiala:');
gaussPivPart(AC, bC)
disp('-- Gauss cu pivotare totala:');
gaussPivTot(AC, bC)
