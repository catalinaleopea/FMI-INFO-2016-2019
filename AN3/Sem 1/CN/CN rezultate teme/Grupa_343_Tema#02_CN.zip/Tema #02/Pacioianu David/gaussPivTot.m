% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------
function [x] = gaussPivTot(A, b)
%GAUSSPIVTOT Procedura aplica metoda lui Gauss cu pivotare totala asupra 
%   lui A si rezolva ecuatia Ax = b folosind procedura SUBSDESC

    % Function to swap the rows of a matrix
    function M = swapRows(M,rowA,rowB)
        M([rowA rowB],:) = M([rowB rowA],:);
    end

    % Function to swap the columns of a matrix
    function M = swapColumns(M,colA,colB)
        M(:,[colA colB]) = M(:,[colB colA]);
    end

    % Function to subtract row(i) from all the rows in matrix M below
    % it, such that all elements below on column i are zero
    function M = makeZerosBelow(M, row, col)
        gaussRowMultipliers = M(row+1:end,col) / M(row,col);
        M(row+1:end,:) = M(row+1:end,:) - gaussRowMultipliers*M(row,:);
    end

[~,nColumnsA] = size(A); 
A = [A,b];
xOrderIndex = 1:nColumnsA;
for iCol = 1:nColumnsA
   [maxValue,~] = max(max(abs(A(iCol:end,iCol:end-1))));
   if maxValue == 0
       error('Error: Sistemul este incompatibil sau compatibil nedet.');
   end
   
   [pivotRow, pivotCol] = find(abs(A(iCol:end,iCol:end-1)) == maxValue,1);
   [pivotRow, pivotCol] = deal(pivotRow + iCol - 1, pivotCol + iCol - 1);   
   if pivotRow ~= iCol
      A = swapRows(A,iCol,pivotRow); 
   end
   if pivotCol ~= iCol
      A = swapColumns(A,iCol,pivotCol); 
      xOrderIndex = swapColumns(xOrderIndex,iCol,pivotCol); 
   end
   
   A = makeZerosBelow(A, iCol, iCol);
end

b = A(:,end);
A = A(:,1:end-1);
x = subsDesc(A,b);
x(xOrderIndex) = x;

end

