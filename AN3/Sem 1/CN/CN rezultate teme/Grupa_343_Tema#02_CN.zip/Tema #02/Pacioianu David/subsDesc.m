% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------
function x = subsDesc(A, b)
%SUBDESC Procedura aplica metoda substitutiei descendente 
%   x = SubsDesc(A, b), unde x este solu?tia sistemului Ax = b.

% Verificam integritatea datelor de intrare
[mRowsA, nColumnsA] = size(A);
if mRowsA ~= nColumnsA
    error('Error: Matricea nu este patratica.');
end
if istriu(A) == false
    error('Error: Matricea nu este superior triunghiulara.');
end
if nColumnsA ~= length(b)
    error(['Error: Lungimea vectorului b este %d. ' ... 
        'Era asteptat un vector de lungime %d'], length(b), nColumnsA);
end


% aplicam metoda substitutiei descendente 
x = zeros(nColumnsA, 1);

for iCol = nColumnsA:-1:1
   partialSumAx = A(iCol, iCol+1:end) * x(iCol+1:end);
   x(iCol) = (b(iCol) - partialSumAx) / A(iCol, iCol);
end

end

