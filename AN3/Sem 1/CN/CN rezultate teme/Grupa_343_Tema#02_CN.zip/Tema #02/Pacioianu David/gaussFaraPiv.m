% Elegant! Bravo! 
% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------
function [x] = gaussFaraPiv(A, b)
%GAUSSFARAPIV Procedura aplica metoda lui Gauss fara pivotare asupra lui A
%   si rezolva ecuatia Ax = b folosind procedura SUBSDESC

    % Function to swap the rows of a matrix
    function M = swapRows(M,rowA,rowB)
        M([rowA rowB],:) = M([rowB rowA],:);
    end

    % Function to subtract row(i) from all the elements in matrix M below 
    % row i such that all elements below on column i are zero
    function M = makeZerosBelow(M, row, col)
        gaussRowMultipliers = M(row+1:end,col) / M(row,col);
        M(row+1:end,:) = M(row+1:end,:) - gaussRowMultipliers*M(row,:);
    end

[~,nColumnsA] = size(A); 
A = [A,b];
for iCol = 1:nColumnsA
   pivotRow = find(A(iCol:end,iCol), 1) + iCol-1;
   if isempty(pivotRow) == true
       error('Error: Sistemul este incompatibil sau compatibil nedet.');
   end
   if pivotRow ~= iCol
      A = swapRows(A,iCol,pivotRow); 
   end
   A = makeZerosBelow(A, iCol, iCol);
end

b = A(:,end);
A = A(:,1:end-1);
x = subsDesc(A,b);

end

