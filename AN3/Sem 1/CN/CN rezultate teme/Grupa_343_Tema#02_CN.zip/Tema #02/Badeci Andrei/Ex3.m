% 1. -
% 2. 10/10
% 3. 5/ 10
% Total: 15/30 i.e. 5/10. Apreciez efortul tau :) 
% Pune si mesaje la consola de acum inainte
% Atentie ca gasesti balarii. Aparent Gauss-ii tai nu merg. :( 
function Ex3
    A1 = [0 1 1; 2 1 5; 4 2 1];
    b1 = [3;5;1];
    %primul sistem de la ex1
    aSist1 = GaussFaraPiv(A1,b1)
    bSist1 = GaussPivPart(A1,b1)
    cSist1 = GaussPivTot(A1,b1)

    A2 = [0 1 -2;1 -1 1; 1 0 -1];
    b2 = [4;6;2];
    aSist2 = GaussFaraPiv(A2,b2)
    bSist2 = GaussPivPart(A2,b2)
    %cSist2 = GaussPivTot(A2,b2) 
    %Sistem incompatibil sau compatibil nedeterminat
    %al doilea sistem de la ex1
    
    epsilon = 10^(-20);
    A3 = [epsilon 1;1 1];
    b3 = [1;2];
    aSist3 = GaussFaraPiv(A3,b3)
    bSist3 = GaussPivPart(A3,b3)
    %primul sistem de la c
    
    C = 10^20;
    A4 = [1 C;1 1];
    b4 = [C;2];
    aSist4 = GaussPivPart(A4,b4)
    bSist4 = GaussPivTot(A4,b4)
    %al doilea sistem de la c
end