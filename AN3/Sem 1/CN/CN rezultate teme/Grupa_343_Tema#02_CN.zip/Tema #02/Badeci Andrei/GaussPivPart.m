function [xNumeric] = GaussPivPart(A, b)
    B = [A, b]; %Matricea extinsa
    n = size(B, 1); %dimensiunea unei linii, nu conteaza pe care o luam
    for k = 1 : n - 1
        p = k;
        for i = k : n
            if abs(B(i, k)) > abs(B(p, k))
                p = i;
            end
        end
        if B(p, k) == 0
            fprintf("Sistem incompatibil sau compatibil nedeterminat");
        end
        if p ~= k %swap -> Vezi Fara Pivotare
            aux = B(k, :);
            B(k, :) = B(p, :);
            B(p, :) = aux;
        end
    end
    for l = (k + 1):n
        m = B(l, k)/B(k, k);
        B(l, :) = B(l, :) - m*B(k, :);
    end
    if B(n, n) == 0
        printf("Sistem incompatibil sau compatibil nedeterminat");
        return;  % nu am pus break pentru ca nu este intr-un loop
    end
    [xNumeric] = SubsDesc(B, b);
end