% ! 
function [xNumeric] = GaussFaraPiv(A, b)
    B = [A, b]; %Matricea extinsa
    n = size(B, 1); %dimensiunea unei linii, nu conteaza pe care o luam
    for k = 1: n - 1
        p = k;
        while B(p, k) == 0 && p <= n
            p = p + 1;
        end
        if p == n + 1
            printf("Sistem incompatibil sau compatibil nedeterminat");
            break
        end
        if p ~= k %swap
            % !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            % God, NO! Use B([linia_i linia_j], :) = B([linia_j linia_i], :)
            aux = B(k, :);
            B(k, :) = B(p, :);
            B(p, :) = aux;
        end
    end
    for l = (k + 1):n
        m = B(l, k)/B(k, k);
        B(l, :) = B(l, :) - m*B(k, :);
    end
    if B(n, n) == 0
        printf("Sistem incompatibil sau compatibil nedeterminat");
        return;  % nu am pus break pentru ca nu este intr-un loop
    end
    [xNumeric] = SubsDesc(B, b);
end 