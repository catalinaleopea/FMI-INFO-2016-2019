function [xNumeric] = GaussPivTot(A, b)
    B = [A, b]; %Matricea extinsa
    n = length(b); %dimensiunea unei linii, nu conteaza pe care o luam
    index = 1:n;
    for k = 1 : n - 1
        p = k;
        m = k;
        for i = k : n
            for j = k : n
                if abs(B(i, j)) > abs(B(p, m))
                    p = i;
                    m = j;
                end
            end
        end
        if B(p, m) == 0
            fprintf("Sistem incompatibil sau compatibil nedeterminat");
            break;
        end
        if p ~= k %swap
            A([p, k], :) = A([k, p], :);
            aux = B(k, :);
            B(k, :) = B(p, :);
            B(p, :) = aux;
        end
        if m ~= k %swap
            A(:, [m, k]) = A(:, [k, m]);
            aux = B(:, k);
            B(:, k) = B(:, m);
            B(:, m) = aux;
            index([m, k]) = index([k, m]);
        end
        for l = (k + 1) : n
            m = B(l, k)/B(k, k);
            B(l, :) = B(l, :) - m*B(k, :);
        end
    end
    if B(n, n) == 0
        fprintf("Sistem incompatibil sau compatibil nedeterminat");
        return; % nu am pus break pentru ca nu este intr-un loop
    end
    [y] = SubsDesc(B, b);
    for i = 1 : n
        xNumeric(index(i)) = y(i);
    end
end