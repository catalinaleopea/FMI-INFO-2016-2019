% Fisier de tip FUNCTION
% =========================================================================
% DATE DE INTRARE:
% A - Matrice N x N ce reprezinta coefiecientii sistemului
% b - Vector N x 1
% =========================================================================
% DATE DE IESIRE:
% x - vector 1 x N = solutia sistemului
% =========================================================================
% Author: Robert Stancu, 2018
% =========================================================================
% Frumos! 

function x = SubsDesc(A,b)

[n, ~] = size(A); % Dimensiunea matricei A

x(n) = (1/A(n,n)) * b(n); % Aflam elementul xn

k = n - 1;

% Iteratiile algorimtului

while k > 0
    
   product = sum(A(k,k+1:n) .* x(k+1:n)); % Calculam suma din
                                          % produsul scalar 
                                          
                                          
   x(k) = (1/A(k,k)) * (b(k) - product); % Aflam x(k)
   k = k - 1;
end


end

