% Fisier de tip FUNCTION
% =========================================================================
% DATE DE INTRARE:
% A - Matrice N x N ce reprezinta coefiecientii sistemului
% b - Vector N x 1
% =========================================================================
% DATE DE IESIRE:
% x - vector 1 x N = solutia sistemului
% =========================================================================
% Author: Robert Stancu, 2018
% =========================================================================



function x = GaussPivPart(A,b)

[n, ~] = size(A);

Ae = [A b];

faraSolutie = inf(1);

for k = 1:n - 1
    
   %Spre deosebire de Gauss fara pivotare, vom cautam maximul de pe
   % linie in modul
    
   [maxim,index] = max(abs(Ae(k:n,k)));
   
   % Incrementam indexul
   index = index + k - 1;   
   
   if maxim == 0
      fprintf('Sistem incompatibil / Sistem compatibil nedet\n');
      x = faraSolutie;
      return;
   end
   
   if index ~= k
       %Interschimbam liniile
       Ae([k, index],:) = Ae([index, k],:);
   end
   
   for l = k+1:n
      factor = Ae(l,k) / Ae(k,k); % Calculam raportul pentru a transforma
                                  % elementele de sub diagonala principala
                                  % in 0
                                  
      Ae(l,:) = Ae(l,:) - factor * Ae(k,:);
   end
   
end

if Ae(n,n) == 0
    fprintf('Sistem incompatibil sau sist comp nedet\n');
    x = faraSolutie;
    return;
end

 % Avand o matrice superior triunghiulara, putem aplica substitutia 
     % descendenta
x = SubsDesc(Ae(1:n,1:n),Ae(1:n,n+1));

end

