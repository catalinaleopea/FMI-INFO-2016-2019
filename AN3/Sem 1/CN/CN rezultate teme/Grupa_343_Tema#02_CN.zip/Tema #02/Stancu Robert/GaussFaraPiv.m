% Fisier de tip FUNCTION
% =========================================================================
% DATE DE INTRARE:
% A - Matrice N x N ce reprezinta coefiecientii sistemului
% b - Vector N x 1
% =========================================================================
% DATE DE IESIRE:
% x - vector 1 x N = solutia sistemului
% =========================================================================
% Author: Robert Stancu, 2018
% =========================================================================



function x = GaussFaraPiv(A,b)

infinity = inf(1);

[n, ~] = size(A); % Dimensiunea matricei A

Ae = [A b]; % Bordam matricea A cu vectorul coloana b

for k = 1:n-1
    
   [maxim,index] = max(Ae(k:n,k) ~= 0); % Cautam maximul pe linia curenta 
   
   if maxim == 0
      fprintf('Sistem incompatibil / Sistem compatibil nedet\n');
      x = infinity;
      return %Oprim algoritmul
   end
   
   index = index + k - 1; % Incrementam indicele liniei deoarece
                          % Submatricea va avea linii de la 1 la k
   
   if index ~= k
       Ae([k index],:) = Ae([index k],:); % Interschimbam liniile
   end
   
   for l = k+1:n
      factor = Ae(l,k) / Ae(k,k); % Calculam raportul pentru a transforma
                                  % elementele de sub diagonala principala
                                  % in 0
                                  
      Ae(l,:) = Ae(l,:) - factor * Ae(k,:); 
   end
  
end

if Ae(n,n) == 0
    fprintf('Sistem incompatibil sau sist comp nedet\n');
    x = infinity;
    return;
else
     % Avand o matrice superior triunghiulara, putem aplica substitutia 
     % descendenta
    x = SubsDesc(Ae(1:n,1:n),Ae(1:n,n+1));
end

end

