% Fisier de tip FUNCTION
% =========================================================================
% DATE DE INTRARE:
% A - Matrice N x N ce reprezinta coefiecientii sistemului
% b - Vector N x 1
% =========================================================================
% DATE DE IESIRE:
% x - vector 1 x N = solutia sistemului
% =========================================================================
% Author: Robert Stancu, 2018
% =========================================================================

function x = GaussPivTotala(A,b)

faraSolutie = inf(1); 

% Dimensiunea matricei A
[n, ~] = size(A);

% Bordam matricea A cu vectorul coloana b
Ae = [A b];

% Pozitiile elementelor xi,i = 1:n
index = 1:n;

for k = 1:n - 1

    
    %Cautam maximul in modul de pe toata submatricea
    [maximLinie,IndexLinie] = max(abs(Ae(k:n,k:n)));

    % Functia max va returna maximul de pe fiecare coloana,
    % deci functia max va trebui aplicata de doua ori
    
    [~,coloanaMaxim] = max(maximLinie);
    linieMaxim = IndexLinie(coloanaMaxim);
    
    if maximLinie(coloanaMaxim) == 0
      fprintf('Sistem incompatibil / Sistem compatibil nedet\n');
      x = faraSolutie;
      return;
    end
    
    % Incrementam coloana si linia unde se afla elementul respectiv
    coloanaMaxim = coloanaMaxim + k - 1; 
    linieMaxim = linieMaxim + k - 1;
   
    %Interschimbam liniile
   if linieMaxim ~= k
       Ae([k, linieMaxim],:) = Ae([linieMaxim, k],:);
   end
   
   % Interschimbam coloanele
   if coloanaMaxim ~= k
       Ae(:,[k,coloanaMaxim]) = Ae(:,[coloanaMaxim,k]);
       temp = index(k);
       index(k) = index(coloanaMaxim);
       index(coloanaMaxim) = temp;
   end
   
   for l = k+1:n
      factor = Ae(l,k) / Ae(k,k); % Calculam raportul pentru a transforma
                                  % elementele de sub diagonala principala
                                  % in 0
      
      
      Ae(l,:) = Ae(l,:) - factor * Ae(k,:);
   end
   
end

if Ae(n,n) == 0
    fprintf('Sistem incompatibil sau sist comp nedet\n');
    x = faraSolutie;
    return;
end

 % Avand o matrice superior triunghiulara, putem aplica substitutia 
 % descendenta
x = SubsDesc(Ae(1:n,1:n),Ae(1:n,n+1));

 % Schimbam ordinea elementelor solutiei
 
x(index) = x;

end

