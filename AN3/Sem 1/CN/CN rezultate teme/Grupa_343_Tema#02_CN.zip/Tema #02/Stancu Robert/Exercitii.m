% FISIER DE TIP SCRIPT
% CONTINE REZOLVARILE EXERCITIILOR DIN TEMA2, SEPARATE PRIN SECTIUNI
%%
% Exercitiile urmatoare sunt corespunzatoare punctului b de la exercitiul 3

%%
% =========================== PRIMUL SISTEM ===============================
% Fain! Insa arata si tu mesajele la consola cu fprintf. Am vazut ca stii
% sa arati si asa.
clc
A = [0 1 1; 2 1 5; 4 2 1];
b = [3 5 1]';

fprintf('Solutia sistemului folosind Gauss fara pivotare este: ');
x = GaussFaraPiv(A,b)

fprintf('Solutia sistemului folosind Gauss cu pivotare partiala este: ');
x = GaussPivPart(A,b)

fprintf('Solutia sistemului folosind Gauss cu pivotare totala este: ');
x = GaussPivTotala(A,b)
%%

% =========================== AL DOILEA SISTEM ============================
clc
A = [0 1 -2; 1 -1 1; 1 0 -1];
b = [4 6 2]';

fprintf('Solutia sistemului folosind Gauss fara pivotare este: ');
x = GaussFaraPiv(A,b)

fprintf('Solutia sistemului folosind Gauss cu pivotare partiala este: ');
x = GaussPivPart(A,b)

fprintf('Solutia sistemului folosind Gauss cu pivotare totala este: ');
x = GaussPivTotala(A,b)

%%

% Exercitiile urmatoare sunt corespunzatoare punctului c de la exercitiul 3

%% 

% ======================== PRIMUL SISTEM ==================================
clc
epsilon = 10 ^(-20);

A = [epsilon 1; 1 1];
b = [1 2]';

fprintf('Solutia sistemului folosind Gauss fara pivotare este: ');
x = GaussFaraPiv(A,b)

% Metoda Gauss Fara Pivotare este sensibila la coeficienti mici,
% Astfel, rezultatul va fi o aproximare a solutiei exacte

fprintf('Solutia sistemului folosind Gauss cu pivotare partiala este: ');
x = GaussPivPart(A,b)

% Metoda Gauss cu Pivotare Partiala intoarce rezultatul corect

%% 

% ======================== AL DOILEA SISTEM ===============================
clc
C = 10 ^(20);

A = [1 C; 1 1];
b = [C 2]';

fprintf('Solutia sistemului folosind Gauss cu pivotare partiala este: ');
x = GaussPivPart(A,b)

% Metoda Gauss cu Pivotare Partiala este sensibila la coeficienti mari,
% Astfel, rezultatul va fi o aproximare a solutiei exacte

fprintf('Solutia sistemului folosind Gauss cu pivotare totala este: ');
x = GaussPivTotala(A,b)

% Metoda Gauss cu Pivotare Totala intoarce rezultatul corect