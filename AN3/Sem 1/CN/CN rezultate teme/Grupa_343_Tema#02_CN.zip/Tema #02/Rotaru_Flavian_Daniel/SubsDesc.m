% !
function [x] = SubsDesc(A,b)
    [m,n] = size(A);
    if m ~= n
        fprintf("Matricea introdusa trebuie sa fie patratica !");
    else
        x(n,1) = b(n,1)/A(n,n);
        k = n-1;
        % Q: Poti sa scapi de sum si sa faci totul dintr-o linie de cod?
        % Hint: Produs scalar
        while k>0
            sum =0;
            for j = k+1:n
                sum = sum + A(k,j) * x(j,1);
            end
            x(k) = (1 / A(k,k)) *( b(k,1) - sum);
            k = k -1;
        end
    end

end
