function [x] = GaussPivTot(A,b)
    A = [A b];
    n = size(A,1);
    conditie = true;
    schimbariIndex = [];
    for k = 1 : (n-1)
       for i = k:n
           for j = k:n
               if abs(A(i,j)) == max(max(abs(A(k:n,k:n))))
                  p = i;
                  m = j;
               end
           end
       end
       if A(p,k) == 0
           conditie = false;
           break;
       end
       if p ~=k
           aux = A(p, :);
           A(p, :) = A(k, :);
           A(k, :) = aux;
       end
       if m ~= k
           aux = A(:, m);
           A(:, m) = A(:, k);
           A(:, k) = aux;
           schimbariIndex = [schimbariIndex; m,k];
           
       end
       for l = (k+1) : n
           raport = A(l, k)/A(k, k);
           A(l, :) = A(l, :) - raport*A(k,:);
       end
    end
    if A(n,n) == 0
        conditie = false;
    end
    if conditie == true
        m = size(schimbariIndex,1);
        x = SubsDesc(A(1:n,1:n), A(1:n,n+1));
        for i = m : -1:1
            index1 = schimbariIndex(i,1);
            index2 = schimbariIndex(i,2);
            aux = x( index1,1);
            x(index1,1) = x(index2,1);
            x(index2,1) = aux;
        end
    else
        fprintf("Sistemul este incompatibil sau compatibil nedeterminat\n");
    end
    
end