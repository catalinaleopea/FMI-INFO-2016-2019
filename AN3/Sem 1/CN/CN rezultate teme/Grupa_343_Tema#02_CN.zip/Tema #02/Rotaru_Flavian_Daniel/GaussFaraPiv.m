function [x] = GaussFaraPiv(A,b)
    A = [A b];
    n = size(A,1);
    conditie = true;
    for k = 1 : (n-1)
        p = n+1;
       for i = k:n
           if A(i,k) ~= 0
               p = i;  
           end
       end
       if p > n
           conditie = false;
           break;
       end
       % Schimba liniile intre ele asa: A([l_p l_k], :) = A([l_k l_p], :)
       if p ~= k
           aux = A(p,:);
           A(p,:) = A(k,:);
           A(k,:) = aux;
       end
       for l = k+1:n
           raport = A(l,k)/A(k,k);
           A(l,:) = A(l,:) - raport*A(k,:);
       end
    end
    if A(n,n) == 0
        conditie = false;
    end
    if conditie == true
        x = SubsDesc(A(1:n,1:n), A(1:n,n+1));
    else 
        fprintf("Sistemul este incompatibil sau compatibil nedeterminat\n");
    end
end