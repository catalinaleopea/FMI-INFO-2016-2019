% 1. -      Q: De ce nu faci si tema scrisa?
% 2. 10/10
% 3. 8/10 -> Neatentie + discutia de la c?
% Total: 18/30 i.e. 6/10 :(
% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Problema numarul -3- din Tema 02 rezolvata cu ajutorul algoritmilor:
%  
%  -> Metoda Substitutiei Descendente
%  -> Algoritmul Gauss fara Pivotare
%  -> Algoritmul Gauss cu Pivotare Partiala
%  -> Algoritmul Gauss cu Pivotare Totala
%
%   Toti acesti algoritmi se pot gasi atasati in arhiva, in fisiere de 
%   tip functie, alaturi de acest fisier script.
%
% -------------------------------------------------------------------------
% Author: Flavian Rotaru, 2018
% =========================================================================


%%
%==========================================================================
%   Subpunctul - B -
%--------------------------------------------------------------------------
%  Sa se apeleze procedurile pentru sistemele de la Ex. 1, apeland cele
%  trei ?siere create la subpunctul - A - .
%            x2 +  x3 = 3                        x2 - 2x3 = 4
%      2x1 + x2 + 5x3 = 5                   x1 - x2 +  x3 = 6
%      4x1 + 2x2 + x3 = 1                   x6      -  x3 = 2
%==========================================================================
 A = [0 1 1; 2 1 5; 4 2 1];    % Matricea corespunzatoare sistemului 1,
                            %alcatuita din coeficientii fiecarei necunoscute
% E mai usor cu transpusa la scris Rez1 = [3 5 1]'; 
Rez1 = [3;5;1];                %             Matricea Coloana alcatuita
                                %                  din solutiile ecuatiilor
 
 B = [0 1 -2; 1 -1 1; 1 0 -1];  % Matricea corespunzatoare sistemului 2,
                            %alcatuita din coeficientii fiecarei necunoscute
 Rez2 = [4;6;2];                %              Matricea coloana alcatuita
                                %              din solutiile ecuatiilor
 % - Solutiile Sistemului 1, calculate prin fiecare algoritm in parte
 Sol_sistem1_GaussFaraPiv = GaussFaraPiv(A,Rez1);   
 Sol_sistem1_GaussPivPart = GaussPivPart(A,Rez1);
 Sol_sistem1_GaussPivTot = GaussPivTot(A,Rez1);
 
 % Offff
 % Data viitoare baga si tu la argumentele de intrare matricile sistemului
 % 2 daca pe ala il vrei...
 % - Solutiile Sistemului 2, calculate prin fiecare algoritm in parte
 Sol_sistem2_GaussFaraPiv = GaussFaraPiv(A,Rez1);
 Sol_sistem2_GaussPivPart = GaussPivPart(A,Rez1);
 Sol_sistem2_GaussPivTot = GaussPivTot(A,Rez1);
 

%%
%==========================================================================
%   Subpunctul - C -
%--------------------------------------------------------------------------
%  Sa se aplice :
%   -> Metodele Gauss fara Pivotare si cu pivotare Partiala pentru
%   sistemul:
%        Epsilon * x1 + x2 = -12
%                  x1 + x2 = 2              unde: Epsilon = 10 ^ (-20) <<1    
%
%   -> Metodele Gauss cu Pivotare Partiala si cu pivotare Totala pentru
%   sistemul: 
%         x1 + C * x2 = C
%         x1 +     x2 = 2               unde : C = 10^ 20 >> 1
%
%   -> Verificati Solutiile si comparati metodele
%==========================================================================

Epsilon = 1e-20;
C = 1e20;

Mat_Sis1 = [Epsilon 1; 1 1];       % Matricea corespunzatoare sistemului 1
Rez_Sis1 = [1; 2];                 % Matricea corespunzatoare solutiilor 
                                   %       ecuatiilor sistemului 1

Mat_Sis2 = [1 C;1 1];              % Matricea corespunzatoare sistemului 1
Rez_Sis2 = [C; 2];                  % Matricea corespunzatoare solutiilor
                                   %       ecuatiilor sistemului 2 

% - Solutiile sistemului 1, calculate prin Metodele Gauss fara pivotare si
%   cu pivotare partiala
SolSistem1_GaussFaraPiv = GaussFaraPiv(Mat_Sis1,Rez_Sis1);
SolSistem1_GaussPivPart = GaussPivPart(Mat_Sis1,Rez_Sis1);
%  Afisare:
Sol1Inv = SolSistem1_GaussFaraPiv';
Sol2Inv = SolSistem1_GaussPivPart';
fprintf("Solutia Sistemului 1 Calculata prin Metoda Gauss fara Pivotare:");
fprintf("\n");
fprintf("[x1,x2] = [%d, %d]",Sol1Inv(1),Sol1Inv(2));
fprintf("\n");
fprintf("Solutia Sistemului 1 Calculata prin Metoda Gauss cu Pivotare Partiala:");
fprintf("\n");
fprintf("[x1,x2] = [%d, %d]",Sol2Inv(1),Sol2Inv(2));
fprintf("\n");


% Offff... Aceeasi problema ca mai sus .....
% - Solutiile sistemului 2, calculate prin Metodele Gauss cu pivotare
%   partiala si cu pivotare Totala
SolSistem2_GaussPivPart = GaussPivPart(Mat_Sis1,Rez_Sis1);
SolSistem2_GaussPivTot = GaussPivTot(Mat_Sis1,Rez_Sis1);
%  Afisare:
Sol3Inv = SolSistem2_GaussPivPart';
Sol4Inv = SolSistem2_GaussPivTot';
fprintf("Solutia Sistemului 2 Calculata prin Metoda Gauss cu Pivotare Partiala:");
fprintf("\n");
fprintf("[x1,x2] = [%d, %d]",Sol3Inv(1),Sol3Inv(2));
fprintf("\n");
fprintf("Solutia Sistemului 1 Calculata prin Metoda Gauss cu Pivotare Totala:");
fprintf("\n");
fprintf("[x1,x2] = [%d, %d]",Sol4Inv(1),Sol4Inv(2));
fprintf("\n");

% - Verificarea Solutiilor:
verificare = [false, false, false, false];      % Vectorul cu valorile de 
                                                % adevar ale verificarilor
verif_1 = Mat_Sis1 * SolSistem1_GaussFaraPiv;   % Valoarea verificarii 1
verif_2 = Mat_Sis1 * SolSistem1_GaussPivPart;   % Valoarea verificarii 2
verif_3 = Mat_Sis2 * SolSistem2_GaussPivPart;   % Valoarea verificarii 3
verif_4 = Mat_Sis2 * SolSistem2_GaussPivTot;    % Valoarea verificarii 4
if (verif_1 == Rez_Sis1)
    verificare(1) = true;       % Setarea valorii de adevar a verificarii 1
end
if (verif_2 == Rez_Sis1)
    verificare(2) = true;       % Setarea valorii de adevar a verificarii 2
end
if (verif_3 == Rez_Sis2)
    verificare(3) = true;       % Setarea valorii de adevar a verificarii 3
end
if (verif_4 == Rez_Sis2)
    verificare(4) = true;       % Setarea valorii de adevar a verificarii 4
end

%   Afisarea Verificarii eronate:

for i = 1:4
    if verificare(i) == false
        fprintf("Verificarea cu numarul %d nu este buna ! \n", i);
    end
end





