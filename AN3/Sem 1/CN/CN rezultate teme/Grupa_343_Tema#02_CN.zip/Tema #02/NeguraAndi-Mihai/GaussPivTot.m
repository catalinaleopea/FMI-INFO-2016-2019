function x = GaussPivTot(A,b)

% n = dimensiunea lui A
n = size(A,1);

for i = 1:n
    index(i) = i;
end
%Adaugam coloana ba la A
A = [A,b];
%Verificare daca programul va apela la urma SubsDesc
%contorSistemCompatibil = 1;

for k = 1:n-1
    %aceeasi verificare ca la gauss fara pivot.
    %psalvat = 1;
    %msalvat = 1;
   for p = n: -1:k
      for m = n:-1:k
        if abs(A(p,m)) == max(abs(A(k:n,k:n)))
            psalvat = p;
            msalvat = m;
        end
      end
   end
   
 %  if psalvat == n+1 || msalvat == n+1 || A(p,k) == 0
  %     contorSistemCompatibil = 0;
  % end
   
   if psalvat ~= k
       aux = A(psalvat,:);
       A(psalvat,:) = A(k,:);
       A(k,:) = aux;
   end
   
   if msalvat ~= k
      aux2 = A(:,msalvat);
      A(:,msalvat) = A(:,k);
      A(:,k) = aux2;
      y = index(msalvat);
      index(msalvat) = index(k);
      index(k) = y;
   end
   for l = k+1:n
      %calculam raportul
      m = A(l,k)/A(k,k);
      %transformam linia 
      A(l,:) = A(l,:) - m*A(k,:);
   end
   
   %cazul in care nu se poate apela SubsDesc
   % if A(n,n) == 0
    %    contorSistemCompatibil = 0;
    %end
    %apelam SubsDesc doar daca programul nu ar fi trebuit sa se opreasca pe
    %undeva
    %if contorSistemCompatibil == 1
        x = SubsDesc(A(1:n,1:n),A(1:n,n+1));
        %for i = n:-1:1
         %   if i~=index(i)
          %      aux = x(index(i),1);
           %     x(index(i),1) = x(i,1);
            %    x(i,1) = aux;
                
           % end
      %  end
    %else
     %   fprintf("Sist. incomp. sau sist. comp. nedet.");
    %end
end


end