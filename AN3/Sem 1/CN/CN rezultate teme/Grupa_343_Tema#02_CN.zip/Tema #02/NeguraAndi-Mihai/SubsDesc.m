function x = SubsDesc(A,b)

%datorita faptului ca matricea este patratica aflam dimensiunea ei cu size 
%n va fi numarul de linii
n = size(A,1);

%calculez x(n) stiind ca ultima ecuatie are doar o necunoscuta
x(n) = b(n) / A(n,n);
k = n-1;

while k > 0
   %initializez o suma cu 0
   s = 0;
   for j=k+1:n
       %calculez suma pentru formula din curs
       s = s + A(k,j)*x(j);
   end
   x(k) = 1/A(k,k)*(b(k) - s);
   k = k-1;
end
%returnez x transpus pentru ca el ar fi un vector linie
x = x';
end