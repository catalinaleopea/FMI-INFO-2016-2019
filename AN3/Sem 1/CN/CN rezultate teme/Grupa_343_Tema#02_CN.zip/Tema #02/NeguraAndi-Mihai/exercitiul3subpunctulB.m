% Virgulele Nu sunt necesare
A = [0,1,1;2,1,5;4,2,1]; 
b = [3;5;1];

GaussFaraPivotare1 = GaussFaraPiv(A,b);
GaussCuPivotarePartiala1 = GaussPivPart(A,b);
%pivotarea totala are o anumita problema
GaussCuPivotareTotala1 = GaussPivTot(A,b);

A2 = [0,1,-2;1,-1,1;1,0,-1];
b2 = [4;6;2];

GaussFaraPivotare2 = GaussFaraPiv(A2,b2);
GaussCuPivotarePartiala2 = GaussPivPart(A2,b2);
%gauss cu pivotare partiala 2 nu prevede cazul de sistem compatibil
%nedeterminat sau sistem incompatibil dar ne putem da seama din valorile
%returnate de functie
%GaussCuPivotareTotala1 = GaussPivTot(A2,b2);
