E = 10 ^ -20;
A = [E,1;1,1];
b = [1;2];

GaussFaraPivotare3 = GaussFaraPiv(A,b);
GaussPivPartiala3 = GaussPivPart(A,b);


C = 10 ^ 20;
A2 = [1,C;1,1];
b2 = [1;2];

GaussPivPartiala4 = GaussPivPart(A2,b2);
%GaussPivTotala4 = GaussPivTot(A2,b2);

