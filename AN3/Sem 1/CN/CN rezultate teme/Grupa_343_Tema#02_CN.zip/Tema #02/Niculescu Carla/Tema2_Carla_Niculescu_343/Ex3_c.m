% Exercitiul 3 - c
% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Aplicam metoda Gauss fara pivotare pentru primul sistem dat
epsilon = 10 ^ (-20); 
A = [epsilon 1; 1 1]; %declaram matricea asociata sistemului de ecuatii 
b = [1;2]; %declaram vectorul coloana al termenilor liberi din sistem

[x1] = GaussFaraPiv(A,b); % calculam vectorul coloana al necunoscutelor, 
                          % apeland metoda GaussFaraPiv
fprintf('Solutia primului sistem cu metoda Gauss fara pivotare: \n');
for ind = 1:2 %parcurgem cele doua necunoscute ale sistemului 
    fprintf('x%d = %d ; ', ind, x1(ind));
end
fprintf('\n');

% -------------------------------------------------------------------------
% Aplicam metoda Gauss cu pivotare partiala pentru primul sistem dat
[x2] = GaussPivPart(A,b); % calculam vectorul coloana al necunoscutelor, 
                          % apeland metoda GaussPivPart
fprintf('Solutia primului sistem cu metoda Gauss cu piv partiala(solutie corecta): \n');
for ind = 1:2
    fprintf('x%d = %d ; ', ind, x2(ind));
end
fprintf('\n');

% -------------------------------------------------------------------------
% Comparand cele doua rezultate pentru primul sistem si inlocuind 
% necunoscutele x1 si x2 in sistemul initial, observam ca rezultatul obtinut
% prin aplicarea lui Gauss cu pivotare partiala este cel corect;
% -------------------------------------------------------------------------

%Aplicam Gauss cu pivotare partiala pentru al doilea sistem de ecuatii dat
C = 10^20;
A1 = [1 C; 1 1]; %definim matricea asociata celui de-al doilea sistem
b1 = [C;2]; %definim vectorul coloana al termenilor liberi din cel de-al doilea sistem

[x3] = GaussPivPart(A1,b1);% calculam vectorul coloana al necunoscutelor, 
                          % apeland metoda GaussPivPart
fprintf('Solutia sistemului 2 cu metoda Gauss cu piv partiala: \n');
for ind = 1:2
    fprintf('x%d = %d ; ', ind, x3(ind));
end                     

fprintf('\n');

% -------------------------------------------------------------------------
%Aplicam Gauss cu pivotare totala pentru al doilea sistem de ecuatii dat
[x4] = GaussPivTot(A1,b1);% calculam vectorul coloana al necunoscutelor, 
                          % apeland metoda GaussPivPart
fprintf('Solutia sistemului 2 cu metoda Gauss cu piv totala(solutie corecta): \n');
for ind = 1:2
    fprintf('x%d = %d ; ', ind, x4(ind));
end 

% -------------------------------------------------------------------------
% Comparand cele doua rezultate pentru al doilea sistem si inlocuind 
% necunoscutele x1 si x2 in sistemul initial, observam ca rezultatul obtinut
% prin aplicarea lui Gauss cu pivotare totala este cel corect;
% -------------------------------------------------------------------------
fprintf('\n');