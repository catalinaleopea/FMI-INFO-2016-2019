% Exercitiul 3 - a
% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea asociata sistemului de ecuatii liniare 
% 'b' = vectorul coloana al termenilor liberi
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = vectorul coloana al necunoscutelor sistemului de ecuatii 
% -------------------------------------------------------------------------
% Exemplu de apel in consola:
% A = [0 1 1; 2 1 5; 4 2 1]; 
% b = [3;5;1];
% GaussPivTot(A,b)
% =========================================================================
function [x] = GaussPivTot(A,b)
[m, n] = size(A);
%verificam ca matricea A asociata sistemului de ecuatii sa fie patratica
if m~=n
    error('Matricea A trebuie sa fie patratica');
end
ncol = n+1; %ncol este nr de coloane dupa concatenarea matricei A cu coloana b
A = [A b];  %A se transforma in matricea extinsa asociata sistemului

% alocam spatiul de memorie necesar pentru vectorul index, pentru ca acesta
% sa nu-si schimbe dimensiunea la fiecare iteratie
index = zeros(1,n); 
% initializam vectorul de indici index care arata ordinea necunoscutelor in 
% vectorul coloana x (initial avem index = [1 2 ... n])
for ind = 1:n
    index(ind) = ind;
end

% parcurgem toate liniile de sus in jos, pana la penultima inclusiv
for k = 1:n-1
    % determina primii indici p si m astfel incat valoarea A(p,m) in modul 
    % este maxima in submatricea cu indicii liniilor si coloanelor de la 
    % k la n
    maxSubmatrice = 0;
    for linieSubm = k:n
        for colSubm = k:n
            if abs(A(linieSubm, colSubm)) > maxSubmatrice
                maxSubmatrice = abs(A(linieSubm, colSubm));
                p = linieSubm;
                m = colSubm;
            end
        end
    end
    
    if A(p,m) == 0
        fprintf('Sistem incompatibil sau compatibil nedeterminat');
        break;
    end
    
    if p~=k
        A([p k],:)=A([k p],:); %interschimbam liniile p si k in matricea A
    end
    
    if m~=k
        A(:,[m k]) = A(:,[k m]); %interschimbam coloanele m si k in matricea A
        % odata cu interschimbarea coloanelor m si k, se interschimba si
        % ordinea necunoscutelor x(m) si x(k) in vectorul x
        aux = index(m);
        index(m) = index(k);
        index(k) = aux;
    end
    
    for l = k+1:n
        factor = A(l,k)/A(k,k);
        %Efectuam operatia: Linia l <- Linia l - factor * Linia k;
        A(l,1:ncol) = A(l,1:ncol) - factor * A(k, 1:ncol);
    end
end

if A(n,n) == 0
        fprintf('Sistem incompatibil sau compatibil nedeterminat');
end

% aplicam metoda substitutiei descendente pentru sistemul superior
% triunghiular obtinut si retinem rezultatul in vectorul coloana y
y = SubsDesc(A, A(1:n, ncol));
for ind = 1:n
    x(index(ind)) = y(ind); %renumerotare necunoscute 
end
end
    
    