% Exercitiul 2
% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea superior triunghiulara asociata sistemului de ecuatii liniare 
% 'b' = vectorul coloana al termenilor liberi
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = vectorul coloana al necunoscutelor sistemului de ecuatii 
% =========================================================================
% Exemplu de apel in consola:
%    A = [2 1 5 ; 0 1 1; 0 0 -9];
%    b = [5;3;-9];
%    SubsDesc(A, b);
% =========================================================================    
function [x] = SubsDesc(A,b)
    n = length(b); % calculez in n dimensiunea matricei patratice A, care este 
                   % egala cu dimensiunea vectorului b
    x(n) = (1/A(n,n)) * b(n); % sistemul se va rezolva conform algoritmului 
                              % de jos in sus; am calculat necunoscuta x(n)
    %parcurgem fiecare ecuatie de jos in sus, incepand cu penultima
    k = n-1; 
    
    while k>0 
        %calculam x(k) conform formulei din algoritm 
        S1 = 0;
        for ind = k+1:n
            S1 = S1 + A(k,ind)*x(ind);
        end
        x(k) = (1/A(k,k))*(b(k) - S1);
        k = k-1;
    end
end


   