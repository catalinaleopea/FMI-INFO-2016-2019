% Exercitiul 3 - b
% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Apeleaza procedurile pentru cele doua sisteme de la Ex1, proceduri din
% cele 3 fisiere: GaussFaraPiv, GaussPivPart, GaussPivTot;
% Afiseaza vectorul x al necunoscutelor sistemelor
% =========================================================================
% Testare pentru sistemul 1:
% declaram si initializam matricea A1 asociata sistemului 1 si vectorul
% coloana b1 al termenilor liberi;
A1 = [0 1 1; 2 1 5; 4 2 1]; 
b1 = [3;5;1];

% aflu vectorul coloana al necunoscutelor sistemului, apeland metoda Gauss 
% fara pivotare
[xGaussFaraPiv] = GaussFaraPiv(A1,b1); 
fprintf('Solutia sistemului 1 dupa apelul la metoda GaussFaraPiv: \n');
for ind = 1:3
    fprintf('x%d = %d ; ', ind, xGaussFaraPiv(ind));
end
fprintf('\n');

% aflu vectorul coloana al necunoscutelor sistemului, apeland metoda Gauss cu
% pivotare partiala
[xGaussPivPart] = GaussPivPart(A1,b1);
fprintf('Solutia sistemului 1 dupa apelul la metoda GaussPivPart: \n');
for ind = 1:3
    fprintf('x%d = %d ; ', ind, xGaussPivPart(ind));
end
fprintf('\n');
                                   
% aflu vectorul coloana al necunoscutelor sistemului, apeland metoda Gauss cu
% pivotare totala
[xGaussPivTot] = GaussPivTot(A1,b1);
fprintf('Solutia sistemului 1 dupa apelul la metoda GaussPivTot: \n');
for ind = 1:3
    fprintf('x%d = %d ; ', ind, xGaussPivTot(ind));
end
fprintf('\n');
