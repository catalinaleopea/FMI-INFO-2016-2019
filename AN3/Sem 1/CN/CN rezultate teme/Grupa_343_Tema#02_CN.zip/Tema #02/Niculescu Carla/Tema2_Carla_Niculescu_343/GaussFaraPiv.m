% Exercitiul 3 - a
% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea asociata sistemului de ecuatii liniare 
% 'b' = vectorul coloana al termenilor liberi
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = vectorul coloana al necunoscutelor sistemului de ecuatii
% -------------------------------------------------------------------------
% Exemplu de apel in consola:
% A = [0 1 1; 2 1 5; 4 2 1]; 
% b = [3;5;1];
% GaussFaraPiv(A,b)
% =========================================================================
function [x] = GaussFaraPiv(A,b)
[m, n] = size(A);
%verificam ca matricea A asociata sistemului de ecuatii sa fie patratica
if m~=n
    error('Matricea A trebuie sa fie patratica');
end
ncol = n+1; %ncol este nr de coloane dupa concatenarea matricei A cu coloana b
A = [A b];  %A se transforma in matricea extinsa asociata sistemului 
%parcurgem toate liniile de sus in jos, pana la penultima inclusiv
for k = 1:n-1
    %cautam primul p cu k<=p<=n astfel incat A(p,k)~=0
    for p = k:n
        if A(p,k) ~= 0
           break;
        end
    end
    if p == n+1 %cazul in care p nu a fost gasit 
        fprintf('Sistem incompatibil sau compatibil nedeterminat');
        break;
    end
    if p~=k
        A([p k],:)=A([k p],:); %interschimbam liniile p si k in matricea A
    end
    for l = k+1:n
        factor = A(l,k)/A(k,k);
        %Efectuam operatia: Linia l <- Linia l - factor * Linia k;
        A(l,1:ncol) = A(l,1:ncol) - factor * A(k, 1:ncol);
    end
    if A(n,n) == 0
        fprintf('Sistem incompatibil sau compatibil nedeterminat');
        break;
    end
    %rezolvam sistemul cu matricea A transformata in matrice superior
    %triunghiulara, prin metoda substitutiei descendente
    x = SubsDesc(A, A(1:n, ncol));  
end
end

