% Functie specifica metodei Gauss cu pivotare partiala

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% x -> solutiile sistemului

% Aloritmul este implementat dupa pseudocodul aflat in cursul 2,pagina 22.

function [x] = GaussPivTot(A, b)

n = length(A); % Dimensiunea initiala a matricei (fara coloana termenilor 
%liberi)
A = [A,b]; % Adaugam coloana termenilor liberi
index = linspace(1,n,n); % Generam vectorul index cu valori de la 1 la n

% Iteratiile algoritmului
for k = 1:n - 1
    max = abs(A(k,k));
    for i = k:n
        for j = k:n
            if(abs(A(i,j)) > max)
                max = abs(A(j,k));
            end
        end
    end
    
    for p = k:n
        for m = k:n
            if(abs(A(p, m)) == max)
                break;
            end
        end
    end
    
    if(A(p,m) == 0)
        fprintf('Sistem incomp. sau sist. comp. nedet.\n');
        x = [];
        return;
    end
    
    if(p ~= k)
        aux = A(p,:);
        A(p,:) = A(k,:);
        A(k,:) = aux;
    end
    
    if(m ~= k)
        aux = A(:,m);
        A(m,:) = A(:,k);
        A(:,k) = aux;
        
        aux2 = index(m);
        index(m) = index(k);
        index(k) = aux2;
    end
    
    for l = k + 1:n
        m = A(l,k) / A(k,k);
        A(l,:) = A(l,:) - m * A(k,:);
    end
end

if(A(n,n) == 0)
    fprintf('Sistem incomp. sau sist. comp. nedet.\n');
    x = [];
    return;
end

y = SubsDesc(A(1:n,1:n), A(1:n,n+1));

for i = 1:n
    x(index(i)) = y(i);
end
  
end