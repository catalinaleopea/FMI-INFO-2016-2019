% Afiseaza si tu la consola cu fprintf mesaje si valori ca sa stiu si eu ce
% face script-ul asta. 


% Exercitiul 3,subpunctele b) si c)

% Adaugam matricea sistemului(A) si coloana termenilor liberi(b)



%Sistem ex 1
A1 = [0 1 1;2 1 5;4 2 1];
b1 = [3;5;1];

%Sistem ex 1
A2 = [0 1 -2;1 -1 1;1 0 -1];
b2 = [4;6;2];

%Sistem ex 2
A3 = [eps 1;1 1];
b3 = [1;2];

%Sistem ex 2
cMare = 10^20;
A4 = [1 cMare;1 1];
b4 = [cMare;2];

% Apelam metodele pentru fiecare sistem in parte

%Sistem ex 1
x1 = GaussFaraPiv(A1,b1);
x2 = GaussPivPart(A1,b1);
x3 = GaussPivTot(A1,b1);

%Sistem ex 1
x4 = GaussFaraPiv(A2,b2);
x5 = GaussPivPart(A2,b2);
x6 = GaussPivTot(A2,b2);

%Sistem ex 2
x7 = GaussFaraPiv(A3,b3);
x8 = GaussPivPart(A3,b3);

%Sistem ex 2
x9 = GaussPivPart(A4,b4);
x10 = GaussPivTot(A4,b4);