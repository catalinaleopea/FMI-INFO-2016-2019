% Functie specifica metodei Gauss cu pivotare partiala

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% x -> solutiile sistemului

% Aloritmul este implementat dupa pseudocodul aflat in cursul 2,pagina 12.

function [x] = GaussPivPart(A, b)

n = length(A); % Dimensiunea initiala a matricei (fara coloana termenilor 
%liberi)
A = [A,b]; % Adaugam coloana termenilor liberi

% Iteratiile algoritmului
for k = 1:n - 1
    max = abs(A(k,k));
    for j = k:n
        if(abs(A(j,k)) > max)
            max = abs(A(j,k));
        end
    end
    
    for p = k:n
        if(abs(A(p,k)) == max)
            break;
        end
    end
    
    for i = k : n
      if abs(A(i,k)) > abs(A(p,k))
        p = i;
      end
    end
    
    if(A(p,k) == 0)
      fprintf('Sistem incomp. sau sist. comp. nedet.\n');
      x = [];
      return;
    end
    
    if(p ~= k)
        aux = A(p,:);
        A(p,:) = A(k,:);
        A(k,:) = aux;
    end
    
    for l = k + 1:n
        m = A(l,k) / A(k,k);
        A(l,:) = A(l,:) - m * A(k,:);
    end
end

if(A(n,n) == 0)
    fprintf('Sistem incomp. sau sist. comp. nedet.\n');
    x = [];
    return;
end
  
x = SubsDesc(A(1:n,1:n),A(1:n,n+1));
  
end