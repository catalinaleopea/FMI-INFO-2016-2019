% Functie specifica metodei substitutiei descendente

% Date de intrare :
% A -> matricea asociata sistemului
% b -> coloana termenilor liberi

% Date de iesire :
% x -> solutiile sistemului

% Aloritmul este implementat dupa pseudocodul aflat in cursul 2,pagina 4.

function [x] = SubsDesc(A,b)

x(length(A)) = b(length(A)) / A(length(A),length(A)); % Aflam x(n) conform
%definitiei
k = length(A) - 1; % Initializare k

% Iteratiile algoritmului
while(k > 0)
    sum = 0;
    for j = k + 1:length(A)
        sum = sum + A(k,j) * x(j);
    end
    
    x(k) = (b(k) - sum) / A(k,k);
    k = k - 1;
end
  
end