
% Error in Isaia_Vlad_Lucian_343_tema_6_cn (line 82)
% y = f(x);

% Undefined function 'f' for input arguments of type 'double'.
% 
% Error in Isaia_Vlad_Lucian_343_tema_6_cn (line 128)
% y = f(x);
%% Exercitiul 3
f = @(x) x.^4 + 2*x.^2 - x - 3;
g = @(x) (3 + x - 2*x.^2) .^ (1 / 4);

%subpunctul c
a = -1;
b = 3/2;
figure(1);
x = linspace(a, b);
y = g(x);
plot(x, y);
title("g(x) = (3 + x - 2x^2)^(^1^/^4^)");
xlim([-1.5 2]);
ylim([-1.5 2]);
line([a a b b a], [a b b a a]);

%subpunctul d
syms x;
dg = matlabFunction(diff(g(x)));
figure(2);
x = linspace(a, b);
y = dg(x);
xlim([-0.5, 1.2]);
ylim([-0.5, 2]);
plot(x, y);
title("g'(x)");
line([-5, 5], [1, 1]);
line([-5, 5], [-1, -1]);

%subpunctul e
x0 = 1.2;
epsilon = 10^(-5);
x_sol = MetPunctFix(g, x0, epsilon);
disp("Solutia ecuatiei f(x) = 0 este:");
disp(x_sol);

%subpunctul f
x = linspace(a, b);
y = f(x);
figure(3);
plot(x, y);
hold on;
plot(x_sol, f(x_sol), 'o');
title("f(x) = x^4 + 2x^2 - x - 3");
xL = xlim;
yL = ylim;
line([0 0], yL);  %Ox
line(xL, [0 0]);  %Oy

%% Exercitiul 4
%a)
g1 = @(x) ((x + 3) ./ (x.^2 + 2)) .^ (1/2);
%subpunctul c)
a = -3;
b = 5;
figure(1);
x = linspace(a, b);
y = g1(x);
plot(x, y);
title("g1(x) = sqrt(((x+3) / (x^2 + 2)))");
line([a a b b a], [a b b a a]);

%subpunctul d)
syms x;
dg1 = matlabFunction(diff(g1(x)));
figure(2);
x = linspace(a, b);
y = dg1(x);
plot(x, y);
title("g1'(x)");
line([-5, 5], [1, 1]);
line([-5, 5], [-1, -1]);

%subpunctul e
x0 = 1.2;
epsilon = 10^-5;
x_sol = MetPunctFix(g1, x0, epsilon);
disp("Solutia ecuatiei f(x) = 0:");
disp(x_sol);
%subpunctul f
x = linspace(a, b);
y = f(x);
figure(3);
plot(x, y);
title("f(x) = x^4 + 2x^2 - x - 3");
hold on;
plot(x_sol, f(x_sol), 'o');
xL = xlim;
yL = ylim;
line([0 0], yL);  %Ox
line(xL, [0 0]);  %Oy

%% b)
g2 = @(x) ((x + 3 - x.^4) ./ 2) .^ (1/2);
%subpunctul c)
a = -1.16404;
b = 1.45263;
figure(1);
x = linspace(a, b);
y = g2(x);
plot(x, y);
title("g2(x) = sqrt(((x + 3 - x^4) / 2))");
line([a a b b a], [a b b a a]);

%subpunctul d)
syms x;
dg2 = matlabFunction(diff(g2(x)));
figure(2);
x = linspace(a, b);
y = dg2(x);
plot(x, y);
title("g2'(x)");
line([-5, 5], [1, 1]);
line([-5, 5], [-1, -1]);

%subpunctul e
x0 = 1.2;
epsilon = 10^-5;
disp("g2 nu converge la solutie");
%x_sol = MetPunctFix(g2, x0, epsilon);
%disp("Solutia ecuatiei f(x) = 0:");
%disp(x_sol);
%subpunctul f
x = linspace(a, b);
y = f(x);
figure(3);
plot(x, y);
title("f(x) = x^4 + 2x^2 - x - 3");
hold on;
plot(x_sol, f(x_sol), 'o');
xL = xlim;
yL = ylim;
line([0 0], yL);  %Ox
line(xL, [0 0]);  %Oy

%% Exercitiul 6
%subpunctul c
epsilon = 10^-5;
syms x1 x2;

F1 = x1.^2 - 10*x1 + x2.^2 + 8;
F2 = x1 .* x2.^2 + x1 - 10 * x2 + 8;

G1 = (x1.^2 + x2.^2 + 8) / 10;
G2 = (x1.*x2.^2 + x1 + 8) / 10;

cond = 1;

x0 = [0.5, 0.5];

while cond ~= 0
    xk_1 = subs(G1, x1, x0(1));
    xk_1 = subs(xk_1, x2, x0(2));
    
    xk_2 = subs(G2, x1, x0(1));
    xk_2 = subs(xk_2, x2, x0(2));
    
    if(norm([xk_1, xk_2] - [x0(1), x0(2)], inf) < epsilon)
        cond = 0;
    end

    x0 = [xk_1, xk_2];
end
xaprox = [xk_1, xk_2];
disp("Solutia sistemului de ecuatii F1(x1, x2) = 0 si F2(x1, x2) = 0");
disp(double(xaprox));

%subpunctul d
figure(1);
fimplicit(F1, [0, 10, -5, 5]);
title(['{\color{red}F2(x1, x2) = x1*x2^2 + x1 - 10*x2 + 8;','\color{blue}F1(x1, x2) = x1^2 - 10*x + x2^2 + 8;}'],'interpreter','tex');
hold on;
fimplicit(F2, [-15, 10, -10, 10]);

%subpunctul e
%nu stiu de ce trebuie asa, am fost ajutat de cineva aici
plot(xaprox(1), 'o');
%%
function [x1] = MetPunctFix(f, x0, epsilon)
    cond = 1;
    
    while cond ~= 0
        x1 = f(x0);
        
        if(abs(x1 - x0) < epsilon)
            cond = 0;
        end
        
        x0 = x1;
    end
end


