%==========================================================================
% EX.3: Fie ecuatia f(x) = 0, unde f(x) = x^4 + 2*x^2 - x - 3 .
% Se considera functia g(x) = (3 + x  - 2*x^2) ^ 1/4. 
% 
% a) Aratati ca daca x* este un punct fix pentru g, atunci x* este radacina 
% functiei f.
% b) Aflati domeniul de definitie [a,b] al functiei g.
% c) Construiti in Matlab graficul functiei g pe intervalul [a,b] si un 
% patrat cu varfurile de coordonate (a,a), (a,b), (b,a), (b,b). Verficati 
% conform graficului daca g(x) ? [a,b], ?x ? [a, b], i.e. graficul functiei
% g ramane in interiorul patratului.
% d) Construiti graficul functiei g' pe intervalul [a,b]..
% e) Construiti intr-o alta figura functia f pe intervalul [a,b] si solutia
% aproximativa.

% 1,2, 6 -> 0
% 5. s-a scos
% 3. 10
% 4. ^* 8/10 (Mai multa atentie la cod! )
% Total> 18/50 i.e. 3.6/10
%==========================================================================

syms x;
syms f(x);
syms g(x);

f(x) = x^4 + 2*(x^2) - x - 3;
g(x) = (3 + x - 2*(x^2)) ^(1/4);

a = -1;         
b = 3/2;                            % Domeniul de definitie al lui g

% - Punctul c)

X = linspace(a,b,100);              
Y = g(X);               
figure(1);
grid on;
hold on;
plot(X,Y,'--b');                % Graficul lui g
hold on;
plot([a,a,b,b,a],[a,b,b,a,a],'r');          % Patratul
hold on; 
axis([-1.5 2 -1.5 2]);                  
hold on;

% - Punctul d) 
error = 1.e-5  ;                        % Am luat o erroare mica deoarece
X2 = linspace(a+error, b-error,100);    % nu exista derivata in pct x=a si
dg(x) = diff(g(x));                     % x = b, iar diff afisa eroare.
Z = dg(X2);
plot(X,Z,'--g');                    % Graficul lui g'
hold on;
plot([-100,100],[1,1],'m');         % linia y = 1
hold on;
plot([-100,100],[-1,-1],'m');       % linia y = -1

legend('g(x)', 'Patratul', "g'(x)", 'y = 1', 'y = -1');

hold off;

% Alegem intervalul [-0.7,0.7] 

%%
%==========================================================================
% EX.4: Acelasi lucru ca la ex. 3, cu functiile: 
% a) g(x) = ( (x + 3)/(x^2 + 2) )^ (1/2).
% b) g(x) = ( (x + 3 - x^4) / 2) ^ (1/2).
%==========================================================================

syms g1(x);
syms g2(x);

g1(x) = ( (x + 3)/(x^2 + 2) )^ (1/2);
g2(x) = ( (x + 3 - x^4) / 2) ^ (1/2);

% - Punctul a) -> NU merge rulat pentru ca da eroare

% 
% a2 = -3;                               % Am luat valorile [-3,100] pentru ca
% b2 = 100;                              % domeniul este R, dar pentru x >= -3
%                                        % g1(x) = 0
% X1 = linspace(a2,b2,100);
% Y = g1(X);
% figure(2);
% grid on;
% hold on;
% plot(X,Y,'--b');                        % Graficul lui g1
% hold on;        
% plot([a2,a2,b2,b2,a2],[a2,b2,b2,a2,a2],'r');        % Patratul
% hold on; 
% axis([-10 120 -10 120]);
% hold on;
% 
% dg2(x) = diff(g1(x));                % derivata lui g1, iar da eroare
% Z = dg2(X1);                     % deoarece intr-un punct nu este definita
% plot(X1,Z,'--g');                   % Incercarea de grafic
% hold on;
% plot([-100,100],[1,1],'m');             % incercarile liniilor
% hold on;
% plot([-100,100],[-1,-1],'m');
% 
% legend('g(x)', 'Patratul', "g'(x)", 'y = 1', 'y = -1');
% 
% hold off;

% - Punctul b)

a2 = -1;
b2 = 1.5;

X2 = linspace(a2,b2,100);
Y = g2(X);
figure(3);
grid on;
hold on;
plot(X,Y,'--b');                        % Graficul lui g1
hold on;        
plot([a2,a2,b2,b2,a2],[a2,b2,b2,a2,a2],'r');        % Patratul
hold on; 
axis([-3 3 -3 3]);
hold on;

dg2(x) = diff(g2(x));                % derivata lui g2, iar da eroare
Z = dg2(X1);                    
plot(X1,Z,'--g');                   % Graficul derivatei lui g2
hold on;
plot([-100,100],[1,1],'m');             % linia y = 1
hold on;
plot([-100,100],[-1,-1],'m');           % linia y = -1

legend('g(x)', 'Patratul', "g'(x)", 'y = 1', 'y = -1');
