%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMA 6                                                                  %
% - acest fisier reprezinta implementarile anumitor exercitii din tema 6  %
% - exercitiile care contin demonstratii sau care cereau explicit         %
%               rezolvare manuala vor fi predate personal; acestea sunt:  %
%                         => exercitiul 1                                 %
%                         => exercitiul 2                                 %
%                         => exercitiul 3 (punctele a si b)               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;

%% %%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% c)
syms x
g = @(x) (3 + x - 2 .* (x.^ 2)).^(1/4); % functia g
a = -1;                                 % capetele domeniului de definitie
b = 3 / 2;
X = linspace(a,b);                      % discretizam domeniul de definitie
Y = g(X);                               % codomeniul

figure(1)
title('Ex. 3, c): Graficul functiei g')
plot(X,Y,'-r');                         % graficul functiei g
hold on
xlim([-1.5 2]);
ylim([-1.5 2]);
plot(a,a,'*b');                         % colturile dreptunghiului
plot(a,b,'*b');
plot(b,a,'*b');
plot(b,b,'*b');
line([-1 -1 3/2 3/2 -1], [-1 3/2 3/2 -1 -1]); % creez dreptunghiul 
hold off;

% d)
dg = matlabFunction(diff(g(x),x)); % derivata lui g
Z = dg(X);                         % valorile derivatei lui g

figure(2)
title('Ex. 3, d): Graficul functiei dg')
plot(X,Z,'-r');                    % graficul derivatei lui g
hold on
line([0 1],[1 1]);
line([0 -1], [-1 -1]);
xlim([-1.5 2]);
ylim([-1.5 2]);
%hold off;

% incercare de rezolvare pt restul cerintei
a1 = 0;
b1 = 0.5;

% e)
% implementarea metodei se gaseste in fisierul function metPctFix.m
eps = 10.^(-5);   % eroarea  
pctStart = 1.2;   % un punct aleator din intervalul [a,b]

pctFixDg = metPctFix(dg, eps, pctStart);
plot(pctFixDg, dg(pctFixDg), '*m');
hold off;

sprintf('Punctul fix x* al functiei dg este %0.3f.\ndg(%0.3f) = %0.3f.', ...
         pctFixDg, pctFixDg, dg(pctFixDg))
     
% f) (e' de fapt)
figure(3)
title('Ex. 3, f): Graficul functiei f')
f = @(x) x.^4 + 2*(x.^2) - x - 3;  % functia f
df = matlabFunction(diff(f(x),x)); % derivata lui f
% aproxZeroF = MetBisectie(f,a,b,eps);  % chestia asta nu e ok pt ca
%                                       % f(a)*f(b) > 0; ca sa pot face
%                                       % totusi ceva voi lua un alt a
a2 = -0.8;
aproxZeroF = MetBisectie(f,a2,b,eps);
pctFixG = metPctFix(g, eps, pctStart);
sprintf('f(%0.3f) = 0', aproxZeroF)
if (aproxZeroF == pctFixG)
    sprintf('Aproximarea valorii lui f(x)=0 si a punctului fix al lui g coincid.')
else
    sprintf('Aproximarea valorii lui f(x)=0 si a punctului fix al lui g NU coincid.')
end
   
Y2 = f(X);
plot(X,Y2,'-r');
xlim([-1.5 2]);
ylim([-5 10]);
hold on
plot(X,Y,'-r');
plot(aproxZeroF, f(aproxZeroF), '*b');
plot(pctFixG, g(pctFixG), '*g');
hold off;

%% %%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% a)
g1 = @(x) ((x + 3)/(x.^2 + 2)).^(1/2);
% domeniul acestei functii este [-3, +inf) (calculul se gaseste pe foi)
% pentru rezolvarea exercitiului, voi alege un subinterval
ag1 = -3;
bg1 = 3;
Xg = linspace(ag1, bg1, 1000);
Yg1 = g1(Xg); % nu stiu ce se intampla, dar Yg1 ramane un singur float in 
              % loc de un vector
pctFixG1 = metPctFix(g1,eps,0);
sprintf('Punctul fix x* al functiei g1 este %0.3f.\ndg(%0.3f) = %0.3f.', ...
         pctFixG1, pctFixG1, g1(pctFixG1))
figure(4)
plot(Xg,Yg1,'-r');
hold on
plot(pctFixG1,g1(pctFixG1),'*b');
hold off;

g2 = @(x) ((x + 3 - x.^4) / 2).^(1/2);
% domeniul acestei functii este [-inf, +inf) 
% voi folosi acelais subinterval ca la g1
Yg2 = g2(Xg);

figure(5)
plot(Xg,Yg2,'-r');
hold on
pctFixG2 = metPctFix(g2,eps,0);
sprintf('Punctul fix x* al functiei g2 este %0.3f.\ndg(%0.3f) = %0.3f.', ...
         pctFixG2, pctFixG2, g2(pctFixG2))
plot(pctFixG2,g2(pctFixG2),'*b');

%%
% nu stiu de ce, MATLAB-ul a facut urat cand am incercat sa rulez ce am
% avut nevoie din fisiere function
% fiindca nu am reusit sa ii dau de cap si pentru ca nu am mai avut mult
% timp la dispozitie, am pus functiile aici; imi pare rau :(

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUNCTII %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [sol] = metPctFix(func, eps, pctStart)
    
    penultim = pctStart;
    ultim = 0;
    cond = 1;
    
    while (cond)
        ultim = func(penultim);
        % disp(ultim);
        if (abs(ultim - penultim) < eps)
            cond = 0;
        else
            penultim = ultim;
        end
    end
    
    sol = ultim;
end

function [xaprox] = MetBisectie(f,a,b,epsi)
% initializari
    A(1) = a; % sirul capetelor din stanga obtinute pe parcursul 
              %       algoritmului
              % primul este chiar capatul din stanga al intervalului
    B(1) = b; % sirul capetelor din dreapta obtinute pe parcursul
              %       algoritmului
              % primul este chiar capatul din dreapta al intervalului
    x(1) = (a + b) / 2; % sirul aproximarilor lui x
                        % incepem cu el la jumatatea intervalului
    n = floor(log((b - a) / epsi) - 1) + 1; % criteriul de oprire (a se
                                            % vedea demonstratia din curs)
    k = 1;
% algoritm    
    for k = 2 : n
        if (f(x(k - 1)) == 0)
            x(k) = x(k-1); %am gasit solutia exacta
            break;
        elseif (f(A(k-1)) * f(x(k-1)) < 0)
            A(k) = A(k - 1); %ramane la fel
            B(k) = x(k - 1); %deplasez b-ul la stanga
            x(k) = (A(k-1) + B(k-1)) / 2;
        else
            A(k) = x(k-1); %deplasez a-ul mai la dreapta
            B(k) = B(k-1);
            x(k) = (A(k-1) + B(k-1)) / 2;
        end
    end
    xaprox = x(k); % aproximarea numerica a lui x
end