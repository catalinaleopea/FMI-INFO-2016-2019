%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA DE PUNCT FIX                                                     %
% - functia de mai jos gaseste punctul fix al unei functii conform        %
%           teoremei III.2 din cursul 6                                   %
% - se construieste un sir conform specificatiilor din teorema si cu      %
%      conditia de oprire data de cerinta exercitiului; acest sir va      %
%      converge la punctul fix, deci ultima valoare pe care o va calcula  %
%      functia va fi chiar aproximarea lui x*                             %
% - pentru a efuicientiza programul, eu nu voi construi tot sirul, ci voi %
%          pastra mereu ultimul si penultimul termen, pentru a construi   %
%          mereu din acestia noua valoare                                 %
% INPUT:  - func => functia al carei punct fix il caut                    %
%         - eps => eroarea                                                %
%         - pctStart => un punct aleator din domeniul de definitie al     %
%                       functiei                                          %
% OUTPUT: - sol => aproximarea numerica a punctului fix                   %                                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sol] = metPctFix(func, eps, pctStart)
    
    penultim = pctStart;
    ultim = 0;
    cond = 1;
    
    while (cond)
        ultim = func(penultim);
        % disp(ultim);
        if (abs(ultim - penultim) < eps)
            cond = 0;
        else
            penultim = ultim;
        end
    end
end