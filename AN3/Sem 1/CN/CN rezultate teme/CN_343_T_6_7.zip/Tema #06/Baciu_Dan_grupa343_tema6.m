% % % Undefined function or variable
% % % 'tol'.
% % % 
% % % Error in Baciu_Dan_grupa343_tema6
% % % (line 40)
% % % sol = punctFix(g,1,tol);

% Pune sectiuni data viitoare pentru fiecare exercitiu!
% Nota: 4/10 -> Codul tau este problematic tare! 

%Baciu Dan-Stefan
%grupa 343
%tema 6
%% 
g = @(x)(3+x-2*x.^2).^(1/4);
a = -2;
b = 2;
%ex 3 c
figure
plot([a,b,b,a,a],[a,a,b,b,a],'g-');
hold on;
x = linspace(a,b);
plot(x,g(x),':');

%ex3 d
x = linspace(a,b);
syms arg;
dg = matlabFunction(diff(g(arg)));
plot(x,dg(x),'-b')
hold on;
plot([a b],[-1 -1],'--r');
plot([a b],[1 1], '--g');

%alt exemplu
a = -1;
b = 1;
figure
plot([a,b,b,a,a],[a,a,b,b,a],'g-');
hold on;
x = linspace(a,b);
plot(x,g(x),':');
x = linspace(a,b);
syms arg
dg = matlabFunction(diff(g(arg)));
plot(x,dg(x),'-b')
hold on;
plot([a b],[-1 -1],'--r');
plot([a b],[1 1], '--g');

%ex3 e
sol = punctFix(g,1,tol);

%ex3 f
f = @(x)x.^4 + 2*x.^2-x-3;
tol = 10^(-5);
figure
x = linspace(a,b);
plot(x,f(x),'-r');
hold on;
plot(sol,f(sol),'ob');


%% ex 4 -> Ruleaza la Inf
g1 = @(x)((x+3)/(x.^2 + 2)).^(1/2);
a1 = -1;
b1 = 3/2;
%ex 4A c
figure
plot([a1,b1,b1,a1,a1],[a1,a1,b1,b1,a1],'g-');
hold on;
x1 = linspace(a1,b1);
plot(x1,g1(x1),':');

%ex 4A d
x1 = linspace(a1,b1);
syms arg
dg1 = matlabFunction(diff(g1(arg)));
plot(x1,dg1(x1),'-b')
hold on;
plot([a1 b1],[-1 -1],'--r');
plot([a1 b1],[1 1], '--g');

%alt exemplu
a1 = -0.25;
b1 = 0.5;
figure
plot([a1,b1,b1,a1,a1],[a1,a1,b1,b1,a1],'g-');
hold on;
x1 = linspace(a1,b1);
plot(x1,g1(x1),':');
x1 = linspace(a1,b1);
dg1 = matlabFunction(diff(g1(arg)));
plot(x1,dg1(x1),'-b')
hold on;
plot([a1 b1],[-1 -1],'--r');
plot([a1 b1],[1 1], '--g');

%ex4A e
tol = 10^(-5);
sol1 = punctFix(g1,1,tol);

%ex4A f
f = @(x)x.^4 + 2*x.^2-x-3;
figure
x1 = linspace(a1,b1);
plot(x1,f(x1),'-r');
hold on;
plot(sol1,f(sol1),'ob');


g2 = @(x)((x + 3 -(x.^4))/2).^(1/2);
a2 = -1;
b2 = 3/2;

%ex4B c
figure
plot([a2,b2,b2,a2,a2],[a2,a2,b2,b2,a2],'g-');
hold on;
x2 = linspace(2,2);
plot(x2,g2(x2),':');

%ex4B d
x2 = linspace(a2,b2);
syms arg
dg2 = matlabFunction(diff(g2(arg)));
plot(x2,dg2(x2),'-b')
hold on;
plot([a2 b2],[-1 -1],'--r');
plot([a2 b2],[1 1], '--g');

%alt exemplu
a2 = -0.25;
b2 = 0.5;
figure
plot([a2,b2,b2,a2,a2],[a2,a2,b2,b2,a2],'g-');
hold on;
x2 = linspace(a2,b2);
plot(x2,g2(x2),':');
x2 = linspace(a2,b2);
dg2 = matlabFunction(diff(g2(arg)));
plot(x2,dg2(x2),'-b')
hold on;
plot([a2 b2],[-1 -1],'--r');
plot([a2 b2],[1 1], '--g');

%ex4A e
tol = 10^(-5);
sol2 = punctFix(g2,1,tol);

%ex4A f
f = @(x)x.^4 + 2*x.^2-x-3;
figure
x2 = linspace(a2,b2);
plot(x2,f(x2),'-r');
hold on;
plot(sol2,f(sol2),'ob');

%% EX 6
G1 = @(x1,x2) x1.^2 - 10.*x1 + x2.^2 + 8;
G2 = @(x1,x2) x1 .* x2.^2 + x1 - 10 .* x2 + 8;

%EX6 c
tol4 = 10 ^(-5);
G = @(x) [(x(1) .^ 2 + x(2) .^2 +8)/10, (x(1) .^ x(2).^2 + 8)/10];
sol4 = punctFix(G,[1:1], tol4);

%ex6 d
F1(x1,x2) = 0;
F2(x1,x2) = 0;
F1 = @(x1,x2) x1.^2 - 10.*x1 + x2.^2 + 8;
F2 = @(x1,x2) x1 .* x2.^2 + x1 - 10 .* x2 + 8;
figure;
fimplicit(F1);
fimplicit(F2);

%% 
function x_punct_fix = punctFix(g,x, tol)
    x_temp = g(x);
    while abs(x_temp - x) >= tol
        x = x_temp;
        x_temp = g(x);
    end
   x_punct_fix = x_temp;
end
