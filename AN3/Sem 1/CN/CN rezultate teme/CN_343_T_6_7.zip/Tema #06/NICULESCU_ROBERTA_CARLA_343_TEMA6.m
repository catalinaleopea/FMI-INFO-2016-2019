%%
%Exercitiul 3 
%c)
figure
g=@(x)(3 + x -2*x.^2).^(1/4);
a = -1;
b = 3/2;
x = linspace(a,b,100); %discretizarea intervalului [a,b]
plot(x, g(x), '-r'); %plotam graficul functiei g
hold on;
plot([a,b,b,a,a],[a,a,b,b,a],'xg'); %plotam patratul dat
%se observa ca graficul functiei g ramane in interiorul patratului
title('Graficul functiei g')
legend('y = g(x)', 'colt de patrat')

%d)
figure
syms arg;
dg = matlabFunction(diff(g(arg))); %calculam derivata functiei g
plot(x, dg(x), '-b'); %trasam graficul derivatei lui g 
hold on;
%plotare a doua segmente de dreapta de pe dreptele y=1 si y=-1
plot([a b], [-1 -1], '-k');
plot([a b], [1 1], '-k');

line(xlim, [0 0], 'color', 'k', 'linewidth', 2)  % Axa Ox
line([0 0], ylim, 'color', 'k', 'linewidth', 2) %axa Oy 
xlabel('x')
ylabel('y')
str = sprintf('Grafic g restrictionat la [%f, %f]', a, b);
title(str)
legend('y = dg(x)', 'segment de dreapta')
%se observa ca pt a si b alese, exista x din [a,b] a.i. 
%dg(x) nu apartine intervalului [a,b]

%cautam alta solutie [a,b] care sa respecte conditiile
%construim un patrat cu diagonala pe bisectoarea y=x care contine punctul
%fix

a = -0.75;
b = 1.25;

figure;
plot([a,b,b,a,a], [a,a,b,b,a], 'xg'); %trasam patrat 

hold on;
x = linspace(a,b,100);
plot(x, g(x), '-r'); %trasam graficul lui g
plot(x, x, '-k'); %trasam bisectoarea y=x
syms arg;
dg = matlabFunction(diff(g(arg)));
plot(x, dg(x), '-b'); %trasam graficul derivatei lui g
hold on;
%trasam cele doua segmente 
plot([a b], [-1 -1], '-k');
plot([a b], [1 1], '-k');

line(xlim, [0 0], 'color', 'k', 'linewidth', 2)  % Axa Ox
line([0 0], ylim, 'color', 'k', 'linewidth', 2) %axa Oy 
xlabel('x')
ylabel('y')
str = sprintf('Grafic g restrictionat la [%f, %f]', a, b);
title(str)
legend('patrat', 'y = g(x)', 'bisectoare y=x', 'y = dg(x)', 'segment de dreapta')

% caut alta solutie 
a = 0.8;
b = 1.27;

figure;
plot([a,b,b,a,a],[a,a,b,b,a],'xg');
hold on;
x = linspace(a,b,100);
plot(x,g(x),'-r');
plot(x,x,'-y');
syms arg;
dg = matlabFunction(diff(g(arg)));
plot(x,dg(x), '-b');
hold on;
plot([a b], [-1 -1], '-k');
plot([a b], [1 1], '-k');
str = sprintf('Grafic g restrictionat la [%f, %f]', a, b);
title(str)
rect = [0.4, 0.4, .25, .25];
h = legend('patrat', 'y = g(x)', 'bisectoare y=x', 'y = dg(x)', 'segment de dreapta');
set(h, 'Position', rect)
%observam ca gra?cul functiei g restrictionata la intervalul [a,b] nu
%depaseste cadrul patratului 

%e)
xsol_aprox = pctFix(g,1,1e-5);
fprintf('Punctul fix aproximativ al functiei g: %f \n', xsol_aprox);

%f)
f = @(x) x.^4 + 2*x.^2 - x -3;
figure;
x = linspace(a,b,100);
plot(x,f(x),'-b');
hold on;
plot(xsol_aprox, f(xsol_aprox), 'og', 'MarkerSize', 8);
title('Grafic f si solutie aproximativa');
legend('y = f(x)', 'solutie aproximativa');
%%

%%
%Exercitiul 4 - primul exemplu (functia g1)
f = @(x) x.^4 + 2*x.^2 -x -3;
g1 = @(x) ((x + 3) ./(x.^2 +2)).^(1/2);

%c)
a = -3;
b = 3;
figure
plot([a,b,b,a,a],[a,a,b,b,a],'xg');
hold on;
x = linspace(a,b,100);
plot(x,g1(x),'-r');
plot (x,x,'-k');
%se observa ca graficul functiei g1 ramane in interiorul patratului
title('Graficul functiei g1')
legend('y = g1(x)', 'colt de patrat')

%d)
figure
syms arg;
dg1 = matlabFunction(diff(g1(arg)));
plot(x, dg1(x), '-b');
hold on;
plot([a b], [-1 -1], '-r', 'Linewidth', 2);
plot([a b], [1 1], '-r', 'Linewidth', 2);

str = sprintf('Grafic g1 restrictionat la [%f, %f]', a, b);
title(str)
legend('y = dg1(x)', 'segment de dreapta')
% observam ca sunt indeplinite conditiile din enunt => 
% => nu mai trebuie sa alegem alte valori pt a si b

%e
xsol_aprox_4a = pctFix(g1,1,1e-5);
fprintf('Punctul fix aproximativ al functiei g1: %f \n', xsol_aprox_4a);

%f
figure;
x = linspace(a,b,100);
plot(x, f(x),'-b');
hold on;
plot(xsol_aprox_4a, f(xsol_aprox_4a), 'og', 'MarkerSize', 8);
title('Grafic f si solutie aproximativa');
legend('y = f(x)', 'solutie aproximativa');
%%

%%
%Exercitiul 4 - al doilea exemplu(functia g2)

f = @(x) x.^4 + 2*x.^2 -x -3;
g2 = @(x) ((x + 3 - x.^4)/2).^(1/2);

%b)
%din conditiile de existenta pt functia g2 => p(x) = x + 3 - x^4 >=0 
%reprezint grafic functia p si aleg o aproximare cat mai buna a
%intervalului [a,b] cerut, a.i. p(x)>=0, pt orice x din [a,b]
m = -5;  n = 5;
x = linspace(m,n);
p = @(x)(-x.^4+x+3);
plot(x, p(x), '-r');
title('Graficul functiei p(x) = -x^4+x+3');
%[a,b] = [-1.16404, 1.45263] domeniu de def pt functia g2

%c)
a = -1.16404;
b = 1.45263;
figure
plot([a,b,b,a,a],[a,a,b,b,a],'xg');
hold on;
x = linspace(a,b,100);
plot(x,g2(x),'-r');
title('Graficul functiei g2')
rect = [0.4, 0.4, .25, .25];
h = legend('colt de patrat', 'y = g2(x)');
set(h, 'Position', rect)
%observam ca gra?cul functiei g restrictionata la intervalul [a,b] nu
%depaseste cadrul patratului 

%d)
figure
syms arg;
dg2 = matlabFunction(diff(g2(arg)));
plot(x,dg2(x), '-b');
hold on;
plot([a b], [-1 -1], '-k');
plot([a b], [1 1], '-k');
legend('y = dg2(x)', 'segment de dreapta');
%se observa ca nu sunt indeplinite conditiile
%nu se poate alege alt interval pt care conditiile sa fie indeplinite 

% exemplu de interval pt care nu se respecta conditiile, g2 nu apartine 
% patratului creat de a si b
a = -0.75;
b = 1;
figure;
plot([a,b,b,a,a],[a,a,b,b,a],'xg');
hold on;
x = linspace(a,b,100);
plot(x, g2(x), '-r');
plot (x, x, '-k');
syms arg;
dg2 = matlabFunction(diff(g2(arg)));
plot(x, dg2(x), '-b');
hold on;
plot([a b], [-1 -1], '-k');
plot([a b], [1 1], '-k');

str = sprintf('Grafic g2 restrictionat la [%f, %f]', a, b);
title(str)
rect = [0.5, 0.2, .1, .1];
h = legend('patrat', 'y = g2(x)', 'bisectoare y=x', 'y = dg2(x)', 'segment de dreapta');
set(h, 'Position', rect)

%alt exemplu de interval a b pt care nu se respecta conditiile
a = -1;
b = 0;
figure;
plot([a,b,b,a,a],[a,a,b,b,a],'xg');
hold on;
x = linspace(a,b,100);
plot(x,g2(x),'-r');
plot (x,x,'-k');
syms arg;
dg2 = matlabFunction(diff(g2(arg)));
plot(x,dg2(x), '-b');
hold on;
plot([a b], [-1 -1], '-k');
plot([a b], [1 1], '-k');
str = sprintf('Grafic g2 restrictionat la [%f, %f]', a, b);
title(str)
rect = [0.5, 0.2, .1, .1];
h = legend('patrat', 'y = g2(x)', 'bisectoare y=x', 'y = dg2(x)', 'segment de dreapta');
set(h, 'Position', rect) 

%%

%%
%Exercitiul 6
f1 = @(x1,x2) x1.^2 - 10.*x1 + x2.^2 + 8;
f2 = @(x1,x2) x1.*x2.^2 - 10.*x2 + 8; 
G1 = @(x1,x2) (x1.^2 + x2.^2 + 8) / 10;
G2 = @(x1,x2) (x1.*x2.^2 +x1 + 8) / 10;
%G = @(x1,x2) [g1(x1,x2) g2(x1,x2)];

%c)
G =@(x) [(x(1)^2 + x(2)^2 + 8)/10; (x(1)*x(2)^2 + x(1) + 8)/10];
x0 = [0;0];
eps = 10^(-5);
[xaprox] = MetPunctFix(G, x0, eps);
fprintf('Solutia aproximativa, cf metodei pct fix: (%f, %f) \n', xaprox(1), xaprox(2));

%d)
figure;
syms x1 x2; 
F1 = @(x1,x2) x1.^2 - 10*x1 + x2.^2 + 8;
F2 = @(x1,x2) x1*x2.^2 + x1 - 10*x2 + 8;

ezplot(F1, [0 3 0 3]);
hold on
ezplot(F2, [0 3 0 3]);

%e
plot(xaprox(1), 'o', 'markerFaceColor' , 'r');

%%


%functie ce returneaza solutia aproximativa conform metodei de punct fix
%argumente: 
%g - functie vectoriala definita pe o multime convexa, cu proprietatea ca
%    orice valoare a sa ramane in domeniul sau de definitie si g admite un
%    unic punct fix;
%x0 - valoare initiala de la care se porneste construirea sirului 
%eps - valoare folosita in criteriul de oprire, conform enuntului metodei
%pctFix construieste sirul x(k) = g(x(k-1)) ce converge la unicul punct fix 
%al functiei g

function [x_sol] = pctFix(g,x0,eps)
    x1 = g(x0);
    while abs(x1 - x0) >= eps
        x0 = x1;
        x1 = g(x0);
    end
    x_sol = x1;
end

% Generalizarea functiei pctFix de mai sus pentru o functie definita pe 
% R^n, unde n>=2;
% Argumentele functiei sunt de acelasi tip ca la pctFix;
% A fost deja verificata teorema III.2 din curs, a.i. functia G admite un
% unic punct fix in domeniul sau de definitie si construim sirul convergent
% la acesta;
function [xaprox] = MetPunctFix(G, x0, eps)
    x(:,1) = x0;
    cond = 1;
    k = 1;
    while cond
        k = k+1;
        x(:,k) = G(x(:,k-1));
        if norm(x(:,k) - x(:,k-1),inf) < eps
            cond = 0;
        end
    end
    
    xaprox = x(:,k); 
    %returneaza ultima valoare din sir, cea mai apropiata de unicul punct
    %fix cautat
end