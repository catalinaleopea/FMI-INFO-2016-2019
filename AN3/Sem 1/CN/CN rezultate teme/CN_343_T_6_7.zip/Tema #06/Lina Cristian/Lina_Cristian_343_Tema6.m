% Lina Cristian 343 - Tema 6
% 1. 10
% 2. 10
% 3. 10
% 4. 10
% 5. s-a scos
% 6. 7/10 (a, b?)
% Total: 47/50 i.e. ~9.5/10


%% Exercitiul 3 c)

g = @(x) (3 + x -2*x.^2).^(1/4);
a = -1; b = 3/2;
X = linspace(a,b,50);
plot(X,g(X),'--b');
hold on;
plot([a,b,b,a,a],[a,a,b,b,a],'r*');
hold off;
legend('g(x)','patrat')

%% d)

g = @(x) (3 + x -2*x.^2).^(1/4);
a = -1; b = 3/2;
X = linspace(a,b,50);
syms x;
dg = matlabFunction(diff(g(x)));
plot(X, dg(X), '--g*'); 
hold on;
plot([a b],[-1 -1], '-r');
plot([a b],[1 1],'-r');
hold off;
legend('dg(x)','dreapta')


%% e)

g = @(x) (3 + x -2*x.^2).^(1/4);
epsilon = 10^(-5);
[xaprox] = pFix(g,epsilon);
disp(xaprox);

%% f)

f = @(x) x.^4 + 2*x.^2 - x - 3;
X = linspace(a,b,50);
plot(X,f(X),'-b');
hold on;
plot(xaprox, f(xaprox),'*r');
hold off;
legend('f(x)', 'xaprox');

%% Exercitiul 4 a) -> 3 c)

g = @(x) ((x + 3)./(x.^2 + 2)).^(1/2);
a = -3; b = 3;
X = linspace(a,b,50);
plot(X,g(X),'--b');
hold on;
plot([a,b,b,a,a],[a,a,b,b,a],'r*');
hold off;
legend('g(x)','patrat')

%% Exercitiul 4 a) -> 3 d)

g = @(x) ((x + 3)./(x.^2 + 2)).^(1/2);
a = -3; b = 3;
X = linspace(a,b,50);
syms x;
dg = matlabFunction(diff(g(x)));
plot(X, dg(X), '--g*'); 
hold on;
plot([a b],[-1 -1], '-r');
plot([a b],[1 1],'-r');
hold off;
legend('dg(x)','dreapta')


%% Exercitiul 4 a) -> 3 e)

g = @(x) ((x + 3)./(x.^2 + 2)).^(1/2);
epsilon = 10^(-5);
[xaprox] = pFix(g,epsilon);
disp(xaprox);

%% Exercitiul 4 a) -> 3 f)

f = @(x) x.^4 + 2*x.^2 - x - 3;
X = linspace(a,b,50);
plot(X,f(X),'-b');
hold on;
plot(xaprox, f(xaprox),'*r');
hold off;
legend('f(x)', 'xaprox');

%% Exercitiul 4 b) -> 3 c)

g = @(x) ((x + 3 - x.^4)/2).^(1/2);
a = -1.1; b = 1.4;
X = linspace(a,b,50);
plot(X,g(X),'--b');
hold on;
plot([a,b,b,a,a],[a,a,b,b,a],'r*');
hold off;
legend('g(x)','patrat')

f = @(x) x.^4 + 2*x.^2 -x -3;


%% Exercitiul 4 b) -> 3 d)

g = @(x) ((x + 3 - x.^4)/2).^(1/2);
a = -1.1; b = 1.4;
X = linspace(a,b,50);
syms x;
dg = matlabFunction(diff(g(x)));
plot(X, dg(X), '--g*'); 
hold on;
plot([a b],[-1 -1], '-r');
plot([a b],[1 1],'-r');
hold off;
legend('dg(x)','dreapta')


%% Exercitiul 4 b) -> 3 e)

g = @(x) ((x + 3 - x.^4)/2).^(1/2);
epsilon = 10^(-5);
% [xaprox] = pFix(g,epsilon); ruleaza la infinit
disp(xaprox);

%% Exercitiul 4 b) -> 3 f)

% depinde de punctul anterior


%% Exercitiul 6 c)

g = @(x) [(x(1)^2 + x(2)^2 + 8)/10; (x(1)*x(2)^2 + x(1) + 8)/10];
epsilon = 10^(-5);
[xaprox] = metPctFix(g,epsilon);
disp(xaprox);

%% d) + e)

syms x1; syms x2; 
F1 = @(x1,x2) x1.^2 - 10.*x1 + x2.^2 + 8;
F2 = @(x1,x2) x1.*x2.^2 - 10.*x2 + 8; 

% Am luat de la colegi partea asta, nu am stiut sa afisez in R^2 graficul
ezplot(F1, [0 3 0 3]);
hold on
ezplot(F2, [0 3 0 3]);
plot(xaprox(1), '*r');

%% Functii

function [xk] = metPctFix(g,epsilon)
    x0 = [0;0]; ok = 1;
    while(ok == 1)
        xk = g(x0);
        if(norm(xk - x0,Inf) < epsilon)
            ok = 0;
        end
        x0 = xk;
    end
end

function [xk] = pFix(g,epsilon)
    x0 = 1; xk = g(x0);
    while(abs(xk-x0) >= epsilon)
        x0 = xk;
        xk = g(x0);
    end
end