% Tema 4 - Caluian Iulian 343 - CN - 2018
% 1.
% 2. 
% 3. -> 8/10 (a) & b)?)
% 4. -> 8/10 (domeniile de definitie?)
% 5. s-a scos
% 6. -
% Total: 16/50 i.e. ~3.5/10
%%
%Exercitiul 3 c

a = -1;
b = 3/2;

fig=figure; 
hold on 
xt = @(t) ( (3 + t - 2*t^2) ^ (1/4));


fplot(xt)
xlim([(a-1) (b+1)])
ylim([(a-1) (b+1)])


line ([a,a] , [a,b]);
line ([a,b] , [a,a]);
line ([b,b] , [a,b]);
line ([a,b] , [b,b]);

%% 3 d
syms f(t)
f(t) =  ( (3 + t - 2*t^2) ^ (1/4));
df = diff(f,t)

fig=figure; 
hold on 
fplot(df);
xlim([(a-1) (b+1)])
ylim([(a-1) (b+1)])

line (xlim , [-1 -1]);
line (ylim , [1 , 1]);

%% 3 e

syms f(t)
f(t) =  ( (3 + t - 2*t^2) ^ (1/4));
a = 1.05;
x0 = double(f(a));
epsi = 10^-5;
while (1)
x1 = double(f(x0));
err = x0 - x1;
x0 = x1;
    if ( abs (err) <= epsi)
        break;
    end 
end
disp(x0);

fig=figure; 
hold on 
xt = @(t) ( t^4 + 2*t^2 - t -3);
fplot(xt);
plot(x0,0,'r*');


%% 4a

%Exercitiul 4a c

a = -3;
b = 3; % de fapt b ar fi oo 

fig=figure; 
hold on 
xt = @(t) ( (t + 3) / (t^2 + 2) ) ^ (1/2);
fplot(xt)


xlim([(a-1) (b+1)])
ylim([(a-1) (b+1)])


line ([a,a] , [a,b]);
line ([a,b] , [a,a]);
line ([b,b] , [a,b]);
line ([a,b] , [b,b]);

%% 4a d
a = -3;
b = 3;
syms f(t)
f(t) =  ( (t + 3) / (t^2 + 2) ) ^ (1/2);
df = diff(f,t);

fig=figure; 
hold on 
fplot(df);
xlim([(a-1) (b+1)])
ylim([(a-1) (b+1)])

line (xlim , [-1 -1]);
line (ylim , [1 , 1]);

%% 4a e

syms f(t)
f(t) =  ( (t + 3) / (t^2 + 2) ) ^ (1/2);
a = 0.8; 
b = 1.2;
x0 = double(f(a)) % 1.199 
xb = double(f(b)) % 1.10 
% functia descrescatoare pe [0.8 , 1.2] -> oricare ar fi x in interval ->
% f(x) apartine interval.
epsi = 10^-5;
while (1)
x1 = double(f(x0));
err = x0 - x1;
x0 = x1;
    if ( abs (err) <= epsi)
        break;
    end 
end
disp(x0);

fig=figure; 
hold on 
xt = @(t) ( t^4 + 2*t^2 - t -3);
fplot(xt);
plot(x0,0,'r*');

%% 4b

%Exercitiul 4b c

a = -1.16;
b = 1.45;

fig=figure; 
hold on 
xt = @(t) ( (t + 3 - t^4) / 2) ^ (1/2);
fplot(xt)


xlim([(a-1) (b+1)])
ylim([(a-1) (b+1)])


line ([a,a] , [a,b]);
line ([a,b] , [a,a]);
line ([b,b] , [a,b]);
line ([a,b] , [b,b]);

%% 4b d
a = -1.16;
b = 1.45;
syms f(t)
f(t) =  ( (t + 3 - t^4) / 2) ^ (1/2);
df = diff(f,t);

fig=figure; 
hold on 
fplot(df);
xlim([(a-1) (b+1)])
ylim([(a-1) (b+1)])

line (xlim , [-1 -1]);
line (ylim , [1 , 1]);

%% 4b e
%% Num merge 
% Intradevar 1.1241 este punct fix al lui g, dar nu se poate deduce prin
% metoda deoarece nu indeplineste conditiile.
% syms f(t)
% f(t) =  ( (t + 3 - t^4) / 2) ^ (1/2);
% a = 1.13;
% x0 = double(f(a));
% epsi = 10^-5;
% while (1)
% x1 = double(f(x0));
% err = x0 - x1;
% x0 = x1;
%     if ( abs (err) <= epsi)
%         break;
%     end 
% end
% disp(x0);
% 
% fig=figure; 
% hold on 
% xt = @(t) ( t^4 + 2*t^2 - t -3);
% fplot(xt);
% plot(x0,0,'r*');


