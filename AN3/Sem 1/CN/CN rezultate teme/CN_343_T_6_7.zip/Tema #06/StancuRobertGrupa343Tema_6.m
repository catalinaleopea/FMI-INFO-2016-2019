%%
%=============================== Ex 3 =====================================
close all

disp('Rezultatele exercitiului 3')

f = @(x) x.^4 + 2*x.^2 - x - 3;
g = @(x) (3 + x - 2 * x.^2) .^ (1/4);

a = -1;
b = 3/2;

points = linspace(a,b);

xSquare = [a a b b a];
ySquare = [a b b a a];

plot(xSquare,ySquare,'b');

hold on

plot(points,g(points),'g');

title('Graficul functiei g inconjurat de patratul (a,a),(a,b),(b,a),(b,b)')

ylabel(['G(x) = ' func2str(g)]);
xlabel('x');

xlim([-1.5, 2]);
ylim([-1.5, 2]);
legend( {'Patratul specific','Graficul functiei g'},'Location','North');
syms x

gder = eval(['@(x)' vectorize(char(diff(g(x))))]);

hold off

figure(2)

ylabel(['G(x) = ' func2str(gder)]);
xlabel('x');

plot(points,gder(points),'Color','k')

hold on

y1 = 1;
y2 = -1;

line([a b],[y1 y1],'Color','b')
line([a,b],[y2 y2],'Color',[0.7 0.3 0])

legend({'Derivata functiei g','Dreapta y = 1', 'Dreapta y = -1'},'Location','North');
title('Graficul functiei dg');

a1 = 1/4;
b1 = 1/3;

xales = linspace(a1,b1);
yales = g(xales);

existaA1 = find(yales < a1);
existaB1 = find(yales < b1);

if numel(existaA1) ~= 0 || numel(existaB1) ~= 0
    disp('Intervalul ales nu este bun');
end

x0 = a1;
x1 = g(x0);
epsilon = 10^(-5);

while abs(x1 - x0) >= epsilon
    x0 = x1;
    x1 = g(x0);
end

%disp
disp(['Solutia ecuatiei f(x) = 0 este: ', num2str(x1)])

figure(3)

plot(points,f(points),'Color',[0 0.8 0.4]);

hold on

plot(x1,f(x1),'xr');

line([a b],[0 0])
title('Reprezentarea solutiei aproximative pe graficul functiei f')

legend({'Graficul functiei f','Solutia aproximativa',...
    'Dreapta de ecuatie y = 0'},'Location','North')

%%

%=============================== Ex 4.a ===================================
close all
clc
clear all

disp('Rezultatele exercitiului 4, subpunctul a')

f = @(x) x.^4 + 2*x.^2 - x - 3;
g = @(x) ((x+3)./(x.^2 + 2)).^(1/2);

% g(x) >= 0 oricare x >= -3.
% Alegem b = 3

a = -3;
b = 3;

points = linspace(a,b);

xSquare = [a a b b a];
ySquare = [a b b a a];

plot(xSquare,ySquare,'b');

hold on
y = g(points);

plot(points,g(points),'g');

title('Graficul functiei g inconjurat de patratul (a,a),(a,b),(b,a),(b,b)')

ylabel(['G(x) = ' func2str(g)]);
xlabel('x');

xlim([-4, 4]);
ylim([-4, 4]);
legend( {'Patratul specific','Graficul functiei g'},'Location','North');
syms x

gder = eval(['@(x)' vectorize(char(diff(g(x))))]);

hold off

figure(2)

ylabel(['G(x) = ' func2str(gder)]);
xlabel('x');

plot(points,gder(points),'Color','k')

hold on

y1 = 1;
y2 = -1;

line([a b],[y1 y1],'Color','b')
line([a,b],[y2 y2],'Color',[0.7 0.3 0])

legend({'Derivata functiei g','Dreapta y = 1', 'Dreapta y = -1'},'Location','North');
title('Graficul functiei dg');

ylim([-2, 2]);

a1 = 0;
b1 = 1/4;

xales = linspace(a1,b1);
yales = g(xales);

existaA1 = find(yales < a1);
existaB1 = find(yales < b1);

if numel(existaA1) ~= 0 || numel(existaB1) ~= 0
    disp('Intervalul ales nu este bun');
end

x0 = a1;
x1 = g(x0);
epsilon = 10^(-5);

while abs(x1 - x0) >= epsilon
    x0 = x1;
    x1 = g(x0);
end

%disp
disp(['Solutia ecuatiei f(x) = 0 este: ', num2str(x1)])

figure(3)

plot(points,f(points),'Color',[0 0.8 0.4]);

hold on

plot(x1,f(x1),'xr');

line([a b],[0 0])
title('Reprezentarea solutiei aproximative pe graficul functiei f')

legend({'Graficul functiei f','Solutia aproximativa',...
    'Dreapta de ecuatie y = 0'},'Location','North')

%%

%=============================== Ex 4.b ===================================

disp('Rezultatele exercitiului 4, subpunctul b')

syms x

f = @(x) x.^4 + 2*x.^2 - x - 3;
g = @(x) ( (x + 3 - x.^4)/2).^(1/2);


% :) E bine ca ai avut curiozitatea macar! GG
% Folosind Wolfram Alpha
% g(x) > 0 pentru x apartine -1.16 1.45
% rotunjim pana la 1 si 1.5

% g(x) >= 0 oricare x >= -3.
% Alegem b = 3

a = -1;
b = 1.5;

points = linspace(a,b);

xSquare = [a a b b a];
ySquare = [a b b a a];

plot(xSquare,ySquare,'b');

hold on
y = g(points);

plot(points,g(points),'g');

title('Graficul functiei g inconjurat de patratul (a,a),(a,b),(b,a),(b,b)')

ylabel(['G(x) = ' func2str(g)]);
xlabel('x');

xlim([-1.5, 2]);
ylim([-1.5, 2]);
legend( {'Patratul specific','Graficul functiei g'},'Location','North');
syms x

gder = eval(['@(x)' vectorize(char(diff(g(x))))]);

hold off

figure(2)

ylabel(['G(x) = ' func2str(gder)]);
xlabel('x');

plot(points,gder(points),'Color','k')

hold on

y1 = 1;
y2 = -1;

line([a b],[y1 y1],'Color','b')
line([a,b],[y2 y2],'Color',[0.7 0.3 0])

legend({'Derivata functiei g','Dreapta y = 1', 'Dreapta y = -1'},'Location','North');
title('Graficul functiei dg');

%ylim([-5, 5]);


a1 = -0.5;
b1 = 0;

xales = linspace(a1,b1);
yales = g(xales);

existaA1 = find(yales < a1);
existaB1 = find(yales < b1);

if numel(existaA1) ~= 0 || numel(existaB1) ~= 0
    disp('Intervalul ales nu este bun');
end

x0 = a1;
x1 = g(x0);


% Sirul construit in baza functiei g nu converge, deoarece acesta
% alterneaza intre doua valori: 1.2611 si 0.93054(Adica, g(1.2611) = 
% 0.93054 si g(0.93054) = 1.2611

%{

epsilon = 10^(-5);

while abs(x1 - x0) >= epsilon
    x0 = x1;
    disp(['x0 = ',num2str(x0)]);
    
    x1 = g(x0);
    disp(['x1 = ',num2str(x1)]);
    
end


disp(['Solutia ecuatiei f(x) = 0 este: ', num2str(x1)])

figure(3)

plot(points,f(points),'Color',[0 0.8 0.4]);

hold on

plot(x1,f(x1),'xr');

line([a b],[0 0])
title('Reprezentarea solutiei aproximative pe graficul functiei f')

legend({'Graficul functiei f','Solutia aproximativa',...
    'Dreapta de ecuatie y = 0'},'Location','North')
%}

%%
% ============================== Exercitiul 6 =============================

g1 = @(x,y) (x.^2 + y.^2 + 8)/10;
g2 = @(x,y) (x.*(y.^2)+x+8)/10;

x0 = [0 0];
x1 = [g1(x0(1),x0(2)) g2(x0(1),x0(2))];

epsilon = 10^(-5);

while norm( abs(x1 - x0),inf) >= epsilon
   x0 = x1;
   x1 = [g1(x0(1),x0(2)) g2(x0(1),x0(2))];
end

disp(['Punctul fix pe intervalul [0 1.5] este: ','(',...
                    num2str(x1(1)),',',num2str(x1(2)),')']);

syms x y;

F1 = x^2 - 10*x + y^2 + 8;
F2 = x*(y^2) + x - 10 * y + 8;

fimplicit(F1)
hold on
fimplicit(F2)
xlim([-5 1.5])
ylim([-5 1.5])

title('Curbele F1 si F2 si punctul fix')
plot(x1,[g1(x1(1),x1(2)),g2(x1(1),x1(2))],'xr')

% Explicatie:
% Conform punctului b) metoda punctului fix converge pe intervalul [0,1.5]
% Curbele F1 si F2 au, insa, doua puncte de intersectie,unul nefiind in
% intervalul [0,1.5]. Asadar, figura a fost restrictionata la intervalul 
% -5 1.5, pentru a se putea vedea intersectia celor doua curbe si punctul
% fix. 

legend({'Curba F1','Curba F2','Punctul fix'},'Location',...
       'SouthEast');
