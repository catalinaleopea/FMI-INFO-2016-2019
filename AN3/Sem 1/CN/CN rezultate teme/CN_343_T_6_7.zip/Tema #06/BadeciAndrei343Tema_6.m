%% Exercitiul 3
f = @(x) x.^4 + 2*x.^2 - x - 3;
g = @(x) (3 + x - 2*x.^2) .^ (1 / 4);

close all

% c
a = -1;
b = 3/2;
x = linspace(a, b);
y = g(x);

figure(1);
plot(x, y);
title("g(x) = (3 + x - 2 * x)^(1/4)");
xlim([-1.5 2]);
ylim([-1.5 2]);
line([a a b b a], [a b b a a]);

% d
syms x;
dg = matlabFunction(diff(g(x)));
x = linspace(a, b);
y = dg(x);

figure(2);
plot(x, y);
title("g'(x)");
xlim([-0.5, 1.2]);
ylim([-0.5, 2]);
line([-5, 5], [1, 1]);
line([-5, 5], [-1, -1]);

% f
x = linspace(a, b);
y = f(x);

figure(3);
plot(x, y);
title("f(x) = x^4 + 2x^2 - x - 3");
xL = xlim;
yL = ylim;
line([0 0], yL);  %axa X
line(xL, [0 0]);  %axa Y
