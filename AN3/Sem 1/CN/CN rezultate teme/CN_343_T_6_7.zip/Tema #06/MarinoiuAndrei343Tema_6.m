% Exercitiul 3,sub c)
% 1,2, 4, 6 -> 0
% 5. s-a scos
% 3. 5/10
% Total: 5/50 i.e. 1/10

syms x; % Definim x simbolic pentru derivata
g = @(x) (3+x-2*x.^2).^(1/4); % Declarare functie

% Initializam capetele intervalului
A = -1;
B = 3/2;

X = linspace(A,B,100); % Atribuim valori lui x
Y = g(X); % Valorile lui g(x) adaugate intr-un vector

figure(1); % Construim figura 1
plot(X,Y,'--b*'); % Se adauga graficul functiei g

% Setam limitele pentru axa x si y
xlim([-1.5 2]);
ylim([-1.5 2]);

% Construim patratul conform coordonatelor (a, a),(a, b),(b, a),(b, b)
line([-1, -1, 3/2, 3/2, -1],[-1, 3/2, 3/2, -1, -1]);

hold off;

%% Exercitiul 3,sub d)

% Calculam derivata functiei g si o salvam in Z
dg = matlabFunction(diff(g(x),x));
Z = dg(X);

figure(2); % Construim figura 2
plot(X,Z,'--r'); % Se adauga graficul functiei g derivat

% Trasam 2 linii conform coordonatelor specificate
line([-5,5],[1,1]);
hold on;

line([-5,5],[-1,-1]);
hold on;

% Setam limitele pentru axa x si y
xlim([-1.5 2]);
ylim([-1.5 2]);

hold off;