% Ex 6?
% Tema6
% Ex 3
    %c
      syms x;
    % folosim o functie handle pentru a reprezenta functia din cerinta
    g = @(x) (3 + x -2*x.^2).^(1/4); 
    a = -1; b = 3/2; % setam capetele intervalului [a,b]
    X = linspace(a,b,100); % distribuim intervalul
    figure(1) % initiem prima figura
    plot(X,g(X),'--b'); % creem graficul lui g
    hold on; % pastram graficul in figura
    plot([a,b,b,a,a],[a,a,b,b,a],'r*'); % creem patratul
    
    xlim([-1.5 2]); % intervalul pe x
    ylim([-1.5 2]); % intervalul pe y

    line([a, a, b, b, a],[a, b, b, a, a]); % trasam marginile
    % pastram in legenda reprezentarile
    legend('g(x)','puncte patrat','margini')
    hold off; % nu pastram graficul
    
    %d
    dg = matlabFunction(diff(g(x),x)); % pastram derivata lui g
    figure(2); % initiem a doua figura
    line([-5,5],[1,1]); % trasam liniile (superioara)
    hold on;
    line([-5,5],[-1,-1]); % trasam liniile (inferioara)

    xlim([-1.5 2]); % setam limitele pe x
    ylim([-1.5 2]); % setam limitele pe y

    Z = dg(X); % pastram in Z valoarea lui g' pe distributia din X
    plot(X,Z,'--r'); % afisam graficul pe punctele din X
    legend('linie super','linie infer','g`(x)')
    hold off; % pastram graficul in figura

% Ex 4
    % a
    % 3c
    % folosim o functie handle pentru a reprezenta functia din cerinta
    g1 = @(x) ((3 + x)/(x.^2 + 2)).^(1/2); 
    a1 = -3; b1 = 5; % setam capetele intervalului [a,b]
    X1 = linspace(a1,b1,100); % distribuim intervalul
    Y = zeros(1,length(X1)); % prealocam Y
    % evaluarea lui g1 pare sa dea probleme asa ca vom face manual 
    % evaluarea pe X1
    for i = 1:length(X1)
        Y(i) = g1(X1(i));
    end
    figure(3) % initiem prima figura
    plot(X1,Y,'--b'); % creem graficul lui g
    hold on; % pastram graficul in figura
    plot([a1,b1,b1,a1,a1],[a1,a1,b1,b1,a1],'r*'); % creem patratul
    
    xlim([-3.5 6]); % intervalul pe x
    ylim([-3.5 6]); % intervalul pe y
    
    line([a1, a1, b1, b1, a1],[a1, b1, b1, a1, a1]); % trasam marginile
    % pastram in legenda reprezentarile
    legend('g1(x)','puncte patrat','margini')
    hold off; % nu pastram graficul
    
    %3d
    dg = matlabFunction(diff(g1(x),x)); % pastram derivata lui g
    figure(4); % initiem a doua figura
    line([-5,5],[1,1]); % trasam liniile (superioara)
    hold on; % pastram linia in grafic
    line([-5,5],[-1,-1]); % trasam liniile (inferioara)

    xlim([-3.5 5]); % setam limitele pe x
    ylim([-1.5 2]); % setam limitele pe y

    Z = dg(X1); % pastram in Z valoarea lui g' pe distributia din X
    plot(X1,Z,'--r'); % afisam graficul pe punctele din X
    legend('linie super','linie infer','g`(x)')
    hold off; % pastram graficul in figura
    % b
    f = @(x) x.^4+2*x.^2-x-3;
    %3c
    % folosim o functie handle pentru a reprezenta functia din cerinta
    g2 = @(x) ((x+3-x.^4)/2).^(1/2); 
    a2 = -1; b2 = 1; % setam capetele intervalului [a,b]
    X2 = linspace(a2,b2,100); % distribuim intervalul
    figure(5) % initiem prima figura
    plot(X2,g2(X2),'--b'); % creem graficul lui g
    hold on; % pastram graficul in figura
    plot([a2,b2,b2,a2,a2],[a2,a2,b2,b2,a2],'r*'); % creem patratul
    
    xlim([-1.5 1.5]); % intervalul pe x
    ylim([-1.5 1.5]); % intervalul pe y

    line([a2, a2, b2, b2, a2],[a2, b2, b2, a2, a2]); % trasam marginile
    % pastram in legenda reprezentarile
    legend('g(x)','puncte patrat','margini')
    hold off; % nu pastram graficul
    
    %d
    dg = matlabFunction(diff(g2(x),x)); % pastram derivata lui g
    figure(6); % initiem a doua figura
    line([-5,5],[1,1]); % trasam liniile (superioara)
    hold on;
    line([-5,5],[-1,-1]); % trasam liniile (inferioara)

    xlim([-1.5 1.5]); % setam limitele pe x
    ylim([-1.5 1.5]); % setam limitele pe y

    Z = dg(X2); % pastram in Z valoarea lui g' pe distributia din X
    plot(X2,Z,'--r'); % afisam graficul pe punctele din X
    legend('linie super','linie infer','g`(x)')
    hold off; % pastram graficul in figura
    
    % vom testa daca sirul construit la b converge cu f
    
    R = f(X2);
    ok = 0;
    for i = 1:100
        if R(i) == 0
            ok = 1;
        end
    end
    if ok
        fprintf('Sirul converge cu f');
    else
        fprintf('Sirul nu converge cu f');
    end