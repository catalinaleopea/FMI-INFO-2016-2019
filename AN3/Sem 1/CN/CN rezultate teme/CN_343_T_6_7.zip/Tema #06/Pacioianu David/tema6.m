% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% 1. 10
% 2. 10
% 3. 10
% 4. ^* -> 10
% 5. s-a scos
% 6. 0/10
% Total: 40/50 i.e. 8/10 
% -------------------------------------------------------------------------
%% Ex3
% c)
f = @(x) (x.^4)+2.*(x.^2)-x-3;
g = @(x) (3+x-2.*x.^2).^(1/4);
dg = @(x) 1/4.*((3+x-2.*x.^2).^(1/4-1)).*(1-4.*x);

figure(1);
x = linspace(-1,3/2,100);
y = g(x);
plot(x,y,'--b');
hold on
xlim([-1.5 2]);
ylim([-1.5 2]);
line([-1, -1, 3/2, 3/2, -1],[-1, 3/2, 3/2, -1, -1]);
hold off;

% d)
figure(2);
line([-5,-5],[1,1]);
hold on
line([-5,-5],[-1,-1]);
hold on
xlim([-1.5 2]);
ylim([-1.5 2]);
z = dg(x);

plot(x,z,'--r');
hold on

%e
xPrev = 1;
xN = 0;
epsilon = 10^(-5);
shouldStop = false;
while shouldStop == false
    xN = g(xPrev);
    shouldStop = abs(xPrev - xN) < epsilon;
    xPrev = xN;
end
xN

%f
figure(3);
x = linspace(-1.5,1.5,100);
y = f(x);
plot(x,y,'--r');
hold on;
plot(xN,f(xN),'xb');

%% Ex4.a
% c)
f = @(x) (x.^4)+2.*(x.^2)-x-3;
g = @(x) ((x + 3)./(x.^2 + 2)).^(1/2);
dg = @(x)(-x.^2 - 6*x + 2)./(2.*g(x).*(x.^2+2).^2);

figure(1);
x = linspace(-6,0,100);
xlim([-4 0]);
ylim([0 1.5]);
y = g(x);
plot(x,y,'--b');

% d)
figure(2);
xlim([-5 0]);
ylim([-0.1 1]);
z = dg(x);

plot(x,z,'--r');
hold on

%e
xPrev = 1;
xN = 0;
epsilon = 10^(-5);
shouldStop = false;
while shouldStop == false
    xN = g(xPrev);
    shouldStop = abs(xPrev - xN) < epsilon;
    xPrev = xN;
end
xN

%f
figure(3);
x = linspace(-1.5,1.5,100);
y = f(x);
plot(x,y,'--r');
hold on;
plot(xN,f(xN),'xb');

%% Ex4.b
% c)
f = @(x) (x.^4)+2.*(x.^2)-x-3;
g = @(x) ((x + 3 - x.^2)./2).^(1/2);
dg = @(x)(1-2*x)./(2*sqrt(2).*g(x));

figure(1);
x = linspace(-6,0,100);
y = g(x);
plot(x,y,'--b');
hold on
xlim([-5 0]);
ylim([-1 1.5]);
hold off;

% d)
figure(2);
xlim([-5 0]);
ylim([0 5]);
z = dg(x);

plot(x,z,'--r');
hold on

%e
xPrev = 1;
xN = 0;
epsilon = 10^(-5);
shouldStop = false;
while shouldStop == false
    xN = g(xPrev);
    shouldStop = abs(xPrev - xN) < epsilon;
    xPrev = xN;
end
xN

%f
figure(3);
x = linspace(-1.5,1.5,100);
y = f(x);
plot(x,y,'--r');
hold on;
plot(xN,f(xN),'xb');