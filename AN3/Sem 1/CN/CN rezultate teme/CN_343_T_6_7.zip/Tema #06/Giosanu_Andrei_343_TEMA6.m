% Total: 4/10 -> Scrie codul cu sectiuni, asa cum v-am rugat. Totodata,
% pune si mesaje la consola. Este inteligibil ce ai facut aici, pentru ca
% sunt "fortat" sa rulez tot codul. 
%Giosanu Andrei
%Grupa 343

%%ex-3

%a)
%x pct fix pt. g, atunci f(x) = 0
%g(x) = x
%(3 + x -2x^2)^(1/4) = x ridicam la puterea a 4 a
%3 + x -2x^2 = x^4 => x^4 + 2x^2 - x - 3 = 0

%b)
%Domeniul de definitie pentru g
%3 + x - 2x^2 >= 0
%x1,2 = (-1 +/- sqrt(25))/(-4) => x1 = -1, x2 = 3/2

%c)
g = @(x)(3 + x - 2*x.^2).^(1/4);
a = -1;
b = 3/2;
figure
plot([a,b,b,a,a],[a,a,b,b,a],'-g');
hold on;
x=linspace(a,b,100);
plot(x,g(x),'-r');
plot(x,x,'-k');

%d)
figure
syms arg
dg = matlabFunction(diff(g(arg)));
plot(x,dg(x),'-b')
hold on;
plot ([a b], [-1 -1],'-k');
plot ([a b], [1 1],'-k');

%interval2
a=-0.75;
b=1.25;

figure
plot([a,b,b,a,a],[a,a,b,b,a],'-g');
hold on;
x=linspace(a,b,100);
plot(x,g(x),'-r');
plot(x,x,'-k');
%ex-3 d)
figure
syms arg
dg = matlabFunction(diff(g(arg)));
plot(x,dg(x),'-b')
hold on;
plot ([a b], [-1 -1],'-k');
plot ([a b], [1 1],'-k');

%interval3
a=0.8;
b=1.27;

figure
plot([a,b,b,a,a],[a,a,b,b,a],'-g');
hold on;
x=linspace(a,b,100);
plot(x,g(x),'-r');
plot(x,x,'-k');
%ex-3 d)
figure
syms arg
dg = matlabFunction(diff(g(arg)));
plot(x,dg(x),'-b')
hold on;
plot ([a b], [-1 -1],'-k');
plot ([a b], [1 1],'-k');

%e)
eps= 10^(-5);
x_sol=punctFix(g,1,eps);

%f)
f = @(x) x.^4 + 2*x.^2-x-3;
figure
x = linspace(a,b,100);
plot(x,f(x),'-b');
hold on;
plot(x_sol,f(x_sol),'og','MarkerSize',10)

%%ex-4

%A
%a)
%x pct fix pt. g, atunci f(x) = 0
%g1(x) = x
%[(x+3)/(x^2 + 2)]^(1/2) = x ridicam la puterea a 2 a
%(x+3)/(x^2 + 2) = x^2 => x^4 + 2x^2 - x - 3 = 0

%b)
%Domeniul de definitie pentru g1
%x+3 >= 0 => x>=-3 domeniul este [-3,inf)

%c)
g1 = @(x)((x + 3)./(x.^2 + 2)).^(1/2);
a = -2;
b = 2;
figure
plot([a,b,b,a,a],[a,a,b,b,a],'-g');
hold on;
x=linspace(a,b,100);
plot(x,g1(x),'-r');
plot(x,x,'-k');

%d)
syms arg
dg1 = matlabFunction(diff(g1(arg)));
plot(x,dg1(x),'-b')
hold on;
plot ([a b], [-1 -1],'-k');
plot ([a b], [1 1],'-k');

%interval1
a = -2;
b = -1;
figure
plot([a,b,b,a,a],[a,a,b,b,a],'-g');
hold on;
x=linspace(a,b,100);
plot(x,g1(x),'-r');
plot(x,x,'-k');
syms arg
dg1 = matlabFunction(diff(g1(arg)));
plot(x,dg1(x),'-b')
hold on;
plot ([a b], [-1 -1],'-k');
plot ([a b], [1 1],'-k');

%e)
x_sol1=punctFix(g1,-3,eps);

%f)
figure
x = linspace(a,b,100);
plot(x,f(x),'-b');
hold on;
plot(x_sol1,f(x_sol1),'og','MarkerSize',10);

%B
%a)
%x pct fix pt. g1, atunci f(x) = 0
%g1(x) = x
%((x + 3 - x^4)/2)^(1/2) = x ridicam la puterea a 2 a
%x + 3 - x^4= 2x^2 => x^4 + 2x^2 - x - 3 = 0

%b)
%Domeniul de definitie este [-1.16, 1.45]
g2=@(x)((x + 3 - x.^4)/2).^(1/2);
a=-1.16;
b=1.45;

%c)
figure
plot([a,b,b,a,a],[a,a,b,b,a],'-g');
hold on;
x=linspace(a,b,1000);
plot(x,g2(x),'-r');
plot(x,x,'-k');

%d)
syms arg
dg = matlabFunction(diff(g2(arg)));
plot(x,dg(x),'-b')
hold on;
plot ([a b], [-1 -1],'-k');
plot ([a b], [1 1],'-k');

% alt interval
a=-0.8;
b=1;

figure
hold on;
x=linspace(a,b,100);
plot(x,g2(x),'-r');

syms arg
dg = matlabFunction(diff(g2(arg)));
plot(x,dg(x),'-b')
hold on;
plot ([a b], [-1 -1],'-k');
plot ([a b], [1 1],'-k');

% alt exemplu
a=-0.8;
b=-0.85;

figure
hold on;
x=linspace(a,b,100);
plot(x,g1(x),'-r');

syms arg
dg = matlabFunction(diff(g1(arg)));
plot(x,dg(x),'-b')
hold on;
plot ([a b], [-1 -1],'-k');
plot ([a b], [1 1],'-k');

% e nu converge 

%ex-6
G1 = @(x1,x2) x1.^2 - 10.*x1 + x2.^2 + 8;
G2 = @(x1,x2) x1 .* x2.^2 + x1 - 10 .* x2 + 8;

%a)
%(x1, x2) pct fix, atunci 
%x1^2 + x2^2 + 8 = 10 * x1 => x1^2 + x2^2 + 8 - 10 * x1 = 0 si
%x1 * x2^2 + x1 + 8 = 10 * x2 => x1 * x2^2 +x1 + 8 - 10 * x2 = 0
% in continuare folosim sistemul
%x1^2 + x2^2 + 8 = 10 * x1 si x1 * x2^2 + x1 +8 = 10 * x2 deci
%G(x1, x2) = (10 * x1/10, 10 * x2/10) => (x1, x2) punct fix
%Astfel ca rezulta ceea ce trebuia demonstrat

%b)
%calculam derivatele partiale
%dG1/dx1 = x1/5 <= 0.3
%dG1/dx2 = x2/5 <= 0.3
%dG2/dx1 = x1*x2/5 <= 0.22
%dG2/dx2 = x1*x2/5 <= 0.22
%q = 0.3, aplicand teorema rezulta ca exista un singur punct fix pe D
 
%c)
g_nou = @(x) [(x(1) .^ 2 + x(2) .^2 +8)/10, (x(1) .^ x(2).^2 + 8)/10];
x_solc = punctFix(g_nou, [1; 1], 10^(-5));

%d)
figure
fimplicit(G1);
fimplicit(G2);
xlim([0, 1.5]);

function x_sol = punctFix(g, x0, eps)
x1 = g(x0);
while abs(x1-x0) >= eps
    x0 = x1;
    x1 = g(x0);
end
x_sol = x1;
end
