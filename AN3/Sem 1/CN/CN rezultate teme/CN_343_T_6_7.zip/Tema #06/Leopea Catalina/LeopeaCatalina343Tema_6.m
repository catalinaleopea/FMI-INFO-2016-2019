%Leopea Catalina, grupa 343, tema 6
% 1. 10
% 2. 10
% 3. 10
% 4. 8/10 (a) si b) de la fiecare?)
% 5. s-a scos
% 6. -
% Total: 38/50 i.e. 7.6/10

%% Ex. 3
f = @(x) x.^4 + 2*x.^2 - x - 3;
g = @(x) (3 + x - 2*x.^2) .^ (1 / 4);

%c)
a = -1;
b = 3/2;
figure(1);
x = linspace(a, b);
y = g(x);
plot(x, y);
title("g(x) = (3 + x - 2x^2)^(1/4)");
xlim([-1.5 2]);
ylim([-1.5 2]);
line([a a b b a], [a b b a a]);

%d)
syms x;
dg = matlabFunction(diff(g(x)));
figure(2);
x = linspace(a, b);
y = dg(x);
xlim([-0.5, 1.2]);
ylim([-0.5, 2]);
plot(x, y);
title("g'(x)");
line([-5, 5], [1, 1]);
line([-5, 5], [-1, -1]);

%e)
x0 = 1.2;
epsilon = 10^(-5);
x_sol = MetPunctFix(g, x0, epsilon);
disp("Solutia f(x) = 0 este ");
disp(x_sol);

%f)
x = linspace(a, b);
y = f(x);
figure(3);
plot(x, y);
hold on;
plot(x_sol, f(x_sol), 'o');
title("f(x) = x^4 + 2x^2 - x - 3");
xL = xlim;
yL = ylim;
line([0 0], yL);
line(xL, [0 0]);

%% Ex. 4 a) ->
g1 = @(x) ((x + 3) ./ (x.^2 + 2)) .^ (1/2);

%c)
a = -3;
b = 5;
figure(1);
x = linspace(a, b);
y = g1(x);
plot(x, y);
title("g1(x) = sqrt(((x+3) / (x^2 + 2)))");
line([a a b b a], [a b b a a]);

%d)
syms x;
dg1 = matlabFunction(diff(g1(x)));
figure(2);
x = linspace(a, b);
y = dg1(x);
plot(x, y);
title("g1'(x)");
line([-5, 5], [1, 1]);
line([-5, 5], [-1, -1]);

%e)
x0 = 1.2;
epsilon = 10^-5;
x_sol = MetPunctFix(g1, x0, epsilon);
disp("Solutia f(x) = 0 este ");
disp(x_sol);

%% b)
g2 = @(x) ((x + 3 - x.^4) ./ 2) .^ (1/2);

%c)
a = -1.16404;
b = 1.45263;
figure(1);
x = linspace(a, b);
y = g2(x);
plot(x, y);
title("g2(x) = sqrt(((x + 3 - x^4) / 2))");
line([a a b b a], [a b b a a]);

%d)
syms x;
dg2 = matlabFunction(diff(g2(x)));
figure(2);
x = linspace(a, b);
y = dg2(x);
plot(x, y);
title("g2'(x)");
line([-5, 5], [1, 1]);
line([-5, 5], [-1, -1]);

%e)
x0 = 1.2;
epsilon = 10^-5;
disp("g2 nu converge");

%% Functii
function [x1] = MetPunctFix(f, x0, epsilon)
    ok = 1;
    while ok ~= 0
        x1 = f(x0);
        if(abs(x1 - x0) < epsilon)
            ok = 0;
        end
        x0 = x1;
    end
end