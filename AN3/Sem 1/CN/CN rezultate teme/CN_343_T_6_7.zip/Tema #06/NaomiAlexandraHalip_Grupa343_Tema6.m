% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 6
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

%%
% Ex. 3 
% c)
f = @(x) x.^4+2*x.^2-x-3;
g = @(x) (3+x-2*x.^2).^(1/4);
a = -1; % capatul din stanga al intervalului
b = 3/2; % capatul din dreapta al intervalului
figure(1);
x = linspace(a,b,100); % discretizare interval 
y = g(x);
plot(x,y,'--r');
xlim([-1.5 2]);
ylim([-1.5 2]);
hold on
% reprezentare patrat
line([-1, -1, 3/2, 3/2, -1],[-1, 3/2, 3/2, -1, -1]);
legend('Graficul functiei g(x) = (3+x-2*x.^2).^(1/4)','Patratul de coordonate (a, a),(a, b),(b, a),(b, b)');
hold off
% Graficul functiei g ramane in interiorul patratului pentru orice x din
% [a,b]

% d)
syms x
figure(2);
dg = diff(g(x)); % derivata functiei g

h = fplot(dg,[a b]); % plotez graficul derivatei functiei g
xlim([-1.5 2]);
ylim([-1.5 2]);
h.Color = 'red';
h.LineStyle = '-.';
title('Graficul derivatei functiei g'); 
hold on
line([-1.5, 2],[1, 1]); % segment de dreapta situat pe dreapta y = 1
hold on
line([-1.5, 2],[-1, -1]); % segment de dreapta situat pe dreapta y = -1
hold on
% aleg intevalul [-0.5, 1] care este inclus in [a, b]
aa = -0.5;
bb = 1.2;
fplot(g,[aa bb],'g');
% Se observa ca graficul lui g nu apartine lui [aa, bb] pentru orice x
% apartinand lui [aa bb]
legend('Graficul derivatei functiei g(x) = (3+x-2*x.^2).^(1/4)','Segment situat pe dreapta y = 1','Segment situat pe dreapta y = -1','Graficul functiei g pe intervalul [-0.5, 1]');
hold off

% e)
epsilon = 10^(-5);
x0 = 1.2;
xap = MetPctFix(g,x0,epsilon); % solutia aproximativa a lui g conform
% metodei de punct fix

syms x
figure(3);
% graficul functiei f pe intervalul [a b]
fplot(f,[a b],'-r');
xlim([-1.5 2]);
ylim([-1.5 2]);
hold on
plot(xap,f(xap),'*m');
legend('Graficul functiei f(x) = x.^4+2*x.^2-x-3 pe intervalul [a b]','Solutia aproximativa');
%%

%%
% Ex. 4
% a) 
g1 = @(x) ((x+3)./(x.^2+2)).^(1/2);
a1 = -2;
b1 = 10;
figure(4); 
fplot(g1,[a1 b1],'--r');
xlim([-3 11]);
ylim([-3 11]);
hold on
line([-2, -2, 10, 10, -2],[-2, 10, 10, -2, -2]);
legend('Graficul functiei g1(x) = ((x+3)./(x.^2+2)).^(1/2)','Patratul de coordonate (a, a),(a, b),(b, a),(b, b)');

syms x
figure(5);
dg1 = diff(g1(x)); % derivata functiei g

h1 = fplot(dg1,[a1 b1]); % plotez graficul derivatei functiei g
xlim([-3 11]);
ylim([-3 11]);
h1.Color = 'red';
h1.LineStyle = '-.';
title('Graficul derivatei functiei g1'); 
hold on
line([-3, 11],[1, 1]); % segment de dreapta situat pe dreapta y = 1
hold on
line([-3, 11],[-1, -1]); % segment de dreapta situat pe dreapta y = -1
legend('Graficul derivatei functiei g1(x) = ((x+3)./(x.^2+2)).^(1/2)','Segment situat pe dreapta y = 1','Segment situat pe dreapta y = -1');

% Ex. 4
% b)
g2 = @(x) ((x+3-x.^4)./2).^(1/2);
a2 = -1.165;
b2 = 1.45;
figure(6); 
fplot(g2,[a2 b2],'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on
line([-1.165, -1.165, 1.45, 1.45, -1.165],[-1.165, 1.45, 1.45, -1.165, -1.165]);
legend('Graficul functiei g2(x) = ((x+3-x.^4)./2).^(1/2)','Patratul de coordonate (a, a),(a, b),(b, a),(b, b)');

syms x
figure(7);
dg2 = diff(g2(x)); % derivata functiei g

h2 = fplot(dg2,[a2 b2]); % plotez graficul derivatei functiei g
xlim([-2 2]);
ylim([-2 2]);
h2.Color = 'red';
h2.LineStyle = '-.';
title('Graficul derivatei functiei g2'); 
hold on
line([-2, 2],[1, 1]); % segment de dreapta situat pe dreapta y = 1
hold on
line([-2, 2],[-1, -1]); % segment de dreapta situat pe dreapta y = -1
legend('Graficul derivatei functiei g2(x) = ((x+3-x.^4)./2).^(1/2)','Segment situat pe dreapta y = 1','Segment situat pe dreapta y = -1');
%%

%%
% Ex. 6
% c) 
F1 = @(x1,x2) x1.^2-10*x1+x2.^2+8;
F2 = @(x1,x2) x1*x2.^2+x1-10*x2+8;
% F = @(x1,x2) [F1 F2]

aG = 0;
bG = 1.5;
% Din punctul a rezulta
G1 = @(x1,x2) (x1.^2+x2.^2+8)./10;
G2 = @(x1,x2) (x1*x2.^2+x1+8)./10;
% G = @(x1,x2) [G1 G2]
epsilon1 = 10^(-5);
% x0G = [1 1];
% xapG1 = MetPctFix(G1,x0G,epsilon1);
% xapG2 = MetPctFix(G2,x0G,epsilon1);

% d)
syms x1 x2
figure(8)
%F1 = @(x1,x2) x1.^2-10*x1+x2.^2+8;
hF1 = ezplot(F1,[0, 10, -6, 6]);
hF1.Color = 'blue';
hF1.LineStyle = '-';
grid on
% axis equal
hold on
%F2 = @(x1,x2) x1*x2.^2+x1-10*x2+8;
hF2 = ezplot(F2,[-15, 15, -15, 15]);
hF2.Color = 'magenta';
hF2.LineStyle = '-';
grid on
%axis equal
legend('Curba descrisa implicit de ecuatia F1(x1, x2) = 0','Curba descrisa implicit de ecuatia F2(x1, x2) = 0');
%%

%%
% Metoda punctului fix
% Implementata pentru Ex. 3 e)
function [xaprox] = MetPctFix(g,x0,epsilon)
    x1 = g(x0);
    while abs(x1-x0) > epsilon
        x0 = x1;
        x1 = g(x0);
    end
    xaprox = x1;
end
%%
