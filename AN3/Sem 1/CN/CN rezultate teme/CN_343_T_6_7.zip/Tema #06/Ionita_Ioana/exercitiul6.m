%Exercitiul 6
%Tema 6
%Autor: Ionita Ioana
%Grupa: 343
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%subpunctul c)
epsilon = 10^(-5);  %eroarea considerata
%Am vrut sa declar functia ca un sistem, am incercat initial sa iau cele 2 
%ecuatii ca doua functii separate si sa calculez x1 si x2 separat, dar nu
%am obtinut valorile aproximative ok...
G = @(x) [(x(1)^2 + x(2)^2 + 8)/10; (x(1)*x(2)^2 + x(1) + 8)/10];
x0 = [0; 0];
x(:, 1) = x0; %am initializat primul x1 si primul x2 (primele solutii ale 
%sistemului cu 0 si 0
cond = 1;
k = 1;
while cond
    k = k + 1;
    %x1 si x2 de la pasul k ii determin aplicand functiile G1 si G2 (cele 2
    %ecuatii ale sistemului G) asupra solutiilor determinate la pasul k-1
    x(:, k) = G(x(:, k-1)); 
    if norm(x(:, k) - x(:, k-1), inf) <epsilon  %calculez norma si o compar
        cond = 0;   %cu eroarea data pentru a sti daca am ajuns la solutiile 
                    %aproximative cautate
    end
end
xaprox = x(:, k);

%subpunctul d)
figure(1);
syms x1 x2;
F1 = @(x1, x2) (x1.^2 - 10*x1 + x2.^2 + 8);
F2 = @(x1, x2) (x1*x2.^2 + x1 - 10*x2 + 8);
%Am incercat si cu fplot, dar imi cerea sa am o variabila constanta, din
%cate am vazut. 
ezplot(F1, [0, 3, 0, 3]);
hold on;
ezplot(F2, [0, 3, 0, 3]);
%subpunctul e
plot(xaprox(1), 'o', 'MarkerFaceColor', 'r');
hold off;
