%Exercitiul 3
%Tema 6
%Autor: Ionita Ioana
%Grupa: 343
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%subpunctul c), rezolvat in clasa
syms x; %x trebuie declarat simbolic
g = @(x) (3+x-2*x.^2).^(1/4);   %declararea functiei

A = -1;     %capatul stang al intervalului
B = 3/2;    %capatul drept al intervalului
figure(1);
X = linspace(A, B, 100);
% X = -1 : 0.1 : 3/2 discretizeaza de la -1 la 3/2 cu pasul 0.1
Y = g(X);
plot(X, Y, '--b*');
hold on;
%pun graficul intr-un patrat
xlim([-1.5, 2]);
ylim([-1.5, 2]);
line([-1, -1, 3/2, 3/2, -1], [-1, 3/2, 3/2, -1, -1]);
legend('g(x)', 'patratul care incadreaza functia');
hold off;
%Intradevar, graficul functiei g ramane in interiorul patratului.

%subpunctul d), rezolvat in clasa
figure(2);
dg = matlabFunction(diff(g(x)));    %derivata functiei g
line([-5, 5], [1, 1]);  %segment pe linia y = 1            
hold on;
line([-5, 5], [-1, -1]);    %segment pe linia y = -1
xlim([-1.5, 2]);
ylim([-1.5, 2]);
line([-1, -1, 1, 1, -1], [-1, 1, 1, -1, -1]); 
Z = dg(X);
plot(X, Z, '--g');
%caut intervalul [Aprim, Bprim]
%plotez mai intai functia g in aceeasi figura
plot(X, Y, '--r');
%Se observa ca daca aleg intervalul 0.8 si 1.26, g(x) ramane in acest
%interval, oricare ar fi x din [0.8, 1.26]. De asemenea, functia g derivat
%este in intervalul (-1, 1)
legend('y = 1', 'y = -1', 'patrat', 'g derviat', 'g(x)');
hold off;

%subpunctul e)
x0(1) = 1.2;    %x0(1) = x0 ales
epsilon = 10^(-5); 
x0(2) = g(x0(1));
k = 2;
while abs(x0(k) - x0(k-1)) >= epsilon
    k = k + 1;
    x0(k) = g(x0(k-1));
end 
solutiaAproximativa = x0(k);
%g(solutiaAproximativa) = solutiaAproximativa

%subpunctul e) numarul 2
figure(3);
f = @(x)(x.^4 + 2*x.^2 - x - 3);
X1 = linspace(A, B, 100);
Y1 = f(X);
plot(X1, Y1, '--b');
hold on;
plot(solutiaAproximativa, f(solutiaAproximativa), 'ro', 'MarkerSize', 10, 'MarkerFaceColor','red');
legend('f(x)', 'solutia aproximativa');
hold off;




