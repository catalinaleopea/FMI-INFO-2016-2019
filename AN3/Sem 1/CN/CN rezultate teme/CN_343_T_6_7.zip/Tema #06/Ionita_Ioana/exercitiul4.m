%Exercitiul 4
%Tema 6
%Autor: Ionita Ioana
%Grupa: 343
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

syms x; 
g1 = @(x) ((x+3)./(x.^2+2)).^(1./2);
f = @(x)(x.^4 + 2*x.^2 - x - 3);

%subpunctul c) aplicat lui g1
A1 = -3;
B1 = 3;
figure(1);
X1 = linspace(A1, B1, 100);
Y1 = g1(X1);
plot(X1, Y1, '--r');
hold on;
%pun graficul intr-un patrat
xlim([-4, 4]);
ylim([-4, 4]);
line([-3, -3, 3, 3, -3], [-3, 3, 3, -3, -3]);
legend('g1(x)', 'patratul care incadreaza functia');
hold off;

%subpunctul d) aplicat lui g1
figure(2);
dg = matlabFunction(diff(g1(x)));    %derivata functiei g
line([-3, 3], [1, 1]);              
hold on;
line([-3, 3], [-1, -1]);
xlim([-4, 4]);
ylim([-4, 4]);
line([-3, -3, 3, 3, -3], [-3, 3, 3, -3, -3]);
Z1 = dg(X1);
plot(X1, Z1, '--g');
legend('g1 derivat', 'y = 1', 'y = -1', 'patratul in care incadrez derivata');
%intervalul [a', b'] poate fi considerat chiar intervalul [a, b]
%Z = dg(X1);
%plot(X1, Z, '--g');
hold off;

%subpunctul e) aplicat lui g1
epsilon = 10^(-5);
x0(1) = 1;
x0(2) = g1(x0(1));
k = 2;
while abs(x0(k) - x0(k-1)) >= epsilon
    k = k + 1;
    x0(k) = g1(x0(k-1));
end 
solAprox1 = x0(k);
%g1(solAprox1) = solAprox1

%subpunctul e) numarul 2, aplicat lui g1
figure(3);
Y = f(X1);
plot(X1, Y, '--b');
hold on;
plot(solAprox1, f(solAprox1), 'ro', 'MarkerSize', 10, 'MarkerFaceColor','red');
legend('f(x)', 'solutia aproximativa');
hold off;

%subpunctul b)
g2 = @(x) ((x + 3 - x.^4)./2).^(1./2);
%Conditia care imi da domeniul de definitie este ca -x^4+x+3 >=0
%De aceea caut radacinile reale ale ecuatiei -x^4+x+3 = 0
coefvct = [-1  0  0  1 3];               %vectorul coeficientilor
solutiile = roots(coefvct);              %solutiile ecuatiei
%Solutiile reale sunt -1.1640 si 1.4526, interval care reprezinta domeniul
%de definitie cautat.
A2 = -1.1640;
B2 = 1.4526;

%subpunctul c) aplicat lui g1
figure(4);
X2 = linspace(A2, B2, 100);
Y2 = g2(X2);
plot(X2, Y2, '--r');
hold on;
%pun graficul intr-un patrat
xlim([-3, 3]);
ylim([-3, 3]);
line([-2, -2, 2, 2, -2], [-2, 2, 2, -2, -2]);
legend('g2(x)', 'patratul care incadreaza g2');
hold off;

%subpunctul d) aplicat lui g2
figure(5);
dg2 = matlabFunction(diff(g2(x)));    %derivata functiei g2
line([-3, 3], [1, 1]);              
hold on;
line([-3, 3], [-1, -1]);
xlim([-4, 4]);
ylim([-4, 4]);
Z2 = dg2(X2);
plot(X2, Z2, '--g');
plot(X2, Y2, '--r');
plot(X2, X2, '-k');
legend('y = 1', 'y = -1', 'g2 derivat', 'g2(x)', 'segment din bisectoare');
hold off;

%subpunctul e) aplicat lui g2
epsilon = 10^(-5);
x0(1) = 1;
x0(2) = g2(x0(1));
k = 2;
while abs(x0(k) - x0(k-1)) >= epsilon
    k = k + 1;
    x0(k) = g1(x0(k-1));
end 
solAprox2 = x0(k);
%g2(solAprox2) = solAprox2

%subpunctul e) numarul 2, aplicat lui g2
figure(6);
Y2 = f(X2);
plot(X2, Y2, '--b');
hold on;
plot(solAprox2, f(solAprox2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor','red');
legend('f(x)', 'solutia aproximativa');
hold off;

%Se observa ca sirul construit in baza functiei g converge la solutia
%ecuatiei f(x) = 0, obtinand de fiecare data valoarea 1.1241, f(1.1241)=0.