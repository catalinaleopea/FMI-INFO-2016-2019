%Tema 6
%Autor: Ionita Ioana
%Grupa: 343
%% 
%Exercitiul 3
%subpunctul c), rezolvat in clasa
syms x; %x trebuie declarat simbolic
g = @(x) (3+x-2*x.^2).^(1/4);   %declararea functiei

A = -1;     %capatul stang al intervalului
B = 3/2;    %capatul drept al intervalului
figure(1);
X = linspace(A, B, 100);
% X = -1 : 0.1 : 3/2 discretizeaza de la -1 la 3/2 cu pasul 0.1
Y = g(X);
plot(X, Y, '--b*');
hold on;
%pun graficul intr-un patrat
xlim([-1.5, 2]);
ylim([-1.5, 2]);
line([-1, -1, 3/2, 3/2, -1], [-1, 3/2, 3/2, -1, -1]);
legend('g(x)', 'patratul care incadreaza functia');
hold off;
%Intradevar, graficul functiei g ramane in interiorul patratului.

%subpunctul d), rezolvat in clasa
figure(2);
dg = matlabFunction(diff(g(x)));    %derivata functiei g
line([-5, 5], [1, 1]);  %segment pe linia y = 1            
hold on;
line([-5, 5], [-1, -1]);    %segment pe linia y = -1
xlim([-1.5, 2]);
ylim([-1.5, 2]);
line([-1, -1, 1, 1, -1], [-1, 1, 1, -1, -1]); 
Z = dg(X);
plot(X, Z, '--g');
%caut intervalul [Aprim, Bprim]
%plotez mai intai functia g in aceeasi figura
plot(X, Y, '--r');
%Se observa ca daca aleg intervalul 0.8 si 1.26, g(x) ramane in acest
%interval, oricare ar fi x din [0.8, 1.26]. De asemenea, functia g derivat
%este in intervalul (-1, 1)
legend('y = 1', 'y = -1', 'patrat', 'g derviat', 'g(x)');
hold off;

%subpunctul e)
x0(1) = 1.2;    %x0(1) = x0 ales
epsilon = 10^(-5); 
x0(2) = g(x0(1));
k = 2;
while abs(x0(k) - x0(k-1)) >= epsilon
    k = k + 1;
    x0(k) = g(x0(k-1));
end 
solutiaAproximativa = x0(k);
%g(solutiaAproximativa) = solutiaAproximativa

%subpunctul e) numarul 2
figure(3);
f = @(x)(x.^4 + 2*x.^2 - x - 3);
X1 = linspace(A, B, 100);
Y1 = f(X);
plot(X1, Y1, '--b');
hold on;
plot(solutiaAproximativa, f(solutiaAproximativa), 'ro', 'MarkerSize', 10, 'MarkerFaceColor','red');
legend('f(x)', 'solutia aproximativa');
hold off;

%% 
%Exercitiul 4
syms x; 
g1 = @(x) ((x+3)./(x.^2+2)).^(1./2);
f = @(x)(x.^4 + 2*x.^2 - x - 3);

%subpunctul c) aplicat lui g1
A1 = -3;
B1 = 3;
figure(1);
X1 = linspace(A1, B1, 100);
Y1 = g1(X1);
plot(X1, Y1, '--r');
hold on;
%pun graficul intr-un patrat
xlim([-4, 4]);
ylim([-4, 4]);
line([-3, -3, 3, 3, -3], [-3, 3, 3, -3, -3]);
legend('g1(x)', 'patratul care incadreaza functia');
hold off;

%subpunctul d) aplicat lui g1
figure(2);
dg = matlabFunction(diff(g1(x)));    %derivata functiei g
line([-3, 3], [1, 1]);              
hold on;
line([-3, 3], [-1, -1]);
xlim([-4, 4]);
ylim([-4, 4]);
line([-3, -3, 3, 3, -3], [-3, 3, 3, -3, -3]);
Z1 = dg(X1);
plot(X1, Z1, '--g');
legend('g1 derivat', 'y = 1', 'y = -1', 'patratul in care incadrez derivata');
%intervalul [a', b'] poate fi considerat chiar intervalul [a, b]
%Z = dg(X1);
%plot(X1, Z, '--g');
hold off;

%subpunctul e) aplicat lui g1
epsilon = 10^(-5);
x0(1) = 1;
x0(2) = g1(x0(1));
k = 2;
while abs(x0(k) - x0(k-1)) >= epsilon
    k = k + 1;
    x0(k) = g1(x0(k-1));
end 
solAprox1 = x0(k);
%g1(solAprox1) = solAprox1

%subpunctul e) numarul 2, aplicat lui g1
figure(3);
Y = f(X1);
plot(X1, Y, '--b');
hold on;
plot(solAprox1, f(solAprox1), 'ro', 'MarkerSize', 10, 'MarkerFaceColor','red');
legend('f(x)', 'solutia aproximativa');
hold off;

%subpunctul b)
g2 = @(x) ((x + 3 - x.^4)./2).^(1./2);
%Conditia care imi da domeniul de definitie este ca -x^4+x+3 >=0
%De aceea caut radacinile reale ale ecuatiei -x^4+x+3 = 0
coefvct = [-1  0  0  1 3];               %vectorul coeficientilor
solutiile = roots(coefvct);              %solutiile ecuatiei
%Solutiile reale sunt -1.1640 si 1.4526, interval care reprezinta domeniul
%de definitie cautat.
A2 = -1.1640;
B2 = 1.4526;

%subpunctul c) aplicat lui g1
figure(4);
X2 = linspace(A2, B2, 100);
Y2 = g2(X2);
plot(X2, Y2, '--r');
hold on;
%pun graficul intr-un patrat
xlim([-3, 3]);
ylim([-3, 3]);
line([-2, -2, 2, 2, -2], [-2, 2, 2, -2, -2]);
legend('g2(x)', 'patratul care incadreaza g2');
hold off;

%subpunctul d) aplicat lui g2
figure(5);
dg2 = matlabFunction(diff(g2(x)));    %derivata functiei g2
line([-3, 3], [1, 1]);              
hold on;
line([-3, 3], [-1, -1]);
xlim([-4, 4]);
ylim([-4, 4]);
Z2 = dg2(X2);
plot(X2, Z2, '--g');
plot(X2, Y2, '--r');
plot(X2, X2, '-k');
legend('y = 1', 'y = -1', 'g2 derivat', 'g2(x)', 'segment din bisectoare');
hold off;

%subpunctul e) aplicat lui g2
epsilon = 10^(-5);
x0(1) = 1;
x0(2) = g2(x0(1));
k = 2;
while abs(x0(k) - x0(k-1)) >= epsilon
    k = k + 1;
    x0(k) = g1(x0(k-1));
end 
solAprox2 = x0(k);
%g2(solAprox2) = solAprox2

%subpunctul e) numarul 2, aplicat lui g2
figure(6);
Y2 = f(X2);
plot(X2, Y2, '--b');
hold on;
plot(solAprox2, f(solAprox2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor','red');
legend('f(x)', 'solutia aproximativa');
hold off;

%Se observa ca sirul construit in baza functiei g converge la solutia
%ecuatiei f(x) = 0, obtinand de fiecare data valoarea 1.1241, f(1.1241)=0.

%% 
%Exercitiul 6
%subpunctul c)
epsilon = 10^(-5);  %eroarea considerata
%Am vrut sa declar functia ca un sistem, am incercat initial sa iau cele 2 
%ecuatii ca doua functii separate si sa calculez x1 si x2 separat, dar nu
%am obtinut valorile aproximative ok...
G = @(x) [(x(1)^2 + x(2)^2 + 8)/10; (x(1)*x(2)^2 + x(1) + 8)/10];
x0 = [0; 0];
x(:, 1) = x0; %am initializat primul x1 si primul x2 (primele solutii ale 
%sistemului cu 0 si 0
cond = 1;
k = 1;
while cond
    k = k + 1;
    %x1 si x2 de la pasul k ii determin aplicand functiile G1 si G2 (cele 2
    %ecuatii ale sistemului G) asupra solutiilor determinate la pasul k-1
    x(:, k) = G(x(:, k-1)); 
    if norm(x(:, k) - x(:, k-1), inf) <epsilon  %calculez norma si o compar
        cond = 0;   %cu eroarea data pentru a sti daca am ajuns la solutiile 
                    %aproximative cautate
    end
end
xaprox = x(:, k);

%subpunctul d)
figure(1);
syms x1 x2;
F1 = @(x1, x2) (x1.^2 - 10*x1 + x2.^2 + 8);
F2 = @(x1, x2) (x1*x2.^2 + x1 - 10*x2 + 8);
%Am incercat si cu fplot, dar imi cerea sa am o variabila constanta, din
%cate am vazut. 
ezplot(F1, [0, 3, 0, 3]);
hold on;
ezplot(F2, [0, 3, 0, 3]);
%subpunctul e
plot(xaprox(1), 'o', 'MarkerFaceColor', 'r');
hold off;




