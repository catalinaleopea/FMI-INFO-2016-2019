%%
% Tema 7 CN
% Author: Robert Stancu

% OBSERVATIE: La exercitiul 4, am construit pentru fiecare metoda o
% sectiune separata, pentru a nu incurca graficele intre ele


%%
% =================================== EX 1 ================================
% ========================== CU JACOBIAN CALCULAT =========================

syms x y

f = x.^2 + y^2 - 4;
g = (x.^2)/8 - y;

fimplicit(f)
hold on
fimplicit(g)

F = [f g]';
J = matlabFunction(jacobian(F,[x,y]),'Vars',{[x y]});
F = matlabFunction(F,'Vars',{[x y]});

J([-2 -1])

epsilon = 10 ^ (-6);

[xaprox1,N1] = metodaNewton(F,J,[-2 -1]',epsilon);
[xaprox2,N2] = metodaNewton(F,J,[1 2]',epsilon);

scatter(xaprox1(1),xaprox1(2));
scatter(xaprox2(1),xaprox2(2));

legend({'Curba x^2+y^2-4 = 0','Curba (x^2)/8 -y = 0',...
    'xaprox1','xaprox2'});

ylim([-3,3])
xlim([-3,3])



%%
% =================================== EX 1 ================================
% ========================== CU JACOBIAN APROXIMAT ========================

syms x y

f = x.^2 + y^2 - 4;
g = (x.^2)/8 - y;

fimplicit(f)
hold on
fimplicit(g)

F = [f g]';
F = matlabFunction(F,'Vars',{[x y]});

epsilon = 10^(-6);
h = 10^(-6);

[xaprox1,N1] = metodaNewtonN(F,h,[-2 -1],epsilon);
[xaprox2,N2] = metodaNewtonN(F,h,[1 2],epsilon);

scatter(xaprox1(1),xaprox1(2));
scatter(xaprox2(1),xaprox2(2));

legend({'Curba x^2+y^2-4 = 0','Curba (x^2)/8 -y = 0',...
    'xaprox1','xaprox2'});

ylim([-3,3])
xlim([-3,3])


%%
% =============================== EX 2 ====================================
% ========================== CU JACOBIAN CALCULAT =========================
syms x y

f = x.^2 - 10*x + y.^2 + 8;
g = x*(y.^2) + x - 10 * y + 8;

fimplicit(f)
hold on
fimplicit(g)

F = [f g]';
J = matlabFunction(jacobian(F,[x,y]),'Vars',{[x y]});
F = matlabFunction(F,'Vars',{[x y]});

epsilon = 10 ^ (-6);

[xaprox1,N1] = metodaNewton(F,J,[1 1]',epsilon);
[xaprox2,N2] = metodaNewton(F,J,[2 3]',epsilon);

scatter(xaprox1(1),xaprox1(2));
scatter(xaprox2(1),xaprox2(2));

legend({'Curba x^2 - 10*x + y^2 + 8 = 0',...
        'Curba xy^2 + x - 10 * y + 8',...
        'xaprox1','xaprox2'});

ylim([0,5])
xlim([0,5])


%%
% =============================== EX 2 ====================================
% ========================== CU JACOBIAN APROXIMAT ========================

f = x.^2 - 10*x + y.^2 + 8;
g = x*(y.^2) + x - 10 * y + 8;

fimplicit(f)
hold on
fimplicit(g)

F = [f g]';
F = matlabFunction(F,'Vars',{[x y]});

epsilon = 10^(-6);

h = 10^(-6);

[xaprox1,N1] = metodaNewtonN(F,h,[1 1],epsilon);
[xaprox2,N2] = metodaNewtonN(F,h,[2 3],epsilon);

scatter(xaprox1(1),xaprox1(2));
scatter(xaprox2(1),xaprox2(2));

legend({'Curba x^2 - 10*x + y^2 + 8 = 0',...
        'Curba xy^2 + x - 10 * y + 8',...
        'xaprox1','xaprox2'});

ylim([0,5])
xlim([0,5])

%%
% ============================ Exercitiul 4 ===============================
% =========================== METODA DIRECTA ==============================

n = 3;
a = -pi/2;
b = pi/2;

f = @(x) sin(x);

X = linspace(a,b,n);
Y = f(X);

x = linspace(a,b);
y = metDirecta(X,Y,x);

hold on

plot(x,f(x),'Color',[0.8 0.4 0]);

plot(x,y,'Color',[0.4 0.8 0]);

plot(X,Y,'xk');

xlim([a b]);
ylim([f(a) f(b)]);

legend({'Graficul functiei f = sin(x)',strcat('Polinomul P de grad',...
        num2str(n-1)),...
        'Valorile functiei f in nodurile de interpolare'},...
        'Location','NorthWest');

hold off
figure

plot(x,abs(f(x)-y))
title('Eroarea E = |f(x) - Pn|');


%%
% ============================= EXERCITIUL 4 ==============================
% ============================ METODA LAGRANGE ============================

n = 3;
a = -pi/2;
b = pi/2;

f = @(x) sin(x);

X = linspace(a,b,n);
Y = f(X);

x = linspace(a,b);
y = metLagrange(X,Y,x);

hold on

plot(x,f(x),'Color',[0.8 0.4 0]);

plot(x,y,'Color',[0.4 0.8 0]);

plot(X,Y,'xk');

xlim([a b]);
ylim([f(a) f(b)]);

legend({'Graficul functiei f = sin(x)',strcat('Polinomul P de grad',...
        num2str(n-1)),...
        'Valorile functiei f in nodurile de interpolare'},...
        'Location','NorthWest');

hold off
figure

plot(x,abs(f(x)-y))
title('Eroarea E = |f(x) - Pn|');


%%

% ============================= EXERCITIUL 4 ==============================
% ============================= METODA NEWTON =============================

n = 3;
a = -pi/2;
b = pi/2;

f = @(x) sin(x);

X = linspace(a,b,n);
Y = f(X);

x = linspace(a,b);
y = metN(X,Y,x);

hold on

plot(x,f(x),'Color',[0.8 0.4 0]);

plot(x,y,'Color',[0.4 0.8 0]);

plot(X,Y,'xk');

xlim([a b]);
ylim([f(a) f(b)]);

legend({'Graficul functiei f = sin(x)',strcat('Polinomul P de grad',...
        num2str(n-1)),...
        'Valorile functiei f in nodurile de interpolare'},...
        'Location','NorthWest');

hold off
figure

plot(x,abs(f(x)-y))
title('Eroarea E = |f(x) - Pn|');


%%

function y = metDirecta(X,Y,x)

    n = length(X);
    M = zeros(n,n);
    
    M(:,1) = 1;
    
    for i = 2:n
        M(:,i) = (X.^(i-1))';
    end
    
    a = GaussPivTotala(M,Y');

    y = zeros(1,length(x));
    
    for i = 1:length(a)
        y = y + a(i) * (x.^(i - 1));
    end
    
end

function y = metLagrange(X,Y,x)

    n = length(X);
    L = zeros(n,length(x));

    for i = 1:n
        produs = ones(1,length(x));
        
        for j = 1:n
            if(j ~= i)
                produs = produs .* ( (x - X(j)) ./ (X(i) - X(j)) );
            end
        end
        
        L(i,:) = produs;
    end
    
    y = Y * L;
    
end



function y = metN(X,Y,x)
    
    n = length(X);
    M = zeros(n,n);
    
    M(:,1) = 1;
    
    for i = 2:n
        for j = 2:i
            vect = zeros(1,j-1) + X(i);
            M(i,j) = prod(vect - X(1:j-1));
        end
    end

    c = SubsAsc(M,Y');
    
    y = zeros(1,length(x)) + c(1);
    
    for i = 2:length(c)
        
        produs = ones(1,length(x));
        for j = 1:i-1
            produs = produs .* (x - X(j)); 
        end
        
        y = y + c(i) * produs;
    end
   
end

function [xaprox,N] = metodaNewtonN(F,h,x0,epsilon)

J = zeros(2,numel(x0));

for i = 1:2
    
    for j = 1:numel(x0)
        w = zeros(1,numel(x0));
        w(j) = h;
        
        val = (F(x0 + w) - F(x0)) / h;
        J(i,j) = val(i);
    end
end

xaprox = x0 + GaussPivTotala(J,-F(x0));

N = 1;


while true
    
    J = zeros(2,numel(xaprox));
    
    for i = 1:2
        
        for j = 1:numel(xaprox)
            w = zeros(1,numel(xaprox));
            w(j) = h;
            
            val = (F(xaprox + w) - F(xaprox)) / h;
            J(i,j) = val(i);
        end
    end
    
    
    zk = GaussPivTotala(J,-F(xaprox));
    xaprox = xaprox + zk;
    
    if norm(zk,inf) < epsilon
        break;
    end
    
    N = N + 1;
end

end


function [xaprox,N] = metodaNewton(F,J,x0,epsilon)

xaprox = x0 + J(x0')\(-F(x0'));
N = 1;

while true
    zk = GaussPivTotala(J(xaprox'),-F(xaprox'));
    xaprox = xaprox + zk';
    
    if norm(zk,inf) < epsilon
        break;
    end
    
    N = N + 1;
end

end


function x = GaussPivTotala(A,b)

faraSolutie = inf(1);

[n, ~] = size(A);

Ae = [A b];

index = 1:n;

for k = 1:n - 1
    
    [maximLinie,IndexLinie] = max(abs(Ae(k:n,k:n)));
    
    [~,coloanaMaxim] = max(maximLinie);
    linieMaxim = IndexLinie(coloanaMaxim);
    
    if maximLinie(coloanaMaxim) == 0
        fprintf('Sistem incompatibil / Sistem compatibil nedet\n');
        x = faraSolutie;
        return;
    end
    
    coloanaMaxim = coloanaMaxim + k - 1;
    linieMaxim = linieMaxim + k - 1;
    
    if linieMaxim ~= k
        Ae([k, linieMaxim],:) = Ae([linieMaxim, k],:);
    end
    
    if coloanaMaxim ~= k
        Ae(:,[k,coloanaMaxim]) = Ae(:,[coloanaMaxim,k]);
        temp = index(k);
        index(k) = index(coloanaMaxim);
        index(coloanaMaxim) = temp;
    end
    
    for l = k+1:n
        factor = Ae(l,k) / Ae(k,k);
        
        
        Ae(l,:) = Ae(l,:) - factor * Ae(k,:);
    end
    
end

if Ae(n,n) == 0
    fprintf('Sistem incompatibil sau sist comp nedet\n');
    x = faraSolutie;
    return;
end

x = SubsDesc(Ae(1:n,1:n),Ae(1:n,n+1));

x(index) = x;

end

function x = SubsAsc(A,b)

[n, ~] = size(A); % Dimensiunea matricei A

x(1) = (1/A(1,1)) * b(1); % Aflam elementul xn

k = 2;

% Iteratiile algorimtului

while k <= n  
   product = sum(A(k,1:k-1) .* x(1:k-1)); % Calculam suma din
                                          % produsul scalar 
                                                                             
   x(k) = (1/A(k,k)) * (b(k) - product); % Aflam x(k)
   k = k + 1;
end

end


function x = SubsDesc(A,b)

[n, ~] = size(A); % Dimensiunea matricei A

x(n) = (1/A(n,n)) * b(n); % Aflam elementul xn

k = n - 1;

% Iteratiile algorimtului

while k > 0
    
    product = sum(A(k,k+1:n) .* x(k+1:n)); % Calculam suma din
    % produsul scalar
    
    
    x(k) = (1/A(k,k)) * (b(k) - product); % Aflam x(k)
    k = k - 1;
end


end



