% Tema nu este pe formatul cerut & NU ruleaza. :(

%Pentru 1 si 2 :


%Problema 1
syms x y
F = [x^2+y^2-4;(x^2)/8-y];
J = jacobian(F, [x, y]);

range = [-3 3 -3 3];
plot(F(1));
hold on;
plot(F(2));
axis(range);

[xaprox,N] = Newton(F,J,[2 0.5],10^(-6))
plot(xaprox(1),xaprox(2),'r*');

[xaprox,N] = NewtonV2(F,[2 0.5],10^(-6))
plot(xaprox(1),xaprox(2),'bo');

%Problema 2
syms x y
F = [x^2-10*x+y^2+8;x*(y^2)+x-10*y+8];
J = jacobian(F, [x, y]);

range = [0 5 0 5];
plot(F(1));
hold on;
plot(F(2));
axis(range);

[xaprox,N] = Newton(F,J,[1.1 1.1],10^(-6))
plot(xaprox(1),xaprox(2),'r*');

[xaprox,N] = NewtonV2(F,[1.1 1.1],10^(-6))
plot(xaprox(1),xaprox(2),'bo');


%Problema 3
%{
x = [-pi/2,0,pi/2];
y = sin(x);
syms x1 x2 x3 xval

%Metoda directa
A = [1 x1 x1^2; 1 x2 x2^2; 1 x3 x3^2];
val = linsolve(subs(A,[x1 x2 x3],x),y.');
P2 = val(1)*1 + val(2)*xval + val(3)*(xval^2);
EroareDirecta = abs(subs(P2,[xval],pi/6) - sin(pi/6))

%Metoda Lagrange
L2 = [((xval-x(2))*(xval-x(3)))/((x(1)-x(2))*((x(1)-x(3)))),...
      ((xval-x(1))*(xval-x(3)))/((x(2)-x(1))*((x(2)-x(3)))),...
      ((xval-x(1))*(xval-x(2)))/((x(3)-x(1))*((x(3)-x(1))))];
P2 = L2 * y.';
EroareLagrange = abs(subs(P2,xval,pi/6) - sin(pi/6))

%Metoda Newton
C = ones(3,1);
C(1) = y(1);
C(2) = (y(2)-y(1))/(x(2)-x(1));
C(3) = (y(3)-y(1)-y(2)*(x(3)-x(1)))/((x(3)-x(2))*(x(3)-x(1)));
P2 = C(1)*1 + C(2)*xval + C(3)*(xval^2);
EroareNewton = abs(subs(P2,xval,pi/6) - sin(pi/6))
%}

%Problema 4
%a)
%{
function y = MetDirecta(X, Y, x)

N = size(X,2);

A = ones(N,N);
for i = 1:N
    for j = 2:N
        A(i,j) = X(i)^(j-1);
    end
end

val = linsolve(A,Y.');
y = val(1);
for i = 1:N-1
    y = y + val(i+1) * x.^(i);
end

%}
%{
function y = MetLagrange(X, Y, x)

N = size(X,2);

L = ones(size(x,2),N);
for i = 1:N
    for j = 1:N
        if(j~=i)
            L(:,i) = L(:,i) .* ((x-X(j))/(X(i)-X(j))).';
        end
    end
end

y = 0;
for i = 1:N
    y = y + L(:,i) * Y(i);
end
%}
%{
function y = MetN(X, Y, x)

N = size(X,2);

C = ones(1,N);

for i = 2:N
    C(i) = Y(i);
    
    for j = 1:i-1
        
        produs = 1;
        for k = 1:j-1
            produs = produs * (X(i)-X(k));
        end
        
        C(i) = C(i) - C(j) * produs;
    end
    for j = 1:i-1
        C(i) = C(i) / (X(i)-X(j));
    end
end

y = 0;
for i = 1:N
    
    produs = 1;
    for j = 1:i-1
        produs = produs .* (x-X(j));
    end
    
    y = y + C(i) * produs;
end
%}
%b)
n = 3;
a = -pi/2;
b = pi/2;
X = [a,0,b];
Y = sin(X);
discretizare = [a:(b-a)/100:b];
lagrange = MetLagrange(X, Y, discretizare);
plot(discretizare,lagrange, 'r');
hold on;
newton = MetN(X, Y, discretizare);
plot(discretizare,newton, 'b');
axis([a b -1 1]);
legend('MetLagrange','MetN')

%c)
f = sin(discretizare);
figure
plot(discretizare,abs(lagrange - f), 'r');
hold on;
plot(discretizare,abs(newton - f), 'b');
axis([a b -1 1]);
legend('eroareMetLagrange','eroareMetN');