function [y] = MetN(X, Y, x)
n = length(X) - 1;
%stiu ca c1 = y1
c(1) = Y(1);
%calculez c2..cn+1
for i = 2:n+1
    %voi determina suma pe care o voi scadea pentru a avea in membrul stang
    %doar ck (la un anumit pas k)
    suma = c(1);
    for j = 2:i-1
        produs = 1;
        for k = 1:j-1
            produs = produs * (X(i)-X(k));
        end
        suma = suma + c(j)*produs;
    end
    produs = 1;
    for k = 1:i-1
        produs = produs * (X(i)-X(k));
    end
    %astfel calculez de sus in jos, inlocuind in fiecare ecuatie valorile
    %determinate la pasii anteriori
    c(i) = (Y(i) - suma)/produs;
end
y = c(1);
for i=2:n+1
    produs = 1;
    for j = 1:i-1
        produs = produs*(x-X(j));
    end
    y = y + c(i)*produs;
end
end