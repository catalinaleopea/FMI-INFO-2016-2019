function [x0, k ] = MetNewton( F, J, x0, epsilon)
k = 0;
ok = 1;
while ok == 1
    k = k + 1;
    zk = J(x0')\(-F(x0'));
    x0 = x0 + zk;
    if norm(zk, inf) < epsilon
        ok = 0;
    end
end
end
