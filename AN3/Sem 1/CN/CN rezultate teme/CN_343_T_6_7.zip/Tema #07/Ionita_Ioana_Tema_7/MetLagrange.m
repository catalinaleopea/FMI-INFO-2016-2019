function [y] = MetLagrange(X, Y, x)
n = length(X) - 1;
y = 0;
%calculez toate polinoamele Lnk, urmand ca polinomul Lagrange sa fie
%calculat ca suma algebrica Lnk * Y(k)
for k = 1:n+1
    Lnk = 1;
    for j = 1:n+1
        if j ~= k
            Lnk = Lnk*(x - X(j))/(X(k) - X(j));
        end
    end
    y = y + Lnk*Y(k);
end
end