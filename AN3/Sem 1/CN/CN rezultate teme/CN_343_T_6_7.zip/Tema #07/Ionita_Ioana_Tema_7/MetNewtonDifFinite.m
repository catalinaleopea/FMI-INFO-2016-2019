function [xaprox, k] = MetNewtonDifFinite(f1, f2, x0, epsilon)
k = 1;
x(:,1) = x0;
cond = 1;
while cond
    k = k + 1;
    h = 0.1;
    %am aplicat formula data la cursul 6&7, determinand J in functie de
    %cele 2 componente ale lui F
    J = [(f1(x(1,k-1)+h,x(2,k-1)) - f1(x(1,k-1),x(2,k-1)))/h
        (f1(x(1,k-1),x(2,k-1)+h)-f1(x(1,k-1),x(2,k-1)))/h ;...
        (f2(x(1,k-1)+h,x(2,k-1)) - f2(x(1,k-1),x(2,k-1)))/h
        (f2(x(1,k-1),x(2,k-1)+h)-f2(x(1,k-1),x(2,k-1)))/h];
    F = [f1(x(1,k-1),x(2,k-1)); f2(x(1,k-1),x(2,k-1))];
    z = transpose(GaussPivTot(J, -F));
    x(:,k) = z + x(:, k-1);
    %iteratia se repeta pana cand norma infinita lui z de la pasul k devine 
    %mai mica decat eroarea considerata epsilon
    if norm(z,inf) < epsilon
        cond = 0;
    end
end
xaprox = x(:,k);
end
