function [y] = MetDirecta (X, Y, x)
n = length(X) - 1;
%calculez matricea A
for i = 1:n+1
    for j =1:n+1
        A(i,j) = X(i)^(j-1);
    end
end
%determin a stiind ca A*a = transpose(Y)
a = GaussPivTot(A,transpose(Y));
y = 0;
%fiecare y reprezinta membrul din dreapta din ecuatiile sistemului
for i = 1:n+1
    y = y + a(i)*x^(i-1);
end
end