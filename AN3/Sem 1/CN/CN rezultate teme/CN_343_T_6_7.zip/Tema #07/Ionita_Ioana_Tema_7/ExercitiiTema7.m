%Tema 7
%Ionita Ioana
%Grupa 343
%% Exercitiul 1
%primul subpunct
syms x y
F1 = x.^2 + y.^2 - 4;
F2 = x.^2/8 - y;
%determin simbolic jacobianul sistemului
J = jacobian([F1, F2], [x, y]);

%al doilea subpunct
figure(1);
ezplot(F1, [-3, 3, -3, 3]);
hold on;
ezplot(F2, [-3, 3, -3, 3]);

%al treilea subpunct a fost implementat in fisierul functie MetNewton.m
%metoda Newton va calcula toate punctele fixe

%al patrulea subpunct
%Pregatirea datelor
syms x y;
F = [x.^2 + y.^2 - 4; x.^2/8 - y];
J = matlabFunction(jacobian(F, [x, y]), 'Vars', {[x, y]}); %Il face pe J de input 1
F = matlabFunction(F, 'Vars', {[x, y]});
%e vector de [x, y], ia din vector pe x si pe y si le pune in functie
[xaprox, N] = MetNewton(F, J, [-2 -1]', 10.^(-6));
disp(xaprox);
disp(N);

%al cincilea subpunct
[xaprox1, N1] = MetNewton(F, J, [-2 -1]', 10.^(-6));
[xaprox2, N2] = MetNewton(F, J, [1 2]', 10.^(-6));
grid on;
hold on;
scatter(xaprox1(1), xaprox1(2));
scatter(xaprox2(1), xaprox2(2));

%recalcularea cu metoda Newton cu diferente finite
f1 = @(x1,x2) x1^2 + x2^2 - 4;
f2 = @(x1,x2) x1^2/8-x2;
%Nu ruleaza pentru metoda Newton cu diferente finite, nu am reustit sa
%identific eroarea, desi am scris functia mai desfasurata...
% [xaproxdif1, N3] = MetNewtonDifFinite(f1, f2, [-3; 3], 10.^(-6));
% [xaproxdif2, N4] = MetNewtonDifFinite(f1, f2, [1; 2], 10.^(-6));
% hold on;
% scatter(xaproxdif1(1), xaproxdif1(2));
% scatter(xaproxdif2(1), xaproxdif2(2));

%% Exercitiul 2
%primul subpunct
syms x1 x2
F1 = x1.^2 - 10.*x1 + x2.^2 + 8;
F2 = x1.*x2.^2 + x1 -10.*x2 + 8;
%determin simbolic jacobianul sistemului
J = jacobian([F1, F2], [x1, x2]);

%subpunctul al doilea
figure(2);
ezplot(F1, [0, 5, 0, 5]);
hold on;
ezplot(F2, [0, 5, 0, 5]);

%al treilea subpunct a fost implementat in fisierul functie MetNewton.m

% %al patrulea subpunct
syms x1 x2;
F = [x1.^2 - 10.*x1 + x2.^2 + 8, x1.*x2.^2 + x1 -10.*x2 + 8];
J = matlabFunction(jacobian(F, [x1, x2]), 'Vars', {[x1, x2]}); %Il face pe J de input 1
F = matlabFunction(F, 'Vars', {[x1, x2]});
%e vector de [x1, x2], ia din vector pe x1 si pe x2 si le pune in functie
[xaprox, N] = MetNewton(F, J, [0 5]', 10.^(-6));
disp(xaprox);
disp(N);

%al cincilea subpunct
[xaprox1, N1] = MetNewton(F, J, [-2 -1]', 10.^(-6));
[xaprox2, N2] = MetNewton(F, J, [1 2]', 10.^(-6));
grid on;
hold on;
scatter(xaprox1(1), xaprox1(2));
scatter(xaprox2(1), xaprox2(2));

%recalcularea cu metoda Newton cu diferente finite
syms x1 x2
f1 = x1.^2 + x2.^2 - 4;
f2 = x1.^2/8-x2;
[xaproxdif1, N3] = MetNewtonDifFinite(f1, f2, [-3; 3], 10.^(-6));
[xaproxdif2, N4] = MetNewtonDifFinite(f1, f2, [1; 2], 10.^(-6));
hold on;
scatter(xaproxdif1(1), xaproxdif1(2));
scatter(xaproxdif2(1), xaproxdif2(2));

%% Exercitiul 4
% Metoda directa
syms x;
f = @(x) sin(x);
A = -pi/2;
B = pi/2;
N = 3;
X = linspace (A, B, N+1);
Y = f(X);
figure(1);
plot(X, Y, 'o', 'MarkerFaceColor', 'r');
x0 = pi/6;
y0 = MetDirecta(X, Y, x0);
Xgrafic = linspace(A, B, 100);
%aplic metoda directa pentru fiecare punct din discretizare, voi lua
%punctele pe rand, avand metoda directa definita pentru cate o valoare a
%lui x, nu un vector de valori
for i=1:length(Xgrafic)
    
   Ygrafic(i) = MetDirecta(X, Y, Xgrafic(i));
   
end
hold on;
plot(Xgrafic, Ygrafic, '--g');
figure(2);
plot (Xgrafic, abs(f(Xgrafic) - Ygrafic), '--b');

%Metoda Lagrange

figure(3);
plot(X, Y, 'o', 'MarkerFaceColor', 'r');
y0 = MetLagrange(X, Y, x0);
%similar cu metoda directa, voi aplica metoda pentru fiecare valoare din
%discretizare
for i=1:length(Xgrafic)
    
    Ygrafic(i) = MetLagrange(X, Y, Xgrafic(i));
    
end
hold on;
plot(Xgrafic, Ygrafic, '--b','LineWidth', 1);

figure(4);
plot (Xgrafic, abs(f(Xgrafic)-Ygrafic), '--g');

%Metoda Newton

figure(5);
plot(X, Y, 'o', 'MarkerFaceColor', 'r');
y0 = MetN(X, Y, x0);
%la fel, aplic metoda pentru fiecare valoare din discretizare
for i=1:length(Xgrafic)
    
    Ygrafic(i) = MetN(X, Y, Xgrafic(i));
    
end
hold on;
plot(Xgrafic, Ygrafic, '--y')
figure(6);
plot (Xgrafic, abs(f(Xgrafic) - Ygrafic), '-g');


%subpunctul 4
%Modificand pe metoda Newton, am crescut gradul polinomului de la n = 3 la 
% n1 = 50. Crescand pana la 60, se observa ca polinomul Pn nu isi pierde
% caracterul. Dupa 60, incep sa apara variatii in valorile lui Pn.
N1 = 50;
X = linspace (A, B, N1+1);
Y = f(X);
plot(X, Y, 'o', 'MarkerFaceColor', 'r');
y0 = MetN(X, Y, x0);
Xgrafic = linspace(A, B, 100);
for i=1:length(Xgrafic)
    
    Ygrafic(i) = MetN(X, Y, Xgrafic(i));
    
end
hold on;
plot(Xgrafic, Ygrafic, '-y');

figure(7);
N2 = 60;
X2 = linspace (A, B, N2+1);
Y2 = f(X2);
plot(X2, Y2, 'o', 'MarkerFaceColor', 'r');
x02 = pi/6;
y02 = MetN(X2, Y2, x02);
Xgrafic2 = linspace(A,B,100);
for i=1:length(Xgrafic2)
    
    Ygrafic2(i) = MetN(X2 ,Y2, Xgrafic2(i));
    
end
hold on;
plot(Xgrafic2, Ygrafic2, '-y');


