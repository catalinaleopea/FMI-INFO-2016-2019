% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = matricea asociata sistemului
% 'b'       = vector coloana reprezentand termenul din dreapta in cadrul
% sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x'    = vectorul solutiilor sistemului
% -------------------------------------------------------------------------
% Author: Ioana Ionita, 2018
% =========================================================================
function [x] = GaussPivTot( A, b )
% C = [A b];                  %matricea extinsa a sistemului
% n = length(b);              %numarul ecuatiilor sistemului
% index = 1:n;                
% for k = 1:n-1 
%     maxim = abs(C(k, k));        %initializez maximul 
%     p = k;                  %indicele de pe coloana unde se afla maximul
%     m = k;
%     for i = k:n
%         for j = k:n
%             if abs(C(i, j))> maxim   %compar cu maximul curent
%                 maxim = abs(C(i, j)); %caut maximul in submatrice
%                 p = i;
%                 m = j;
%             end
%         end
%     end
%     if maxim == 0           %nu exista C(p, m) diferit de 0
%         disp('Sist. incomp. sau sist. comp. nedet.');
%         break;
%     end
%     if p ~= k               %efectuez interschimbarea liniilor p si k
%        C([p,k],:) = C([k,p],:);
%     end
%     if m ~=k                %efectuez interschimbarea coloanelor m si k
%         C(:, [m,k]) = C(:, [k,m]);
%         index([m,k]) = index([k,m]);%retin ca trebuie schimbati si indecsii 
%     end
%     for l = k+1:n           %din linia l scad m(l, k)*linia k pentru a face
%                             %zerouri
%         C(l,:) = C(l,:) - C(l,k)/C(k,k)*C(k,:);
%     end
% end
% if C(n, n) == 0
%     disp('Sistem incomp. sau sist. comp. nedet.');
% end
% y = SubsDesc(C(:, 1:n), C(:, n+1));
% for i=1:n                   %necunoscutele sunt returnate in y, dar in
%                             %ordinea din index
%     x(index(i)) = y(i);
% end
% end
 n = length(b);
    index = 1:n;
    
    Aext = [A b];
    for k = 1:n-1
        p = k;
        m = k;
        max = abs(Aext(k,k));
        for i=k:n
            for j = k:n
                if abs(Aext(i,j))>max
                    max = abs(Aext(i,j));
                    p=i;
                    m=j;
                end
            end
        end
        if max == 0
            fprintf('Sist incomp sau sist comp nedet.')
            return
        end
        if p ~= k
            Aext([p,k],:) = Aext([k,p],:);
        end
        if m ~= k
             Aext(:, [m,k]) = Aext(:, [k,m]);
             index([m,k]) = index([k,m]);
        end
        for l = k+1:n
            m(l,k) = Aext(l,k) / Aext(k,k);
            Aext(l,:) = Aext(l,:) - m(l,k)*Aext(k,:);
        end
    end
    
    if Aext(n,n) == 0
        fprintf ('Sistem incomp sau sist comp nedet.')
        return
    end
    
    y=SubsDesc(Aext(:,1:n), Aext(:,n+1));
    for i=1:n
        x(index(i)) = y(i);
    end
end

