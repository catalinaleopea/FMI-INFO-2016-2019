% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'X'       = nodurile de interpolare
% 'Y'       = valorile functiei f in nodurile de interpolare
% 'x'       = punctul pentru care se calculeaza interpolarea
% -------------------------------------------------------------------------
% Date de iesire:
% 'y'       = valoarea interpolata
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [y] = MetN (X, Y, x)
    n = size(X, 2);

    c = zeros(1, n - 1);
    c = [1 c];

    C = zeros(n);

    for k = 1 : n
        for i = 1 : k
            d = c;
            P = 1;

            for j = 1 : i - 1
                P = P * (X(k) - X(j));
            end

            C(k, i) = P;
        end
    end

    sol = SubsAsc(C, Y);

    y = sol(1);
    for i = 1 : n
        P = 1;
        d = 0;
        for j = 1 : i - 1
            d = 1;
            P = P * (x - X(j));
        end
        y = y + sol(i) * P * d;
    end
end
