% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'X'       = nodurile de interpolare
% 'Y'       = valorile functiei f in nodurile de interpolare
% 'x'       = punctul pentru care se calculeaza interpolarea
% -------------------------------------------------------------------------
% Date de iesire:
% 'y'       = valoarea interpolata
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [y] = MetLagrange(X, Y, x)
    Ls = [];
    y = 0;

    for i = 1 : size(X, 2)
        P = 1;
        for j = 1 : size(X, 2)
            if i == j
                continue;
            end
            P = P * ((x - X(j)) / (X(i) - X(j))); 
        end
        Ls = [Ls P]; 
    end

    y = sum(Ls * Y');
end
