% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'X'       = nodurile de interpolare
% 'Y'       = valorile functiei f in nodurile de interpolare
% 'x'       = punctul pentru care se calculeaza interpolarea
% -------------------------------------------------------------------------
% Date de iesire:
% 'y'       = valoarea interpolata
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [y] = MetDirecta(X, Y, x)
    A = ones(size(X, 2),1);
    
    for i = 1 : size(X, 2) - 1
        A = [A(X').^i];
    end
    
    sol = GaussPivTot(A, Y');
    
    y = 0;
    for i = 1 : size(sol, 2)
        c = x ^ (i - 1) * sol(i);
        y = y + c;
    end
end
