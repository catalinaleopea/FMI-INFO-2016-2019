%%
%Ex.1

% Calculul simbolic al matricei Jacobian
syms x y 
% functiile componente din sistemul de ec. neliniare
f1 = x.^2 + y.^2 -4; 
f2 = x.^2/8 - y;
F = [f1, f2];
%vector care refera ordinea de calcul a derivatelor partiale 
v = [x y];

J = jacobian(F,v);
disp(J);

% Grafice curbe C1 si C2
figure(1);
ez1 = ezplot(f1,[-3,3,-3,3]); 
hold on 
ezplot(f2,[-3,3,-3,3]);
set(ez1, 'color', [1 0 0]); %plotare cu culoare rosie 

f1func = @(x,y)x^2 + y^2 - 4;
f2func = @(x,y)x^2/8-y;

% Aflare puncte de intersectie cu metoda Newton
%--------------------------------------------------------------------------
syms x y;
F = [x.^2 + y.^2 - 4; x.^2/8 - y];
J = matlabFunction(jacobian(F, [x, y]), 'Vars', {[x, y]}); 
F = matlabFunction(F, 'Vars', {[x, y]});
%e vector de [x, y], ia din vector pe x si pe y si le pune in functie

[xaprox, ~] = MetNewton(F, J, [-2 -1]', 10.^(-6));
% constructia punctului pe grafic
plot(xaprox(1),xaprox(2),'o','markerFaceColor','r');

[xaprox, ~] = MetNewton(F, J, [1 2]', 10.^(-6)); 
% constructia punctului pe grafic
plot(xaprox(1),xaprox(2),'o','markerFaceColor','r');

%Aflare puncte de intersectie cu metoda Newton cu diferente finite
%--------------------------------------------------------------------------
x0 = [-2 ; -1]; 
[xaprox,~] = NewtonDiferenteFin(f1func, f2func, x0,eps);
plot(xaprox(1),xaprox(2),'o','markerFaceColor','b');

x0 = [1 ; 2];
[xaprox,~] = NewtonDiferenteFin(f1func, f2func, x0,eps); 
plot(xaprox(1),xaprox(2),'o','markerFaceColor','b');
%--------------------------------------------------------------------------

legend("x^2+y^2=4", "y=x^2/8", "punct de intersectie");
%%
%Ex.2.

syms x1 x2 
% functiile componente din sistemul de ec. neliniare
f1 = x1.^2 - 10*x1 + x2.^2 + 8; 
f2 = x1*x2.^2 + x1 - 10*x2 + 8;
F = [f1, f2];
%vector care refera ordinea de calcul a derivatelor partiale 
v = [x1 x2];

%Calcul matrice Jacobian
J = jacobian(F,v);
disp(J);


% Grafice curbe 
figure(1);
ez1 = ezplot(f1,[0,5,0,5]); 
hold on 
ez2 = ezplot(f2,[0,5,0,5]);
set(ez1, 'color', [1 0 0]); %plotare cu culoare rosie 

f1func = @(x1,x2)x1.^2 - 10*x1 + x2.^2 + 8;
f2func = @(x1,x2)x1*x2.^2 + x1 - 10*x2 + 8;

% Aflare puncte de intersectie cu metoda Newton
%--------------------------------------------------------------------------
syms x y;
F = [x1.^2 - 10*x1 + x2.^2 + 8; x1*x2.^2 + x1 - 10*x2 + 8];
J = matlabFunction(jacobian(F, [x1, x2]), 'Vars', {[x1, x2]}); 
F = matlabFunction(F, 'Vars', {[x1, x2]});
%e vector de [x1, x2], ia din vector pe x1 si pe x2 si le pune in functie
% 
% [xaprox, ~] = MetNewton(F, J, [0.5 1]', 10.^(-6));
% % constructia punctului pe grafic
% plot(xaprox(1),xaprox(2),'o','markerFaceColor','r');
% 
% [xaprox, ~] = MetNewton(F, J, [2 2.5]', 10.^(-6)); 
% % constructia punctului pe grafic
% plot(xaprox(1),xaprox(2),'o','markerFaceColor','r');

%Aflare puncte de intersectie cu metoda Newton cu diferente finite
%--------------------------------------------------------------------------
x0 = [0.5 ; 1]; 
[xaprox,~] = NewtonDiferenteFin(f1func, f2func, x0, eps);
plot(xaprox(1),xaprox(2),'o','markerFaceColor','b');

x0 = [2 ; 2.5];
[xaprox,~] = NewtonDiferenteFin(f1func, f2func, x0,eps); 
plot(xaprox(1),xaprox(2),'o','markerFaceColor','b');
%--------------------------------------------------------------------------

legend("x1.^2 - 10*x1 + x2.^2 + 8", "x1*x2.^2 + x1 - 10*x2 + 8", "punct de intersectie");
%%

%Ex.4. - subpunctul 2)
%aflare polinom Pn prin metoda directa si reprezentari grafice;

f = @(x)sin(x); 
a = -pi/2; 
b = pi/2;
n = 3;
X = linspace (a, b, n+1); %diviziunea echidistanta pt intervalul [a,b]
Y = f(X); %multimea valorilor functiei in nodurile de interpolare 
%reprezentare grafica puncte (Xi, Yi)
plot(X, Y, 'o', 'MarkerFaceColor', 'r');

x0 = pi/6;
% calcul polinom Lagrange, prin metoda directa; 
y0 = MetDirecta(X,Y,x0);
disp(y0);
disp(sin(x0));

xgrafic = linspace(a,b,100);
for i=1:length(xgrafic)    
    ygrafic(i) = MetDirecta(X,Y,xgrafic(i));
end

hold on
plot(xgrafic, ygrafic, 'r','LineWidth', 3);
legend("Punct (Xi, Yi)", "Grafic f pe [a b]");
title("Reprezentare grafic functie, puncte (Xi, Yi) si polinom Lagrange");

%subpunctul 3)
%reprezentare grafica eroare 
figure
plot (xgrafic, abs(f(xgrafic)-ygrafic), 'b', 'LineWidth', 3);
title("Reprezentare eroare E = abs(f - Pn)");

%%
%Ex.4. - subpunctul 2)
%aflarea polinomului Pn prin metoda Lagrange si reprezentari grafice;

f = @(x)sin(x); 
a = -pi/2;
b = pi/2; 
n = 3; 
X = linspace (a, b, n+1); 
Y = f(X);
plot(X, Y, 'o', 'MarkerFaceColor', 'r');
x0 = pi/6;
y0 = MetLagrange(X,Y,x0);
disp(y0);
disp(sin(x0));

xgrafic = linspace(a,b,100);
for i=1:length(xgrafic)    
    ygrafic(i) = MetLagrange(X,Y,xgrafic(i));
end
hold on
plot(xgrafic, ygrafic, 'b','LineWidth', 3)
legend("Punct (Xi, Yi)", "Grafic f pe [a b]");
title("Reprezentare grafic functie, puncte (Xi, Yi) si polinom Lagrange");

%subpunctul 3)
%reprezentare grafica eroare 
figure 
plot (xgrafic, abs(f(xgrafic)-ygrafic), 'r', 'LineWidth', 3);
title("Reprezentare eroare E = abs(f - Pn)");
%%

%Ex.4. - subpunctul 2)
%aflarea polinomului Pn prin metoda Newton si reprezentari grafice;

f = @(x)sin(x); 
a = -pi/2; 
b = pi/2; 
n = 3; 
X = linspace (a, b, n+1); Y = f(X);
plot(X, Y, 'o', 'MarkerFaceColor', 'r');
x0 = pi/6;
y0 = MetN(X,Y,x0);
disp(y0);
disp(sin(x0));
xgrafic = linspace(a,b,100);
for i=1:length(xgrafic)  
    ygrafic(i) = MetN(X,Y,xgrafic(i)); 
end
hold on
plot(xgrafic, ygrafic, 'y','LineWidth', 3)
legend("Punct (Xi, Yi)", "Grafic f pe [a b]");
title("Reprezentare grafic functie, puncte (Xi, Yi) si polinom Lagrange");

%subpunctul 3)
%reprezentare grafica eroare 
figure 
plot (xgrafic, abs(f(xgrafic)-ygrafic), 'g', 'LineWidth', 3);
title("Reprezentare eroare E = abs(f - Pn)");
%%
%Ex.4. - subpunctul 4) 
%Cresteti progresiv gradul polinomului Pn si rulati programele.
%Am facut modificarile pentru una din metodele de mai sus, si anume Newton;

%Se observa ca, daca crestem gradul polinomului de la n=5 pana la n=60
%treptat, polinomul Pn nu isi pierde caracterul;

%crescand gradul de la n=60 in sus, apar variatii semnificative in valorile pe
%care le ia polinomul;

f = @(x)sin(x);
a = -pi/2;
b = pi/2; 
n1 = 50; 
X = linspace (a, b, n1+1); 
Y = f(X);
plot(X, Y, 'o', 'MarkerFaceColor', 'r');
x0 = pi/6;
y0 = MetN(X,Y,x0);
xgrafic = linspace(a,b,100);
for i=1:length(xgrafic)
    ygrafic(i) = MetN(X,Y,xgrafic(i));
end

hold on 
plot(xgrafic, ygrafic, 'y','LineWidth', 3)
figure n2 = 60;
X2 = linspace (a, b, n2+1); 
Y2 = f(X2);
plot(X2, Y2, 'o', 'MarkerFaceColor', 'r');
x02 = pi/6;
y02 = MetN(X2,Y2,x02);
sin(x02)
xgrafic2 = linspace(a,b,100);
for i=1:length(xgrafic2)  
    ygrafic2(i) = MetN(X2,Y2,xgrafic2(i)); 
end
hold on
plot(xgrafic2, ygrafic2, 'y','LineWidth', 3);
%%
% Ex.1. - Metoda Newton construita pe baza algoritmului din curs
function [x0, k ] = MetNewton( F, J, x0, epsilon)
    k = 0;
    ok = 1;
    while ok == 1
        k = k + 1;
        zk = J(x0')\(-F(x0'));
        x0 = x0 + zk;
        if norm(zk, inf) < epsilon
            ok = 0;
        end
    end
end


% Ex.1. - Metoda Newton folosind diferente finite 
function [xaprox,N] = NewtonDiferenteFin(f1,f2,x0, eps) 
    k = 1;    
    x(:,1) = x0; 
    while true      
        k = k + 1;  
        h = 0.1;        
        J = [(f1(x(1,k-1)+h,x(2,k-1)) - f1(x(1,k-1),x(2,k-1)))/h (f1(x(1,k-1),x(2,k-1)+h)-f1(x(1,k-1),x(2,k-1)))/h ;...    
            (f2(x(1,k-1)+h,x(2,k-1)) - f2(x(1,k-1),x(2,k-1)))/h (f2(x(1,k-1),x(2,k-1)+h)-f2(x(1,k-1),x(2,k-1)))/h];   
        
        F = [f1(x(1,k-1),x(2,k-1));...        
            f2(x(1,k-1),x(2,k-1))];    
        
        z(:,k) = transpose(MetGaussCuPivTot(J,-F));       
        x(:,k) = z(:,k)+x(:,k-1);       
        if norm(z(:,k), inf) < eps         
            break;    
        end
    end
    xaprox = x(:,k); 
    N=k;
end

%functie ce returneaza solutia x a sistemului de ecuatii liniare A*x = b,
%folosind metoda Gauss cu pivotare totala;
function x = MetGaussCuPivTot(A, b)  
    A = [A, b];   
    n = length(b); 
    x = zeros(n,1);
    index = (1:n);  
    for k = 1:n-1     
        vmax = abs(A(k, k));    
        p = k;      
        m = k;       
        for i = k:n    
            for j = k:n      
                if abs(A(i, j)) > vmax      
                    vmax = abs(A(i, j));     
                    p = i;               
                    m = j;              
                end
            end
        end
        if(vmax == 0)        
            x(1:n) = 0;         
            disp('Sist. incompatibil sau compatibil nedet.');     
            return;       
        end
        if(p ~= k)   
            A([p k], :) = A([k, p], :);       
        end
        if(m ~= k)    
            A(:, [k, m]) = A(:, [m, k]);    
            aux = index(k);    
            index(k) = index(m);           
            index(m) = aux;      
        end
        for l = k+1:n       
            A(l, :) = A(l, :) - A(l, k) .* A(k, :) / A(k, k);    
        end
    end
    if A(n, n) == 0    
        x(1:n) = 0;    
        disp('Sist. incompatibil sau compatibil nedet.'); 
        return;   
    end
    b = A(:, n+1);
    A(:, n+1) = [];   
    xold = SubsDesc(A, b);  
    for i = 1:n   
        x(index(i)) = xold(i);  
    end
end

%Metoda Substitutiei Descendente pentru un sistem superior triunghiular
function x = SubsDesc(A, b)   
    n = length(b);   
    x(n) = b(n) / A(n, n);   
    for i=n-1:-1:1   
        x(i) = (b(i) - sum(A(i, i+1:n) .* (x(i+1:n)))) / A(i, i);  
    end
end


%Ex.4. - Metoda Directa (primul subpunct) - conform algoritmului din curs
function [Pn] = MetDirecta (X, Y, x)   
    n = length(X) - 1;    
    for i = 1:n+1      
        for j =1:n+1     
            A(i,j) = X(i)^(j-1);   
        end
    end
    %aflam solutia a din sistemul de ecuatii liniare sub forma matriceala;
    a = MetGaussCuPivTot(A,transpose(Y));
    Pn = 0;   
    for i = 1:n+1    
        Pn = Pn + a(i)*x^(i-1);  
    end
end

%Ex.4. - Metoda Lagrange (punctul b) - conform algoritmului din curs 
function [Pn] = MetLagrange(X, Y, x)    
    n = length(X) - 1;
    Pn = 0;    
    for k = 1:n+1       
        Lnk = 1; %polinom de grad n ce urmeaza a fi determinat   
        for j = 1:n+1        
            if j ~= k          
                Lnk = Lnk*(x - X(j))/(X(k) - X(j));     
            end
        end
        Pn = Pn + Lnk*Y(k); %formula de reprezentare a polinomului Lagrange   
    end
end

%Ex.4. - Metoda Newton (punctul c) - conform algoritmului din curs 
function [Pn] = MetN(X,Y,x)   
    n = length(X) - 1;
    c(1) = Y(1);  
    for i = 2:n+1  
        suma = c(1);     
        for j = 2:i-1        
            produs = 1;        
            for k = 1:j-1            
                produs = produs * (X(i)-X(k));    
            end
            suma = suma + c(j)*produs;     
        end
        
        produs = 1;    
        for k = 1:i-1      
            produs = produs * (X(i)-X(k));    
        end
        c(i) = (Y(i) - suma)/produs;  
    end
    
    Pn = c(1);   
    for i=2:n+1  
        produs = 1;   
        for j = 1:i-1       
            produs = produs*(x-X(j));   
        end
        Pn = Pn + c(i)*produs;  
    end
end

