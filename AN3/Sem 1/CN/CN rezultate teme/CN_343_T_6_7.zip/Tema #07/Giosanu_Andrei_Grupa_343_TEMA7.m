%Giosanu Andrei
%Grupa 343
% Erorile se masoara in valoare absoluta!
% Nu ai scris codul cu sectiuni.
% 7/10.

%% ex-1

%a)
f1 = @(x,y) x.^2 + y.^2 - 4;
f2 = @(x,y) x.^2./8 - y;
syms x y
j11_s(x,y) = diff(f1(x,y), x);
j11 = matlabFunction(j11_s);
j12_s(x,y) = diff(f1(x,y), y);
j12 = matlabFunction(j12_s);
j21_s(x,y) = diff(f2(x,y), x);
j21 = matlabFunction(j21_s);
j22_s(x,y) = diff(f2(x,y), y);
j22 = matlabFunction(j22_s);

%b)
figure
hold on
ezplot(f1,[-3 3 -3 3]);
ezplot(f2, [-3 3 -3 3]);

%d)
[x_aprox1, N1] = Newton(f1, f2,  j11, j12, j21, j22, [-2;1], 10^(-6));
[x_aprox2, N2] = Newton(f1, f2,  j11, j12, j21, j22, [2;1], 10^(-6));

%e)
plot(x_aprox1(1), x_aprox1(2), 'og');
plot(x_aprox2(1), x_aprox2(2), 'og');

%% ex-2

%a)
f1 = @(x1,x2) x1.^2 - 10.*x1 + x2.^2 + 8;
f2 = @(x1,x2) x1.*x2.^2 + x1 - 10.*x2 + 8;
syms x1 x2
j11_s(x1,x2) = diff(f1(x1,x2), x1);
j11 = matlabFunction(j11_s);
j12_s(x1,x2) = diff(f1(x1,x2), x2);
j12 = matlabFunction(j12_s);
j21_s(x1,x2) = diff(f2(x1,x2), x1);
j21 = matlabFunction(j21_s);
j22_s(x1,x2) = diff(f2(x1,x2), x2);
j22 = matlabFunction(j22_s);

%b)
figure
hold on
ezplot(f1,[0 5 0 5]);
ezplot(f2, [0 5 0 5]);

%d)
[x_aprox3, N3] = Newton(f1, f2,  j11, j12, j21, j22, [1;3], 10^(-6));
[x_aprox4, N4] = Newton(f1, f2,  j11, j12, j21, j22, [1;2], 10^(-6));

%e)
plot(x_aprox3(1), x_aprox3(2), 'og');
plot(x_aprox4(1), x_aprox4(2), 'og');



f = @(x) sin(x);
n = 3;
a = -pi/2;
b = pi/2;
X = linspace(a,b,n+1)';
Y = f(X);
div = linspace(a,b,100);

figure; 
hold on;
rez1 = MetDirecta(X,Y, div);
plot(div,f(div), 'r');
plot(div, MetDirecta(X,Y, div), 'k--');

figure;
E = f(div) - rez1;
plot(E);

figure; 
hold on;
rez2 = interpolareLagrange(X,Y, div);
plot(div,f(div), 'r');
plot(div, interpolareLagrange(X,Y, div), 'k--');

figure;
E = f(div) - rez2;
plot(E);

figure;
hold on;
rez3 = MetN(X,Y, div);
plot(div,f(div), 'r');
plot(div, MetN(X,Y, div), 'k--');

figure;
E = f(div) - rez3;
plot(E);

% n maxim pentru care polinomul se aproprie de f e:
% 71 pentru MetDirecta
% 66 pentru interpolareLagrange
% 62 pentru MetN
%% 
function [ y ] = interpolareLagrange( X, Y, x )
N = size(X) - 1;
A = ones(N + 1);
for i = 2: N+1
    A = [A, X.^(i-1)];
end
a = A\Y
y = 0;
for i = 1: N+1
    y = y + a(i) * x.^(i-1);
end

end

function y = MetN(X, Y, x)
    n = length(X);
    A = zeros(n, n);
    A(:, 1) = 1;
    
    for i = 2:n
        for j = 2:i
            A(i, j) = prod(X(i) * ones(j - 1, 1) - X(1:(j - 1)));
        end
    end
    coef = SubsAsc(A, Y);
    disp(A);
    y = coef(1);
    for i = 2:n
        y = y + coef(i) * prod(x .* ones(i - 1, 1) - X(1:(i - 1)));
    end
end

function y = MetDirecta(X,Y,x)
    n = length(X);
    A = zeros(n, n);
    for i = 1:n
        A(:, i) = X .^ (i - 1);
    end
    b = Y;
    a = GaussPivTot(A, b);
    
    y = 0;
    for i=1:n
        y = y + a(i) * x .^ (i - 1);
    end
    y = polyval(fliplr(a), x);
end
function [x]=GaussPivTot(A,b)
    A=[A,b];
    n=size(A,1);
    x = [];
    xindice=1:n;
    for k=1:n-1
        max=abs(A(k,k)); 
        p = k; m = k; 
        for i  = k:n
            for j = k:n
                if abs(A(i,j))> max
                    max=abs(A(i,j));
                    p = i; m = j;
                end
            end
        end
        if A(p,m) == 0 
            disp('Sist. incomp. sau comp. nedet.');
            return;
        end
        if p~=k
           A([p,k],:) = A([k,p],:);
        end
        if m~=k
            A(:,[m,k]) = A(:,[k,m]);
            xindice([m,k]) = xindice([k,m]);
        end
        for l=k+1:n
            A(l,:) = A(l,:)-A(l,k)/A(k,k)*A(k,:);
        end
    end
    if A(n,n) == 0
        disp('Sist. incomp. sau comp. nedet.');
        return;
    end
    xschimbat=SubsDesc(A(1:n,1:n),A(:,n+1)); 
    for i = 1:n
        x(xindice(i)) = xschimbat(i);
    end
end

function [x]=SubsDesc(A,b)
    n=length(b);
    x(n)=b(n)/A(n,n);
    k=n-1;
    while k>0
        sum=0;
        for j=k+1:n
            sum=sum+A(k,j)*x(j);
        end
        x(k)=1/A(k,k)*(b(k)-sum);
        k=k-1;
    end
end

function [x]=SubsAsc(A,b)
    n=length(b);
    x(1)=b(1)/A(1,1);
    for k = 2:n
        sum=0;
        for j=1:k-1
            sum=sum+A(k,j)*x(j);
        end
        x(k)=1/A(k,k)*(b(k)-sum);  
    end
end

function [ x_aprox, N ] = Newton(f1, f2, j11, j12, j21, j22, x0, eps) 
N = 1;
J = [j11(x0(1), x0(2)) j12(x0(1), x0(2)); j21(x0(1), x0(2)) j22(x0(1), x0(2))];
F = [f1(x0(1), x0(2)); f2(x0(1), x0(2))];
z = J\(-F);
x1 = x0 + z;
while norm(z) >= eps
    x0 = x1;
    J = [j11(x0(1), x0(2)) j12(x0(1), x0(2)); j21(x0(1), x0(2)) j22(x0(1), x0(2))];
    F = [f1(x0(1), x0(2)); f2(x0(1), x0(2))];
    z = J\(-F);
    x1 = x0 + z;
    N = N + 1;
end
x_aprox = x1;
end
