%% Exercitiul 1.a
% Total> 8/10
syms x y 
ecuatii = [x^2+y^2-4 x^2/8-y] ;
variabile=[x y] ; 

[dummy,dim_ecuatii]=size(ecuatii); 
[dummy,dim_variabile]=size(variabile);  
J = sym(zeros(dim_ecuatii, dim_ecuatii));
for i=1:dim_ecuatii 
    for j=1:dim_variabile 
        J(i,j)=diff(ecuatii(i),variabile(j)); 
    end
end 
J
%% Exercitiul 1.b 

ezplot(ecuatii(1), [-3, 3, -3, 3])  
hold on
ezplot(ecuatii(2), [-3, 3, -3, 3]) 
grid on
axis equal 

%% Exercitiul 1.d,e  
fprintf("Newton simplu:");
[x,N]=Newton(ecuatii,J,[-2 0.5],10^(-6))  
plot(x(1),x(2),'r*'); 
[x,N]=Newton(ecuatii,J,[2 0.5],10^(-6))   
plot(x(1),x(2),'r*'); 
hold off  

%% Exercitiul 1.f  
fprintf("Newton cu J aproximat:");
[x,N]=Newton_Japrox(ecuatii,[-2 0.5],10^(-6)) 
[x,N]=Newton_Japrox(ecuatii,[2 0.5],10^(-6))   

%% Exercitiul 2.a  

syms x y 

ecuatii = [x^2 - 10*x + y^2 + 8   x*(y^2) + x - 10*y+8]
variabile= [x y]

[dummy,dim_ecuatii]=size(ecuatii); 
[dummy,dim_variabile]=size(variabile);  
J = sym(zeros(dim_ecuatii, dim_ecuatii));
for i=1:dim_ecuatii 
    for j=1:dim_variabile 
        J(i,j)=diff(ecuatii(i),variabile(j)); 
    end
end 
J
%% Exercitiul 2.b  
figure(2);
ezplot(ecuatii(1), [0, 5, 0, 5] )  
hold on
ezplot(ecuatii(2), [0, 5, 0, 5] ) 
grid on
axis equal   

%% Exercitiul 2.d,e 

fprintf("Newton simplu:");
[x,N]=Newton(ecuatii,J,[1 1],10^(-6))  
plot(x(1),x(2),'r*'); 
[x,N]=Newton(ecuatii,J,[3 2],10^(-6))   
plot(x(1),x(2),'r*'); 
hold off   

%% Exercitiul 2.f 
fprintf("Newton cu J aproximat:");
[x,N]=Newton_Japrox(ecuatii,[1 1],10^(-6)) 
[x,N]=Newton_Japrox(ecuatii,[3 2],10^(-6))   

%% Exercitiul 3 
X=[-pi/2 0 pi/2]; 
Y=[-1 0 1];
syms x p; 
fprintf("Polinomul obtinut prin metoda Directa:");
poly=MetDirectaPoly(X,Y) 
fprintf("Polinomul obtinut prin metoda Lagrange:");
poly=MetLagrangePoly(X,Y)  
p=vpa(poly,4) 
p=collect(p,x); 
p
fprintf("Polinomul obtinut prin metoda Newton:");
poly=MetNPoly(X,Y)  
p=vpa(poly,4) 
%% Exeritiul 4.2,3,4
figure; 
title('Metoda directa'); 
grafice(3,@MetDirecta); 
figure; 
title('Metoda Lagrange');
grafice(3,@MetLagrange);  
figure;
title('Metoda Newton');
grafice(3,@MetN); 
n=PierdereCaracter(@MetDirecta);  
fprintf("Polinomul determinat prin metoda directa isi pierde caracterul la %d\n",n);
n=PierdereCaracter(@MetLagrange); 
fprintf("Polinomul determinat prin metoda Lagrange isi pierde caracterul la %d\n",n);
n=PierdereCaracter(@MetN); 
fprintf("Polinomul determinat prin metoda Newton isi pierde caracterul la %d\n",n);
%% Functii  
function y=MetDirecta(X,Y,x)
    [dummy,n]=size(X); 
    params=zeros(n,n); 
    for i=1:n  
        for j=1:n
            params(j,i)=X(j)^(i-1);
        end
    end 
    polinom=GaussPivTot(params,Y) ;
    y=0;
    for i=1:n  
        y=y+polinom(i)*x^(i-1);
    end
end

function poly=MetDirectaPoly(X,Y)
    [dummy,n]=size(X); 
    params=zeros(n,n); 
    for i=1:n  
        for j=1:n
            params(j,i)=X(j)^(i-1);
        end
    end 
    poly=GaussPivTot(params,Y) ;
end


function y=MetLagrange(X,Y,x)
    [dummy,n]=size(X);  
    L=zeros(1,n); 
    for i=1:n    
        numarator=1; 
        numitor=1;
        for j=1:n
            if(i~=j)  
                numarator=numarator*(x-X(j)); 
                numitor=numitor*(X(i)-X(j));
            end
        end 
        L(i)=numarator/numitor;
    end  
    y=sum(L.*Y);
end  

function poly=MetLagrangePoly(X,Y)
    [dummy,n]=size(X);   
        syms x;
    for i=1:n    
        numarator=1; 
        numitor=1;
        for j=1:n
            if(i~=j)  
                numarator=numarator*(x-X(j)); 
                numitor=numitor*(X(i)-X(j));
            end
        end 
        L(i)=numarator/numitor;
    end  
    poly=sum(L);
end 

function y=MetN(X,Y,x)
    [dummy,n]=size(X);  
    params=zeros(n,n); 
    params(:,1)=1; 
    for i=2:n 
        for j=2:i   
            params(i,j)=1;
            for k=1:j-1  
                params(i,j)=params(i,j)*(X(i)-X(k));
            end
        end
    end 
    c=SubsAsc(params,Y); 
    y=c(1); 
    for i=2:n-1  
        product=1;
        for j=1:i-1  
            product=product*(x-X(j));
        end  
        y=y+c(i)*product;
    end
end 

function poly=MetNPoly(X,Y)
    [dummy,n]=size(X);  
    params=zeros(n,n); 
    params(:,1)=1;  
    syms x;
    for i=2:n 
        for j=2:i   
            params(i,j)=1;
            for k=1:j-1  
                params(i,j)=params(i,j)*(X(i)-X(k));
            end
        end
    end 
    c=SubsAsc(params,Y); 
    poly=c(1); 
    for i=2:n-1  
        product=1;
        for j=1:i-1  
            product=product*(x-X(j));
        end  
        poly=poly+c(i)*product;
    end
end 


function [xaprox,N]=Newton(F,J,x0,e)    
N=0;  
x=x0;
while 1  
    N=N+1;  
    numerical_J=subs(J,symvar(J),x);
    numerical_F=subs(F,symvar(F),x);
    z=transpose(-inv(numerical_J)*transpose(numerical_F));
    x=x+z; 
    if norm(z)<e  
        xaprox=double(x); 
        break;
    end
end

end 

function [xaprox,N]=Newton_Japrox(F,x0,e)  
N=0;  
x=x0; 
h=0.001;
while 1  
    N=N+1;  
    
    [dummy,dim_ecuatii]=size(F); 
    [dummy,dim_variabile]=size(x);  
    E=eye(dim_variabile);
    J= zeros(dim_ecuatii,dim_variabile);
    for i=1:dim_ecuatii 
        for j=1:dim_variabile  
            value=(subs(F(i),symvar(F(i)),x+h*E(j,:))- subs(F(i),symvar(F(i)),x))/h;
        	J(i,j)=value;
        end
    end 
    numerical_F=subs(F,symvar(F),x);
    z=transpose(-inv(J)*transpose(numerical_F));
    x=x+z; 
    if norm(z)<e  
        xaprox=double(x); 
        break;
    end
end

end  

function [X] = GaussPivTot(A,b) 
X=0;
b=reshape(b,length(b),1);
A=[A b];  
[m,n]=size(A);  
for i=1:m 
    permutation(i)=i; %memoreaza ordinea necunoscutelor pentru refacerea ulterioara a acesteia.
end 
for k=1:m-1    
      
    max=0;
    for q=k:m 
        for p=k:m  
            if abs(A(q,p))>max 
                II=q;
                JJ=p;
                max=abs(A(q,p)) ;
            end
        end
    end   %for ce determina maximum din submatricea aferenta pasului curent
    if max==0  
        fprintf("Sistem incompatibil sau compatibil nedeterminat");   
        return;
    end  
        
    if k~=II
        A([k,II],:) = A([II,k],:); 
    end  %interschimbare de linii
    
    if k~=JJ  
        A(:,[k,JJ]) = A(:,[JJ,k]);   
        aux=permutation(k);
        permutation(k)=permutation(JJ) ;
        permutation(JJ)=aux;
    end  %interschimbare de coloane si memorarea schimbarilor in permutare
    
    for l=k+1:m  
        M=A(l,k)/A(k,k); 
        A(l,:)=A(l,:)-M*A(k,:);
    end  %calculul valorilor liniilor de sub pivot in vederea obtinerii de zero-uri
end 

if A(m,m)==0 
   fprintf("Sistem incompatibil sau compatibil nedeterminat");   
   return;
end  

unpermutedX=SubsDesc(A(1:m,1:m),A(:,n))  ;
for i=1:m  
    X(permutation(i))=unpermutedX(i);%refacerea ordinii necunoscutelor
end 
end 

function [X] = SubsDesc(A,b)
[m,n]=size(A);  
X(n)=1/A(m,m)*b(m); 
k=n-1; 
while k>0 
    X(k)=1/A(k,k) *( b(k) - sum( A(k,k+1:m) .* X(k+1:m) ) ); 
    %calcularea solutiei curente prin inmultirea necunoscutelor deja
    %calculate la coeficientii acestora, scaderea acestei sume din termenul
    %liber si impartirea la coeficientul necunoscutei actuale: 
    %b(k) - termen liber de pe linia k 
    %A(k,k+1:m) coeficientii necunoscutelor de pe linia actuala 
    %X(k+1:m) - necunoscutele calculate la pasii anteriori 
    %A(k,k) - coeficientul necunoscute actuale
    k=k-1;
end
end 

function [X] = SubsAsc(A,b)
[m,n]=size(A);  
X(1)=1/A(1,1)*b(1); 
for k=2:n
    X(k)=1/A(k,k) *( b(k) - sum( A(k,1:k-1) .* X(1:k-1) ) );  
    %Calculeaza solutia unui sistem de forma triunghiulara subsituind in
    %ecuatii solutiile anterioare pana la calcularea tuturor solutiilor.
end
end

function grafice(n,met) 
    subplot(2, 1, 1);
    a=-pi/2 ;
    b=pi/2 ;  
    X=linspace(a,b,n+1); 
    Y=sin(X);
    Xgrafice=linspace(a,b,100);  
    hold on;
    plot(Xgrafice,sin(Xgrafice),'r');  
    for i=1:100
        Ygrafic(i)=met(X,Y,Xgrafice(i));
    end  

    plot(Xgrafice,Ygrafic,'b+'); 
    hold off; 
    Error=sin(Xgrafice)-Ygrafic;  
    subplot(2, 1, 2);
    plot(Xgrafice,abs(Error));   

end 

function n=PierdereCaracter(met)  
    a=-pi/2 ;
    b=pi/2 ;   
    maxError=1;
    for n=5:100
        X=linspace(a,b,n+1); 
        Y=sin(X);
        Xverificare=linspace(a,b,100);  
        for i=1:100
            Yprezis(i)=met(X,Y,Xverificare(i));
        end   
        Error=sin(Xverificare)-Yprezis;   
        if sum(abs(Error))>maxError 
            indexError=n;  
            break;
        end
    end

    n=indexError;
    
end
