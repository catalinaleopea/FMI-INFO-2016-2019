function y = MetLagrange(X, Y, x)
    n = length(X);
    y = 0;
    for k = 1:n
        rest = X(1:(k - 1));
        if k < n
            rest = [rest; X((k + 1):n)];
        end
        u = prod(x * ones(n - 1, 1) - rest);
        v = prod(X(k) * ones(n - 1, 1) - rest);
        L = u / v;
        y = y + L * Y(k);
    end
end