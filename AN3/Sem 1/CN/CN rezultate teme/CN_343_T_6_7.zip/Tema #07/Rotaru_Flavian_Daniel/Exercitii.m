%==========================================================================
% EX.1: Fie urmatorul sistem de ecuatii neliniare:
% {x^2 + y^2 = 4 
% {x^2/8 - y = 0
%
% (x, y) ? [?3, 3] � [?3, 3]. Sa se implementeze in Matlab 
%   urmatoarele cerinte: 
% 
% a)Sa se calculeze simbolic Jacobianul sistemului;
% b) Sa se construiasca grafic curbele C1 : x^2 + y^2 = 4 si C2: y = x^2/8
% c) Sa se construiasca procedura Newton cu sintaxa 
%  [xaprox, N] =Newton(F, J, x(0), ?) in baza algoritmului metodei Newton;
% d) Sa se afle ambele puncte de intersectie apeland procedura Newton 
%   pentru datele ? = 10?6  ?si x(0) ales in vecinatatea punctelor de 
%   intersectie
% e) Sa se construiasca pe graficul curbelor punctele de intersectie.
% f) Sa se adapteze programul Newton astfel incat matricea Jacobian va fi 
%   calculata aproximativ folosind diferente finite. Sa se recalculeze 
%   solutia apeland noua procedura.
%==========================================================================

syms x y;

nec = [x,y];

Ec = [x^2+y^2-4; x^2/8-y];      % Matricea cu ecuatiile sistemului

%- Punctul a)

Jacobo = jacobian(Ec,nec);      % Jacobianul sistemului

%- Punctul b) 

syms C1(x,y) C2(x,y);
C1(x,y) = x^2 + y^2 - 4;        % Curba C1
C2(x,y) = x^2/8 - y;            % Curba C2

figure(1);
grid on; 
hold on;
ez1 = ezplot(C1, [-3,3]);       % Graficul curbei C1
hold on ;
ez2 = ezplot(C2,[-3,3]);        % Graficul curbei C2
set(ez1,'color',[1 0 0])
hold on;
legend('Curba C1', 'Curba C2')  % Legenda
hold on;

%- Punctul d)

J = matlabFunction(Jacobo,'Vars',{[x,y]});
Ec = matlabFunction(Ec,'Vars',{nec});

[xaprox] = MetNewton(Ec,J,[-2 -1]',1e-6);       % aplicam metoda newton
disp(xaprox);                        % pentru a afla punctele de intesectie



%%
%==========================================================================
% EX.2: Fie urmatorul sistem de ecuatii neliniare:
% {x1^2 -10*x1 + x2^2 + 8 = 0 
% {x1*x2^2 + x1 - 10*x2 + 8 = 0
%
% (x, y) ? [0, 5] � [0, 5]. Raman valabile punctele de la ex.1 . 
%==========================================================================

syms x1 x2;

nec = [x1,x2];

Ec = [x1^2-10*x1+x2^2+8; x1*x2^2+x1-10*x2+8];   % Matricea cu ecuatiile 
                                                        %sistemului

%- Punctul a)

Jacobo = jacobian(Ec,nec);                       % Jacobianul sistemului

%- Punctul b) 

syms C1(x1,x2) C2(x1,x2);
C1(x1,x2) = x1^2-10*x1+x2^2+8;           % Curba C1
C2(x1,x2) = x1*x2^2+x1-10*x2+8;          % Curba C2

figure(2);
grid on; 
hold on;
ez1 = ezplot(C1, [0,5]);                % Graficul curbei C1
hold on ;
ez2 = ezplot(C2,[0,5]);                 % Graficul curbei C2
set(ez1,'color',[1 0 0])
hold on;
legend('Curba C1', 'Curba C2')          % Legenda
hold on;

%- Punctul d)

J = matlabFunction(Jacobo,'Vars',{[x1,x2]});
Ec = matlabFunction(Ec,'Vars',{nec});

[xaprox] = MetNewton(Ec,J,[-2 -1]',1e-6);       % aplicam metoda newton
disp(xaprox);                       % pentru a afla punctele de intesectie

