% Lina Cristian 343 - Tema7
% 1. 10
% 2. 10
% 3. - 
% 4. 8 -> pune si tu eroarea in alta figura
% Total: 28/40 i.e. 7/10
%% Exercitiul 1 a)
clear all;
syms x; syms y; 
f = x.^2 + y.^2 - 4;
g = x.^2/8 - y;
[jac] = jacobian([f g],[x y]);
disp(jac);

%% b)

syms x; syms y;
f = x.^2 + y.^2 - 4;
g = x.^2/8 - y;
figure(1);
e = ezplot(f,[-3,3,-3,3]); 
set(e, 'Color', 'black' );
hold on 
ezplot(g,[-3,3,-3,3]);
legend("f", "g");

%% d) + e)
% ca sa se vada punctele pe graficul curbelor, trebuie rulat
% punctul b inainte
syms x y;
f = x.^2 + y.^2 - 4;
g = x.^2/8 - y;
F = matlabFunction([f;g], 'Vars', {[x y]});
jac = matlabFunction(jacobian([f g],[x y]),'Vars',{[x,y]});
epsilon = 10^(-6);
[xaprox, N] = MetNewton(F, jac, [-2;-1], epsilon);
plot(xaprox(1),xaprox(2),'*b');
disp(N);
hold on;
[xaprox, N] = MetNewton(F, jac, [1;2], 10.^(-6)); 
plot(xaprox(1),xaprox(2),'*r');
disp(N);
legend("f", "g", "pct. int 1", "pct. int 2");

%% f)

f = @(x,y) x^2 + y^2 - 4;
g = @(x,y) x^2/8 - y;
epsilon = 10^(-6);
[xaprox,~] = MetNewtonDifFin(f,g,[-2;-1],epsilon);
plot(xaprox(1),xaprox(2),'or');
hold on;
[xaprox,~] = MetNewtonDifFin(f, g, [1;2],epsilon); 
plot(xaprox(1),xaprox(2),'ob');
legend("f", "g", "pct. int 1", "pct. int 2","dif fin 1","dif fin 2");

%% Exercitiul 2 a)
clear all;
syms x1; syms x2; 
f = x1.^2 - 10*x1 + x2.^2 + 8; 
g = x1*x2.^2 + x1 - 10*x2 + 8;
[jac] = jacobian([f g],[x1 x2]);
disp(jac);

%% b) 

syms x1; syms x2; 
f = x1.^2 - 10*x1 + x2.^2 + 8; 
g = x1*x2.^2 + x1 - 10*x2 + 8;
figure(2);
e = ezplot(f,[-5,5,-5,5]); 
set(e, 'Color', 'black' );
hold on 
ez2 = ezplot(g,[-5,5,-5,5]);
legend("f","g");

%% d) + e)
%trebuie rulat b) inainte
syms x1; syms x2; 
f = x1.^2 - 10*x1 + x2.^2 + 8; 
g = x1*x2.^2 + x1 - 10*x2 + 8;
F = matlabFunction([f;g], 'Vars', {[x1 x2]});
jac = matlabFunction(jacobian([f g],[x1 x2]),'Vars',{[x1 x2]});
epsilon = 10^(-6);
[xaprox, N] = MetNewton(F, jac, [0;1], epsilon);
plot(xaprox(1),xaprox(2),'*b');
disp(N);
hold on;
[xaprox, N] = MetNewton(F, jac, [2;3], 10.^(-6)); 
disp(N);
plot(xaprox(1),xaprox(2),'*r');
legend("f", "g", "pct. int 1", "pct. int 2");

%% f)

f = @(x1,x2) x1.^2 - 10*x1 + x2.^2 + 8;
g = @(x1,x2) x1*x2.^2 + x1 - 10*x2 + 8;
epsilon = 10^(-6);
[xaprox,N] = MetNewtonDifFin(f,g,[0;1],epsilon);
plot(xaprox(1),xaprox(2),'or');
disp(N);
hold on;
[xaprox,N] = MetNewtonDifFin(f, g, [2;3],epsilon); 
plot(xaprox(1),xaprox(2),'ob');
disp(N);
legend("f", "g", "pct. int 1", "pct. int 2","dif fin 1","dif fin 2");

%% Exercitiul 4 b) + c) -
% trebuie full screen la grafic pentru a se vedea mai bine culorile
f = @(x) sin(x); 
a = -pi/2; b = pi/2; n = 3;
X = linspace(a,b,n+1); Y = f(X);
figure(3);
plot(X, Y, '--*r'); 
hold on;
W = linspace(a,b,100);
for i = 1:length(W)    
    Z(i) = MetDirecta(X,Y,W(i));
    T(i) = MetLagrange(X,Y,W(i));
    S(i) = MetNew(X,Y,W(i));
end
plot(W,Z,'*b');
plot(W,T,'og');
plot(W,S,'y'); 
% eroarea
plot(W, abs(f(W)-Z), '*r');
plot(W, abs(f(W)-T), 'oblack');
plot(W, abs(f(W)-S), 'c'); 
legend("Xi Yi","f directa","f lagrange","f newton","er directa","er lagrange","er newton");

%% Functii
% la functii chiar m-a batut rau, am mai luat de la colegi, 
% daca imi scazi pentru asta nu am sa comentez, multumesc!)

% gauss luata din tema2
function [x] = GaussPivTot(a,b)
    % concatenam coloana b la matricea a (mat. extinsa)
    ae = [a, b];
    % nr de linii a matricei
    n = length(b);
    % formam vectorul de indexi
    index = ones(n,1);
    for i = 1:n
       index(i) = i; 
    end
    % implementarea propriu-zisa a algoritmului descris in curs
    for k = 1 : n-1
       % maxim va avea ca valoare initiala minimul din submatrice         
       maxim = min(min(abs(ae(k:n,:))))-1;
       ind1 = 0; ind2 = 0;
       % cautam in submatrice
       for p = k : n
           for m = k : n
               % daca gasim o valoare mai mare ca max, il actualizam
               if(abs(ae(p,m)) > maxim)
                   maxim = abs(ae(p,m));
                   ind1 = p; ind2 = m;
               end
           end          
       end
       if(ae(ind1,ind2) == 0)
           disp('Sistem incop. sau sistem comp. nedet.');
           break;
       end
       if(ind1 ~= k)
%          % interschimbam liniile
           ae([k,ind1],:) = ae([ind1,k],:);
       end
       if(ind2 ~= k)
           % interschimbam coloanele; actualizam vec de indexi
           ae(:,[k,ind2]) = ae(:,[ind2,k]);
           ind = index(ind2);
           index(ind2) = index(k); index(k) = ind;
       end
       for l = k + 1 : n
          if(ae(l,k) ~= 0)
            m = ae(l,k)/ae(k,k);
            ae(l,:) = ae(l,:) - m*ae(k,:); 
          end          
       end
    end
    if(ae(n,n) == 0)
       disp('Sistem incop. sau sistem comp. nedet.');
    end
    [y] = SubsDesc(ae(:,1:n),ae(:,n+1));
    % ordonam rezultatul dupa vectorul de indexi
    x = zeros(length(y),1);
    for i = 1:length(y)
       x(index(i)) = y(i);
    end
end

function [x] = SubsDesc(a,b)
    % avem matricea superior triunghiulara a cu solutiile b
    n = length(a);
    x = zeros(n,1);
    % calculam xn
    x(n) = 1/a(n,n)*b(n);
    k = n - 1;
    % continua algoritmul ca cel descris in curs
    while(k>0)
       sum = 0;
       for j = k+1 : n
           sum = sum + a(k,j)*x(j);
       end
       x(k) = 1/a(k,k)*(b(k)-sum);
       k = k - 1;
    end
end

function [P] = MetDirecta(X,Y,x)   
    n = length(X) - 1;    
    for i = 1:n+1      
        for j =1:n+1     
            A(i,j) = X(i).^(j-1);   
        end
    end
    [xaprox] = GaussPivTot(A,Y');
    P = 0;
    for i = 1:n+1    
        P = P + xaprox(i)*x.^(i-1);  
    end
end

function [P] = MetLagrange(X, Y, x)    
    n = length(X) - 1;
    P = 0;    
    for k = 1:n+1       
        L = 1; 
        for j = 1:n+1        
            if(j ~= k)  
                L = L*(x - X(j))/(X(k) - X(j));     
            end
        end
        P = P + L*Y(k);
    end
end

function [P] = MetNew(X,Y,x)
    n = length(X) - 1;
    a(1) = Y(1);  
    for i = 2:n+1  
        s = a(1);     
        for j = 2:i-1        
            p = 1;        
            for k = 1:j-1            
                p = p * (X(i)-X(k));    
            end
            s = s + a(j)*p;     
        end        
        p = 1;    
        for k = 1:i-1      
            p = p * (X(i)-X(k));    
        end
        a(i) = (Y(i) - s)/p;  
    end    
    P = a(1);   
    for i=2:n+1  
        p = 1;   
        for j = 1:i-1       
            p = p*(x-X(j));   
        end
        P = P + a(i)*p;  
    end
end


function [xk,k] = MetNewtonDifFin(f,g,x0,epsilon) 
    k = 1;    
    x(:,1) = x0; h = 0.1; ok = 1;
    while(ok == 1)     
        k = k + 1;              
        J = [(f(x(1,k-1)+h,x(2,k-1)) - f(x(1,k-1),x(2,k-1)))/h (f(x(1,k-1),x(2,k-1)+h)-f(x(1,k-1),x(2,k-1)))/h ;...    
            (g(x(1,k-1)+h,x(2,k-1)) - g(x(1,k-1),x(2,k-1)))/h (g(x(1,k-1),x(2,k-1)+h)-g(x(1,k-1),x(2,k-1)))/h];   
        F = [f(x(1,k-1),x(2,k-1)) ; g(x(1,k-1),x(2,k-1))];
        z(:,k) = transpose(GaussPivTot(J,-F));       
        x(:,k) = z(:,k)+x(:,k-1);       
        if(norm(z(:,k),Inf) < epsilon)
            ok = 0;    
        end
    end
    xk = x(:,k);
end

function [x0,k] = MetNewton(F,J,x0,epsilon)
    k = 0; ok = 1;
    while(ok == 1)
        k = k + 1;
        xk = J(x0')\(-F(x0'));
        x0 = x0 + xk;
        if(norm(xk,Inf) < epsilon)
            ok = 0;
        end
    end
end

