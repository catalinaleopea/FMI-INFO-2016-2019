% Tema 4 - Caluian Iulian 343 - CN - 2018

% 1. 10
% 2. 10
% 3. -
% 4. 8
% Total> 28/40 i.e. 7/10

%% Exercitiul 1:

syms f(x,y)
f1(x,y) = (x)^2 + (y)^2 -4; % ecuatia sistemului
f2(x,y) = (((x)^2) / 8)  - (y);

syms x y;
jac = jacobian ([f1 ; f2] , [x y]);
disp(jac);

figure;
ezplot(f1 );
hold on;
ezplot(f2 );
epsi = 10^(-6);

[xaprox, N] = Newton([f1;f2],jac,[-2;0.5],epsi);
disp(xaprox);

hold on;
plot(xaprox(1),xaprox(2),'r*');
[xaprox, N] = Newton([f1;f2],jac,[2;0.5],epsi);
disp(xaprox);
plot(xaprox(1),xaprox(2),'r*');

% [xaprox, N] = Newton2([f1;f2],[-2;0.5],epsi);
% disp(xaprox);


%% Exercitiul 2:

syms f(x,y)
f1(x,y) = (x)^2 -10*(x) + (y)^2 + 8; % ecuatia sistemului
f2(x,y) = (x*(y)^2) + (x) - 10*(y) + 8;

syms x y;
jac = jacobian ([f1 ; f2] , [x y]);
disp(jac);

figure;
ezplot(f1 );
hold on;
ezplot(f2 );
epsi = 10^(-6);

[xaprox, N] = Newton([f1;f2],jac,[1;1],epsi);
disp(xaprox);
xlim([0 5]);
ylim([0 5]);
hold on;
plot(xaprox(1),xaprox(2),'r*');
[xaprox, N] = Newton([f1;f2],jac,[2.2;3],epsi);
disp(xaprox);
plot(xaprox(1),xaprox(2),'r*');

% [xaprox, N] = Newton2([f1;f2],[-2;0.5],epsi);
% disp(xaprox);



%% Ex. 4
%
% Eroarea, stabilitatea? 

a = -pi/2;
b = pi/2;
n = 4;
x = linspace(a,b,n);
y = sin(x);
plot(x,y)
p = MetDirecta(x,y);
p = fliplr(p');
fx = linspace(a,b,100); % discretizare cu 100 noduri
fy = sin(fx);
px = polyval(p,fx); %  valorile polinomului determinat
plot(fx,fy);
hold on;
plot (fx,px);

%Met lagrange:
p = MetLagrange(x,y,x);
p = fliplr(p');
pxL = polyval(p,fx);

% pxL = linspace(a,b,100);
plot (fx,pxL);





%% Partea cu functii

function [xaprox,N] = Newton(F,J,x0,epsi) 
k = 0;
x = x0;
while (1)
    k = k+1;

    jac = J(x(1), x(2));
    minusF = (-1)*F(x(1), x(2));

    z = GaussPivTot(jac,minusF);
    x = x + z;
    
    norma = normap(z,1);
    if(norma < epsi) 
        break;
    end
    
    disp("Mai fac o iteratie");
end
xaprox = x;
N = k;
end


function [xaprox,N] = Newton2(F,x0,epsi) 
k = 0;
x = x0;
while (1)
    k = k+1;

    %jac = J(x(1), x(2));
    jac = zeros(2);
    e = eye(2);
    h = 0.034;
    f = formula(F);
    for i = 1:2
        for j= 1:2 
            fi = f(i);
            fi
            jac(i,j) =( fi(x(1) + h*e(1,j) ,x(2) + h*e(2,j)) - fi(x(1),x(2)) ) / h;
        end
    end
    
    
    minusF = (-1)*F(x(1), x(2));

    z = GaussPivTot(jac,minusF);
    x = x + z;
    
    norma = normap(z,1);
    if(norma < epsi) 
        break;
    end
    
    disp("Mai fac o iteratie");
end
xaprox = x;
N = k;
end


function [norma] = normap(Z,p)
    % Putem calcula doar norma 1 sau infinit cu aceasta functie.
if p == 1
    norma = sum(abs(Z));
elseif p== -1
    norma = max(abs(Z));
else
    disp('Invalid p');
    norma = 0;
end
end


function [x] = GaussPivTot(A,b)
%SUBSDESC Summary of this function goes here
%   Detailed explanation goes here

[~,n] = size(A);

AB = [A b(:)]; %AB este matricea extinsa.

for k = 1:(n-1)
    
    %caut p a.i. AB(p,k) sa aiba valoarea absoluta cea mai mare.
    maxim = -1;
    p = k;
    q = k;
    for i = k:n
        for j = k:n
            if maxim < abs(AB(i,j))
               maxim = abs(AB(i,j));
               p = i;
               q = j;
            end
        end
    end

    if maxim == -1
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        disp('Sistemul nu este compatibil, sau compatibil nedeterm');
        break;
    else
       % am gasit deja p-ul si q-ul
        
        
        % swap linii:
        line = AB( k, 1:(n+1));
        AB(k, 1:(n+1)) = AB(p, 1:(n+1));
        AB(p, 1:(n+1)) = line;
        
        coloana  = AB( 1:n , k);
        AB(1:n, k ) = AB( 1:n, q);
        AB(1:n, q) = coloana;
    
        for p = (k+1):n 
            %update restul liniilor pentru a face apk sa fie 0
            mpk = AB(p,k) / AB(k,k);
            AB(p, 1:(n+1)) = AB(p, 1:(n+1)) - mpk*AB(k,1:(n+1));
        end
    end
    
end

if AB(n,n) == 0
        %daca nu exista nenule inseamna ca akk va fi 0 -> incompatibil 
        disp('Sistemul nu este compatibil, sau compatibil nedeterm');
end

%extrag componentele pentru a rezolva cu metoda substitutiei.
AB(1:n,1:n)
x = SubsDesc(AB(1:n,1:n),AB(1:n,n+1));


end

function [x] = SubsDesc(A,b)
%SUBSDESC Summary of this function goes here
%   Metoda substitutiei descendente:

[~,n] = size(A);
x = zeros(n,1);
x(n) = b(n)/A(n,n); % calculam x(n)

for i = (n-1):-1:1
    ac = A(i,(i+1):n);
    ac = ac(:); 
    % iau coef lui x(i+1)..x(n) in ac
    x(i) = 1 / A(i,i) * (b(i) - sum( ac .* x((i+1):n) ));
    % calculam pe rand x(i) 
    % cu formula din curs avand deja calculate x(i+1)..x(n)
end

end




%% Functii polinoame etc.

function [y] = MetDirecta(X,Y)
X = X(:);
n = size(X,1);
B = zeros(n);

for i = 1: n
    B(:,i) = X .^ (i-1);
end
y = GaussPivTot(B,Y);


end

function y=MetLagrange(X,Y,x)
n=size(X,2);
B=ones(n,size(x,2));

for i=1:n
  for j=1:n
     if (i~=j)
        B(i,:)=B(i,:).*(x-X(j))/(X(i)-X(j));
     end
  end
end

y=0;
for i=1:n
  y=y+Y(i)*B(i,:);
end

end

