%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMA 7                                                                  %
% - Madalina Pietreanu, grupa 343                                         %
% - acest fisier reprezinta implementarile anumitor exercitii din tema 7  % 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all;
clear all;
% aceste date vor ajuta in rezolvarea tuturor subpunctelor
syms x y
f1 = x.^2 + y.^2 - 4;
f2 = x.^2/8 - y;
F = [f1; f2];
nec = [x, y];

% a)
J = jacobian(F, nec);

% b)
figure(1);
fimplicit(f1, [-3 3 -3 3]);
hold on;
fimplicit(f2, [-3 3 -3 3]);
% hold off;

% c)
% folosesc jacobianul calculat anterior, dar le transform in 
% matbabFunction ca sa pot face calcule mai simplu
% explicatii despre implementare se gasesc in fisierul function MetNewton.m
J = matlabFunction(J, 'Vars', {nec});
F = matlabFunction(F, 'Vars', {nec});
x0 = [-2 -1]';
eps = 10^(-6);

% MetNewton nu 4 argumente de intrare. Mai multa atentie, te rog!
[xaprox, N] = MetNewton(F, J, x0, eps);

% d)
% pt ca aceasta metoda merge numai cand exista o singura solutie, ca sa
% gasesc doua puncte, impart intervalul in doua bucati, astfel incat
% intr-unul sa se gaseasca un singur punct de intersectie (pcti); astfel, 
% voi alege cate un punct in vecinatatea fiecarui pcti pentru fiecare
% bucata
x0_1 = [1 2]';
[xaprox1, N1] = MetNewton(F, J, x0, eps);
[xaprox2, N2] = MetNewton(F, J, x0_1, eps);

% e)
% plotez primul punct
scatter(xaprox1(1), xaprox1(2));
hold on;
% plotez al doilea punct
scatter(xaprox2(1), xaprox2(2));
hold off;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% aceleasi cerinte ca la 1, alta functie
close all;
clear all;
syms x y
f1 = x.^2 - 10*x + y.^2 + 8;
f2 = x * y.^2 + x - 10 * y + 8;
F = [f1; f2];
nec = [x, y];

% a)
J = jacobian(F, nec);

% b)
figure(1);
fimplicit(f1, [0 5 0 5]);
hold on;
fimplicit(f2, [0 5 0 5]);
% hold off;

% d)
x0 = [2 2]';
x0_1 = [1 2]';
eps = 10^(-6);
[xaprox1, N1] = Newton(F, J, x0, eps);
[xaprox2, N2] = Newton(F, J, x0_1, eps);

% e)
scatter(xaprox1(1), xaprox1(2));
hold on;
scatter(xaprox2(1), xaprox2(2));
hold off;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
% a)
% date necesare rularii functiilor

f = @(x) sin(x);
n = 3;
a = -pi/2;
b = pi/2;

% % exemplul din curs; l-am folosit sa ma asigur ca am implementat bine
% f = @(x) exp(2*x);
% n = 2;
% a = -1;
% b = 1;

X = linspace(a,b,n + 1);
Y = f(X);

y1 = MetDirecta(X,Y,n);
% polinomul obtinut prin metoda directa
P_MetDir = @(x) y1(1) + y1(2)*x + y1(3)*(x.^2) + y1(4)*(x.^3);

%y2 = MetNewton(X,Y,n);

% b)
% utilizez datele de la punctul anterior (functia, intervalul)
% pentru Metoda Directa
A = linspace(a,b);
figure(1);
title('MetDirecta');
plot(A, f(A), '-b');
hold on;
plot(A, P_MetDir(A),'-r');
hold off;
E_MetDir = @(x) abs(f(x) - P_MetDir(x));
figure(2);
title('Eroare MetDirecta');
plot(A,E_MetDir(A),'--g');

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% functii %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% aceasta functie a fost implementata la laborator
function [x0, N] = Newton(F, J, x0, epsilon)
    k = 0;
    cond = 1;
    while(cond)
        k = k + 1;
        zk = J(x0') \ (-F(x0'));
        zk
        x0 = x0 + zk;
       if(norm(zk, Inf) < epsilon)
          cond = 0; 
       end
       N = k;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA DIRECTA                                                          %
% - aceasta functie calculeaza coeficientii polinomului Lagrange de grad  %
%           n conform metodei directe prezentate in cursul 7              %
% - INPUT:  X - multimea nodurilor de interpolare, |X| = n+1              %
%           Y - multimea punctelor yi, unde yi = f(xi), i = 1...n+1       %
%           x - gradul polinomului                                        %
% - OUTPUT: a - coeficientii (a1,a2,...,an+1) ai polinomului Lagrange,    %
%               unde P(n) = a1 + a2*x + a3*x^2 + an+1*x^n                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [a] = MetDirecta(X,Y,x)
    
    %A(i:1:x+1 ,j:1:x+1) = X(i).^(j-1); % nu mi-a iesit :(
    
    % formez matricea conform metodei din curs
    % pe fiecare linie i, fiecare nod xi va fi ridicaat la puterea
    % indicelui coloanei
    for i = 1 : x+1
        for j = 1 : x+1
            A(i,j) = X(i).^(j-1);
        end
    end
    A
    % rezolv sistemul Ax = Y folosind metoda Gauss cu pivotare totala
    a = GaussPivTot(A,Y);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA NEWTON                                                           %
% - aceasta functie calculeaza coeficientii polinomului Lagrange de grad  %
%           n conform metodei newton prezentate in cursul 7               %
% - INPUT:  X - multimea nodurilor de interpolare, |X| = n+1              %
%           Y - multimea punctelor yi, unde yi = f(xi), i = 1...n+1       %
%           x - gradul polinomului                                        %
% - OUTPUT: a - coeficientii (a1,a2,...,an+1) ai polinomului Lagrange,    %
%               unde P(n) = c1 + c2*(x?x1) + c3*(x?x1)*(x?x2) + . . . +  %
%               cn+1*(x?x1)*(x?x2)*. . .*(x?xn)                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [a] = MetNewton(X,Y,x)
    
    % initializez matricea cu 1 pt a face calcule
    A = ones(x+1);
    
    % construiesc matricea care ma va ajuta sa gasesc coeficintii c 
    % conform metodei din curs
    % fiindca pe prima coloana am deja 1, incep cu a doua pozitie calculul
    % pe fiecare linie
    % forma generala: c1 + c2(xn+1 ? x1) + c3(xn+1 ? x1)(xn+1 ? x2) +...+
    % +...+ cn+1(xn+1 ? x1)...(xn+1 ? xn)
    for i = 1 : x + 1
        for j = 2 : i
            for k = 1 : j - 1
                A(i,j) = A(i,j) * (X(i)-X(k));
            end
        end
    end
    A
    
    c = SubsAsc(A,Y); % am aflat c-urile din formula polinomului din curs
                      % acum vreau sa obtin si coeficientii polinomului
                      
    % to be continued; de aici ma bate; ar trebui sa caut o forma generala
    % a coeficientilor polinomului in functie de c (cu inductie sau ceva
    % de genul)
        
end

% algoritm implementat de mine la tema 2
function [x] = SubsDesc(A,b)
    
    n = length(A);  % aflu dimensiunea matricii
    
    if (A(n,n) == 0)
        disp('Sistemul nu este compatibil determinat');
        x = -1;
        return;
    end
    
    x(n) = (1 ./ A(n,n)) .* b(n); % solutia de pe ultima linie
    k = n - 1;
    
    while k >= 1
        % introduc in ecuatie necunoscutele aflate deja si le inmultesc cu
        % scalarii corespunzatori lor      
        aux = 0;
        for i = k + 1 : n
            aux = aux + (A(k,i) .* x(i));
        end
        
        % acum aflu x-ul de la pasul curent folosindu-ma de aux
        x(k) = (1 ./ A(k,k)) .* (b(k) - aux);
        
        k = k - 1;
    end
    
    disp('Solutia sistemului: ');
    disp(x);
    
end

% urmatorii 2 algoritmi nu imi apartin; sunt implementati de Ioana Ionita
% de la grupa 343; i-am folosit aici pentru ca eu nu am implementat
% SubsAsc si pentru ca GaussPivTot facut de mine nu era bine implementat;
% am vrut sa ma concentrez pe tema asta, de aceea m-am gandit sa iau de
% la cineva (din ce ne-ai dat pe Drive) ceva ce stiu ca e deja bine facut;
function [x] = SubsAsc(A, b)
    n = length(b);  
    x(1) = b(1)/A(1, 1);        %plec de la prima ecuatie, unde singura 
                                %necunoscuta este x(1)
    k = 2;                      
    while k<=n                  %calculez treptat necunoscutele de sus in jos
        sum = 0;                %pot calcula aceasta suma, stiind x1,...xk-1
        for j = 1:k-1           
            sum = sum + A(k,j)*x(j);
        end 
        x(k) = 1/A(k, k)*(b(k)-sum); %scazand suma, am iar o ecuatie cu o     
        k = k+1;                     %singura necunoscuta si trebuie doar sa 
    end                              %impart la coeficientul A(k, k) pentru a-l
                                     %afla pe xk
                                  
    disp('Solutia sistemului: ');
    disp(x);
    
end
function [x] = GaussPivTot( A, b )
C = [A b'];                  %matricea extinsa a sistemului
n = length(b);              %numarul ecuatiilor sistemului
index = 1:n;                
for k = 1:n-1 
    maxim = abs(C(k, k));        %initializez maximul 
    p = k;                  %indicele de pe coloana unde se afla maximul
    m = k;
    for j = k:n
        for r = k:n
            if abs(C(j, r))> maxim   %compar cu maximul curent
                maxim = abs(C(j, r)); %caut maximul in submatrice
                p = j;
                m = r;
            end
        end
    end
    if maxim == 0           %nu exista C(p, m) diferit de 0
        disp('Sist. incomp. sau sist. comp. nedet.');
        break;
    end
    if p ~= k               %efectuez interschimbarea liniilor p si k
        aux = C(p, :);
        C(p, :) = C(k, :);
        C(k, :) = aux;
    end
    if m ~=k                %efectuez interschimbarea coloanelor m si k
        aux = C(:, m);
        C(:, m) = C(:, k);
        C(:, k) = aux;
        y = index(m);       %retin ca trebuie schimbati si indecsii 
        index(m) = index(k);
        index(k) = y;
    end
    for l = k+1:n           %din linia l scad m(l, k)*linia k pentru a face
                            %zerouri
        C(l,:) = C(l,:) - C(l,k)/C(k,k)*C(k,:);
    end
end
if C(n, n) == 0
    disp('Sistem incomp. sau sist. comp. nedet.');
    x = -1;
    return
end
y = SubsDesc(C(1:n, 1:n), C(1:n, n+1));
for i=1:n                   %necunoscutele sunt returnate in y, dar in
                            %ordinea din index
    x(index(i)) = y(i);
end
end