% am implementat algoritmul de determinare a polinomului lagrange Pn prin
% metoda directa urmarind metoda din cursul 7 pag.11-12.Metoda primeste ca
% date de intrare un interval in X si in Y rezultatul functiei studiate in
% punctele din X, in x primeste necunoscuta polinomului
function y = MetN(X, Y, x)
    n = length(X); % pastram lungimea 
    A = zeros(n, n); % prealocam A
    A(:, 1) = 1; % initialziam prima coloana
    
    for i = 2:n
        for j = 2:i
            % formam matricea inferior triunghiulara conform algoritmului
            A(i, j) = prod(X(i) * ones(j - 1, 1) - X(1:(j - 1)));
        end
    end
    % calculez coef astfel incat A * coef = Y
    coef = SubsAsc(A, Y);
    
    y = coef(1);
    for i = 2:n
        % formam polinomul in y
        y = y + coef(i) * prod(x * ones(i - 1, 1) - X(1:(i - 1)));
    end
end