% am implementat algoritmul de determinare a polinomului lagrange Pn prin
% metoda directa urmarind metoda din cursul 7 pag.3-7.Metoda primeste ca
% date de intrare un interval in X si in Y rezultatul functiei studiate in
% punctele din X, in x primeste necunoscuta polinomului.Ca date de iesire
% va avea polinomul rezultat y
function y = MetDirecta(X,Y,x)
    n = length(X); % pastram lungimea 
    A = zeros(n, n); % prealocam A
    for i = 1:n
        A(:, i) = X .^ (i - 1); % creem matricea A folosind valorile din X
    end
    b = Y; % solutia este Y
    
    % Rezolv ecuatia A * (a) = b, unde a sunt indicii polinomului
    a = GaussPivTot(A, b);
    
    y = 0;
    for i=1:n
        y = y + a(i) * x .^ (i - 1); % formam polinomul in y
    end
end