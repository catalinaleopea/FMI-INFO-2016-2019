% am implementat algoritmul de determinare a polinomului lagrange Pn prin
% metoda directa urmarind metoda din cursul 7 pag.8-9.Metoda primeste ca
% date de intrare un interval in X si in Y rezultatul functiei studiate in
% punctele din X, in x primeste necunoscuta polinomului.Ca date de iesire
% va avea polinomul rezultat y
function y = MetLagrange(X, Y, x)
    n = length(X); % pastram lungimea 
    y = 0;
    for k = 1:n
        % formam primul termen din diferentele de x conform algoritmului
        restul = X(1:(k - 1));
        if k < n % cat timp nu a ajuns la ultimul termen
            % pastram diferenta curenta 
            restul = [restul; X((k + 1):n)];
        end
        % adaugam diferenta curenta la produsul deimpartitului
        top = prod(x * ones(n - 1, 1) - restul);
        % adaugam diferenta curenta la produsul impartitorului
        bottom = prod(X(k) * ones(n - 1, 1) - restul);
        L = top / bottom; % calculam L la pasul curent
        % adaugam rezultatul de la pasul curent la y conform algoritmului
        y = y + L * Y(k);
    end
end