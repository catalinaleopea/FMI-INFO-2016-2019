% procedura Newton
function [x0,N] = Newton(F,J,x0,epsilon)
    N = 0; ok = 1;
    while(ok)
        N = N + 1;
        zk = J(x0')\(-F(x0'));
        x0 = x0 + zk;
        if norm(zk,Inf) < epsilon
            ok = 0;
        end
    end
end