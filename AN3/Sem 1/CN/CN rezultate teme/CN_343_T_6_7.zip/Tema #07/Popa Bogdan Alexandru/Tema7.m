% Tema7
% Total: 30/40 + bonus 2p = 32/40 i.e. 8/10

%Ex 1
syms x y;
% pastram functiile din sistemul din enunt
C1 = x.^2 + y.^2 - 4;
C2 = x.^2/8 - y;

J = jacobian([C1,C2],[x,y]) % calculam jacobianul simbolic

figure(1); % initiem figura
title('C1 = x^2 + y^2 - 4 C2 = (x^2)/8 - y')
fimplicit(C1,[-3,3,-3,3]); % formam graficul primei ecuatii
hold on;
fimplicit(C2,[-3,3,-3,3]); % formam graficul celei dea doua ecuatie

syms x y
nec = [x, y]; % pastram un vector cu termenii simbolici
F = [C1;C2]; % pastram un vector cu cele 2 ecuatii din sistem
% creem in J o functie ce calculeaza jacobianul lui F
J = matlabFunction(jacobian(F,nec),'Vars',{nec});
F = matlabFunction(F,'Vars',{nec}); % pastram in F functia data de sistem
epsilon = 10^(-6); % eroarea
x0 = [-2 -1]; % primul interval
x02 = [1 2]; % al doilea interval
% calculam cele 2 aproximari ale lui x
[xaprox,N] = Newton(F,J,x0',epsilon) 
[xaprox1,N1] = Newton(F,J,x02',epsilon)

% afisam in grafic cele 2 puncte obtinute
scatter(xaprox(1), xaprox(2));
scatter(xaprox1(1), xaprox1(2));
legend('C1','C2','xaprox','xaprox1')
hold off

%Ex 2
syms x1 x2;
% pastram functiile din sistemul din enunt
C3 = x1.^2 - 10.*x1 + x2.^2 + 8;
C4 = x1.*x2.^2 - 10.*x2 + 8;


J1 = jacobian([C3,C4],[x1,x2]) % calculam jacobianul simbolic

figure(2); % initiem figura
title('C3 = x1^2 - 10*x1 + x2^2 + 8 C4 = x1*x2^2 - 10*x2 + 8')
fimplicit(C3,[0,5,0,5]); % formam graficul primei ecuatii
hold on;
fimplicit(C4,[0,5,0,5]); % formam graficul celei dea doua ecuatie

syms x1 x2
nec1 = [x1, x2]; % pastram un vector cu termenii simbolici
F1 = [C3;C4]; % pastram un vector cu cele 2 ecuatii din sistem
% creem in J o functie ce calculeaza jacobianul lui F
J1 = matlabFunction(jacobian(F1,nec1),'Vars',{nec1});
% pastram in F functia data de sistem
F1 = matlabFunction(F1,'Vars',{nec1});
epsilon = 10^(-6); % eroarea
x03 = [0 1]; % primul interval
x04 = [2 3]; % al doilea interval
% calculam cele 2 aproximari ale lui x
[xaprox2,N2] = Newton(F1,J1,x03',epsilon)
[xaprox3,N3] = Newton(F1,J1,x04',epsilon)

% afisam in grafic cele 2 puncte obtinute
scatter(xaprox2(1), xaprox2(2));
scatter(xaprox3(1), xaprox3(2));
legend('C3','C4','xaprox2','xaprox3')
hold off

% Ex 3
f = inline('sin(x)','x'); % formam functia sin(x)
a = -pi / 2; b = pi / 2; % intervalul pe care este definita functia
n = 2; % gradul polinomului
x_grafic = linspace(a,b,3); % intervalul din enunt
x_calcul = linspace(a,b,n+1)'; % diviziunea functiei
y_calcul = f(x_calcul); % valoarea functiei in punctele din x_calcul

for i = 1:3 % pastram si afisam pentru fiecare metoda rezultatul obtinut
    metDir = MetDirecta(x_calcul,y_calcul,x_grafic(i))
    metLag = MetLagrange(x_calcul,y_calcul,x_grafic(i))
    metNew = MetN(x_calcul,y_calcul,x_grafic(i))
end

% pastram si afisam erorile obtinute pentru fiecare metoda
e_2_d = abs(MetDirecta(x_calcul,y_calcul,pi/6) - f(pi/6))
e_2_l = abs(MetLagrange(x_calcul,y_calcul,pi/6) - f(pi/6))
e_2_n = abs(MetN(x_calcul,y_calcul,pi/6) - f(pi/6))


% Ex 4
% 1) rezolvarea se regaseste in fisierele MetDirecta.m,MetLagrange.m,MetN.m

f = inline('sin(x)','x'); % formam functia sin(x)
a = -pi / 2; b = pi / 2; % intervalul pe care este definita functia
n = 3; % n al polinomului conform cerintei

figure(3); % initiem figura

subplot(3, 1, 1); % includem graficul in figura
% apelam Display pentru a rezolva cerinta in cazul metodei directe
[x_dir, e_dir] = Display(n, a, b, f, @MetDirecta, "Metoda Directa");

subplot(3, 1, 2); % includem graficul in figura
% apelam Display pentru a rezolva cerinta in cazul metodei Lagrange
[x_lag, e_lag] = Display(n, a, b, f, @MetLagrange, "Metoda Lagrange");

subplot(3, 1, 3); % includem graficul in figura
% apelam Display pentru a rezolva cerinta in cazul metodei Newton
[x_n, e_n] = Display(n, a, b, f, @MetN, "Metoda Newton");


xlabel("x");
xlabel("y");

figure(4); % initiem figura

subplot(3, 1, 1); % includem graficul in figura
% realizam graficul erorii in metoda directa
plot(x_dir, e_dir, 'r-');
title("Metoda Directa");

subplot(3, 1, 2); % includem graficul in figura
% realizam graficul erorii in metoda lagrange
plot(x_lag, e_lag, 'r-');
title("Metoda Lagrange");

subplot(3, 1, 3); % includem graficul in figura
% realizam graficul erorii in metoda Newton
plot(x_n, e_n, 'r-');
title("Metoda Newton");

% n max pentru care Pn se aproprie de f e:
% 62 pentru Metoda Newton
% 66 pentru Metoda Lagrange
% 71 pentru Metoda Directa
