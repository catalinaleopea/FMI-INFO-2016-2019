% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 6
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

%%
% Ex. 1
syms x y
F1 = x.^2 +y.^2 -4;
F2 = (x.^2)/8 -y;
J = jacobian([F1,F2],[x,y]);

figure(1);
fimplicit(F1, [-3 3 -3 3],'-m');
hold on
fimplicit(F2, [-3 3 -3 3],'-b');
grid on

epsilon = 10^(-6);
F = [F1;F2];
Jac = matlabFunction(jacobian(F, [x, y]), 'Vars', {[x, y]});
F = matlabFunction(F, 'Vars', {[x, y]});
[xaprox1,N1] = MetNewton(F,Jac,[-2;-1],epsilon);
[xaprox2,N2] = MetNewton(F,Jac,[1;2],epsilon);

scatter(xaprox1(1),xaprox1(2),'or','filled');
hold on
scatter(xaprox2(1),xaprox2(2),'or','filled');
grid on
legend('Curba C1:x^2+y^2=4','Curba C2:y=x^2/8','puncte de intersectie');
%%

%%
% Ex 2
syms x1 x2
G1 = x1.^2 -10*x1 +x2.^2 +8;
G2 = x1*x2.^2 +x1 -10*x2 +8;

figure(2);
fimplicit(G1, [0 5 0 5],'-m');
hold on
fimplicit(G2, [0 5 0 5],'-b');
grid on

epsilon = 10^(-6);
G = [G1;G2];
Jac2 = matlabFunction(jacobian(G, [x1, x2]), 'Vars', {[x1, x2]});
G = matlabFunction(G, 'Vars', {[x1, x2]});
[xaprox12,N12] = MetNewton(G,Jac2,[0.75;1.25],epsilon);
[xaprox22,N22] = MetNewton(G,Jac2,[2;2.5],epsilon);

scatter(xaprox12(1),xaprox12(2),'or','filled');
hold on
scatter(xaprox22(1),xaprox22(2),'or','filled');
grid on
legend('Curba C1:x1^2 -10*x1 +x2^2 =-8','Curba C2:x1*x2^2 +x1 -10*x2 =-8','puncte de intersectie');
%%

%%
% Ex. 4. 2)
f = @(x) sin(x);
n = 3;
a = -pi/2;
b = pi/2;

figure(3);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=3');

% Ex. 4.3)
figure(4)
plot(abs(f(X)-t2));
legend('Eroarea flosind Metoda Directa');

% Ex. 4.4)
n = 4;
figure(5);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=4');

n = 5;
figure(6);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=5');

n = 6;
figure(7);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=6');

n = 7;
figure(8);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=7');

n = 8;
figure(9);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=8');

n = 9;
figure(10);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=9');

n = 10;
figure(11);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=10');

n = 11;
figure(12);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=11');

n = 500;
figure(13);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'--r');
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1);
Y = f(X);
t2 = MetDirecta(X,Y,z);
plot(X,t2,'--b');
legend('functia f(x)=sin(x)','polinomul obtinut prin Metoda directa');
title('Graficul functiei si polinomul pentru n=500');


% Este o greseala undeva. de la n= 61 isi pierde caracterul

% La calculul polinomului cu Metoda Directa se observa ca cu cat n este mai
% mare, cu atat eroarea dintre graficul functiei si polinom este mai mica.
% Din figurile reprezentate, se observa ca dupa n = 10 (folosind Metoda
% Directa), polinomul este stabil
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'F' = functie de clasa C1(D), unde F:D inclus in R^n->R^n
% 'J' = matricea Jacobian
% 'x0' = valoarea initiala
% 'epsilon' = eroarea de aproximare
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox' = suma de la i=k+1 pana la n din Aki*xi
% -------------------------------------------------------------------------
function [xaprox,N] = MetNewton(F,J,x0,epsilon)
    k = 0;
    ok = 1;
    while(ok)
        k = k +1;
        zk = J(x0')\(-F(x0'));
        x0 = x0 +zk;
        if norm(zk,Inf) < epsilon
            ok = 0;
        end
    end
    xaprox = x0;
    N = k;
end
%%

%%
% Ex. 4. 1) a)
function [y] = MetDirecta(X,Y,x)
    n1 = size(X); % numarul de noduri de interpolare
    n = n1(1);
    A = 1.+zeros(n);
    for i = 2:n
        A(1:n,i) = (X(1:n)).^(i-1);
    end
    y = zeros(n:1);
    [invA, detA] = GaussJordan(A);
    y = invA *Y; % coeficientii lui x din polinom   
end
%%

%%
% Ex. 4. 1) b)
function [y] = MetLagrange(X,Y,x)
     n1 = size(X); % numarul de noduri de interpolare
     n = n1(1);
     y = zeros(n,1);
     C = zeros(n,1);
     Lnk = 1;
     for k=1:n
         C(k) = aflC(k,X); 
         Lnk = C(k).*prod(x,X,n);
         y = y +Lnk *Y(k);
     end   
end
%%

%%
% Ex. 4. 1) c)
function [y] = MetN(X,Y,x)
    n1 = size(X); % numarul de noduri de interpolare
    n = n1(1);
    A = zeros(n);
    for i=1:n
        A(i,1) = 1;
    end
    for i=2:n
        for j=2:i
            A(i,j) = prod2(X,i,j);
        end
    end
    c = SubsAsc(A,Y);
    for i=2:n
        y = y+c(i)*prod(x,X,i-1);
    end
end
%%

%%
% functie construita pentru a afla Ck din MetLagrange (Ex. 4. b)
function [Ck] = aflC(k,X)
    n1 = size(X); % numarul de noduri de interpolare
    n = n1(1);
    Ck = 1;
    p = 1;
    for i=1:n
        if i~=k
            p = p.*(X(k)-X(i));
        end
    end
    Ck =1/p;
end
%%

%%
% functie implementata pentru a construi cu ajutorul ei Lnk (Ex. 4. b)
function [p1] = prod(x,X,n)
    %n = size(X);
    p1 = 1;
    for i=1:n
        p1 = p1.*(x-X(i));
    end
end
%%

%%
function [p2] = prod2(X,i,j)
    %n = size(X);
    p2 = 1
    for k=1:j-1
        p2 = p2*(X(i)-X(k));
    end
end
%%

% Metode implementate in temele anterioare si utilizate si in aceasta tema

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'invA' = o matrice, care reprezinta inversa matricei A
% 'detA' = un scalar, rezprezentand determinantul matricei A
% -------------------------------------------------------------------------

function [invA, detA] = GaussJordan(A)
    n1 = size(A);
    n = n1(1);
    invA = eye(n);
    for i = 1:n
        E = InterschLin(eye(n,1),i,1);
        invA(:,i) = GaussPivPart(A,E); % GaussPivPart intoarce ca rezultat
        % un vector de tip coloana
    end  
    % folosesc o portiune din GaussPivPart pentru a aduce matricea A la o
    % matrice superior triunghiulara. Astfel determinantul devine produsul
    % elementelor de pe diagonala principala
    for k = 1:n-1
        % cu ajutorul functiei predefinite 'find' gasesc indicele la care
        % se afla valoarea maxima
        y = find(abs(A(k:n,k))==max(max(abs(A(k:n,k)))));
        p = y(1) +(k-1); % indicele primului elem max de pe coloana k 
        if p ~= k
            A = InterschLin(A, p, k); % 'InterschLin'-functie implementata 
            % intr-un fisier de tip function
        end
        for l = k+1:n
            m(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - m(l, k)*A(k,:);
        end
    end
    detA = 1;
    % Calculez determinantul
    for i =1:n
        detA = detA *A(i,i);
    end
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = o matrice
% 'k' = indicele uneia dintre liniile ce urmeaza a fi interschimbate
% 'p' = indicele celeilalte linii ce urmeaz a fi interschimbata
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = matricea A, in care sunt interschimbate liniile k cu p
% -------------------------------------------------------------------------

function [x] = InterschLin(A, k, p)
    n1 = size(A);
    n = n1(1); 
    % folosim o matrice identitate de dimensiunea matricei A
    I = eye(n);
    I(k, k) = 0;
    I(p, p) = 0;
    I(p, k) = 1;
    I(k, p) = 1;
    A = I * A;  %interschimbam linia p cu linia k, din matricea A
    x = A;
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b, obtinuta prin metoda Gauss cu pivotare
% partiala
% -------------------------------------------------------------------------


function [x] = GaussPivPart(A, b)
    A = [A,b];
    n1 = size(A);
    n = n1(1);
    for k = 1:n-1
        % cu ajutorul functiei predefinite 'find' gasesc indicele la care
        % se afla valoarea maxima
        y = find(abs(A(k:n,k))==max(max(abs(A(k:n,k)))));
        p = y(1) +(k-1); % indicele primului elem max de pe coloana k 
        if A(p, k) == 0
           disp('Sistem incompatibil sa compatibil nedeterminat');
           break;
        end
        if p ~= k
            A = InterschLin(A, p, k); % 'InterschLin'-functie implementata 
            % intr-un fisier de tip function
        end
        for l = k+1:n
            m(l, k) = A(l, k)/A(k, k);
            A(l,:) = A(l,:) - m(l, k)*A(k,:);
        end
    end
    if A(n, n) == 0
        disp('Sistem incompatibil sau compatibil nedeterminat');
    end
    % apelez metoda 'SubscDesc', implementata intr-un fisier de tip
    % function
    x = SubsDesc(A, A(:,n+1));
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea unui sistem liniar de ecuatii
% 'b' = vectorul cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax=b
% -------------------------------------------------------------------------

function [x] = SubsDesc(A, b)
    n1 = size(A);
    n = n1(1); %numarul de linii al matricei A
    x(n) = (1/A(n,n)) *b(n);
    k = n - 1;
    while k > 0
        % Suma(k,A,x) este o functie construita petru a calcula suma de la
        % j=k+1 pana la n din akj*xj
        x(k) = (1/A(k,k)) *(b(k) -Suma(k,A,x)); 
        k = k - 1;
    end
    x = x';
end

% Date de intrare:
% 'k' = indicele unei pozitii in matrice
% 'A' = o matrice
% 'x' = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 's' = suma de la i=k+1 pana la n din Aki*xi
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================

%functie creata pentru a putea construi met SubsDesc
function s = Suma(k, A, x)
    n = size(A);
    s = 0;
    for i = k+1:n
        s = s + A(k,i) *x(i);
    end
end
%%

%%
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matricea sistemului
% 'b' = vectorul coloana cu rezultatele sistemului
% -------------------------------------------------------------------------
% Date de iesire:
% 'x' = solutia sistemului Ax = b
% -------------------------------------------------------------------------
function [x] = SubsAsc(A,b)
 n1 = size(A);
    n = n1(1); %numarul de linii al matricei A
    x(1) = (1/A(1,1)) *b(1);
    for k =2:n
        x(k) = (1/A(k,k)) *(b(k) - Sum(k,A,x));
    end
    x = x';
end

%%

%%
% Date de intrare:
% 'k' = indicele unei pozitii in matrice
% 'A' = o matrice
% 'x' = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 's' = suma de la j=1 pana la k-1 din Akj*xj
% -------------------------------------------------------------------------
function s = Sum(k,A,x)
    s = 0;
    for j =1:k-1
        s = s + (A(k,j)*x(j));
    end
end
%%