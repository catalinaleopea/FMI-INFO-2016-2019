% -------------------------------------------------------------------------
% Author: David Pacioianu, 2018
% -------------------------------------------------------------------------

% a
syms x y;
F1 = x^2 + y^2 - 4;
F2 = (x^2) / 8 - y;
F = [F1 F2]';
J = jacobian(F, [x, y]);
% b
figure(1);
fimplicit(F1, [-3 3 -3 3]);
hold on
fimplicit(F2, [-3 3 -3 3]);
hold off
% c
J = matlabFunction(jacobian(F, [x, y]), 'Vars', {[x y]});
F = matlabFunction(F, 'Vars', {[x, y]});
[x, N] = Newton(F, J, zeros(length(F), 1)', 10^(-4));

% d
[x1, ~] = Newton(F, J, -100*ones(length(F), 1)', 10^(-6));
[x2, ~] = Newton(F, J, 100*ones(length(F), 1)', 10^(-6));

% c
    function [xAprox, N] = Newton(F, J, currentX, epsilon)
        N = 0; stopCondition = false;
        while stopCondition == false
            N = N + 1;
            z = J(currentX') \ -F(currentX');
            currentX = currentX + z;
            stopCondition = norm(z) < epsilon;
        end
    end
    
    
    
    


