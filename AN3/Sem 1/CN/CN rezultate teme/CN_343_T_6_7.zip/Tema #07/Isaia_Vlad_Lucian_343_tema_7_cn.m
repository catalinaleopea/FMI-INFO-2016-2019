%% Exercitiul 1
syms x y;
F1 = x.^2 + y.^2 - 4;
F2 = (x.^2) / 8 - y;

J = jacobian([F1, F2], [x, y]);

figure(1);

fimplicit(F1, [-3, 3, -3, 3]);
hold on;
fimplicit(F2, [-3, 3, -3, 3]);

title(['{\color{blue}F1(x, y) = x^2 + y^2 - 4;','\color{red}F2(x, y) = (x^2) / 8 - y;}'],'interpreter','tex');

%pregatirea datelor
syms x y;
F = [F1; F2];
J = matlabFunction(jacobian(F, [x, y]), "Vars", {[x, y]});
F = matlabFunction(F, 'Vars', {[x, y]}); 

epsilon = 10^-6;

[x_aprox1, N1] = MetNewton(F, J, [-2 1]', epsilon);
[x_aprox2, N2] = MetNewton(F, J, [1, 2]', epsilon);

plot(x_aprox1(1), x_aprox1(2), 'o');
plot(x_aprox2(1), x_aprox2(2), 'o');

%% Exercitiul 2
syms x y;

F1 = x.^2 - 10*x + y.^2 + 8;
F2 = x.*y.^2 - 10*y + 8;

J = jacobian([F1, F2], [x, y]);

figure(1);

fimplicit(F1, [0, 5, 0, 5]);
hold on;
fimplicit(F2, [0, 5, 0, 5]);
title(['{\color{blue}F1(x, y) = x^2 - 10*x + y^2 + 8;','\color{red}F2(x1, x2) = x*y^2 - 10*y + 8;}'],'interpreter','tex');

%pregatirea datelor
syms x y;
F = [F1; F2];
J = matlabFunction(jacobian(F, [x, y]), "Vars", {[x, y]});
F = matlabFunction(F, 'Vars', {[x, y]}); 

epsilon = 10^-6;

[x_aprox1, N1] = MetNewton(F, J, [0.5, 1]', epsilon);
[x_aprox2, N2] = MetNewton(F, J, [2, 2.5]', epsilon);

plot(x_aprox1(1), x_aprox1(2), 'o');
plot(x_aprox2(1), x_aprox2(2), 'o');

%% Exercitiul 4 -> Hmmm
%2)
f = @(x) sin(x);
n = 3;
a = -pi / 2;
b = pi / 2;
X = linspace(a, b, n+1);
X = X';
Y = f(X);
%Metoda directa pentru a afla polinomul
a_Pn = coefPnDirect(X, Y);

x = linspace(a, b, 100);
y = f(x);
y_Pn = Pn(a_Pn, x);

figure(1);
hold on;
plot(x, y);
plot(x, y_Pn);
title(['{\color{blue}F1(x) = sin(x);','\color{red}P_3(x) dedus prin metoda directa;}'],'interpreter','tex');

%incrementam gradul polinomului gradual
n = 4;
X = linspace(a, b, n+1);
X = X';
Y = f(X);
a_Pn = coefPnDirect(X, Y);
y_Pn = Pn(a_Pn, x);
figure(2)
hold on;
plot(x, y);
plot(x, y_Pn);
title(['{\color{blue}F1(x) = sin(x);','\color{red}P_4(x) dedus prin metoda directa;}'],'interpreter','tex');

%%incrementam gradul polinomului gradual
n = 5;
X = linspace(a, b, n+1);
X = X';
Y = f(X);
a_Pn = coefPnDirect(X, Y);
y_Pn = Pn(a_Pn, x);
figure(3)
hold on;
plot(x, y);
plot(x, y_Pn);
title(['{\color{blue}F1(x) = sin(x);','\color{red}P_5(x) dedus prin metoda directa;}'],'interpreter','tex');
fprintf("Observam ca P4(x) produce cel mai apropiat polinom de functia originala\niar incepand cu gradul 5 polinomul isi pierde drastic acuratetea aproximarii\n");
%%n=6
n = 6;
X = linspace(a, b, n+1);
X = X';
Y = f(X);
a_Pn = coefPnDirect(X, Y);
y_Pn = Pn(a_Pn, x);
figure(4);
hold on;
plot(x, y);
plot(x, y_Pn);
title(['{\color{blue}F1(x) = sin(x);','\color{red}P_6(x) dedus prin metoda directa;}'],'interpreter','tex');

%% Functii ajutatoare
%polinom de grad n, unde a sunt coeficientii iar x este variabila
function [a] = coefPnDirect(X, Y)
    n = length(X);
    A = zeros(n, n);
    A(:, 1) = 1;

    for i = 1 : n
        for j = 2 : n
            A(i, j) = X(i) ^ (j+1);
        end
    end

    a = A \ Y;
end

function [y] = Pn(a, x)
    n = length(a);
    m = length(x);
    y = zeros(1, m);
    for i = 1 : m
        for j = 1 : n
            y(i) = y(i) + a(j) * x(i)^(j-1);
        end
    end
end

function [x0, k] = MetNewton(F, J, x0, epsilon)
    k = 0;
    
    ok = 1;

    while(ok == 1)
        k = k + 1;
        zk = J(x0') \ (-F(x0'));
        x0 = x0 + zk;
        
        if(norm(zk, inf) < epsilon)
            ok = 0;
        end
    end
end

function [y] = MetDirecta(X, Y, x)
    %presupunem ca X si Y sunt vetori coloana
    n = length(X);
    
    A = zeros(n, n);
    A(:, 1) = 1;
    for i = 1 : n
        for j = 2 : n
            A(i, j) = X(i) ^ (j+1);
        end
    end
    %fie a vector coloana cu coeficientii polinomului
    %conform cursului avem relatia
    %A * a = Y
    %deci avem a = A \ Y;
    a = A \ Y;
    %acum avem coeficientii polinomului
    %iar f(x) ~ Pn(x) = a1 + a2 * x + a3 * x + ... + an * x
    y = Pn(a, x);
end

function [y] = MetLagrange(X, Y, x)
    n = length(X)-1; %n = gradul polinomului
    
    L = ones(1, n+1);
    for k = 1 : n+1
        for j = 1 : n+1
            if j == k
                continue;
            end
            
            L(k) = L(k) .* (x - X(j)) / (X(k) - X(j));
        end
    end
    
    y = 0;
    
    for k = 1 : n+1
        y = y + L(k) .* Y(k);
    end
end

function [y] = MetN(X, Y, x)
    n = length(X);
    A = zeros(n);
    
    for i = 1 : n
        A(i, 1) = 1;
    end
    
    for i = 2:n
        for j = 2:i
            A(i, j) = 1;
            
            for k = 1:j-1
                A(i, j) = A(i, j) * (X(i) - X(k));
            end
        end
    end
    
    c = SubsAsc(A, Y);
    
    y = c(1);
    
    for i = 2:n
        prod = 1;
        
        for j = 1 : i-1
            prod = prod * (x - X(j));
        end
        
        y = y + c(i) * prod;
    end
end

function x = SubsAsc(A, b)
    x(1) = b(1) / A(1,1);
    
    n = size(A, 1);
    
    for k = 2 : n
        sum = 0;
        for j = 1 : k-1
            sum = sum + A(k,j) * x(j);
        end
        
        x(k) = (b(k) - sum) / A(k,k);
    end
end
