% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 10
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2019
% =========================================================================


%%
% Ex. 2.
% b)
f = @(x) sin(x);
a = -pi/2;
b = pi/2;
n = 2;

X = linspace(a,b,n+1); % generarea nodurilor de interpolare
X(1) = a;
X(n+1) = b;
Y = f(X); % valorile functiei f in nodurile de interpolare 

figure(1);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'-b'); % trasarea graficului functiei f
xlim([-2 2]);
ylim([-2 2]);
hold on

plot(X,Y,'-r'); % reprezentarea grafica a perechilor de forma (Xi,Yi), i=1:n+1
hold on

syms x
df = matlabFunction(diff(f(x))); % derivata functiei f
fpa = df(a); % derivata functiei f in capatul din stanga al intervalului

% valorile functiei spline patratica calculata in 100 de noduri
for i=1:100
    [S(i),Sd(i)] = SplineP(X,Y,fpa,z(i));
end
plot(z,S,'--m'); % reprezentarea grafica a functiei spline patratice calculata in 100 de noduri
legend('Functia f(x)=sin(x)','perechile (Xi,Yi), i=1:n+1','Valoarea functiei spline patratica');
title('Aplicarea functiei SplinP pentru n = 2');

% Pentru n = 4
n = 4;

X = linspace(a,b,n+1); % generarea nodurilor de interpolare
X(1) = a;
X(n+1) = b;
Y = f(X); % valorile functiei f in nodurile de interpolare 

figure(2);
plot(z,t,'-b'); % trasarea graficului functiei f
xlim([-2 2]);
ylim([-2 2]);
hold on

plot(X,Y,'-r'); % reprezentarea grafica a perechilor de forma (Xi,Yi), i=1:n+1
hold on

% valorile functiei spline patratica calculata in 100 de noduri
for i=1:100
    [S(i),Sd(i)] = SplineP(X,Y,fpa,z(i));
end
plot(z,S,'--m'); % reprezentarea grafica a functiei spline patratice calculata in 100 de noduri
legend('Functia f(x)=sin(x)','perechile (Xi,Yi), i=1:n+1','Valoarea functiei spline patratica');
title('Aplicarea functiei SplineP pentru n = 4');

% Pentru n = 10
n = 10;

X = linspace(a,b,n+1); % generarea nodurilor de interpolare
X(1) = a;
X(n+1) = b;
Y = f(X); % valorile functiei f in nodurile de interpolare 

figure(3);
plot(z,t,'-b'); % trasarea graficului functiei f
xlim([-2 2]);
ylim([-2 2]);
hold on

plot(X,Y,'-r'); % reprezentarea grafica a perechilor de forma (Xi,Yi), i=1:n+1
hold on

% valorile functiei spline patratica calculata in 100 de noduri
for i=1:100
    [S(i),Sd(i)] = SplineP(X,Y,fpa,z(i));
end
plot(z,S,'--m'); % reprezentarea grafica a functiei spline patratice calculata in 100 de noduri
legend('Functia f(x)=sin(x)','perechile (Xi,Yi), i=1:n+1','Valoarea functiei spline patratica');
title('Aplicarea functiei SplineP pentru n = 10');

% c)
figure(4)
plot(z,Sd,'-m'); % reprezentarea grafica a derivatei functiei spline patratice calculata in 100 de noduri
hold on
fplot(df,[a b],'--b'); % derivata functiei f
legend('Derivata functiei Spline patratica','Derivata functiei f');

% Verificare Spline patratic cu vectori
figure(5);
[Sv,Svd] = SplinePVec(X,Y,fpa,z); % valorile functiei spline patratica calculata in 100 de noduri
% folosind metoda Spline patratica pentru vectori
xlim([-2 2]);
ylim([-2 2]);
hold on
plot(z,Sv,'-m'); % reprezentarea grafica a functiei spline patratica folosind metoda SplinePVec
hold on
plot(z,S,'--b'); % reprezentarea grafica a functiei spline patratica folosind metoda SplineP
legend('Valoarea functiei spline patratica folosind vectori','Valoarea functiei spline patratica');
%%

%%
% Ex. 3.
% b)
f = @(x) sin(x);
a = -pi/2;
b = pi/2;
n = 2;

X = linspace(a,b,n+1); % generarea nodurilor de interpolare
X(1) = a;
X(n+1) = b;
Y = f(X); % valorile functiei f in nodurile de interpolare 

figure(6);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'-b'); % trasarea graficului functiei f
xlim([-2 2]);
ylim([-2 2]);
hold on

plot(X,Y,'-r'); % reprezentarea grafica a perechilor de forma (Xi,Yi), i=1:n+1
hold on

syms x
df = matlabFunction(diff(f(x))); % derivata functiei f
dff = matlabFunction(diff(df(x))); % derivata a doua a functiei f
fpa = df(a); % derivata functiei f in capatul din stanga al intervalului
fpb = df(b); % derivata functiei f in capatul din dreapta al intervalului
% valorile functiei spline cubica calculata in 100 de noduri
for i=1:100
    [S(i),Sd(i),Sdd(i)] = SplineC(X,Y,fpa,fpb,z(i));
end
plot(z,S,'-m'); % reprezentarea grafica a functiei spline cubica calculata in 100 de noduri
legend('Functia f(x)=sin(x)','perechile (Xi,Yi), i=1:n+1','Valoarea functiei spline cubica');
title('Aplicarea functiei SplinC pentru n = 2');

% Pentru n = 4
n = 4;

X = linspace(a,b,n+1); % generarea nodurilor de interpolare
X(1) = a;
X(n+1) = b;
Y = f(X); % valorile functiei f in nodurile de interpolare 

figure(7);
plot(z,t,'-b'); % trasarea graficului functiei f
xlim([-2 2]);
ylim([-2 2]);
hold on

plot(X,Y,'-r'); % reprezentarea grafica a perechilor de forma (Xi,Yi), i=1:n+1
hold on

% valorile functiei spline cubica calculata in 100 de noduri
for i=1:100
    [S(i),Sd(i),Sdd(i)] = SplineC(X,Y,fpa,fpb,z(i));
end
plot(z,S,'-m'); % reprezentarea grafica a functiei spline cubica calculata in 100 de noduri
legend('Functia f(x)=sin(x)','perechile (Xi,Yi), i=1:n+1','Valoarea functiei spline cubica');
title('Aplicarea functiei SplineC pentru n = 4');

% Pentru n = 10
n = 10;

X = linspace(a,b,n+1); % generarea nodurilor de interpolare
X(1) = a;
X(n+1) = b;
Y = f(X); % valorile functiei f in nodurile de interpolare 

figure(8);
plot(z,t,'-b'); % trasarea graficului functiei f
xlim([-2 2]);
ylim([-2 2]);
hold on

plot(X,Y,'-r'); % reprezentarea grafica a perechilor de forma (Xi,Yi), i=1:n+1
hold on

% valorile functiei spline cubica calculata in 100 de noduri
for i=1:100
    [S(i),Sd(i),Sdd(i)] = SplineC(X,Y,fpa,fpb,z(i));
end
plot(z,S,'-m'); % reprezentarea grafica a functiei spline cubica calculata in 100 de noduri
legend('Functia f(x)=sin(x)','perechile (Xi,Yi), i=1:n+1','Valoarea functiei spline cubica');
title('Aplicarea functiei SplineC pentru n = 10');

% c)
figure(9)
plot(z,Sd,'-m'); % reprezentarea grafica a derivatei functiei spline cubica calculata in 100 de noduri
hold on
fplot(df,[a b],'--b'); % derivata functiei f
legend('Derivata functiei Spline cubica','Derivata functiei f');

% d)
figure(10)
plot(z,Sdd,'-m'); % reprezentarea grafica a derivatei functiei spline cubica calculata in 100 de noduri
hold on
fplot(dff,[a b],'--b'); % derivata functiei f
legend('Derivata a doua a functiei Spline cubica','Derivata a doua a functiei f');

% Verificare Spline cubica cu vectori
figure(11);
Scv = SplineCVec(X,Y,fpa,fpb,z); % valorile functiei spline cubica calculata in 100 de noduri
% folosind metoda Spline cubica pentru vectori
xlim([-2 2]);
ylim([-2 2]);
hold on
plot(z,Scv,'-m'); % reprezentarea grafica a functiei spline cubica folosind metoda SplineCVec
hold on
plot(z,S,'--b'); % reprezentarea grafica a functiei spline cubica folosind metoda SplineC
legend('Valoarea functiei spline patratica folosind vectori','Valoarea functiei spline patratica');
%%

%%
% Ex. 2.
% a)
% -------------------------------------------------------------------------
% Date de intrare:
% 'X' = matrice reprezantand nodurile de interpolare
% 'Y' = matrice reprezentand valorile functiei f in nodurile de interpolare
% 'fpa' = derivata functiei f in capatul din stanga al intervalului
% 'x' = variabila scalara, x apartine intervalului [a,b]
% -------------------------------------------------------------------------
% Date de iesire:
% 'y' = valoarea functiei spline patratice
% 'z' = valoarea derivatei functiei spline patratice
% -------------------------------------------------------------------------
function [y,z] = SplineP(X,Y,fpa,x)
    n1 = size(X);
    n = n1(2) - 1;
    B(1) = fpa;
    for j = 1:n
        A(j) = Y(j);
        H(j) = X(j+1) - X(j); 
    end
    for j = 1:n-1
        B(j+1) = (2/H(j)) *(Y(j+1) -Y(j)) -B(j);
    end
    for j = 1:n
        C(j) = (1/(H(j))^2) *(Y(j+1) -Y(j) -H(j) *B(j));
    end
    for j = 1:n
        if ((x >= X(j)) && (x <= X(j+1)))
            S = A(j) +B(j)*(x -X(j)) +C(j)*((x -X(j))^2);
            Sd = B(j) +2*C(j)*(x -X(j));
            break;
        end
    end
    y = S;
    z = Sd;
end
%%

%%
% Ex. 2.
% d)
% -------------------------------------------------------------------------
% Date de intrare:
% 'X' = matrice reprezantand nodurile de interpolare
% 'Y' = matrice reprezentand valorile functiei f in nodurile de interpolare
% 'fpa' = derivata functiei f in capatul din stanga al intervalului
% 'x' = vector, x apartine intervalului [a,b]
% -------------------------------------------------------------------------
% Date de iesire:
% 'y' = vector reprezentand valoarea functiei spline patratica
% 'z' = vector reprezentand valoarea derivatei functiei spline patratica
% -------------------------------------------------------------------------
function [y,z] = SplinePVec(X,Y,fpa,x)
    n2 = size(x);
    n2 = n2(2);
    for i = 1:n2
        n1 = size(X);
        n = n1(2) - 1;
        B(1) = fpa;
        for j = 1:n
            A(j) = Y(j);
            H(j) = X(j+1) - X(j); 
        end
        for j = 1:n-1
            B(j+1) = (2/H(j)) *(Y(j+1) -Y(j)) -B(j);
        end
        for j = 1:n
            C(j) = (1/(H(j))^2) *(Y(j+1) -Y(j) -H(j) *B(j));
        end
        for j = 1:n
            if ((x(i) >= X(j)) && (x(i) <= X(j+1)))
                S = A(j) +B(j)*(x(i) -X(j)) +C(j)*((x(i) -X(j))^2);
                Sd = B(j) +2*C(j)*(x(i) -X(j));
                break;
            end
        end
        y(i) = S;
        z(i) = Sd;
    end
end
%%

%%
% Ex. 3.
% a)
% -------------------------------------------------------------------------
% Date de intrare:
% 'X' = matrice reprezantand nodurile de interpolare
% 'Y' = matrice reprezentand valorile functiei f in nodurile de interpolare
% 'fpa' = derivata functiei f in capatul din stanga al intervalului
% 'fpb' = derivata functiei f in capatul din dreapta al intervalului
% 'x' = variabila scalara, x apartine intervalului [a,b]
% -------------------------------------------------------------------------
% Date de iesire:
% 'y' = valoarea functiei spline cubica
% 'z' = valoarea derivatei functiei spline cubica
% 't' = valoarea derivatei de ordinul 2 a functiei spline cubica
% -------------------------------------------------------------------------
function [y,z,t] = SplineC(X,Y,fpa,fpb,x)
    n1 = size(X);
    n = n1(2) - 1;
    B(1) = fpa;
    B(n+1) = fpb;
    epsilon = 10^(-8);
    for j = 1:n
        A(j) = Y(j);
        H(j) = X(j+1) - X(j); 
    end
    Bm = zeros(n+1);
    Bm(1,1) = 1;
    Bm(n+1,n+1) = 1;
    for i =2:n
        Bm(i,i-1) = 1;
        Bm(i,i) = 4;
        Bm(i,i+1) = 1;
    end
    B = MetJacobiDDL(Bm,X',epsilon);
    B(1) = fpa;
    B(n+1) = fpb;
    for j = 1:n
        C(j) = (3/((H(j))^2)) *(Y(j+1) -Y(j)) -(B(j+1) +2*B(j))/H(j);
        D(j) = (-2/((H(j))^3)) *(Y(j+1) -Y(j)) +(1/((H(j))^2)) *(B(j+1) -B(j));
    end
    for j = 1:n
        if ((x >= X(j)) && (x <= X(j+1)))
            S = A(j) +B(j)*(x -X(j)) +C(j)*((x -X(j))^2) +D(j)*((x -X(j))^3);
            Sd = B(j) +2*C(j)*(x -X(j)) +3*D(j)*((x -X(j))^2);
            Sdd = 2*C(j) +6*D(j)*(x-X(j));
            break;
        end
    end
    y = S;
    z = Sd;
    t = Sdd;
end
%%

%%
% Ex. 3.
% e)
function [y] = SplineCVec(X,Y,fpa,fpb,x)
    n2 = size(x);
    n2 = n2(2);
    for i = 1:n2
        n1 = size(X);
        n = n1(2) - 1;
        B(1) = fpa;
        B(n+1) = fpb;
        epsilon = 10^(-8);
        for j = 1:n
            A(j) = Y(j);
            H(j) = X(j+1) - X(j); 
        end
        Bm = zeros(n+1);
        Bm(1,1) = 1;
        Bm(n+1,n+1) = 1;
        for j =2:n
            Bm(j,j-1) = 1;
            Bm(j,j) = 4;
            Bm(j,j+1) = 1;
        end
        B = MetJacobiDDL(Bm,X',epsilon);
        B(1) = fpa;
        B(n+1) = fpb;
        for j = 1:n
            C(j) = (3/((H(j))^2)) *(Y(j+1) -Y(j)) -(B(j+1) +2*B(j))/H(j);
            D(j) = (-2/((H(j))^3)) *(Y(j+1) -Y(j)) +(1/((H(j))^2)) *(B(j+1) -B(j));
        end

        for j = 1:n
            if ((x(i) >= X(j)) && (x(i) <= X(j+1)))
                S = A(j) +B(j)*(x(i) -X(j)) +C(j)*((x(i) -X(j))^2) +D(j)*((x(i) -X(j))^3);
                % Sd = B(j) +2*C(j)*(x(i) -X(j)) +3*D(j)*((x(i) -X(j))^2);
                % Sdd = 2*C(j) +6*D(j)*(x(i)-X(j));
                break;
            end
        end
        y(i) = S;
    end
end
%%




% Functii implementate in laboratoarele anterioare, pe care le-am folosit
% si in acest laborator

%%
% Ex. 4
% b) Metoda Jacobi pentru matrice diagonal dominante pe linii
% Date de intrare:
% 'A' = matrice nesingulara si diagonal dominanta
% 'epsilon' = un scalar
% a = un vector
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox' = aproximarea solutiei sistemului de ecuatii Ax = a
% -------------------------------------------------------------------------
function [xaprox,N] = MetJacobiDDL(A,a,epsilon)
    n1 = size(A);
    n = n1(1);
    for i = 1:n
        if abs(A(i,i)) <= sum3(A,i)
            disp('Matr. nu este diag. dom. pe linii');
        end
    end
    x = zeros(n,1);
    x0 = x;
    k = 0;
    for i = 1:n
        for j = 1:n
            if i == j
             B(i,j) = 0;
            end
            if i ~= j
                B(i,j) = -A(i,j)/A(i,i);
            end
        end
    end
    for i = 1:n
        b(i) = a(i)/A(i,i);
    end
    b = b';
    q = normap(B,'inf');
    ok = 1;
    while ok == 1
        k = k+1;
        if k == 1
            x1 = B*x+b;
        end
        x = B*x+b;
        if ((q^k)/(1-q))*normav((x1-x0),'inf') < epsilon
            ok = 0;
        end
    end
    xaprox = x;
    N = k;
end
%%

%%
% suma modulelor elementelor unei matrice fara elem. de pe diagonala
% principala
% pentru algoritmul MetJacobiDDL de la Ex. 4
function [s] = sum3(A,i)
    n1 = size(A);
    n = n1(1);
    s = 0;
    for j =1:n
        if i ~= j
            s = s+abs(A(i,j));
        end
    end
end
%%

%%
% norma unui vector
% pentru Ex.2 c)
function [norma] = normav(x,p)
    [s1, s2] = sum2(x);
    if p == 'inf' 
        p = 0; 
    end
    switch p
        case 1
            norma = s1; % norma 1 a unei vector
        case 2
            norma = sqrt(s2);
        case 0     % calculeaza norma infinit
            norma = max(abs(x)); % norma infinit a unui vector
        otherwise
            disp('Norma nedefinita!');
    end
end
%%

%%
% Suma modulelor elementelor unui vector de tip coloana si supa patratelor
% elementelor unui vector
function [s1, s2] = sum2(x)
    n1 = size(x);
    n = n1(1);
    x = x';
    s1 = 0;
    s2 = 0;
    for i =1:n
        s1 = s1+abs(x(i));
        s2 = s2+x(i)^2;
    end
end
%%

%%
% Ex. 1
% a) Functie care returneaza norma p, a matricei A
% Pentru a aela norma infinit, p='inf'
function [norma] = normap(A,p)
    [s1, s2] = sum1(A); % calculeaza suma pe linii, respectiv pe coloane 
    % pentru matricea A 
    if p == 'inf' 
        p = 0; 
    end
    switch p
        case 1
            norma = max(s1); % norma 1 a unei matrice
        case 2
            B = A'*A;
            epsilon = 10^(-4);
            [lambda] = MetodaJacobi(B,epsilon);
            norma = max(sqrt(lambda));
        case 0     % calculeaza norma infinit
            norma = max(s2); % norma infinit a unei matrice
        otherwise
            disp('Norma nedefinita!');
    end
end
%%

%%
% Sume pe linii si pe coloana
% Apelez aceasta functie in normap
function [s1,s2] = sum1(A)
    n1 =size(A);
    n = n1(1);
    s1 = zeros(1,n);
    s2 = zeros(1,n);
    for i =1:n
        for j =1:n
            s1(i) = s1(i) + abs(A(i,j));
            s2(i) = s2(i) + abs(A(j,i));
        end
    end
end
%%

%%
% Metoda Jacobi de aproximare a valorilor proprii
% -------------------------------------------------------------------------
% Date de intrare:
% 'A' = matrice simetrica
% 'epsilon' = un scalar
% -------------------------------------------------------------------------
% Date de iesire:
% 'lambda' = vectorul valorilor proprii ale matricei A
% -------------------------------------------------------------------------
function [lambda] = MetodaJacobi(A,epsilon)
    n1 = size(A);
    n = n1(1);
    B = zeros(n);
    while Mod(A) >= epsilon
        for i =1:n
            for j = i+1:n
                B(i,j) = A(i,j);
            end
        end
        [p, q] = find(abs(B)==max(max(abs(B))));
        p = p(1);
        q = q(1);
        if A(p,q) == A(q,q)
            teta = pi/4;
        else
            teta = 1/2 *atan(2*A(p,q)/(A(q,q)-A(p,p)));
        end
        c = cos(teta);
        s = sin(teta);
        for j =1:n
            if (j ~= p) & (j ~= q)
                u = A(p,j)*c -A(q,j)*s;
                v = A(p,j)*s +A(q,j)*c;
                A(p,j) = u;
                A(q,j) = v;
                A(j,p) = u;
                A(j,q) = v;
            end
        end
        u = (c^2)*A(p,p) -2*c*s*A(p,q)+(s^2)*A(q,q);
        v = (s^2)*A(p,p) +2*c*s*A(p,q)+(c^2)*A(q,q);
        A(p,p) = u;
        A(q,q) = v;
        A(p,q) = 0;
        A(q,p) = 0;
    end
    for i =1:n
        lambda(i) = A(i,i);
    end
    lambda = lambda';
end
%%

%%
% fumctie construita pentru a putea calcula modulul matricei A, asa cum 
% este descris in Cursul#4 la pagina 7
% |A| = sqrt(suma(aij^2)), i,j=1:n si i!=j
% functia este folosita in MetodaJacobi
function [s] = Mod(A)
    n1 = size(A);
    n = n1(1);
    s = 0;
    for i = 1:n
        for j = 1:n
            if i ~= j
                s = s +(A(i,j))^2;
            end
        end
    end
    s = sqrt(s);
end
%%
