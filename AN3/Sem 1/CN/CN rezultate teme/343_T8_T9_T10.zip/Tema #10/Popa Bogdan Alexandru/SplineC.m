% Implementam interpolarea functiilor Spline cubice conform indicatiilor
% din cursul 10.Avem ca date de intrare 2 vectori X si Y, 2 scalari
% fpa(derivata din capatul din stanga) si fpb(derivata din capatul din 
% dreapta) si scalarul x care reprezinta punctul in care dorim aproximarea.
% Datele de iesire vor fi un scalar y, un scalar z si un scalar t.
% Pentru rezolvarea acestui exercitiu s-a folosit MetJacobiDDL din Tema 5
function [y,z,t]=SplineC(X,Y,fpa,fpb,x)

n=length(X); % dimensiunea lui X
B=zeros(n,n);  % prealocam B(matricea asociata diagonal dominanta)
B(1,1)=1 ; B(n,n)=1; % initiem B cu 1 pe prima si ultima pozitie
for i=2:n-1
    % completam matricea B
    B(i,i-1)=1;B(i,i)=4;B(i,i+1)=1;
end
% initiem a
a=X(2)-X(1);
% initieam termenii cu fpa si fpb conform cursului
term(1)=fpa ; term(n)=fpb;
for j=2:n-1
    % completam lista termenilor conform cursului
    term(j)=3/a*(Y(j+1)-Y(j-1));
end
% obtinem b folosind metoda JacobiDDL
[b,~]=MetJacobiDDL(B,term,10^(-8));
c = zeros(n-1,1);d = zeros(n-1,1); % prealocam c si d
for j=1:n-1
    d(j)=-2/(a^3)*(Y(j+1)-Y(j))+1/a^2*(b(j+1)-b(j));
    c(j)=3/(a^2)*(Y(j+1)-Y(j))-(b(j+1)+2*b(j))/a;

end

% Calculam S (z si t din indicatie) conform cursului (si indicatiei)
for j=1:n-1
    if X(j)<=x && x<X(j+1)
        S=Y(j)+b(j)*(x-X(j))+c(j)*(x-X(j))^2 + d(j)*(x-X(j))^3;
        z=b(j)+2*c(j)*(x-X(j))+3*d(j)*x-X(j)^2;
        t=2*c(j)+6*d(j)*(x-X(j));
    end
end
% Interogam folosing x pentru completarea lui S (z si t din indicatie) 
% conform cursului (si indicatiei)
if X(n-1)<=x && x<=X(n)
    S=Y(n-1)+b(n-1)*(x-X(j))+c(n-1)*(x-X(j))^2 + d(n-1)*(x-X(n-1))^3;
    z=b(n-1)+2*c(n-1)*(x-X(n-1))+3*d(n-1)*x-X(n-1)^2;
    t=2*c(n-1)+6*d(n-1)*(x-X(n-1));
end
y=S; % intoarcem y
end

    

