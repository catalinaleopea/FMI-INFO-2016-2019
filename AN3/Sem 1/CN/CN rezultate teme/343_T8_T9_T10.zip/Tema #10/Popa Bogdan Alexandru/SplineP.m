% Implementam algoritmul de interpolare cu functii Spline patratice conform
% indicatiilor din cursul 10.Avem ca date de intrare 2 vectori X,Y, un 
% scal fpa(derivata din capatul din stanga) si fpb(derivata din capatul din 
% dreapta) si scalarul x care reprezinta punctul in care dorim aproximarea.
% Datele de iesire sunt cei 2 scalar y si z
function [y,z] = SplineP(X,Y,fpa ,x)
n=length(X); % dimensiunea domeniului X
a = zeros(n-1); % prealocam h
b = zeros(n); % prealocam b
c = zeros(n-1); % prealocam c
b(1)=fpa; % initiem primul element din matricea b cu fpa



for j=1:n-1
    % Aflarea coeficientilor aj conform cursului
    a(j)=X(j+1)-X(j);
    % Alfarea coeficientilor bj si cj conform cursului
    if j<=n-2
        b(j+1)=2/a(j)*(Y(j+1)-Y(j)-b(j));
    end
    c(j)=1/(a(j)^2)*(Y(j+1) - Y(j)-a(j)*b(j));
end

% Aflarea lui S (si z din indicatie)
for j=1:n-1
    % ne vom folosii de comparatia valorilor din X cu x pentru a determina
    % S conform cursului (si z conform indicatiei)
    if X(j)<=x && x<X(j+1)
           S=Y(j)+b(j)*(x-X(j))+c(j)*(x-X(j))^2;
           z=b(j)+2*c(j)*(x-X(j));
    end
end

% Interogam cu x penultima si ultima valoare din X conform cursului pentru
% a finaliza S si z
if X(n-1)<=x && x<=X(n)
     S=Y(n-1)+b(n-1)*(x-X(n-1))+c(n-1)*(x-X(n-1))^2;
     %z = S'(x)
     z=b(n-1)+2*c(n-1)*(x-X(n-1));
end
y=S; % intoarcem y
end

