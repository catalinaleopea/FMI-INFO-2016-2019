% definim functia MetJacobiDDL conform algoritmului din cursul 5 pag.29-30
% care primeste ca date de intrare matricea A, matricea nx1 a si un factor
% de eroare epsilon si ca date de iesire solutia sistemului A*x = a,x_aprox
% si numarul de pasi necesari rezolvari acestui sistem N. Pentru rezolvare
% a fost folosita normap pentru calcularea normelor din algoritm
function [x_aprox, N] = MetJacobiDDL(A, a, epsilon)
    n = size(A,1); % pastram dimensiunea lui A
    x_aprox = zeros(1, n); % prealocam x_aprox
    N = 0; % initializam numarul de pasi cu 0
    for i = 1:n % parcurgem toata dimensiunea lui A
       % conform algoritmului verificam daca modulul elementului de pe
       % diagonala principala al liniei curente este mai mare sau egal
       % decat suma pe linia curenta
       if abs(A(i,i)) < sum(A(i,:)) - A(i, i)
           % in caz contrar oprim metoda
           disp('Matricea nu este diag. dom. pe linii')
           return
       end
    end
    % pastram matricea identitate cu dimensiunea lui A in I
    I = eye(size(A));
    % conform algoritmului luam elementele de pe diagonala lui A si le
    % folosim ca impartitor pentru elementele din A, urmand ca rezultatul
    % aceste impartiri sa fie scazut din I
    B = I - A ./ repmat(diag(A), 1, n);
    % aplicam acelasi rationament pe a confrom algoritmului
    b = a ./ diag(A);
    q = normap(B, inf); % pastram q conform algoritmului
    % pastram x2 pentru a fi folosit in instructiunile urmatoare
    xk = B * x_aprox' + b;
    % pastram x2 ca fiind membrul drept al produsului din conditia de
    % oprire a pasului 4 al algoritmului
    efact = normap(xk, inf);
    k = 2; % incepem cu k de la 2 deoarece am facut deja primele 2 treceri
    while 1 % pornim o ciclare continua
        k = k + 1; % crestem k conform algoritmului
        x = B * xk + b; % calculam x curent conform algoritmului
        % varificam daca a fost atins pasul de oprire conform algoritmului
        if q^k / (1 - q) * efact < epsilon
            break % oprim algoritmul
        end
        xk = x; % atribuim lui xk valoarea curenta
    end
    x_aprox = xk; % xk va avea valoarea lui x_aprox
    N = k; % k reprezinta numarul de pasi
end
