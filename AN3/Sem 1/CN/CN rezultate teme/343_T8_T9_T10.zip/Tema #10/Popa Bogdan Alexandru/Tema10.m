%% Ex 2
% a) A fost rezolvat in fisierul function SplineP.m

% b)
X=linspace(-pi/2,pi/2,3); % domeniul
Y=sin(X); % valorile functiei din Ex 2
xx=linspace(-pi/2,pi/2,100); % diviziunea
fpa=cos(X(1)); % derivata functiei din Ex 2 in capatul din stanga
y = zeros(100,1); z = zeros(100,1); % prealocam y si z
for i=1:100 % aplicam SplineP 
    [y(i),z(i)]=SplineP(X,Y,fpa,xx(i));
end
figure(1)
% graficul punctelor
plot(X,Y,'o' , 'MarkerSize' , 10 , 'MarkerFaceColor' , 'y');
hold on
% graficul functiei f
plot(xx,sin(xx),'r');
% graficul functiei f spline
plot(xx,y,'b');
legend('noduri','f','f spline')
title('Comparatie f spline si f')
hold off

% c)
figure(2)
% graficul punctelor
plot(X,Y,'o' , 'MarkerSize' , 10 , 'MarkerFaceColor' , 'y');
hold on
% graficul derivatei f
plot(xx,cos(xx),'r');
% graficul derivatei spline f
plot(xx,z,'b');
legend('noduri','f derivat','f spline derivat')
title('Comparatie f derivata spline si f derivata')
hold off

%% Ex 3
% a) A fost rezolvat in fisierul function SplineC.m

% b)
X=linspace(-pi/2,pi/2,3); % domeniul
Y=sin(X); % valorile functiei din Ex 3
xx=linspace(-pi/2,pi/2,100); % diviziunea
fpa=cos(X(1)); % derivata functiei din Ex 2 in capatul din stanga
fpb=cos(X(length(X))); % derivata functiei din Ex 2 in capatul din dreapta
t = zeros(100); % prealocam t
for i=1:100 % aplicam SplineC
    [y(i),z(i),t(i)]=SplineC(X,Y,fpa,fpb,xx(i));
end
figure(3)
% graficul punctelor
plot(X,Y,'o' , 'MarkerSize' , 10 , 'MarkerFaceColor' , 'y');
hold on
% graficul functiei f
plot(xx,sin(xx),'r');
% graficul functiei f spline
plot(xx,y,'b');
legend('noduri','f','f spline')
title('Comparatie f spline si f')
hold off

% c)
figure(4)
% graficul punctelor
plot(X,Y,'o' , 'MarkerSize' , 10 , 'MarkerFaceColor' , 'y');
hold on
% graficul derivatei f
plot(xx,cos(xx),'r');
% graficul derivatei spline f
plot(xx,z,'b');
legend('noduri','f derivat','f spline derivat')
title('Comparatie f derivata spline si f derivata')
hold off

% d)
figure(5)
% graficul punctelor
plot(X,Y,'o' , 'MarkerSize' , 10 , 'MarkerFaceColor' , 'y');
hold on
% graficul derivatei de gradul 2 f
plot(xx,cos(xx),'r');
% graficul derivatei de gradul 2 spline f
plot(xx,t,'b');
legend('noduri','f derivat de gradul 2','f spline derivat de gradul 2')
title('Comparatie f derivata de gradul 2 spline si f derivata de gradul 2')
hold off