%X = [x1 x2 .. xn xn+1] -> nodurile din interpolare
%Y = [f(x1) .. f(xn) f(xn+1)] -> Valorile functiei in nodurile din
%interpolare, adica Y = [y1 y2.. yn yn+1]
%fpa = Valoare derivatei functiei 'f' in capatul din stanga i.e. a = x1
%x = punctul in care vrei aproximarea functiei 'f' pe baza interpolarii

function [ y, z ] = SplineP( X, Y, fpa, x)
%Initializarile -> declarari vectori cu dimensiuni etc

n = length(X) - 1;
a = zeros(1, n+1);
b = zeros(1, n+1);
c = zeros(1, n+1);
m = length(x);
%Aflarea coeficientilor aj -> formula (6) din curs

a = Y;

%Aflarea coeficientilor bj si cj -> formula (17) din curs

b(1) = fpa;
for j = 1:n-1
    b(j+1) = 2/(X(j+1) - X(j))*(Y(j+1) - Y(j)) - b(j);
end

for j=1:n
    c(j) = 1/((X(j+1) - X(j))^2)*(Y(j+1) - Y(j) - (X(j+1) - X(j))*b(j));
end

%Interogarile pentru 'x' in sensul ca -> In ce interval Xj < x < Xj+1 se 
%afla? De ce? Pentru a sti pe ce latura sa mergem cu functia spline pentru 
%a afla valoarea y = Spline(x)

for i = 1:length(x)
    for j = 1:n
        if ((x(i) >= X(j)) && (x(i) <= X(j+1)))
            y(i) = a(j) + b(j) * (x(i) - X(j)) + c(j) * (x(i) - X(j))^2;
            z(i) = b(j) + 2*c(j) * (x(i) - X(j));
            break;
        end
    end
end
end

