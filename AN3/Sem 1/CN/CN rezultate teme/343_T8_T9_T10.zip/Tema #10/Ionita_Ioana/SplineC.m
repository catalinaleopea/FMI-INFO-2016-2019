function [ y, z, t ] = SplineC( X, Y, fpa, fpb, x )
n = length(X) - 1;
a = Y;
for j = 1:n
    h(j) = X(j+1) - X(j);
end;
B(1,1) = 1;
B(n+1, n+1) = 1;
w(1) = fpa;
w(n+1) = fpb;
for j =2:n
    w(j) = -3/(h(j-1)^2) *Y(j-1) + (3/(h(j-1)^2) - 3/(h(j)^2))*Y(j) + 3/(h(j)^2) * Y(j+1);
    B(j, j) = 2/h(j) + 2/h(j-1);
    B(j, j-1) = 1/h(j-1);
    B(j,j+1) = 1/h(j);
end
    
b = inv(B) * transpose(w);
    
for j = 1:n
    c(j) = 3/(h(j)^2) * (Y(j+1) - Y(j)) - (b(j+1) + 2*b(j))/h(j);
    d(j) = -2/(h(j)^3) * (Y(j+1) - Y(j)) + 1/(h(j)^2)  *(b(j+1) + b(j));
end
    
for i = 1:length(x)
    for j = 1:n
        if x(i) >= X(j) && x(i) <= X(j+1)
            y(i) = a(j) + b(j) * (x(i) - X(j)) + c(j) * (x(i) - X(j))^2+d(j)*(x(i)-X(j))^3;
            z(i) = b(j) + 2*c(j) * (x(i) - X(j)) + 3*d(j)*(x(i) - X(j))^2;
            t(i) = 2*c(j) + 6*d(j)*(x(i) - X(j));
            break;
        end
    end
end
end