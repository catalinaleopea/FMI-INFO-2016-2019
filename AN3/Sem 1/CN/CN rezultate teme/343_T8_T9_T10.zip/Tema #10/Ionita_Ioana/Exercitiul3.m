f = @(x) sin(x);
a = -pi/2;
b = pi/2;
fprim = @(x) cos(x);
fprimprim = @(x) -sin(x);
%pentru n = 2
n1 = 2;
X1 = linspace(a, b, n1+1); 
Y1 = f(X1);
figure(1);
plot(X1, Y1, 'r', 'LineWidth', 2);
hold on;
plot(X1(1), Y1(1), 'bo', 'MarkerSize', 10, 'MarkerFaceColor','green');
hold on;
plot(X1(2), Y1(2), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'green');
hold on;
plot(X1(3), Y1(3), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'green');
x1 = linspace(a, b, 100);
[y1, z1, t1] = SplineC(X1, Y1, fprim(a), fprim(b), x1);
hold on;
plot(x1, y1, 'b', 'LineWidth', 2);
hold off;
figure(2);
plot(x1, z1, 'b', 'LineWidth', 2);
hold on;
plot(x1, fprim(x1), 'r', 'LineWidth', 2);
hold off;
figure(3);
plot(x1, t1, 'b', 'LineWidth', 2);
hold on;
plot(x1, fprimprim(x1), 'r', 'LineWidth', 2);
hold off;
%pentru n = 4
n2 = 4;
X2 = linspace(a, b, n2+1);
Y2 = f(X2);
figure(4);
plot(X2, Y2, 'r', 'LineWidth', 2);
for i=1:n2+1
    hold on;
    plot(X2(i), Y2(i), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'green');
end
x2 = linspace(a, b, 100);
[y2, z2, t2] = SplineC(X2, Y2, fprim(a), fprim(b), x2);
hold on;
plot(x2, y2, 'b', 'LineWidth', 2);
hold off;
figure(5);
plot(x2, z2, 'b', 'LineWidth', 2);
hold on;
plot(x2, fprim(x2), 'r', 'LineWidth', 2);
hold off;
figure(6);
plot(x2, t2, 'b', 'LineWidth', 2);
hold on;
plot(x2, fprimprim(x2), 'r', 'LineWidth', 2);
hold off;
%pentru n = 10
n3 = 10;
X3 = linspace(a, b, n3+1);
Y3 = f(X3);
figure(7);
plot(X3, Y3, 'r', 'LineWidth', 2);
for i=1:n3+1
    hold on;
    plot(X3(i), Y3(i), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'green');
end
x3 = linspace(a, b, 100);
[y3, z3, t3] = SplineC(X3, Y3, fprim(a), fprim(b), x3);
hold on;
plot(x3, y3, 'b', 'LineWidth', 2);
hold off;
figure(8);
plot(x3, z3, 'b', 'LineWidth', 2);
hold on;
plot(x3, fprim(x3), 'r', 'LineWidth', 2);
hold off;
figure(9);
plot(x3, t3, 'b', 'LineWidth', 2);
hold on;
plot(x3, fprimprim(x3), 'r', 'LineWidth', 2);
hold off;

 