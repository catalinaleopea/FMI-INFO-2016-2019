%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMA 10                                                                 %
% - Madalina Pietreanu, grupa 343                                         %
% - acest fisier reprezinta implementarile anumitor exercitii din tema 10 %
% - exercitiile care se rezolvau "manual" se gasesc in folderul "Papers"  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% b)
% initializari
% % % Error using subs
% % % Expected input number 1, S, to be one of these types:
% % % 
% % % sym
% % % 
% % % Instead its type was function_handle.
% % % 
% % % Error in sym/subs (line 60)
% % % validateattributes(F, {'sym'}, {}, 'subs', 'S', 1);
% % % 
% % % Error in Madalina_Pietreanu_343>SplineP (line 120)
% % %     z = subs(df,x,ics);
% % % 
% % % Error in Madalina_Pietreanu_343 (line 39)
% % %         S(j) = SplineP(X,Y,df(X(1)),m(j));


syms x;
global grafInd;
global f;
f = @(x) sin(x);
df = matlabFunction(diff(f(x),x));
fst = -pi/2;
snd = pi/2;
n = [2,4,10];
max = 100;
global m;
m = linspace(fst,snd,max);
y = f(m); % pentru plotarea functiei f
S = zeros(1,max);

% un mic test
% ceva = linspace(fst,snd,3);
% altceva = f(ceva);
% [ics,zet] = SplineP(ceva,altceva,0,0);
% ics 
% zet

% fac ce imi cere cerinta pentru fiecare n in parte
for i = 1 : length(n)
    grafInd = i+3;
    X = linspace(fst,snd,(n(i)+1));
    Y = f(X);
    
    for j = 1 : max
        S(j) = SplineP(X,Y,df(X(1)),m(j));
    end
    
    figure(i);
    % plotez functia
    plot(m,y,'-r');
    hold on;
    % plotez punctele obtinute pt n-uri
    scatter(X,Y,'*b');
    hold on;
    % plotez punctele de pe intervalul cerut
    scatter(m,S,'xg');
    hold off;
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUNCTII %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [y, z] = SplineP(X,Y,fpa,ics)
% X   = vector de noduri de interpolare
% Y   = vector de valorile functiei in nodurile de interpolare
% fpa = valoarea derivatei functiei f in capatul din stanga (a = x1)
% ics  = punctul in care vrei aproximarea functiei f pe baza interpolarii

% init -> declarari vect cu dimens, etc
n = length(X);          % dimensiunea vectorilor (si numarul de intervale)
a = zeros(1,n-1);       % vectorul coeficientilor a
b = zeros(1,n-1);       % vectorul coeficientilor b
c = zeros(1,n-1);       % vectorul coeficientilor c
h = zeros(1,n-1);       % lungimile intervalelor

% functia f
global f;

% multimea din problema
global m;

% pt plotarea graficului cu derivata
global grafInd;

% aflaraea coef aj din relatia (6)
a = Y(1:n-1);

% aflarea lungimilor intervalelor
for j = 1 : n - 1
   h(j) = X(j+1) - X(j);
end

% aflarea coef bj si cj din relatia (17)
b(1) = fpa;

for j = 2 : n - 1
    b(j) = (2 / h(j)) * (f(X(j)) - f(X(j-1))) - b(j-1);
end

for j = 1 : n - 1
    c(j) = (1 / h(j).^2) * (f(X(j + 1)) - f(X(j))) - h(j)*b(j);
end

% gasesc functia spline
syms x;
for j = 1 : n - 1
    S(j) = a(j) + b(j) * (x - X(j)) + c(j) * ((x - X(j))).^2;
end

% interog pt x: in ce interv XJ < x < XJ+1 se afla; pt a sti pe ce latura
% sa mergem cu func spline pt aflarea val y
    for j = 1 : n - 2
        if X(j) <= ics && ics < X(j+1)
            y = subs(S(j),x,ics);
            ind = j;
            break;
        end
    end
    
    if X(n-1) <= ics && ics <= X(n)
        y = subs(S(n-1),x,ics);
        ind = n-1;
    end
    
    % calculez derivata in punctul x
    func = S(ind);
    df = matlabFunction(diff(func,x));
    z = subs(df,x,ics);
    
%     % calculez valaorea derivatei in punctul dat conform indicatiei din
%     % tema
%     z = b(ind) + 2 * c(ind)*(ics - X(ind));

    set1 = f(m);
    set2 = df(m);
    
    figure(grafInd);
    plot(m,set1,'-r');
    hold on;
    plot(m,set2,'-b');
    hold off;
    
end


