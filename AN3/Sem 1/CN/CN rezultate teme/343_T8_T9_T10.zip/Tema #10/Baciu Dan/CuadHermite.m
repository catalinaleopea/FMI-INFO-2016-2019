function Inum=CuadHermite(f, df, a, b)
x=linspace(a, b, n+1);
Inum=0;
for i=1:n
    Inum=((f(a)+f(b))*(b-a)/2)+((b-a)^2/12)*df(a)*((b-a)^2)/12*df(b);
end
end