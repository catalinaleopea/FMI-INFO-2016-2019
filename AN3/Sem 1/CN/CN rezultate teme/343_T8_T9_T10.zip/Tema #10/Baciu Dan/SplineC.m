function[x,y,t] = SplineC(X,Y,fpa,fpb,x)
n=length(X);
B=zeros(n,n);
B(1,1) = 1;
B(n,n) = 1;
for i=2 : n-1
    B(i,i-1) = 1;
    B(i,i) = 4;
    B(i,i+1) = 1;
end
h = X(2)-X(1);
term(1)=fpa;
term(n)=fpb;
for j=2 : n-1
    term(j-1) = 3/h*(Y(j+1)-Y(j-1));
end
[xaprox,N] = MetJacobiDDL(B,term,10^(-8));
b=xaprox;
for j=1 : n-1
    d(j)=(-2)/(h^3)*(Y(j-1)-Y(j))+1/(h^2)*(b(j+1)-b(j));
    c(j)=3/(h^2)*(Y(j+1)-Y(j))-(b(j+1)+2*b(j))/h;
end
for j=1 : n-1
    if X(j)<=x && x<X(j+1)
        S=Y(j) + b(j)*(x-X(j))+c(j)*(x-X(j))^2 + d(j)*(x-X(j))^3;
        z=b(j)+2*c(j)*(x-X(j))+3*d(j)*(x-X(j))^2;
        t=2*c(j)+6*d(j)*(x-X(j));
    end
end
if X(n-1)<=x && x<=X(n)
    S=Y(n-1)+b(n-1)*(x-X(n-1))+c(n-1)*(x-X(n-1))^2+d(n-1)*(x-X(n-1))^3;
    z=b(n-1)+2*c(n-1)*(x-X(n-1))+3*d(n-1)*(x-X(n-1))^2;
    t=2*c(n-1)+6*d(n-1)*(x-X(n-1));
end
y=S;
end
    
    