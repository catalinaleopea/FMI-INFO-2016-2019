function [y,z]=SplineP(X,Y, fpa, x)
n=length(X);
b(1)=fpa;
for j=1:n-1
    h(j)=X(j+1)-X(j);
    if j<=n-2
        b(j+1)=2/h(j)*(Y(j+1)-Y(j))-b(j);
    end
    c(j)=1/(h(j)^2)*(Y(j+1)-Y(j)-h(j)*b(j));
end
for j=1:n-1
    if X(j)<=x && x<X(j+1)
        S=Y(j)+b(j)*(x-X(j))+c(j)*(x-X(j))^2;
        z=b(j)+2*c(j)*(x-X(j));
    end
end
if X(n-1)<=x && x<=X(n)
    S=Y(n-1)+b(n-1)*(x-X(n-1))+c(n-1)*(x-X(n-1))^2;
    z=b(n-1)+2*c(n-1)*(x-X(n-1));
end
y=S;
end