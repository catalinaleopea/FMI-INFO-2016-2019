%% Exercitiul 2: 
f=@(x)sin(x); 
fDerivat=@(x)cos(x);
a=-pi/2;
b=pi/2; 
N=[2,4,10];

for i=1:size(N,2)
    X=linspace(a,b,(N(i)+1));
    Y=f(X);
    x=linspace(a, b, 100);
    fpa=fDerivat(X(1));

    for k=1:100
        [S(k),z(k)]=SplineP(X,Y,fpa,x(k));
    end
    
    figure(i); 
    title('S si f(x)')
    hold on;
    plot(x,S,'b');
    plot(x,f(x),'r');  

        
    figure(100+i); 
    title('z si fDerivat(x)')
    hold on;
    plot(x,z,'b');
    plot(x,fDerivat(x),'r'); 
    pause(3)
end  
%% Batch
for i=1:size(N,2)
    X=linspace(a,b,(N(i)+1));
    Y=f(X);
    x=linspace(a,b,100);
    fpa=fDerivat(X(1));

    [S,z] = SplineP(X,Y,fpa,x);
    
    figure(300+i); 
    title('S si f(x)')
    hold on; 
    plot(x,S,'b');
    plot(x,f(x),'r'); 
        
    figure(400+i); 
    title('z si fDerivat(x)')
    hold on;
    plot(x,z,'b'); 
    plot(x,fDerivat(x),'r'); 
    pause(3)
end 

%% Exercitiul 3: 

f=@(x)sin(x); 
fDerivat=@(x)cos(x); 
f2Derivat=@(x)(-sin(x));
a=-pi/2;
b=pi/2; 
N=[2,4,10];

for i=1:size(N, 2)
    X=linspace(a, b,(N(i) + 1));
    Y=f(X);
    x=linspace(a, b, 100);
    fpa=fDerivat(X(1));
    fpb=fDerivat(X(N(i)+1));
    for k=1:100
        [S(k),z(k),t(k)]=SplineC(X,Y,fpa,fpb,x(k));
    end
    
    figure(500+i); 
    title('S si f(x)')
    hold on;
    plot(x,S,'b');
    plot(x,f(x),'r');  

        
    figure(600+i);      
    title('z si fDerivat(x)')
    hold on;
    plot(x,z,'b');
    plot(x,fDerivat(x),'r'); 
    
    
    figure(700+i); 
    title('t si f2Derivat(x)')
    hold on;
    plot(x,t,'b');
    plot(x,f2Derivat(x),'r'); 
    pause(6)
end  
%% Batch
for i = 1:size(N, 2)
    X=linspace(a, b,(N(i) + 1));
    Y=f(X);
    x=linspace(a, b, 100);
    fpa=fDerivat(X(1));
    fpb=fDerivat(X(N(i)+1));
    [S,z,t]=SplineC(X,Y,fpa,fpb,x);
    
    figure(800+i); 
    title('S si f(x)')
    hold on;
    plot(x,S,'b');
    plot(x,f(x),'r');  

        
    figure(900+i); 
    title('z si fDerivat(x)')
    hold on;
    plot(x,z,'b');
    plot(x,fDerivat(x),'r'); 
    
    figure(1000+i); 
    title('t si f2Derivat(x)')
    hold on;
    plot(x,t,'b');
    plot(x,f2Derivat(x),'r'); 
    pause(6)
end 



function [y,z] = SplineP(X,Y,fpa,x)  
    n=length(X)-1; 
    
    for j=1:n  
        a(j)=Y(j); 
    end 
    
    for j=1:n 
        h(j)=X(j+1)-X(j);
    end
    
    b(1)=fpa;  
    
    for j=1:n-1  
        b(j+1)=(2/h(j))*(Y(j+1)-Y(j))-b(j); 
        c(j)=(1/(h(j)*h(j)))*(Y(j+1)-Y(j)-h(j)*b(j));
    end 
    c(n)=(1/(h(n)*h(n)))*(Y(n+1)-Y(n)-h(n)*b(n));
    for j=1:length(x)
        for i=1:n  
            if ((x(j)>=X(i))&&(x(j)<=X(i+1))) 
                S(j)=a(i)+b(i)*(x(j)-X(i))+c(i)*(x(j)-X(i))^2; 
                z(j)=b(i)+2*c(i)*(x(j)-X(i));
                break; 
           end 
        end
    end
    y=S; 
end 

function [y,z,t] = SplineC(X,Y,fpa,fpb,x)     
    n=length(X)-1; 

    for j=1:n  
        a(j)=Y(j); 
    end  
    for j=1:n 
        h(j)=X(j+1)-X(j);
    end 
    
    B=zeros(n+1,n+1);
    B(1, 1) = 1;
    for j = 2:n 
        B(j,j-1)=1; 
        B(j,j)=4; 
        B(j,j+1)=1;
    end 
    B(n+1,n+1) = 1;
    resultB=zeros(n+1,1);
    resultB(1)=fpa; 
    gGlobal=(X(n+1)-X(1))/n;
    for j=2:n 
        resultB(j)=(3/gGlobal)*(Y(j+1)-Y(j-1)); 
    end 
    resultB(n+1)=fpb;  
    [b,dummy]=MetJacobiDDL(B,resultB,10^(-5)); 
    for j = 1:n
        c(j)=(3/h(j)^2)*(Y(j+1)-Y(j))-(b(j+1)+2*b(j))/h(j);
        d(j)=(-2/h(j)^3)*(Y(j+1)-Y(j))+(1/h(j)^2)*(b(j+1)+b(j)); 
    end 
    z=[]; 
    t=[];
    for j=1:length(x)
        for i=1:n  
            if ((x(j)>=X(i))&&(x(j)<=X(i+1)))  
                S(j)=a(i)+b(i)*(x(j)-X(i))+c(i)*(x(j)-X(i))^2+d(i)*(x(j)-X(i))^3; 
                z(j)=b(i)+2*c(i)*(x(j)-X(i))+3*d(i)*(x(j)-X(i))^2;
                t(j)=2*c(i) +6*d(i)*(x(j)-X(i));
                break; 
            end
        end   
    end
    y=S; 
    
end 

function[xaprox,N]=MetJacobiDDL(A,a,e)  
[m,n]=size(A);
for i=1:n  
    if abs(A(i,i))<=sum(abs(A(i,:)))-abs(A(i,i))  
        disp('Matricea nu este DDL');
        return;
    end
end 
xaprox=zeros(m, 1); 
N=0;  %Numarul de iteratii necesare pentru aproximare
D=diag(diag(A));
B=eye(n)-inv(D)*A; %Parametru pentru sistemul in baza caruia se construieste metoda
b=a./diag(A); %Parametru pentru sistemul in baza caruia se construieste metoda
q=norm(B,Inf); 
ConditieIesire=1;
x1=0; %solutia dupa prima iteratie
while ConditieIesire  
    N=N+1; 
    xaproxAnterior=xaprox; 
    xaprox=B*xaprox+b;   %solutia dupa iteratia curenta
    if x1==0 
        x1=xaprox;
    end
    if ((q^N)/(1-q))*norm(x1)<e %conditie de precizie
        ConditieIesire=0; 
    end
end
end