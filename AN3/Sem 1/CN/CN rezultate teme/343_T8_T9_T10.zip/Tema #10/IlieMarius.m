%%Exercitii
% Nu ruleaza.

%Ex 1
syms x
a = -pi/2;
b = pi/2;
X = [a,0,b];
Y = sin(X);
[y, z] = SplineP(X, Y, cos(a), x);

%Ex 2
n = 10;

X = a:(b-a)/n:b;
Y = sin(X);
Z = cos(X);
[y,z] = SplineP(X, Y, cos(a), Xval);

figure(1);
hold on;
plot(Xval,sin(Xval));
plot(X,Y,'*');
plot(Xval,y);
legend('f','puncte','SplineP');
hold off;

figure(2);
hold on;
plot(Xval,cos(Xval));
plot(X,Z,'*');
plot(Xval,z);
legend('df','puncte','SplineP');
hold off;

%Ex 3
n = 10;
    
X = a:(b-a)/n:b;
Y = sin(X);
Z = cos(X);
T = -Y;
[y,z,t] = SplineC(X, Y, cos(a), cos(b), Xval);

figure(3);
hold on;
plot(Xval,sin(Xval));
plot(X,Y,'*');
plot(Xval,y);
legend('f','puncte','SplineC');
hold off;

figure(4);
hold on;
plot(Xval,cos(Xval));
plot(X,Z,'*');
plot(Xval,z);
legend('df','puncte','SplineC');
hold off;

figure(5);
hold on;
plot(Xval,-sin(Xval));
plot(X,T,'*');
plot(Xval,t);
legend('ddf','puncte','SplineC');
hold off;


%%
%Functii

% function [y, z] = SplineP(X, Y, fpa, x)
% 
% syms xo functia derivata
% 
% a = Y;
% b = ones(length(X) - 1,1);
% c = ones(length(X) - 1,1);
% h = X(2) - X(1);
% 
% b(1) = fpa;
% for i = 1:length(X) - 2
%     b(i+1) = 2 * ( Y(i+1) - Y(i) )/h - b(i);
% end
% for i = 1:length(X) - 1
%     c(i) = ( Y(i+1) - Y(i) - h * b(i) ) / ( h^2 );
% end
% 
% for i = 1:length(X) - 1
%     functia(i) = a(i) + b(i) * ( xo - X(i) ) + c(i) * (( xo - X(i) )^2);
%     derivata(i) = b(i) + 2 * c(i) * ( xo - X(i) );
% end
% 
% if(isUnit(x))
%     y = functia;
%     z = derivata;
% end
% 
% for i = 1:length(X) - 1
%     poz = find(x >= X(i) & x <= X(i+1));
%     y(poz) = subs(functia(i),xo,x(poz));
%     z(poz) = subs(derivata(i),xo,x(poz));
% end
% 


% function [y, z, t] = SplineC(X, Y, fpa, fpb, x)
% 
% syms xo functia derivata derivata2
% 
% a = Y;
% c = ones(length(X) - 1,1);
% d = ones(length(X) - 1,1);
% h = X(2) - X(1);
% 
% b = ones(length(X),1);
% b(1) = fpa;
% for i = 2:length(X) - 1
%     b(i) = (3/h) * (Y(i+1) - Y(i-1));
% end
% b(length(X)) = fpb;
% 
% B = zeros(length(X),length(X));
% B(1,1) = 1;
% B(length(X),length(X)) = 1;
% for i = 2:length(X) - 1
%     B(i,i-1) = 1;
%     B(i,i) = 4;
%     B(i,i+1) = 1;
% end
% 
% b = Jacobi(B, b, 1.e-8);
% 
% for i = 1:length(c)
%     c(i) = 3 * ( Y(i+1) - Y(i) )/(h^2) - ( b(i+1) + 2 * b(i) )/h;
% end
% for i = 1:length(d)
%     d(i) = (-2) * ( Y(i+1)-Y(i) )/(h^3) + ( b(i+1) + b(i) )/(h^2);
% end
% 
% for j = 1:length(X) - 1
%     functia(j) = a(j) + b(j) * (xo - X(j))...
%                 + c(j) * ((xo - X(j))^2) + d(j) * ((xo - X(j))^3);
%     derivata(j) = b(j) + 2 * c(j) * (xo - X(j))...
%                 + 3 * d(j) * ( (xo - X(j) )^2);
%     derivata2(j) = 2 * c(j) + 6 * d(j) * (xo - X(j));
% end
% 
% if(isUnit(x))
%     y = functia;
%     z = derivata;
%     t = derivata2;
% end
% 
% for i = 1:length(X) - 1
%     poz = find(x >= X(i) & x <= X(i+1));
%     y(poz) = subs(functia(i),xo,x(poz));
%     z(poz) = subs(derivata(i),xo,x(poz));
%     t(poz) = subs(derivata2(i),xo,x(poz));
% end