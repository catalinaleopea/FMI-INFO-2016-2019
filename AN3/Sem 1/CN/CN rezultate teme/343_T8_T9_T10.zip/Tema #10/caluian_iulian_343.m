

%% EX2
% 

x = [-pi/2, 0 , pi/2];
y = [-1, 0 , 1];
[vx,z] = SplineP(x,y,0,-pi/4); %% ar trebui sa fie -0.5 (calculat pe hartie)
vx
%b
xi = linspace(-pi/2,pi/2, 100);
fxi = sin(xi);

l2 = linspace(-pi/2,pi/2, 3);
fy2 = sin(l2);
si2 = xi;
for i= 1:100
    [si2(i),z] = SplineP(l2,fy2,0,xi(i));
end


l4 = linspace(-pi/2,pi/2, 5);
fy4 = sin(l4);

si4 = xi;
for i= 1:100
    [si4(i),z] = SplineP(l4,fy4,0,xi(i));
end


l10 = linspace(-pi/2,pi/2, 11);
fy10 = sin(l10);
%si10 = xi
% for i= 1:100
%     si10(i) = SplineP(l10,fy10,xi(i));
% end
[si10,z] = SplineP(l10,fy10,0,xi);


plot(xi,fxi);
hold on;
plot(xi,si2);
plot(xi,si4);
plot(xi,si10);
%%



function [y,z] = SplineP(X,Y,fpa,x)
    %%return in punctul y
  
    vectSize = size(X);
    siz = max(vectSize(1),vectSize(2));

    vectSize = size(x);
    sizX = max(vectSize(1),vectSize(2)); 
    y = x; %doar pentru lungime, valorile initiale nu au relevanta.
    z = x; %doar pentru lungime, valorile initiale nu au relevanta.
    
    bi = zeros(1,siz-1);
    ci = zeros(1,siz - 1);
    bi(1) = fpa;
    for j = 1:(siz-2) 
       bi(j+1) =( 2 / (X(j+1)-X(j)) ) * (Y(j+1) - Y(j)) - bi(j); 
       ci(j) = ( 1 / (X(j+1)-X(j))^2 ) * (Y(j+1) - Y(j) - bi(j)*((X(j+1)-X(j)))) ; 
    end
    j = siz - 1;
    ci(j) =  ( 1 / (X(j+1)-X(j))^2 ) * (Y(j+1) - Y(j) - bi(j)*((X(j+1)-X(j))));
    
    
    for j = 1:sizX 
          i = 1;
            while ((i<siz) && (X(i+1) < x(j)) )
                i = i+1;
            end
    

         ai = Y(i);
         b = bi(i);
         c = ci(i);
         
         y(j) = ai + b*(x(j) - X(i)) + c*(x(j) - X(i))^2;
    end
    
    % z = bj + 2cj (x ? xj ).
end