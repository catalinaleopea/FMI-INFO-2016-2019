%%
%Ex.2 b)
A = -pi/2;
B = pi/2;
f = @(x)sin(x);
fprim = @(x)cos(x);

X = linspace(A,B,5);
Y = f(X);
xgrafic = linspace(A,B,100);
[y,z] = SplineP(X, Y, fprim(A), xgrafic);

figure(1)
plot(xgrafic, y);
hold on
plot(X, Y, 'o');

%Ex.2 c) - grafic derivata functiei spline si derivata functiei f
figure(2)
plot(xgrafic, z);
hold on
plot(X, fprim(X), 'o');

X = [1, 2.3, 4.23, 5, 5.5, 6.45];
Y = [1.2, 1.6, 2.3, 1.5, 0.5, 4];
fpa = 0;
xgrafic = linspace(X(1), X(length(X)), 100);
[y,z] = SplineP(X, Y, fpa, xgrafic);
figure(3)
plot(X, Y, 'o')
hold on
plot (xgrafic, y);
figure(4)
plot(xgrafic, z);
%%
%Ex.3. 
A = -pi/2;
B = pi/2;
f = @(x)sin(x);
fprim = @(x)cos(x);

X = linspace(A,B,5);
Y = f(X);
xgrafic = linspace(A,B,100);
[y,z,t] = SplineC(X, Y, fprim(A), fprim(B), xgrafic);

figure(1)
plot(xgrafic, y);
hold on
plot(X, Y, 'o');

figure(2)
plot(xgrafic, z);
hold on
plot(X, fprim(X), 'o');

figure(6)
plot(xgrafic, t);
hold on
plot(X, fprim(X), 'o');

X = [1, 2.3, 4.23, 5, 5.5, 6.45];
Y = [1.2, 1.6, 2.3, 1.5, 0.5, 4];
fpa = 0;
fpb = 0;
xgrafic = linspace(X(1), X(length(X)), 100);
[y,z,t] = SplineC(X, Y, fpa,fpb, xgrafic);
figure(3)
plot (xgrafic, y);
hold on
figure(4)
plot(xgrafic, z);
figure(5)
plot(xgrafic, t);

%%
%metoda de interpolare spline patratica 
function [y,z] = SplineP(X, Y, fpa, x)
    n = length(X) - 1;
    for j = 1:n
        a(j) = Y(j);
        h(j) = X(j+1) - X(j);
    end
    b(1) = fpa;
    for j = 1:n-1
        b(j+1) = 2*(Y(j+1) - Y(j)) / h(j) - b(j);
    end
    for j = 1:n
        c(j) = (Y(j+1) - Y(j)) / (h(j)^2) - (b(j)/h(j));
    end
    
    for i = 1:length(x)
        for j = 1:n
            if x(i) >= X(j) && x(i) <= X(j+1)
                S(i) = a(j) + b(j) * (x(i) - X(j)) + c(j) * (x(i) - X(j))^2;
                Sp(i) = b(j) + 2*c(j) * (x(i) - X(j));
                break;
            end
        end
    end
    y = S;
    z = Sp;
end

%interpolare cu functie spline cubica 
function [y,z,t] = SplineC(X, Y, fpa,fpb, x)
    n = length(X) - 1;
    for j = 1:n
        a(j) = Y(j);
        h(j) = X(j+1) - X(j);
    end
    B(1,1) = 1;
    B(n+1, n+1) = 1;
    w(1) = fpa;
    w(n+1) = fpb;
    for j =2:n
        w(j) = -3/(h(j-1)^2) *Y(j-1) + (3/(h(j-1)^2) - 3/(h(j)^2))*Y(j) + 3/(h(j)^2) * Y(j+1);
        B(j, j) = 2/h(j) + 2/h(j-1);
        B(j, j-1) = 1/h(j-1);
        B(j,j+1) = 1/h(j);
    end
    
    b = inv(B) * transpose(w);
    
    for j = 1:n
        c(j) = 3/(h(j)^2) * (Y(j+1) - Y(j)) - (b(j+1) + 2*b(j))/h(j);
        d(j) = -2/(h(j)^3) * (Y(j+1) - Y(j)) + 1/(h(j)^2)  *(b(j+1) + b(j));
    end
    
    for i = 1:length(x)
        for j = 1:n
            if x(i) >= X(j) && x(i) <= X(j+1)
                S(i) = a(j) + b(j) * (x(i) - X(j)) + c(j) * (x(i) - X(j))^2+d(j)*(x(i)-X(j))^3;
                Sp(i) = b(j) + 2*c(j) * (x(i) - X(j)) + 3*d(j)*(x(i) - X(j))^2;
                Ss(i) = 2*c(j) + 6*d(j)*(x(i) - X(j));
                break;
            end
        end
    end
    y = S;
    z = Sp;
    t = Ss;
end