% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'X'       = nodurile de interpolare
% 'Y'       = valorile functiei f in nodurile de interpolare
% 'fpa'     = derivata functie f in capatul din stanga al intervalului
% 'x'       = variabila scalara
% -------------------------------------------------------------------------
% Date de iesire:
% 'y'       = valoarea functiei spline patratica S(x)
% 'z'       = valoarea functiei spline a derivatei S'(x)
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [y, z] = SplineP(X, Y, fpa, x)
    b(1) = fpa;
    n = length(X) - 1;

    for j = 1 : n
       h(j) = X(j + 1) - X(j); 
    end

    for j = 1 : n - 1
       b(j + 1) = 2 / h(j) * (Y(j + 1) - Y(j)) - b(j);  
    end

    for j = 1 : n
       c(j) = 1 / (h(j) ^ 2) * (Y(j + 1) - Y(j) - h(j) * b(j));  
    end

    for j = 1 : n
       a(j) = Y(j); 
    end

    for j = 1 : n
       if x >= X(j) && x <= X(j + 1)
          S = a(j) + b(j) * (x - X(j)) + c(j) * (x - X(j)) ^ 2;
          break;
       end
    end

    y = S;
    
    % aici nu stiu daca trebuie ca j sa fie 1 sau n, am gasit
    % pe net cu ambele variante dar n-am inteles cum e corect...
    z = b(1) + 2 * c(1) * (x - X(1));
end
