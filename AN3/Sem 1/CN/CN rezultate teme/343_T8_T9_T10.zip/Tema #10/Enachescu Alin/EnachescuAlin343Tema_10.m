% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Rezolv exercitiile 2 si 3
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% exercitiul 2                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initializez functia f
f = @(x) sin(x);
% initializez derivata functiei f
fp = @(x) cos(x);
% initializez capetele intervalului
a = -pi / 2;
b =  pi / 2;
% n = 2...nu inteleg aici enuntul cu n = 2,4,10???
% R: Cate noduri sa aiba reteaua + 1
N = 4;
% generez pe X cu 3 elemente echidistante
X = linspace(a, b, N + 1);
% calculez pe Y
Y = f(X);
% generez 100 de puncte pentru care sa se apeleze SplineL
x = linspace(a, b, 100);
% initializez valoarea derivatei lui f in X(1)
fpa = fp(X(1));

[y, z] = SplinePVec(X, Y, fpa, x);

figure(1)
hold on
xlabel('x')
ylabel('y')
% desenez functia f
plot(x, f(x), 'k', 'LineWidth', 3);
% desenez punctele de interpolare
plot(X, Y, 'o', 'MarkerFaceColor', 'g', 'MarkerSize', 10);
% desenez functia spline S(x)
plot(x, y, '--r', 'LineWidth', 3);

figure(2)
hold on
xlabel('x')
ylabel('y')
% desenez derivata functiei f
plot(x, fp(x), 'k', 'LineWidth', 3);
% desenez derivata functiei spline
plot(x, z, '--r', 'LineWidth', 3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% exercitiul 3                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initializez functia f
f = @(x) sin(x);
% initializez derivata functiei f
fp = @(x) cos(x);
% initializez derivata a doua a functiei f
fpp = @(x) -sin(x);
% initializez capetele intervalului
a = -pi / 2;
b =  pi / 2;
% n = 2...nu inteleg aici enuntul cu n = 2,4,10???
N = 2;
% generez pe X cu 3 elemente echidistante
X = linspace(a, b, N + 1);
% calculez pe Y
Y = f(X);
% generez 100 de puncte pentru care sa se apeleze SplineL
x = linspace(a, b, 100);
% initializez valoarea derivatei lui f in X(1)
fpa = fp(X(1));
% initializez valoarea derivatei lui f in X(3)
fpb = fp(X(N + 1));

[y, z, t] = SplineCVec(X, Y, fpa, fpb, x);

figure(3)
hold on
xlabel('x')
ylabel('y')
% desenez functia f
plot(x, f(x), 'k', 'LineWidth', 3);
% desenez punctele de interpolare
plot(X, Y, 'o', 'MarkerFaceColor', 'g', 'MarkerSize', 10);
% desenez functia spline S(x)
plot(x, y, '--r', 'LineWidth', 3);

figure(4)
hold on
xlabel('x')
ylabel('y')
% desenez derivata functiei f
plot(x, fp(x), 'k', 'LineWidth', 3);
% desenez derivata functiei spline
plot(x, z, '--r', 'LineWidth', 3);

figure(5)
hold on
xlabel('x')
ylabel('y')
% desenez derivata a doua afunctiei f
plot(x, fpp(x), 'k', 'LineWidth', 3);
% desenez derivata a doua a functiei spline
plot(x, t, '--r', 'LineWidth', 3);