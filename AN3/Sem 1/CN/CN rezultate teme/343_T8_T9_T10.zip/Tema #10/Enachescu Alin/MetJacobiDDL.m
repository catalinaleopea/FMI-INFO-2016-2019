% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'A'       = o matrice inversabila
% 'a'       = un vector
% 'epsilon' = eroarea maxima dintre solutia numerica si cea exacta
% -------------------------------------------------------------------------
% Date de iesire:
% 'xaprox'  = solutia Ax = a
% 'N'       = iteratia la care ne oprim (data de criteriul de oprire)
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [xaprox, N] = MetJacobiDDL(A, a, epsilon)
    n = size(A, 1);
    
    xaprox = zeros(1, n);
    N = 0;
    
    % verific daca A este diagonal dominante pe linii
    for i = 1 : n
        if abs(A(i, i)) <= sum(A(i, :)) - A(i, i)
            printf('Matricea nu este diag. dom. pe linii');
            return;
        end
    end

    % initializez pe x0 si k
    x_zero = zeros(n, 1);
    k = 0;
    
    % determin pe B, b si q
    B = eye(size(A)) - A ./ repmat(diag(A), 1, n);
    b = a ./ diag(A);
    q = norm(B, inf);
    
    % calculez separat pe x1
    k = k + 1;
    x_one = B * x_zero + b;
    if q ^ k / (1 - q) * norm(x_one - x_zero, inf) >= epsilon
        xaprox = x_one;
        N = k;
        return;
    end
    
    % initializez pe x(k-1) ca fiind x1
    x_k_minus_one = x1;
    
    % iteratiile algoritmului
    while true
        k = k + 1;
        x_k = B * x_k_minus_one + b;
        if q ^ k / (1 - q) * norm(x_one - x_zero, inf) >= epsilon
            break;
        end
        
        x_k_minus_one = x_k;
    end
    
    % returnez rezultatul
    xaprox = x_k;
    N = k;
end
