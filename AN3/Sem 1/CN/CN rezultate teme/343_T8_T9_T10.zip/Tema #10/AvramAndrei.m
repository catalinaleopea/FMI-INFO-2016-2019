%Problema 1
a = -pi/2;
b = pi/2;
X = [a,0,b];
Y = sin(X);
[S, Z] = SplineP(X, Y, cos(a), 'var');
S = S.'
Z = Z.'

%Problema 2
for n = [2,4,10]
    X = a:(b-a)/n:b;
    Y = sin(X);
    Z = cos(X);
    [y,z] = SplineP(X, Y, cos(a), Xval);
    
    %b)
    figure;
    hold on;
    plot(Xval,sin(Xval),'r');
    plot(X,Y,'bo');
    plot(Xval,y,'g--');
    legend('functia','(X,Y)','SplineP','Location', 'Best');
    hold off;
    
    %c)
    figure;
    hold on;
    plot(Xval,cos(Xval),'r');
    plot(X,Z,'bo');
    plot(Xval,z,'g--');
    legend('derivata','(X,Y)','SplineP','Location', 'Best');
    hold off;
end

%Problema 3
for n = [2,4,10]
    X = a:(b-a)/n:b;
    Y = sin(X);
    Z = cos(X);
    T = (-1)*Y;
    [y,z,t] = SplineC(X, Y, cos(a), cos(b), Xval);
    
    %b)
    figure;
    hold on;
    plot(Xval,sin(Xval),'r');
    plot(X,Y,'bo');
    plot(Xval,y,'g--');
    legend('functia','(X,Y)','SplineC','Location', 'Best');
    hold off;
    
    %c)
    figure;
    hold on;
    plot(Xval,cos(Xval),'r');
    plot(X,Z,'bo');
    plot(Xval,z,'g--');
    legend('derivata','(X,Y)','SplineC','Location', 'Best');
    hold off;
    
    %d)
    figure;
    hold on;
    plot(Xval,(-1)*sin(Xval),'r');
    plot(X,T,'bo');
    plot(Xval,t,'g--');
    legend('derivata a doua','(X,Y)','SplineC','Location', 'Best');
    hold off;
end

%%
%Functii

%SplineP
%{
function [y, z] = SplineP(X, Y, fpa, xvalue)
N = size(X,2)-1;

A = 1:N;
B = 1:N;
C = 1:N;

A(1:N) = Y(1:N);
B(1) = fpa;
for j = 1:N-1
    B(j+1) = 2*(Y(j+1)-Y(j))/(X(j+1)-X(j)) - B(j);
end
for j = 1:N
    C(j) = (Y(j+1)-Y(j)-(X(j+1)-X(j))*B(j))/((X(j+1)-X(j))^2);
end

syms S dS x
S = sym('S',[1,N]);
dS = sym('dS',[1,N]);

for j = 1:N
    S(j) = A(j) + B(j) * (x - X(j)) + C(j) * ((x - X(j))^2);
    dS(j) = B(j) + 2 * C(j) * (x - X(j));
end

if strcmp(xvalue,'var')
    y = S;
    z = diff(S);
    return
end

if(isvector(xvalue))
    y = 1:size(xvalue,2);
    z = 1:size(xvalue,2);
    
    for i = 1:N
        Xj = find(xvalue >= X(i) & xvalue <= X(i+1));
        y(Xj) = subs(S(i),x,xvalue(Xj));
        z(Xj) = subs(dS(i),x,xvalue(Xj));
    end
else
    for i = 1:N
        if xvalue >= X(i) && xvalue <= X(i+1)
            y = subs(S(i),x,xvalue);
            z = subs(dS(i),x,xvalue);
            break;
        end
    end
end

clear S dS x
%}
%SplineC
%{
function [y, z, t] = SplineC(X, Y, fpa, fpb, xvalue)
N = size(X,2)-1;

A = 1:N;
C = 1:N;
D = 1:N;

A(1:N) = Y(1:N);

R = 1:N+1;
R = R.';
R(1) = fpa;
R(N+1) = fpb;
for i = 2:N
    R(i) = (-3) * Y(i-1)/((X(i)-X(i-1))^2) ...
            + Y(i) * (3/((X(i)-X(i-1))^2) - 3/((X(i+1)-X(i))^2)) ...
            + 3 * Y(i+1)/((X(i+1)-X(i))^2);
end
MB = zeros(N+1,N+1);
MB(1,1) = 1;
MB(N+1,N+1) = 1;
for i = 2:N
    MB(i,i-1) = 1/(X(i)-X(i-1));
    MB(i,i) = 2/(X(i+1)-X(i)) + 2/(X(i)-X(i-1));
    MB(i,i+1) = 1/(X(i+1)-X(i));
end

B = linsolve(MB,R);
B = B.';

for i = 1:N
    C(i) = 3*(Y(i+1)-Y(i))/((X(i+1)-X(i))^2) ...
            - (B(i+1)+2*B(i))/(X(i+1)-X(i));
end
for i = 1:N
    D(i) = (-2)*(Y(i+1)-Y(i))/((X(i+1)-X(i))^3)...
            + (B(i+1)+B(i))/((X(i+1)-X(i))^2);
end

syms S dS ddS x
S = sym('S',[1,N]);
dS = sym('dS',[1,N]);
ddS = sym('ddS',[1,N]);

for j = 1:N
    S(j) = A(j) + B(j) * (x - X(j)) + C(j) * ((x - X(j))^2) ...
                                    + D(j) * ((x - X(j))^3);
    dS(j) = B(j) + 2 * C(j) * (x - X(j)) + 3 * D(j) * ((x - X(j))^2);
    ddS(j) = 2 * C(j) + 6 * D(j) * (x - X(j));
end

if strcmp(xvalue,'var')
    y = S;
    z = diff(S);
    return
end

if(isvector(xvalue))
    y = 1:size(xvalue,2);
    z = 1:size(xvalue,2);
    t = 1:size(xvalue,2);
    
    for i = 1:N
        Xj = find(xvalue >= X(i) & xvalue <= X(i+1));
        y(Xj) = subs(S(i),x,xvalue(Xj));
        z(Xj) = subs(dS(i),x,xvalue(Xj));
        t(Xj) = subs(ddS(i),x,xvalue(Xj));
    end
else
    for i = 1:N
        if xvalue >= X(i) && xvalue <= X(i+1)
            y = subs(S(i),x,xvalue);
            z = subs(dS(i),x,xvalue);
            t = subs(ddS(i),x,xvalue);
            break;
        end
    end
end

clear S dS ddS x
%}
