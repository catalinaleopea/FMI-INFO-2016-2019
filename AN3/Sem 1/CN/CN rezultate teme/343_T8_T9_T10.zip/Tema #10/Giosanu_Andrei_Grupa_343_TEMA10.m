%Giosanu Andrei
%Grupa 343

% % % Undefined function or variable 'SplinePatratic'.
% % % 
% % % Error in Giosanu_Andrei_Grupa_343_TEMA10 (line
% % % 15)
% % % [S,dS] = SplinePatratic(X, Y, fpa, div);

n = 10;
a = -pi/2;
b = pi/2;
div = linspace(a, b, 100);
syms xsym;
f = @(x)sin(x);
df = matlabFunction(diff(f(xsym)));
X = linspace(a, b, n+1);
Y = f(X);
fpa = df(a);

[S,dS] = SplinePatratic(X, Y, fpa, div);
figure;
hold on;
plot(div,S,'-r');
plot(div,f(div), '--k');

figure;
hold on;
plot(div,dS,'-r');
plot(div,df(div), '--k');

n = 2;

[S,dS] = SplinePatratic(X, Y, fpa, div);
figure;
hold on;
plot(div,S,'-r');
plot(div,f(div), '--k');

figure;
hold on;
plot(div,dS,'-r');
plot(div,df(div), '--k');

n = 4;

[S,dS] = SplinePatratic(X, Y, fpa, div);
figure;
hold on;
plot(div,S,'-r');
plot(div,f(div), '--k');

figure;
hold on;
plot(div,dS,'-r');
plot(div,df(div), '--k');

%%%
n = 10;
a = -pi/2;
b = pi/2;
div = linspace(a, b, 100);
syms xsym;
f = @(x)sin(x);
df = matlabFunction(diff(f(xsym)));
ddf = matlabFunction(diff(df(xsym)));
X = linspace(a, b, n+1);
Y = f(X);
fpa = df(a);
fpb = df(b);
[S,dS, ddS] = SplineCubic(X, Y, fpa, fpb, div);

figure;
hold on;
plot(div,S,'-r');
plot(div,f(div), '--k');

figure;
hold on;
plot(div,dS,'-r');
plot(div,df(div), '--k');

figure;
hold on;
plot(div,dS,'-r');
plot(div,ddf(div), '--k');

n = 2;
figure;
hold on;
plot(div,S,'-r');
plot(div,f(div), '--k');

figure;
hold on;
plot(div,dS,'-r');
plot(div,df(div), '--k');

figure;
hold on;
plot(div,dS,'-r');
plot(div,ddf(div), '--k');

n = 4
figure;
hold on;
plot(div,S,'-r');
plot(div,f(div), '--k');

figure;
hold on;
plot(div,dS,'-r');
plot(div,df(div), '--k');

figure;
hold on;
plot(div,dS,'-r');
plot(div,ddf(div), '--k');