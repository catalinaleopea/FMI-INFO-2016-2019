%%
% ======================== EXERCITIUL 2 ===================================

f = @(x) sin(x);
a = -pi/2;
b = pi/2;
n = [2,4,10];
syms o
df = matlabFunction(diff(f(o)));

fpa = df(a);

for i = 1:length(n)

    X = linspace(a,b,n(i) + 1);
    Y = f(X);
    
    x = linspace(a,b);
    
    S = zeros(1,length(x));
    z = zeros(1,length(x));
    
    for j = 1:length(x)
       [S(j),z(j)] = SplineP(X,Y,fpa,x(j));
    end
    
    figure(2*i-1);
    
    plot(X,Y,'or');
    hold on
    plot(x,f(x),'b');
    plot(x,S,'g-.','LineWidth',1)
    
    legend({'Punctele (X,Y)',strcat('Graficul functiei f =',char(f)), ...
            'Rezultatul interpolarii Spline'},'Location','NorthWest');
    title(strcat('Interpolarea spline pentru n = ',num2str(n(i))));
    hold off
    
    figure(2*i)
    
    plot(X,df(X),'or');
    hold on
    plot(x,df(x),'b');
    plot(x,z,'g-.','LineWidth',1);
    
     legend({'Punctele (X,Z)',...
            strcat('Graficul derivatei functiei f =',char(df)), ...
            'Rezultatul interpolarii Spline pentru derivata'},...
            'Location','South');
    title(strcat('Interpolarea spline(derivata) pentru n = '...
            ,num2str(n(i))));
    
end

%% 
% ========================== EXERCITIUL 2 =================================
% ============= FUNCTIE SPLINE PATRATICA CU INPUT VECTOR ==================

f = @(x) sin(x);
a = -pi/2;
b = pi/2;
n = [2,4,10];

syms o
df = matlabFunction(diff(f(o)));

fpa = df(a);

for i = 1:length(n)

    X = linspace(a,b,n(i) + 1);
    Y = f(X);
    
    x = linspace(a,b);
        
    [S,z] = SplinePMod(X,Y,fpa,x);
        
    figure(2 * i - 1);
    
    plot(X,Y,'or');
    hold on
    plot(x,f(x),'b');
    plot(x,S,'g-.','LineWidth',1)
    
    legend({'Punctele (X,Y)',strcat('Graficul functiei f =',char(f)), ...
            'Rezultatul interpolarii Spline'},'Location','NorthWest');
    title(strcat('Interpolarea spline pentru n = ',num2str(n(i))));
    hold off
    
    figure(2 * i);
    
    plot(X,df(X),'or');
    hold on
    plot(x,df(x),'b');
    plot(x,z,'g-.','LineWidth',1);
    
     legend({'Punctele (X,Z)',...
            strcat('Graficul derivatei functiei f =',char(ddf)), ...
            'Rezultatul interpolarii Spline pentru derivata'},...
            'Location','South');
    title(strcat('Interpolarea spline(derivata) pentru n = '...
            ,num2str(n(i))));
    
end

%% ======================= EXERCITIUL 3 ===================================

f = @(x) sin(x);
a = -pi/2;
b = pi/2;
n = [2,4,10];
syms o
df = matlabFunction(diff(f(o)));
ddf = matlabFunction(diff(df(o)));

fpa = df(a);
fpb = df(b);

for i = 1:length(n)

    X = linspace(a,b,n(i) + 1);
    Y = f(X);
    
    x = linspace(a,b);
    
    S = zeros(1,length(x));
    z = zeros(1,length(x));
    t = zeros(1,length(x));
    
    for j = 1:length(x)
       [S(j),z(j),t(j)] = SplineC(X,Y,fpa,fpb,x(j));
    end
    
    figure(3*i-2);
    
    plot(X,Y,'or');
    hold on
    plot(x,f(x),'b');
    plot(x,S,'g-.','LineWidth',1)
    
    legend({'Punctele (X,Y)',strcat('Graficul functiei f =',char(f)), ...
            'Rezultatul interpolarii cubice Spline'},...
            'Location','NorthWest');
    title(strcat('Interpolarea spline pentru n = ',num2str(n(i))));
    hold off
    
    figure(3*i - 1)
    
    plot(X,df(X),'or');
    hold on
    plot(x,df(x),'b');
    plot(x,z,'g-.','LineWidth',1);
    
     legend({'Punctele (X,Z)',...
            strcat('Graficul derivatei functiei f =',char(df)), ...
            'Rezultatul interpolarii Spline cubice pentru derivata'},...
            'Location','South');
    title(strcat('Interpolarea spline(derivata) pentru n = '...
            ,num2str(n(i))));
    
        
    figure(3*i)
    
    plot(X,ddf(X),'or');
    hold on
    plot(x,ddf(x),'b');
    plot(x,t,'g-.','LineWidth',1);
    
    legend({'Punctele (X,T)',...
         strcat('Graficul derivatei 2 a functiei f =',char(ddf)), ...
         'Rezultatul interpolarii Spline cubice pentru derivata a 2 a'},...
         'Location','South');
    title(strcat('Interpolarea spline(derivata a 2 -a ) pentru n = '...
            ,num2str(n(i))));
    
end


%% ======================= EXERCITIUL 3 ===================================
% ============= FUNCTIE SPLINE CUBICA CU INPUT VECTOR =====================

f = @(x) sin(x);
a = -pi/2;
b = pi/2;
n = [2,4,10];
syms o
df = matlabFunction(diff(f(o)));
ddf = matlabFunction(diff(df(o)));

fpa = df(a);
fpb = df(b);

for i = 1:length(n)

    X = linspace(a,b,n(i) + 1);
    Y = f(X);
    
    x = linspace(a,b);
    
    S = zeros(1,length(x));
    z = zeros(1,length(x));
    t = zeros(1,length(x));
    
    [S,z,t] = SplineCMod(X,Y,fpa,fpb,x);
    
    figure(3*i-2);
    
    plot(X,Y,'or');
    hold on
    plot(x,f(x),'b');
    plot(x,S,'g-.','LineWidth',1)
    
    legend({'Punctele (X,Y)',strcat('Graficul functiei f =',char(f)), ...
            'Rezultatul interpolarii cubice Spline'},...
            'Location','NorthWest');
    title(strcat('Interpolarea spline pentru n = ',num2str(n(i))));
    hold off
    
    figure(3*i - 1)
    
    plot(X,df(X),'or');
    hold on
    plot(x,df(x),'b');
    plot(x,z,'g-.','LineWidth',1);
    
     legend({'Punctele (X,Z)',...
            strcat('Graficul derivatei functiei f =',char(df)), ...
            'Rezultatul interpolarii Spline cubice pentru derivata'},...
            'Location','South');
    title(strcat('Interpolarea spline(derivata) pentru n = '...
            ,num2str(n(i))));
    
        
    figure(3*i)
    
    plot(X,ddf(X),'or');
    hold on
    plot(x,ddf(x),'b');
    plot(x,t,'g-.','LineWidth',1);
    
    legend({'Punctele (X,T)',...
         strcat('Graficul derivatei 2 a functiei f =',char(ddf)), ...
         'Rezultatul interpolarii Spline cubice pentru derivata a 2 a'},...
         'Location','South');
    title(strcat('Interpolarea spline(derivata a 2 -a ) pentru n = '...
            ,num2str(n(i))));
    
end

%%

function [y,z,t] = SplineC(X,Y,fpa,fpb,x)

n = length(X) - 1;
coef = zeros(1,n+1);

coef(1) = fpa;
coef(end) = fpb;

h = X(1,2:end) - X(1,1:end-1);

for j = 2:n
   coef(j) =  (3/(h(j))) * (Y(j+1) - Y(j-1));
end

epsilon = 10^(-8);

B = zeros(n+1,n+1);

B(1,1) = 1;
B(end,end) = 1;

for i = 2:n
    B(i,i-1) = 1;
    B(i,i) = 4;
    B(i,i+1) = 1;
end

a = Y;

[b,~] = MetJacobiDDL(B,coef,epsilon);

c = zeros(1,n);
d = c;

for j = 1:n
   dif = Y(j+1) - Y(j);
   d(j) = - 2/( (h(j))^3) * dif + (1/(h(j) ^2)) *(b(j+1)+b(j));
   c(j) = (3/( (h(j))^2)) * dif - ( (b(j+1) + 2*b(j))/h(j));
end



for i = 1:n
	if X(i) <= x && x < X(i+1)
		break;
	end
end


y = a(i) + b(i) * (x - X(i)) + c(i) * ((x - X(i))^2) + d(i) * ...
        ((x-X(i))^3);
    
z = b(i) + 2 * c(i) * (x - X(i)) + 3 * d(i) * ( (x - X(i))^2);

t = 2 * c(i) + 6 * d(j) * (x - X(i));

end

function [y,z,t] = SplineCMod(X,Y,fpa,fpb,x)

n = length(X) - 1;
coef = zeros(1,n+1);

coef(1) = fpa;
coef(end) = fpb;

h = X(1,2:end) - X(1,1:end-1);

for j = 2:n
   coef(j) =  (3/(h(j))) * (Y(j+1) - Y(j-1));
end

epsilon = 10^(-8);

B = zeros(n+1,n+1);

B(1,1) = 1;
B(end,end) = 1;

for i = 2:n
    B(i,i-1) = 1;
    B(i,i) = 4;
    B(i,i+1) = 1;
end

a = Y;

[b,~] = MetJacobiDDL(B,coef,epsilon);

c = zeros(1,n);
d = c;

for j = 1:n
   dif = Y(j+1) - Y(j);
   d(j) = - 2/( (h(j))^3) * dif + (1/(h(j) ^2)) *(b(j+1)+b(j));
   c(j) = (3/( (h(j))^2)) * dif - ( (b(j+1) + 2*b(j))/h(j));
end

y = zeros(1,length(x));
z = y;
t = y;

for j = 1:length(x)
    
    for i = 1:n
        if X(i) <= x(j) && x(j) < X(i+1)
            break;
        end
    end
    
    y(j) = a(i) + b(i) * (x(j) - X(i)) + c(i) * ...
    ((x(j) - X(i))^2) + d(i) * ((x(j)-X(i))^3);
    
    z(j) = b(i) + 2 * c(i) * (x(j) - X(i)) + 3 * d(i) * ( (x(j) - X(i))^2);

    t(j) = 2 * c(i) + 6 * d(i) * (x(j) - X(i));
end



end

function [xaprox,N] = MetJacobiDDL(A,a,epsilon)

    n = length(A);
    Ac = abs(A);
    
    for i = 1:n
        if i == 1
            suma = sum(Ac(i,2:end));
        elseif i == n
            suma = sum(Ac(i,1:end-1));
        else
            suma = sum(Ac(i,1:i-1)) + sum(Ac(i,i+1:end));
        end
        
        if Ac(i,i) <= suma
           disp('Matricea nu este diagonal dominanta pe linii');
           xaprox = inf;
           N = inf;
           return;
        end
    end
    
    x0 = zeros(length(A),1);
    
    B = zeros(size(A));
    b = zeros(length(A),1);
    
    for i = 1:n
        
        for j = 1:n
           if i == j
               B(i,j) = 0;
           else
               B(i,j) = - A(i,j) / A(i,i);
           end
        end
           
        b(i) = a(i) / A(i,i);
    end
    
    q = norm(B,inf);

    x1 = B * x0 + b;
      
    x = x1;
    
    k = 1;
   
    while true
        k = k + 1;
        
        x = B * x + b;
        
        if( (q^k/(1 - q)) * norm(x1 - x0,inf) < epsilon)
            break;
        end
        
      end
      
    xaprox = x;
    N = k;

end

function [y,z] = SplineP(X,Y,fpa,x)

n = length(X)-1;
a = Y;

h = X(1,2:end) - X(1,1:end-1);

b = zeros(1,n);
c = b;

b(1) = fpa;

for j = 1:n
   b(j + 1) = (2/(h(j))) *(Y(j+1) - Y(j)) - b(j);
   c(j) = (1/(h(j)^2)) * (Y(j+1) - Y(j) - h(j) * b(j));
end

c(n) = (1/(h(n)^2)) * (Y(n+1) - Y(n) - h(n) * b(n));

for i = 1:n
	if X(i) <= x && x < X(i+1)
		break;
	end
end

y = a(i) + b(i) * (x - X(i)) + c(i) * ((x - X(i)) ^ 2);
z = b(i) + 2 * c(i) * (x - X(i));

end


function [y,z] = SplinePMod(X,Y,fpa,x)
 n = length(X)-1;
a = Y;

h = X(1,2:end) - X(1,1:end-1);

b = zeros(1,n);
c = b;

b(1) = fpa;

for j = 1:n
   b(j + 1) = (2/(h(j))) *(Y(j+1) - Y(j)) - b(j);
   c(j) = (1/(h(j)^2)) * (Y(j+1) - Y(j) - h(j) * b(j));
end

c(n) = (1/(h(n)^2)) * (Y(n+1) - Y(n) - h(n) * b(n));

y = zeros(1,length(x));
z = y;


for i = 1:length(x)
     
    for j = 1:n
         if X(j) <= x(i) && x(i) < X(j+1)
             break;
         end
    end
    
    y(i) = a(j) + b(j) * (x(i) - X(j)) + c(j) * ((x(i) - X(j)) ^ 2);
    z(i) = b(j) + 2 * c(j) * (x(i) - X(j));
end

end
