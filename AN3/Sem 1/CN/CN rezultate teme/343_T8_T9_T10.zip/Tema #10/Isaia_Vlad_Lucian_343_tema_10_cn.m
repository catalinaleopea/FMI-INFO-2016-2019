%% Exercitiul 2
close all;
clear;
% subpunctul b)
f = @(x) sin(x);
syms x;
df = diff(f, x);
clear x;
df = @(x) double(subs(df, x));

n = [2, 4, 10];

len_n = length(n);

a = -pi/2;
b = pi/2;

X = cell(len_n, 1);
Y = cell(len_n, 1);

for i = 1:len_n
    X(i) = { linspace(a, b, n(i)+1) };
    Y(i) = { f(X{i}) };
end

discretizare = 100;

x = linspace(a, b, discretizare);

S = zeros(len_n, discretizare);
dS = zeros(len_n, discretizare);

for i = 1:len_n
%     for j = 1:discretizare
%        S(i, j) = SplineP(X{i}, Y{i}, df(a), x(j));
%     end
    [S(i, :), dS(i, :)] = SplineP(X{i}, Y{i}, df(a), x);
end

for i = 1:len_n
    figure(i);
    plot(x, f(x));
    hold on;
    title(['{\color{blue}f(x) = sin(x);','\color{red}Interpolarea liniara SplineP n = ' num2str(n(i)) ';}'],'interpreter','tex');
    plot(x, S(i, :));
end

%subpunctul c)
figureCount = len_n + 1;

for i = 1:len_n
    figure(figureCount);
    figureCount = figureCount + 1;
    plot(x, df(x));
    hold on;
    title(['{\color{blue}df(x) = cos(x);','\color{red}Interpolarea liniara SplineP derivata n = ' num2str(n(i)) ';}'],'interpreter','tex');
    plot(x, dS(i, :));
end

%% Exercitiul 3
close all;
clear;
%subpunctul b)
f = @(x) sin(x);
syms x;
df = diff(f, x);
ddf = diff(df, x);
clear x;
df = @(x) double(subs(df, x));
ddf = @(x) double(subs(ddf, x));

n = [2, 4, 10];

len_n = length(n);

a = -pi/2;
b = pi/2;

X = cell(len_n, 1);
Y = cell(len_n, 1);

for i = 1:len_n
    X(i) = { linspace(a, b, n(i)+1) };
    Y(i) = { f(X{i}) };
end

discretizare = 100;

x = linspace(a, b, discretizare);

S = zeros(len_n, discretizare);
dS = zeros(len_n, discretizare);
ddS = zeros(len_n, discretizare);

for i = 1:len_n
%     for j = 1:discretizare
%        [S(i, j), dS(i, j), ddS(i, j)] = SplineC(X{i}, Y{i}, df(a), df(b), x(j));
%     end
    [S(i, :), dS(i, :), ddS(i, :)] = SplineC(X{i}, Y{i}, df(a), df(b), x);
end

for i = 1:len_n
    figure(i);
    plot(x, f(x));
    hold on;
    title(['{\color{blue}f(x) = sin(x);','\color{red}Interpolarea liniara SplineC n = ' num2str(n(i)) ';}'],'interpreter','tex');
    plot(x, S(i, :));
end

%subpunctul c)
figureCount = len_n + 1;

for i = 1:len_n
    figure(figureCount);
    figureCount = figureCount + 1;
    plot(x, df(x));
    hold on;
    title(['{\color{blue}df(x) = cos(x);','\color{red}Interpolarea liniara SplineC derivata o data, n = ' num2str(n(i)) ';}'],'interpreter','tex');
    plot(x, dS(i, :));
end

%subpunctul d)
figureCount = figureCount + 1;

for i = 1:len_n
    figure(figureCount);
    figureCount = figureCount + 1;
    plot(x, ddf(x));
    hold on;
    title(['{\color{blue}ddf(x) = -sin(x);','\color{red}Interpolarea liniara SplineC derivata de doua ori, n = ' num2str(n(i)) ';}'],'interpreter','tex');
    plot(x, ddS(i, :));
end
%% Functii ajutatoare
function [y, z] = SplineP(X, Y, fpa, x)
    n = length(X) - 1;
    
    h = X(2:n+1) - X(1:n);
    
    a = Y(1:n);
    b = zeros(1, n);
    c = zeros(1, n);

    b(1) = fpa;
    b(2:n) = 2 ./ h(1:n-1) .* (Y(2:n) - Y(1:n-1)) - b(1:n-1);
    c(1:n) = 1 ./ h(1:n).^2 .* (Y(2:n+1) - Y(1:n) - h(1:n) .* b(1:n));
    %subpunctul 2 d)
    %modificat sa mearga si pe vectori
%     for j = 1:n
%         if X(j) <= x && x <= X(j+1)
%             y = a(j) + b(j) * (x - X(j)) + c(j) * (x - X(j)).^2;
%             z = b(j) + 2 * c(j) * (x - X(j));
%             
%             return;
%         end
%     end

    m = length(x);
    
    y = zeros(1, m);
    z = zeros(1, m);

    for j = 1:n
        indices = find(X(j) <= x & x <= X(j+1));

        y(indices) = a(j) + b(j) * (x(indices) - X(j)) + c(j) * (x(indices) - X(j)).^2;
        z(indices) = b(j) + 2 * c(j) * (x(indices) - X(j));
    end
end

function [y, z, t] = SplineC(X, Y, fpa, fpb, x)
    n = length(X) - 1;
    
	h = X(2:n+1) - X(1:n);

    a = Y(1:n);
    b = zeros(1, n+1);
    
    B = zeros(n+1, n+1);
    B(1, 1) = 1;
    for i = 2:n
        B(i, :) = [zeros(1, i-2) [1 4 1] zeros(1, n-i)];
    end
    B(n+1, n+1) = 1;
    
    b_ = zeros(1, n+1);
    b_(1) = fpa;
    b_(2:n) = 3./h(2:n) .* (Y(3:n+1) - Y(1:n-1));
    b_(n+1) = fpb;
    
    c = zeros(1, n);
    d = zeros(1, n);
    
    epsilon = 10^-8;
    
    [b, ~] = MetJacobiDDL(B, b_, epsilon);
    b = b';

    c(1:n) = 3 ./ h(1:n).^2 .* (Y(2:n+1) - Y(1:n)) - (b(2:n+1) + 2 * b(1:n)) ./ h(1:n);
    d(1:n) = -2 ./ h(1:n).^3 .* (Y(2:n+1) - Y(1:n)) + 1 ./ h(1:n).^2 .* (b(2:n+1) + b(1:n));

    m = length(x);
    
    y = zeros(1, m);
    z = zeros(1, m);
    t = zeros(1, m);
    %subpunctul 2e, merge si pentru vectori si pentru un element
    for j = 1:n
        indices = find(X(j) <= x & x <= X(j+1));

        y(indices) = a(j) + b(j) * (x(indices) - X(j)) + c(j) * (x(indices) - X(j)).^2 + d(j) * (x(indices) - X(j)).^3;
        z(indices) = b(j) + 2 * c(j) * (x(indices) - X(j)) + 3 * d(j) * (x(indices) - X(j)).^2;
        t(indices) = 2 * c(j) + 6 * d(j) * (x(indices) - X(j));
    end
end

function [x_aprox, N] = MetJacobiDDL(A, a, epsilon)
    n = size(A, 1);
    
    for i = 1:n
        if abs(A(i, i)) <= sum(abs(A(i, :))) - abs(A(i, i))
            disp("Matricea nu este diagon dominanta pe linii");
            
            x_aprox = 0;
            N = -1;
            
            return;
        end
    end
    
    x(1:n, 1) = 0;
    k = 1;
    
    b = zeros(n, 1);
    B = zeros(n, n);
    
    for i = 1:n
        for j = 1:n
            if i == j
                B(i, j) = 0;
            else
                B(i, j) = -A(i, j) / A(i, i);
            end
        end
        b(i) = a(i) / A(i, i);
    end
    
    q = norm(B, inf);
    
    cond = 1;
    
    while cond ~= 0
        k = k+1;
        x(:, k) = B * x(:, k-1) + b;
        
        if q^k / (1-q) * norm(x(:, 2) - x(:, 1), inf) < epsilon
            cond = 0;
        end
    end
    
    x_aprox = x(:, k);
    N = k-1;
end
