% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'X'       = nodurile de interpolare
% 'Y'       = valorile functiei f in nodurile de interpolare
% 'x'       = punctul pentru care se calculeaza interpolarea
% -------------------------------------------------------------------------
% Date de iesire:
% 'y'       = valoarea interpolata
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [y] = MetNeville(X, Y, x)
    n = length(X);
    Q = zeros(n);

    for i = 1 : n
        Q(i, 1) = Y(i);
    end
    
    for i = 2 : n
        for j = 2 : i
            Q(i, j) = ((x - X(i - j + 1)) * Q(i, j - 1) - (x - X(i)) * Q(i - 1, j - 1)) / (X(i) - X(i - j + 1));
        end
    end
    
    y = Q(n, n);
end
