% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'X'       = nodurile de interpolare
% 'Y'       = valorile functiei f in nodurile de interpolare
% 'x'       = punctul pentru care se calculeaza interpolarea
% -------------------------------------------------------------------------
% Date de iesire:
% 'y'       = valoarea interpolata
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [y] = MetNDD(X, Y, x)
    n = length(X);
    Q = zeros(n);

    for i = 1 : n
        Q(i, 1) = Y(i);
    end
    
    for i = 2 : n
        for j = 2 : i
            Q(i, j) = (Q(i, j - 1) - Q(i - 1, j - 1)) / (X(i) - X(i - j + 1));
        end
    end
    
    Pn = Q(1, 1);
    for k = 2 : n
        p = Q(k, k);
        for i = 1 : k - 1
            p = p * (x - X(i));
        end
        Pn = Pn + p;
    end
    
    y = Pn;
end
