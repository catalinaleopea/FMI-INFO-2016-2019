function [ y ] = MetHermite( X, Y, Z, x )
n = length(X) - 1;
y = 0;
for k = 1:n+1
    L = 1;
    Lp = 0;
    for j = 1:n+1
        if j~=k
            L =  L * ((x-X(j))/(X(k)-X(j)));
            Lp = Lp + 1/(X(k) - X(j));
        end
    end
    Hk = ((L^2)*(1-2*Lp*(x-X(k))));
    K = (L^2) * (x - X(k));
    
    y = y + Hk*Y(k) + K*Z(k);
end
end

