% Total: 8/10

%% Exercitiul 6
f = @(x) sin(x);

n = 3;

a = -pi/2;
b = pi/2;

X = linspace(a, b, n+1);
Y = f(X);

x = linspace(a, b, 100);
y = f(x);

y_Pn = zeros(1, 100);

for i = 1 : 100
    y_Pn(i) = MetNeville(X, Y, x(i));
end

figure(1);
plot(x, y);
hold on;
plot(x, y_Pn);

%%  Functii ajutatoare
function [y] = MetNeville(X, Y, x)
    n = length(X) - 1;
    Q = zeros(n+1, n+1);
    
    %if length(x) > 1
    %    Q = zeros(n+1, n+1, length(x));
    %end
    
    for i = 1 : n+1
        Q(i, 1) = Y(i);
    end
    
    for i = 2 : n+1
        for j = 2 : i
            Q(i, j) = ((x - X(i-j+1)) * Q(i, j-1) - (x - X(i)) * Q(i-1, j-1))/(X(i) - X(i-j+1));
        end
    end
    
    y = Q(n+1, n+1);
end

function [y] = MetNDD(X, Y, x)
    n = length(X) - 1;
    Q = zeros(n+1, n+1);
    
    for i = 1 : n+1
        Q(i, 1) = Y(i);
    end
    
    for i = 2 : n+1
        for j = 2 : i
            Q(i, j) = (Q(i, j-1) - Q(i-1, j-1))/(X(i) - X(i-j+1));
        end
    end
    
    sum = 0;
    
    for k = 2 : n+1
        prod = Q(k, k);
    
        for k2 = 2 : k-1
            prod = prod * (x - X(k));
        end
        
        sum = sum + prod;
    end
    
    y = Q(1, 1) + sum;
end

function [y, z] = MetHermite(X, Y, Z, x)
    
end