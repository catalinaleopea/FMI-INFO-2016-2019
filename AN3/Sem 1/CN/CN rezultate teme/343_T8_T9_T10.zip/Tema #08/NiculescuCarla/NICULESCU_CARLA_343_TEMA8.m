%%
% Ex.5.
% subpunctul 2) cu Metoda Neville------------------------------------------
f = @(x)sin(x);
a = -pi/2;
b = pi/2; 
n = 3;
%diviziunea echidistanta cu n+1 = 4 puncte => norma este (pi/2 - (-pi/2)) / 3  = pi/3;
X = linspace(a, b, n+1); 
Y = f(X); 

Xgrafic = linspace(a, b, 100);
for i = 1:length(Xgrafic)
   Ygrafic(i) = MetNeville(X, Y, Xgrafic(i));
end

figure
plot(X, Y, 'Linewidth', 3) %Constructia graficului  functiei f
hold on
plot(X, Y, 'o', 'MarkerFaceColor', 'r'); %Plotare puncte (Xi, Yi) pe graficul lui f
plot (Xgrafic, Ygrafic, 'LineWidth', 3); %Constructia polinomului Pn

legend("Grafic f = sin(x)", "Punct (Xi, Yi)","Pn-Neville", 'Location', 'southeast');
title("Grafic f, puncte (Xi, Yi) si Pn - Neville");

%subpunctul 3)
figure
plot (Xgrafic, abs(f(Xgrafic)-Ygrafic));
title("Grafic eroare abs(f - Pn)");
%%

% subpunctul 2) cu Metoda Newton cu diferente divizate---------------------

f = @(x)sin(x);
a = -pi/2;
b = pi/2; 
n = 3;
%diviziunea echidistanta cu n+1=4 noduri=> norma este (pi/2 - (-pi/2)) / 3  = pi/3;
X = linspace(a, b, n+1); 
Y = f(X); 

Xgrafic = linspace(a, b, 100);
for i = 1:length(Xgrafic)
    Ygrafic(i) = MetNewtonDD(X, Y, Xgrafic(i));
end

figure(1)
plot(X, Y, 'Linewidth', 3) %Constructia graficului  functiei f
hold on
plot(X, Y, 'o', 'MarkerFaceColor', 'r'); %Plotare puncte (Xi, Yi)
plot (Xgrafic, Ygrafic, 'LineWidth', 3); %Plotare polinom Pn

legend("Grafic f = sin(x)", "Punct (Xi, Yi)", "Pn", 'Location', 'southeast');
title("Grafic f, puncte (Xi, Yi) si Pn-NewtonDD");

%subpunctul 3)
figure(2)
plot (Xgrafic, abs(f(Xgrafic)-Ygrafic));
title("Grafic eroare abs(f - Pn)");

%%
%subpunctul 2) - Metoda Hermite 
f = @(x)sin(x);
a = -pi/2;
b = pi/2;
n = 3;
X = linspace(a,b,n+1);
Y = f(X);
fprim = @(x)cos(x);

Z = fprim(X);
Xgrafic = linspace(a, b, 100);
for i = 1:length(Xgrafic)
    Ygrafic(i) = MetHermite(X, Y, Z, Xgrafic(i));
end

figure(1)
plot(X, Y, 'Linewidth', 3) %Constructia graficului  functiei f
hold on
plot(X, Y, 'o', 'MarkerFaceColor', 'r'); %plotare puncte (Xi, Yi)
plot (Xgrafic, Ygrafic, 'LineWidth', 3); %grafic polinom Pn
title("Grafic f, puncte (Xi, Yi) si Pn - Hermite");

%reprezentare grafica f' si derivata polinomului Hermite Pn
figure(2)
%plot (X, Z,'o', 'MarkerFaceColor', 'b');
plot(X, Z, 'Linewidth',3)
hold on;
plot (Xgrafic(1:length(Xgrafic)-1), diff(Ygrafic)./diff(Xgrafic));
title("f' si derivata polinomului Hermite calculat numeric");
legend("f'(x) = cos(x)", "derivata polinomului Hermite", 'Location', 'southeast');

%subpunctul 3) grafic eroare 
figure(3)
plot (Xgrafic, abs(f(Xgrafic)-Ygrafic));
title("Grafic eroare abs(f - Pn)");

%%

%Ex5. Metoda Neville, conform algoritmului din Curs 8.
function [Pn] = MetNeville(X,Y,x)
    n = length(X) - 1;
    Q = zeros(n+1, n+1);
    for i = 1:n+1
        Q(i,1) = Y(i);
    end
    
    for i= 2:n+1
        for j = 2:i
            Q(i,j) = ((x-X(i-j+1))*Q(i,j-1) - (x-X(i))*Q(i-1,j-1))/(X(i) - X(i-j+1));
        end
    end
    
    Pn = Q(n+1,n+1);
end

%Ex5. Metoda Newton cu diferente divizate
 function [Pn] = MetNewtonDD (X,Y,x)  
     n = length(X) - 1;  
     Q = zeros(n+1, n+1);
     for i = 1:n+1      
         Q(i,1) = Y(i); 
     end
     for i= 2:n+1  
         for j = 2:i  
             Q(i,j) = (Q(i,j-1)-Q(i-1,j-1))/(X(i) - X(i-j+1));
         end
     end

     s = 0;
     for k=2:n+1  
         p = 1;   
         for j=1:k-1      
             p= p* (x-X(j));      
         end
         s= s + Q(k,k)*p; 
     end
        Pn = Q(1,1) + s;    
 end

%Ex.5. - Metoda Hermite
function H = MetHermite(X,Y,Z,x)
    n = length(X) - 1;
    H = 0;
    for k=1:n+1
        L=1;
        Lp = 0;
        for j = 1:n+1
            if j~=k
                L = L* ((x-X(j))/(X(k)-X(j)));
                Lp = Lp + 1/(X(k) - X(j));
            end 
        end
        Hk = ((L^2)*(1-2*Lp*(x-X(k))));
        K = (L^2) *(x-X(k));
        
        H = H + Hk*Y(k) + K*Z(k);
    end
end
