% Lina Cristian 343 - Tema8

%% Exercitiul 5

f = @(x) sin(x);
syms x;
fd = matlabFunction(diff(f(x)));
a = (-1)*pi/2; b = pi/2; n = 3;
X = linspace(a,b,n+1); Y = f(X); Q = fd(X);
figure(1);
plot(X, Y, '--r');
hold on;
W = linspace(a,b,100);
Q = fd(X);
for i = 1:length(W)
   Z(i) = MetNeville(X,Y,W(i));
   T(i) = MetNewtonDD(X,Y,W(i));
   S(i) = MetHermite(X, Y, Q, W(i));
end
plot(W,Z,'*b');
plot(W,T,'og');
plot(W,S,'y');
plot(W, abs(f(W)-Z),'*r');
plot(W, abs(f(W)-T),'oblack');
plot(W, abs(f(W)-S),'c');
legend("f", "f neville", "f newtonDD", "f hermite", "er neville", "er newtonDD", "er hermite",...
    'location', 'NorthWest');

%% Functii (am cerut ajutor de la colegi, dar de scris eu le-am scris)
% nu am stiut sa calculez si z-ul fara valoare simbolica alui x care facea rularea
% sa dureze foarte mult
function [y] = MetHermite(X,Y,Z,x)
    n = length(X) - 1;
    y = 0;
    for i = 1:(n+1)
        sum = 0; pro = 1;
        for j = 1:(n+1)
            if(i~=j)
                pro = pro*((x-X(j))/(X(i)-X(j)));
                sum = sum + 1/(X(i) - X(j));
            end 
        end  
        y = y + ((pro^2)*(1-2*sum*(x-X(i))))*Y(i) + (pro^2) *(x-X(i))*Z(i);        
    end
end

 function [sum] = MetNewtonDD (X,Y,x)  
     n = length(X) - 1;  
     Q = zeros(n+1);
     for i = 1:n+1      
         Q(i,1) = Y(i); 
     end
     for i= 2:n+1  
         for j = 2:i  
             Q(i,j) = (Q(i,j-1)-Q(i-1,j-1))/(X(i) - X(i-j+1));
         end
     end
     sum = Q(1,1);
     for i = 2:(n+1)
         pro = 1;   
         for j = 1:(i-1)
             pro = pro*(x-X(j));      
         end
         sum = sum + Q(i,i)*pro; 
     end
 end

function [P] = MetNeville(X,Y,x)
    n = length(X) - 1;
    Q = zeros(n+1);
    for i = 1:n+1
        Q(i,1) = Y(i);
    end    
    for i= 2:n+1
        for j = 2:i
            Q(i,j) = ((x-X(i-j+1))*Q(i,j-1) - (x-X(i))*Q(i-1,j-1))/(X(i) - X(i-j+1));
        end
    end    
    P = Q(n+1,n+1);
end


