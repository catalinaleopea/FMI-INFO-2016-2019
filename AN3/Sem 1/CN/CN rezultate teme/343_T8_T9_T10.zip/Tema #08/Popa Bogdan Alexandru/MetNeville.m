% am implementat algoritmul de determinare a polinomului lagrange Pn prin
% metoda Neville urmarind algoritmul din cursul 8 pag.6.Metoda primeste ca
% date de intrare un interval in X si in Y rezultatul functiei studiate in
% punctele din X, in x primeste necunoscuta polinomului, iar ca date de
% iesire valoarea polinomului y
function [y] = MetNeville(X,Y,x)
n = length(X)-1; % gradul polinomului Pn
Q = zeros(n+1); % prealocam y
for i = 1:n+1 % initiem Q cu valorile lui Y conform algoritmului
    Q(i,1) = Y(i);
end
for i = 2:n+1 % determinam matricea Q conform algoritmului
    for j=2:i
        % calculam valorile polinomului conform algoritmului
        Q(i,j) = ((x - X(i-j+1))*Q(i,j-1)-(x - X(i))*Q(i-1,j-1))/(X(i)- ...
        X(i-j+1));
    end
end
y = Q(n+1,n+1); % pastram in y valoarea polinomului in punctul x