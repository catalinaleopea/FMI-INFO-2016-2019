% am implementat algoritmul de determinare a polinomului lagrange Pn prin
% metoda Neville urmarind algoritmul din cursul 8 pag.17.Metoda primeste ca
% date de intrare un interval in X si in Y rezultatul functiei studiate in
% punctele din X, in x primeste necunoscuta polinomului, iar ca date de
% iesire valoarea polinomului y
function y = MetNDD(X,Y,x)
n = length(X)- 1; % gradul polinomului Pn
Q = zeros(n+1); % prealocam Q
for i = 1:n+1 % initiem Q cu valorile lui Y conform algoritmului
    Q(i,1) = Y(i);
end
for i = 2:n+1 % determinam matricea Q conform algoritmului
    for j=2:i
        Q(i,j) =(Q(i,j-1)-Q(i-1,j-1))/(X(i) - X(i-j+1));
    end
end
Pn = Q(1,1); % initiem Pn cu Q(1,1)
for k = 2:n+1 % calculam in Pn valoarea polinomului conform algoritmului
    p = 1;
    for j = 1:k-1
        p = p * (x-X(j));
    end
    Pn = Pn + Q(k,k) * p;
end
y=Pn; % returnam polinomul
end