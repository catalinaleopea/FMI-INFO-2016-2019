% am implementat algoritmul de Interpolare Hermite e urmarind metoda
% din cursul 8 pag.18-22.Metoda primeste ca date de intrare un interval 
% in X, in Y rezultatul functiei studiate in punctele din X si in Z
% rezultatul derivatei functiei studiate in punctele din X,
% in x primeste necunoscuta polinomului, iar ca date de iesire
% valoarea polinomului y si in z valoarea derivatei prin metoda Hermite
function [y,z] = MetHermite(X,Y,Z,x)
n = length(X)-1; % gradul polinomului
H = 0; % initializam suma H cu 0
syms t;
for k = 1:n+1 % vom parcurge toate elementele lui X
    L = 1; % initializam produsul L cu 1
    Lk = 0; % initializam suma Lk
    for j = 1:n+1 % parcurgem elementele lui X
        if j~=k 
            % cand avem j != k calculam simbolic L si Lk conform metodei
            L = L*((t-X(j))/(X(k)-X(j)));
            Lk = Lk + 1/(X(k)-X(j));
        end
    end
    Hk = ((L^2)*(1-2*Lk*(t-X(k)))); % calculam Hk simbolic conform metodei
    Kk = (L^2)*(t-X(k)); % calculam Kk simbolic conform metodei
    
    H = H+Hk*Y(k)+Kk*Z(k); % adaugam Hk si Kk sumei H
end
z = diff(H,1); % folosind H pastram derivata simbolica in z
y_ = matlabFunction(H,t); % transformam H in functie handle
z_ = matlabFunction(z,t); % transformam z in functie handle
[y,~] = y_(x); % calculam y in x
[z,~] = z_(x); % calculam derivata lui y in x, z
end