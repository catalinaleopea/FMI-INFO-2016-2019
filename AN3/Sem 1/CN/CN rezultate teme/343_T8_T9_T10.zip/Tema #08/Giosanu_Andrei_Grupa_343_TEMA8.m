% OK, si eu acum ce fac? Ghicesc ce exercitii ai rezolvat? Fii si tu mai
% ordonat! 
% Total: 3.5/10


%Giosanu Andrei
%Grupa 343

n = 3;
a = -pi/2;
b = pi/2;
div = linspace(a, b, 100);
syms xsym;
f = @(x)sin(x);
df = matlabFunction(diff(f(xsym)));
X = linspace(a, b, n+1);
Y = f(X);
Z = df(X);
[H, dH] = MetHermite(X,Y,Z,xsym);
figure, hold on;
plot(div, f(div), '-r');
plot(div, subs(H,xsym,div), '--k');
figure, hold on;
plot(div, df(div), '-r');
plot(div, subs(dH, xsym, div), '--k');

figure; 
hold on;
rez = MetNDD(X,Y, div);
plot(div,f(div), '-r');
plot(div, MetNDD(X,Y, div), 'k--');

figure; 
hold on;
plot(div,f(div), '-r');
for i=1:length(div)
    r(i) = MetNeville(X,Y, div(i));
end
plot(div,r , 'k--');

figure;
E = f(div) - rez;
plot(E);

function y = MetNDD(X,Y,x)
    n = length(X)- 1;
    for i = 1:n+1
        Q(i,1) = Y(i);
    end
    for i = 2:n+1
        for j=2:i
            Q(i,j) =(Q(i,j-1)-Q(i-1,j-1))/(X(i) - X(i-j+1));
        end
    end
    Pn = Q(1,1);
    for k = 2:n+1
        p = 1;
        for j = 1:k-1
            p = p .* (x-X(j));
        end
        Pn = Pn + Q(k,k) * p;
    end
    y=Pn;
end

function y = MetNeville(X,Y,x)
    n = length(X)- 1;
    for i = 1:n+1
        Q(i,1) = Y(i);
    end
    for i = 2:n+1
        for j=2:i
            Q(i,j) = ((x - X(i-j+1))*Q(i,j-1) - (x-X(i))*Q(i-1,j-1))/(X(i) - X(i-j+1));
        end
    end
    Pn = Q(n+1, n+1);
    y=Pn;
end

function [H, dH] = MetHermite(X, Y, Z, xsym)
N = length(X) - 1;
H = sym(0);
for k = 1:N+1
    L = sym(1);
    for i = 1:N+1
        if i ~= k
            L = L * ((xsym - X(i))/(X(k) - X(i)));
        end
    end
    dL = diff(L);
    dLK = subs(dL,xsym, X(k));
    HK = (1 - 2*dLK *(xsym-X(k)))* L^2;
    K = (xsym - X(k)) * L^2;
    H = H + HK*Y(k) + K * Z(k);
end
dH = diff(H);
end