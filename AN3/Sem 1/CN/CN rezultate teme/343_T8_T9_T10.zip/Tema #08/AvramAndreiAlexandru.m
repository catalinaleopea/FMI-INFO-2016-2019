% Rescrie tema pe formatul cerut!

%{
function y = MetNeville(X,Y,xvalue)

n = size(X,2);
Q = zeros(n,n,size(xvalue,2));

Q(:,1,:) = repmat(Y.',1,1,size(xvalue,2));
for i = 2:n
    for j = 2:i
        q1 = Q(i,j-1,:);
        q1 = q1(:).';
        q2 = Q(i-1,j-1,:);
        q2 = q2(:).';
        Q(i,j,:) = ((xvalue-X(i-j+1)).*q1-(xvalue-X(i)).*q2)/(X(i)-X(i-j+1));
    end
end
y = Q(n,n,:);
y = y(:).';
%}
%{
function y = MetNDD(X,Y,xvalue)

n = size(X,2);
Q = zeros(n,n,size(xvalue,2));

Q(:,1,:) = repmat(Y.',1,1,size(xvalue,2));

for i = 2:n
    for j = 2:i
        Q(i,j,:) = (Q(i,j-1,:) - Q(i-1,j-1,:))/(X(i)-X(i-j+1));
    end
end

y = Q(1,1,:);
y = y(:).';
for k = 2:n
    produs = 1;
    for i = 1:k-1
        produs = produs .* (xvalue - X(i));
    end
    Qk = Q(k,k,:);
    y = y + Qk(:).' .* produs;
end
y = y(:).';
%}
%{
function [y, z] = MetHermite(X, Y, Z, xvalue)
syms Hermite H K L x
N = size(X,2);

for i = 1:N
    L(i) = sym(1);
    for j = 1:N
        if(j~=i)
            L(i) = L(i) .* ((x-X(j))/(X(i)-X(j))).';
        end
    end
end

for i = 1:N
    H(i) = (L(i).^2) .* (1 - 2 * subs(diff(L(i),x),x,X(i)) .* (x - X(i)));
end
for i = 1:N
    K(i) = (L(i).^2) .* (x - X(i));
end
Hermite = sym(0);
for k = 1:N
    Hermite = Hermite + H(k) * Y(k) + K(k) * Z(k);
end

y = subs(Hermite,x,xvalue);
z = subs(diff(Hermite,x),x,xvalue);

clear H K L x
%}

%Problema 1
x = [-pi/2,0,pi/2];
y = sin(x);

P = MetNeville(x,y,pi/6);
EroareNeville = abs(P - sin(pi/6))

P = MetNDD(x,y,pi/6);
EroareNewtonDD = abs(P - sin(pi/6))

%Problema 2

x = [-2,-1,0,1,2];
y = 3.^x;
Sqrt3 = MetNeville(x,y,1/2)

%Problema 3
%{
function p = Pn(a,b,x)
if (a==1 && b==2)
    p = x+1;
elseif (a==2 && b==3)
    p = 3*x - 1;
elseif (a==2 && b==4 && x==3/2)
    p = 4;
else
    p = ((x-a)*Pn(a+1,b,x)-(x-b)*Pn(a,b-1,x))/(b-a);
end
%}

P3 = Pn(1,4,3/2)

%Problema 4
%reiese din formula Polinomului de interpolare Lagrange

%Problema 5
%2)
a = -pi/2;
b = pi/2;
Xval = a:(b-a)/99:b;
X = [a,0,b];
Y = sin(X);
Z = cos(X);
figure;
hold on;
yNeville = MetNeville(X,Y,Xval);
plot(Xval,yNeville,'r:');
yNDD = MetNDD(X,Y,Xval);
plot(Xval,yNDD,'b--');
[yHermite,z] = MetHermite(X,Y,Z,Xval);
plot(Xval,yHermite,'g');
legend('MetNeville','MetNDD','MetHermite');
hold off;
figure;
hold on;
plot(Xval,cos(Xval),'r');
plot(Xval,z,'g--');
legend('real','MetHermite');
hold off;
%3)

figure;
hold on;
E = abs(yNeville - sin(Xval));
plot(Xval,E,'r--');
E = abs(yNDD - sin(Xval));
plot(Xval,E,'b:');
E = abs(yHermite - sin(Xval));
plot(Xval,E,'g');
legend('MetNeville','MetNDD','MetHermite');
hold off;

%Problema 6
syms t
f = 3*t*exp(t) - exp(2*t);
df = diff(f,t);
X = [1 1.05];
Y = subs(f,t,X);
Z = subs(df,t,X);

H = MetHermite(X,Y,Z,1.03);
Eroare = abs(H - subs(f,t,1.03))
clear t
