% 1. 10
% 2. 8
% 3. 9
% 4. 6
% Total: 33/40 i.e. ~8.5/10

a = -pi/2;
b = pi/2;
interv = linspace(a, b, 100);
n = 3;
X = linspace(a, b, n + 1);
f = @(x)(sin(x));
syms x;
df = matlabFunction(diff(f(x)));
hold on;
syms x0;
[y, z] = MetHermiteDD(X, f(X), df(X), x0);
plot(interv, f(interv), '-m'), hold on;
plot(interv, subs(y, x0, interv), '-g');

%4
y = SplineL(X,f(X),interv);
plot(interv,y,'k');

function [y, z] = MetHermiteDD(X, Y, Z, x)
  
n = length(X);
n = n * 2;
Q = zeros(n);
Q(1:2:end, 1) = Y';
Q(2:2:end, 1) = Y';
X = sort([X, X]);
 
for i = 2 : n
   for j = 2 : i
      if j == 2 && mod(i, 2) == 0
           Q(i, j) = Z(i/2);
        else
            Q(i, j) = (Q(i, j - 1) - Q(i-1, j-1)) / (X(i) - X(i - j + 1));
        end
   end
end

y = sym(Q(1, 1));
for k = 2 : n
   prod = sym(1);
    for p = 1 : k - 1
        prod = prod * (x - X(p));
     end
    y = y + Q(k, k) * prod;
 end
z = diff(y);
 
end
function y = SplineL(X,Y,x)
    n = length(X) - 1;
    for i = 1 : n - 1
        a = Y(i);
        b = (Y(i+1)-Y(i))/(X(i+1)-X(i));
        ind = find(x >= X(i) & x < X(i+1));
        y(ind) = a + b*(x(ind)- X(i));


    end

      a = Y(n);
        b = (Y(n+1)-Y(n))/(X(n+1)-X(n));
        ind = find(x >= X(n) & x <= X(n+1));
        y(ind) = a + b*(x(ind) - X(n));
end