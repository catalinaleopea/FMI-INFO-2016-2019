
%%
% ========================== EXERCITIUL 2 =================================
n = 3;

f = @(x) sin(x);

syms l;
df = matlabFunction(diff(f(l)));

a = -pi/2;
b = pi/2;

X = linspace(a,b,n + 1);
Y = f(X);
Z = df(X);
x = linspace(a,b);

[y,z] = MetHermiteDD(X,Y,Z,x);

plot(X,Y,'xr');
hold on;
plot(x,f(x),'g');
plot(x,y,'b-.','LineWidth',1);

ylim([f(a) f(b)]);
xlim([a b]);

legend({'Punctele (X,Y',...
            strcat('Graficul functiei f = ',char(f)), ...
                'Graficul metodei Hermite'},'Location','NorthWest');

figure(2)


plot(X,Z,'xr');
hold on
plot(x,df(x),'g');
plot(x,z,'b-.','LineWidth',1);

legend({'Punctele (X,Y)', ...
            strcat('Graficul derivatei functiei f = ',char(df)), ...
                'Graficul derivatei dat de metoda Hermite'},...
                'Location','South');
            
xlim([a b]);

figure(3)

plot(x,abs(f(x) - y));
title('Eroarea de aproximare f(x) - Pn');
%%
% ========================== EXERCITIUL 4 =================================

f = @(x) sin(x);
a = -pi/2;
b = pi/2;
n = [2,4,10];

for i = 1:length(n)

    X = linspace(a,b,n(i) + 1);
    Y = f(X);
    
    x = linspace(a,b);
    
    S = zeros(1,length(x));
    
    for j = 1:length(x)
        S(j) = SplineL(X,Y,x(j));
    end
    
    figure(i);
    
    plot(X,Y,'or');
    hold on
    plot(x,f(x),'b');
    plot(x,S,'g-.','LineWidth',1)
    
    legend({'Punctele (X,Y)',strcat('Graficul functiei f =',char(f)), ...
            'Rezultatul interpolarii Spline'},'Location','NorthWest');
    title(strcat('Interpolarea spline liniara pentru n = ',num2str(n(i))));
    hold off
end
%%

% =========================== EXERCITIUL 4 ================================
% ================= FOLOSIND FUNCTIA SPLINE PENTRU VECTORI ================

f = @(x) sin(x);
a = -pi/2;
b = pi/2;
n = [2,4,10];

for i = 1:length(n)

    X = linspace(a,b,n(i) + 1);
    Y = f(X);
    
    x = linspace(a,b);
    
    S = SplineLMod(X,Y,x);
    
    figure(i);
    
    plot(X,Y,'or');
    hold on
    plot(x,f(x),'b');
    plot(x,S,'g-.','LineWidth',1)
    
    legend({'Punctele (X,Y)',strcat('Graficul functiei f =',char(f)), ...
            'Rezultatul interpolarii Spline'},'Location','NorthWest');
    title(strcat('Interpolarea spline liniara pentru n = ',num2str(n(i))));
    hold off
end




%%

function y = SplineLMod(X,Y,x)

    n = length(X) - 1;
    a = Y;
    b = zeros(1,length(X));
    
    y = zeros(1,length(x));

    for j = 1:n
        b(j) = (Y(j+1) - Y(j)) / (X(j+1) - X(j));
    end

    for i = 1:length(x)
        for j = 1:n
            if x(i) >= X(j) && x(i) < X(j + 1)
               
                break;
            end
        end
        y(i) = a(j) + b(j) * (x(i) - X(j));
    end
    
  
    
    
end

function y = SplineL(X,Y,x)

    n = length(X) - 1;
    a = Y;
    b = zeros(1,length(X));
    
    y = 0;

    for j = 1:n
        a(j) = Y(j);
        b(j) = (Y(j+1) - Y(j)) / (X(j+1) - X(j));
    end

    for j = 1:n
        if x >= X(j) && x < X(j + 1)
            
            break;
        end
    end
    y = a(j) + b(j) * (x - X(j));
    
end

function [y,z] = MetHermiteDD(X,Y,Z,x)

    xbar = zeros(1,2 * length(X));
    xbar(1:2:length(xbar)-1) = X;
    xbar(2:2:length(xbar)) = X;

    Q = zeros(length(xbar), length(xbar) + 1);

    Q(1:2:length(xbar) - 1,1) = Y;
    Q(2:2:length(xbar),1) = Y;
    Q(2:2:2*length(X),2) = Z;

    for i = 2:length(X)
    
        Q(2 * i - 1,2) = (Q(2 * i - 1,1) - Q(2 * i - 2, 1)) / ...
                     (xbar(2 * i - 1) - xbar(2 * i - 2));
    end

    for i = 3:2 * length(X)
        for j = 3:i
            Q(i,j) = (Q(i,j - 1) - Q(i - 1,j - 1)) ...
                        / (xbar(i) - xbar(i-j+1)); 
        end
    end

    syms w;
    H = Q(1,1);

    for i = 2:2 * length(X)
        product = 1;
        for k = 1:i-1
            product = product * (w - xbar(k));
        end
        H = H + Q(i,i) * product;
    end

    Hd = matlabFunction(diff(H));
    H = matlabFunction(H);

    y = H(x);
    z = Hd(x);

end