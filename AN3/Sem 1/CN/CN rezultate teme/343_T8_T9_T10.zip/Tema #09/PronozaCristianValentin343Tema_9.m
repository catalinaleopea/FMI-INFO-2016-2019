% 9/10 -> ex3?

%% Exercitiul 2:
f=@(x)sin(x); 
fDerivat=@(x)cos(x);
a=-pi/2;
b=pi/2; 
n=3;
X=linspace(a, b, n+1); 
Y=f(X); 
Z=fDerivat(X); 
grafX=linspace(a,b,100);  
for i=1:100 
   [grafY(i),grafYderivat(i)]=MetHermiteDD(X,Y,Z,grafX(i));
end 
figure(1)  
plot(X,Y,'r');  
hold on;
plot(grafX,grafY,'b');  
figure(2) 
plot(X,Z,'r');   
hold on;
plot(grafX,grafYderivat,'b'); 

figure(3)
plot (grafX, abs(f(grafX)-grafY));

%% Exercitiul 4: 

f=@(x) sin(x);
a=-pi / 2;
b=pi / 2;
N=[2,4,10];

for i=1:size(N, 2)
    X=linspace(a, b,(N(i) + 1));
    Y=f(X);
    x=linspace(a, b, 100);
    for k=1:100
        S(k)=SplineL(X, Y, x(k));
    end
    figure(i+100);
    hold on;
    plot(x, S, 'r');
    plot(x, f(x), 'b');
    plot(X, Y, 'o');
end 
%% Batch
for i=1:size(N, 2)
    X=linspace(a,b,(N(i)+1));
    Y=f(X);
    x=linspace(a,b,100);
    S=SplineL(X,Y,x);
    figure(i+200);
    hold on;
    plot(x, S, 'r');
    plot(x, f(x), 'b');
    plot(X, Y, 'o');
end 



%% Functii    

function y=SplineL(X,Y,x) 
n=length(X)-1;  

for j=1:n  
    a(j)=Y(j); 
    b(j)=(Y(j+1)-Y(j))/(X(j+1)-X(j));
end
for i=1:length(x)
    for j=1:n  
        if x(i)>=X(j)&& x(i)<=X(j+1)  
            S(i)=a(j)+b(j)*(x(i)-X(j)); 
            break;
        end
    end 
end
y=S;
end

function [y,z]=MetHermiteDD(X,Y,Z,x)   
n=length(X)-1; 
Q=zeros(2*n+2);
for i=1:n+1  
    Xbar(2*i-1)=X(i); 
    Xbar(2*i)=X(i); 
    Ybar(2*i-1)=Y(i); 
    Ybar(2*i)=Y(i);
end 
%Determinam Q 
for i=1:2*n+2  
    Q(i,1)=Ybar(i); 
end 

for i=1:n+1  
    Q(2*i,2)=Z(i);
end 

for i=2:n+1   
    Q(2*i-1,2)=(Q(2*i-1,1)-Q(2*i-2,1))/(Xbar(2*i-1)-Xbar(2*i-2));
end

for i=3:2*n+2 
    for j=3:i  
        Q(i,j)=(Q(i,j-1)-Q(i-1,j-1))/(Xbar(i)-Xbar(i-j+1));
    end 
end 
%Determinam H 
H=Q(1,1); 
for k=2:2*n+2   
    QkkFactor=Q(k,k); 
    for i=1:k-1  
        QkkFactor=QkkFactor*(x-Xbar(i));   
    end
    H=H+QkkFactor;
end 
y=H;

syms xsym

Hderivat=Q(1,1);  

for k=2:2*n+2  
    QkkFactor=Q(k,k); 
    for i=1:k-1  
        QkkFactor=QkkFactor*(xsym-Xbar(i));
    end
    Hderivat=Hderivat+QkkFactor;
end 


Hderivat=diff(Hderivat);


z=subs(Hderivat,x);


end 