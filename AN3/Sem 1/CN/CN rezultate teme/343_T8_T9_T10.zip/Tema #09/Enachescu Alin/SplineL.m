% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'X'       = nodurile de interpolare
% 'Y'       = valorile functiei f in nodurile de interpolare
% 'x'       = punctul pentru care se calculeaza interpolarea
% -------------------------------------------------------------------------
% Date de iesire:
% 'y'       = valoarea interpolata
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [y] = SplineL(X, Y, x)
    % step 1
    n = length(X) - 1;
    
    a = zeros(1, n);
    b = zeros(1, n);
    S = 0;

    % step 2
    for j = 1 : n
        a(j) = Y(j);
        b(j) = (Y(j + 1) - Y(j)) / (X(j + 1) - X(j));
    end
    
    % step 3
    for j = 1 : n
        if x >= X(j) && x <= X(j + 1)
            S = a(j) + b(j) * (x - X(j));
            break;
        end
    end

    y = S;
end
