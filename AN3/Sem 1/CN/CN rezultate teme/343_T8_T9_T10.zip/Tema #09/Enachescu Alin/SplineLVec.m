% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'X'       = nodurile de interpolare
% 'Y'       = valorile functiei f in nodurile de interpolare
% 'x'       = punctele pentru care se calculeaza interpolarea
% -------------------------------------------------------------------------
% Date de iesire:
% 'y'       = valorile interpolate
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [y] = SplineLVec (X, Y, x)
    % step 1
    n = length(X) - 1;
    
    for i = 1 : m
        a = zeros(1, n);
        b = zeros(1, n);
        S = 0;

        % step 2
        for j = 1 : n
            a(j) = Y(j);
            b(j) = (Y(j + 1) - Y(j)) / (X(j + 1) - X(j));
        end
    
        % step 3
        for j = 1 : n
            if x >= X(j) && x <= X(j + 1)
                S = a(j) + b(j) * (x(i) - X(j));
                break;
            end
        end

        y(i) = S;
    end
end
