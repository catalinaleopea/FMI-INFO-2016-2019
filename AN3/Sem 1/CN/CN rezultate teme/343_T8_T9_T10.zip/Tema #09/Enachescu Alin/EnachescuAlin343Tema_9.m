% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Rezolv exercitiile 1, 2 si 4.b
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

% 8/10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% exercitiul 1                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f  = @(x) 3 * x * exp(x) - exp(2 * x);
fd = @(x) exp(x) * (3 * x - 2 * exp(x) + 3);
X = [1, 1.05];
Y = [f(1), f(1.05)];
Z = [fd(1), fd(1.05)];
x = 1.03;

[y, z] = MetHermiteDD(X, Y, Z, x);
y2 = f(x);
fprintf('y = %.9f\n y2 = %.9f\n', y, y2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% exercitiul 2                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initializez datele problemei 5.2 din tema 8
% functia f
f  = @(x) sin(x);
% derivata lui f
fd = @(x) cos(x);
% capetele intervalului
a = -pi / 2;
b =  pi / 2;
% n-ul
N = 3;
% diviziunea echidistanta
X = linspace(a, b, N + 1);
% valorile pt f(x)
Y = f(X);
% valorile pt f'(x)
Z = fd(X);
% 100 de noduri pt a desena graficul
x = linspace(a, b, 100);
y = zeros(1, 100);
z = zeros(1, 100);

for i = 1 : 100
    [y(i), z(i)] = MetHermiteDD(X, Y, Z, x(i));
end

% desenez graficul lui f, punctele (Xi, Yi) si polinomul Pn
figure(1)
hold on
plot(x, y, 'k', 'Linewidth', 3);
xlabel('x')
ylabel('y')
grid on
plot(x, f(x), '--r', 'Linewidth', 3);
plot(X, Y, 'o', 'MarkerFaceColor', 'g', 'MarkerSize', 10)

% desenez f'(x) pentru ca derivata polinomului Hermite n-am stiut sa o calculez
figure(2)
hold on
xlabel('x')
ylabel('y')
plot(x, fd(x), '--r', 'LineWidth', 3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% exercitiul 4.b                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initializez functia f
f = @(x) sin(x);
% initializez capetele intervalului
a = -pi / 2;
b =  pi / 2;


% n = 2...nu inteleg aici enuntul cu n = 2,4,10???
% Se referea la numarul de noduri din discretizare. De ce nu ai dat un mail
% sa intrebi?


N = 2;
% generez pe X cu 3 elemente echidistante
X = linspace(a, b, N + 1);
% calculez pe Y
Y = f(X);
% generez 100 de puncte pentru care sa se apeleze SplineL
x = linspace(a, b, 100);
S = zeros(1, 100);

for i = 1 : 100
    S(i) = SplineL(X, Y, x(i));
end

figure(3)
hold on
% desenez vectorul S calculat conform SplineL
plot(x, S, 'k', 'Linewidth', 3);
xlabel('x')
ylabel('y')
grid on
% desenez functia f
plot(x, f(x), '--r', 'Linewidth', 3);
% desenez punctele de interpolare
plot(X, Y, 'o', 'MarkerFaceColor', 'g', 'MarkerSize', 10)