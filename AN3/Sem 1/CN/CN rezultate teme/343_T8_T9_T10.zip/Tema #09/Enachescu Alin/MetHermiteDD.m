% =========================================================================
% Fisier FUNCTIE
% -------------------------------------------------------------------------
% Date de intrare:
% 'X'       = nodurile de interpolare
% 'Y'       = valorile functiei f in nodurile de interpolare
% 'Z'       = valorile functiei f' in nodurile de interpolare
% 'x'       = punctul pentru care se calculeaza polinomul
% -------------------------------------------------------------------------
% Date de iesire:
% 'y'       = polinumul Hermite
% 'z'       = derivata polinomului Hermite
% -------------------------------------------------------------------------
% Author: Enachescu Alin, 2018
% =========================================================================

function [y, z] = MetHermiteDD(X, Y, Z, x)
    n = length(X) - 1;
    Q = zeros(2*n + 2);
    X_barat = zeros(1, 2*n + 2);
    Y_barat = zeros(1, 2*n + 2);
    H = 0; % H2n+1
    Hd = 0; % H'2n+1
    
    % initializez x barat (step 1 din curs)
    for i = 1 : n + 1
        X_barat(2 * i - 1) = X(i);
        X_barat(2 * i) = X(i);
    end
    
    % initializez y barat care este de fapt f(x_barat(i))
    for i = 1 : n + 1
        Y_barat(2 * i - 1) = Y(i);
        Y_barat(2 * i) = Y(i);
    end
    
    % determin matricea Q (step 2 din curs)
    for i = 1 : 2*n + 2
        Q(i, 1) = Y_barat(i);
    end
    
    for i = 1 : n + 1
        Q(2 * i, 2) = Z(i);
    end
    
    for i = 2 : n + 1
        Q(2 * i - 1, 2) = (Q(2 * i -1, 1) - Q(2 * i - 2, 1)) / (X_barat(2 * i - 1) - X_barat(2 * i - 2));
    end
    
    for i = 3 : 2 * n + 2
        for j = 3 : i
            Q(i, j) = (Q(i, j - 1) - Q(i - 1, j - 1)) / (X_barat(i) - X_barat(i - j + 1));
        end
    end
    
    % step 3
    H = Q(1, 1);
    for k = 2 : 2 * n + 2
        p = Q(k, k);
        for i = 1 : k - 1
            p = p * (x - X_barat(i));
        end
        H = H + p;
    end
    
    % nu am inteles cum se calculeaza H'2n+1 asa ca l-am lasat egal cu 0
    
    % step 4
    y = H;
    z = Hd;
end
