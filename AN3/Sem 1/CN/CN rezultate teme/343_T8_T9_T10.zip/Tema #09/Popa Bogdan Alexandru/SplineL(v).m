% Implementam interpolarea Splin liniara conform algoritmului din cursul 9
% pag.12.Primeste ca date de intrare un vector X de noduri si un interval
% Y cu valorile functiei studiate in nodurile din X, x este un vector de
% scalari iar ca date de iesire y valoarea numeric y reprezentand valoarile
% functiei spline liniara S(x) calculata conform metodei spline liniare.
function [y] = SplineL(X, Y, x)
n = length(X)+1; % numarul de noduri
a = zeros(n); % prealocarea lui a
b = zeros(n); % prealocarea lui b
k = length(x); % dimensiunea lui x
y = zeros(k); % prealocam vectorul de valori
for j = 1:n
    a(j) = Y(j); % calculam a si b conform algoritmului
    b(j) = Y(j+1)-Y(j)/(X(j+1)-X(j));
end
for i = 1:k
    for j = 1:n
        if x(i) >= X(j) && x(i)<= X(j+1) % daca x este in intervalul curent
            y(i) = a(j) + b(j)*(x(i) - X(j)); % am gasit valoarea lui y
            break;
        end
    end
end
end

