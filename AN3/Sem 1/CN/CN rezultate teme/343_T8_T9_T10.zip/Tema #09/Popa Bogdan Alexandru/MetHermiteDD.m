% Implementam metoda Hermite cu diferente divizate conform algoritmului din
% cursul 9 pag.7.Ca date de intrare avem diviziunea X, valorile functiei in
% punctele din X pastrate in Y, valorile functiei derivate in punctele din
% X pastrate in Z si scalarul in care functia va lua valori pastrata in
% x.Ca date de iesire avem valoarea functiei in x pastrata in y conform
% metodei HermiteDD si derivata pastrata in z conform metodei HermiteDD.
function [y,z] = MetHermiteDD(X,Y,Z,x)
n = length(X)-1; % dimensiunea lui X
Xbar = zeros(2*n+1,1); % prealocam Xbar
Ybar = zeros(2*n+1,1); % prealocam Ybar
Q = zeros(2*n+1); % prealocam Q

% parcurgem X
for i = 1:n+1
    % initiem Xbar conform algoritmului
    Xbar(2*i - 1, 1) = X(i,1);
    Xbar(2*i, 1) = X(i,1);
    % odata initat Xbar avem nevoie de f(Xbar) = Ybar
    Ybar(2*i - 1, 1) = Y(i,1);
    Ybar(2*i, 1) = Y(i,1);
end

for i = 1:2*n+2 % initiem Qi,1 conform algoritmului
    Q(i,1) = Ybar(i,1); 
end
for i = 1:n+1 % initiem Q2i,2 conform algoritmului
    Q(2*i,2) = Z(i,1);
end

for i = 2:n+1 % calculam Q2i-1,2 conform algoritmului
    Q(2*i-1,2) = (Q(2*i-1,1)-Q(2*i-2,1))/(Xbar(2*i-1,1)-Xbar(2*i-2,1));
end

for i = 3:2*n+2 % calculam Q conform algoritmului pe i,j
    for j = 3:i
        Q(i,j) = (Q(i,j-1) - Q(i-1,j-1))/(Xbar(i,1) - Xbar(i-j+1,1));
    end
end

H = Q(1,1); % initem H conform algoritmului
syms t;
for k = 2:2*n+2 % calculam simbolic H
    prod = 1;
    for i = 1:k-1
        prod = prod*(t-Xbar(i,1)); % t va fi x din algoritm
    end
    H = H + Q(k,k)*prod;
end

z = diff(H,1); % construim derivata in z
% calculam functia conform metodei HermiteDD calculata anterior
y_ = matlabFunction(H,t);
% calculam derivata conform metodei HermiteDD calculata anterior
z_ = matlabFunction(z,t);
[y,~] = y_(x); % alocam in y valoarea functiei 
[z,~] = z_(x); % alocam in z valoarea derivatei functiei
end