% Tema 9

% 10/10 -> La exercitiul 4 mai trebuie lucrat. Faina treaba cu Display, in
% schimb.

%% Ex 1
f1 = @(x) 3.*x.*eps.^x-eps.^(2.*x); % pastram functia din cerinta
x1 = 1; x2 = 1.05; % capetele intervalului
comp = f1(1.03); % numarul cu care comparam
X = linspace(x1,x2,3)'; % diviziunea
Y = f1(X);
syms x;
z = matlabFunction(diff(f1,x));
Z = z(X);
[y,z] = MetHermiteDD(X,Y,Z,1.03);

fprintf('Aproximarea lui f(1.03) folosind metoda HermiteDD este');
disp(y);
fprintf('cu eroarea');
disp(abs(y-z));
fprintf('Iar valoarea lui f(1.03) este');
disp(comp);

%% Ex 2
% 1)
    % Rezolvarea se regaseste in fisierul MetHermiteDD.m
% 2)
f2 = @(x) sin(x); % formam functia sin(x)
a2 = -pi / 2; b2 = pi / 2; % intervalul pe care este definita functia
n = 3; % n al polinomului conform cerintei

figure(1); % initiem figura
subplot(1,1,1);
% apelam Display pentru a rezolva cerinta in cazul metodei HermiteDD
[x_h,e_h,z] = Display(n, a2, b2, true, f2, @MetHermiteDD, "Metoda HermiteDD");


xlabel("x");
xlabel("y");

figure(2) % initiem figura

syms x
f2_simb = f2(x); % pastram simbolic functia f2
deriv_inter = diff(f2_simb); % calculam derivata lui f2_simb
deriv = matlabFunction(deriv_inter); % pastram functia handle deriv_inter
f2_deriv = deriv(x_h); % pastram derivata lui f

plot(x_h,f2_deriv,'r-'); % realizam graficul derivatei lui f
hold on
plot(x_h,z,'g--'); % realizam graficul derivatei lui f prin metoda Hermite
legend('f derivat','derivata HermiteDD')
title('Comparatia celor 2 derivate')
%3)
figure(3); % initiem figura

% realizam graficul erorii in metoda Hermite
plot(x_h, e_h, 'r-');
title("Metoda HermiteDD");

%% Ex 3
f3 = @(x) sin(x); % declaram functia studiata
a3 = -pi/2; b3 = pi/2; % capetele intervalului pe care este studiat f3
X1 = linspace(a3,b3); % diviziunea echidistanta pe care ia valori f3
Y1 = f3(X1); % valorile lui f3 in punctele din X1
S = zeros(1,3); % prealocam S
% diviziunea pe care este realizata interpolarea SplineL
div = [-pi/2,0,pi/2];
for i = 1:3
    % dam lui S valorile functiei obtinute in urma interpolarii SplineL
    S(i) = SplineL(X1,Y1,div(i));
end

%% Ex 4 
% a) Rezolvarea acestui exercitiu a fost realizata in fisierul SplineL.m
% b)
f4 = @(x) sin(x); % declaram functia studiata
n = [2,4,10]; % nodurile 
a4 = -pi/2; b4 = pi/2; % capetele intervalului pe care va fi studiata f4
S1 = zeros(100); % prealocam S1
x1 = linspace(a4,b4); % punctele in care este realizata interpolarea pe f4
for i = 1:length(n)
    X2 = linspace(a4,b4,n(i)+1); % diviziunea conform cerintei
    Y2 = f4(X2); % valorile lui f4 in punctele din X2
    for j = 1:100 
        S1(j) = SplineL(X2,Y2,x1(j)); % vectorul S1 conform cerintei
    end
    figure; % initiem figura
    plot(X2,Y2,'r-'); % graficul functiei f4
    hold on;grid on; % pastram in figura graficele
    plot(1:100,S1,'b--'); % graficul vectorului S1
    hold off;grid off;
    legend('f','S')
    title('Interpolarea SplineL')
end
% c) Rezolvarea acestui exercitiu se regaseste in SplinL(v).m