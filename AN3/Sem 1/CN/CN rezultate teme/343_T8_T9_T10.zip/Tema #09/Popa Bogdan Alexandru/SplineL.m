% Implementam interpolarea Splin liniara conform algoritmului din cursul 9
% pag.12.Primeste ca date de intrare un vector X de noduri si un interval
% Y cu valorile functiei studiate in nodurile din X, x este un scalar,
% iar ca date de iesire y valoarea numeric y reprezentand valoarea functiei
% spline liniara S(x) calculata conform metodei spline liniare.
function [y] = SplineL(X, Y, x)
n = length(X)-1; % numarul de noduri
a = zeros(n); % prealocarea lui a
b = zeros(n); % prealocarea lui b
for j = 1 : n
    a(j) = Y(j); % calculam a si b conform algoritmului
    b(j) = Y(j+1)-Y(j)/(X(j+1)-X(j));
end
for j = 1 : n
    if x >= X(j) && x<= X(j+1) % daca x este in intervalul curent
        y = a(j) + b(j)*(x - X(j)); % am gasit valoarea lui y
        return;
    end
end
end

