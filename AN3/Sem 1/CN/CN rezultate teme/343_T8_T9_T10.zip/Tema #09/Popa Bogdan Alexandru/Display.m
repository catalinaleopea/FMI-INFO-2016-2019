% am implementat metoda Display pentru a avea o metoda generala de afisare
% a cerintelor cerute la Ex.5.Metoda primeste ca date de intrare numarul
% polinomului lui Lagrange n, capetele intervalului pe care este definita
% functia f, a si b,un boolean care ne spune daca este folosita metoda
% Hermite, metoda folosita pentru calcularea polinomului lui
% Lagrange Met si numele metodei folosite ce va fi folosit in reprezentarea
% grafica (nume).Ca date de iesire are diviziunea pe numarul de noduri din
% cerinta a intervalului x_grafic si eroarea obtinuta E
function [x_grafic, E,z] = Display(n, a, b, herm, f, Met, nume)
    hold on;
    % diviziunea pe numarul de noduri a intervalului
    x_grafic = linspace(a, b, 100)';
    % diviziunea intervalului pe gradul polinomului (n+1)
    x_calcul = linspace(a, b, n + 1)';
    % calculam valorile lui f
    y_calcul = f(x_calcul);
    if herm % varificam daca metoda folosita este Hermite
        % in caz afirmativ calculam derivata lui f
        syms x
        f_simb = f(x);
        z_inter = diff(f_simb);
        z_func = matlabFunction(z_inter);
        z_calcul = z_func(x_calcul);
    end
    
    % afisam functia f pe diviziunea x_grafic
    plot(x_grafic, f(x_grafic), 'r-');
    % afisam punctele obtinute
    plot(x_calcul, y_calcul, 'rx');
    
    if herm % daca este folosita metoda Hermite prealocam z
        z = zeros(100,1);
    end
    y_polinom = zeros(100, 1);
    for i = 1:100
        % formam polinomul pe numarul de noduri folosind metoda mentionata
        % la intrare
        if herm 
            % tratam un caz special pentru metoda Hermite
            [y_polinom(i),z(i)] = Met(x_calcul, y_calcul, z_calcul, ...
            x_grafic(i));
        else
            y_polinom(i) = Met(x_calcul, y_calcul, x_grafic(i));
        end
    end
    % afisam graficul polinomului pe diviziunea x_grafic
    plot(x_grafic, y_polinom, 'g--');
    legend("f", "puncte", nume);
    title(nume);
    
    E = abs(y_polinom - f(x_grafic)); % calculam eroarea
end

