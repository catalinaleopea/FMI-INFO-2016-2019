%% Exercitiul 2
syms f(x);
f(x) = sin(x);
df = diff(f, x);

n = 3;

a = -pi/2;
b = pi/2;

X = linspace(a, b, n+1);
Y = double(f(X));
Z = double(df(X));

x = linspace(a, b, 100);

y_f = double(f(x));
y_df = double(df(x));

[H2n_1, dH2n_1] = ObtinePolinomHermiteDD(X, Y, Z);
y_H2n_1 = double(subs(H2n_1, x));
y_dH2n_1 = double(subs(dH2n_1, x));

figure(1);
plot(x, y_f);
hold on;
title(['{\color{blue}f(x) = sin(x);','\color{red}Pn(x): Aproximarea HermiteDD;}'],'interpreter','tex');
plot(x, y_H2n_1);

figure(2);
plot(x, y_df);
hold on;
title(['{\color{blue}df(x) = cos(x);','\color{red}Pn(x): Derivata aproximarii HermiteDD;}'],'interpreter','tex');
plot(x, y_dH2n_1);

figure(3);
plot(x, abs(y_f - y_H2n_1));
title({"Eroarea E = |f - Pn|", "f(x) = sin(x), Pn = Aproximarea HermiteDD"});

%% Exercitiul 4
close all;
%b)
f = @(x) sin(x);

n = [2, 4, 10];

a = -pi/2;
b = pi/2;

X = cell(length(n), 1);
Y = cell(length(n), 1);

for i = 1:length(n)
    X(i) = { linspace(a, b, n(i)+1) };
    Y(i) = { f(X{i}) };
end

x = linspace(a, b);

S = zeros(length(n), 100);

for i = 1:length(n)
%     for j = 1:100
%        S(i, j) = SplineL(X{i}, Y{i}, x(j));
%     end
    S(i, :) = SplineL(X{i}, Y{i}, x);
end

for i = 1:length(n)
    figure(i);
    plot(x, f(x));
    hold on;
    title(['{\color{blue}f(x) = sin(x);','\color{red}Interpolarea liniara Spline n = ' num2str(n(i)) ';}'],'interpreter','tex');
    plot(x, S(i, :));
end
%% Functii ajutatoare
function [H2n_1, dH2n_1] = ObtinePolinomHermiteDD(X, Y, Z)
    %Step 1
    n = length(X) - 1;
    
    X_ = zeros(1, 2*(n+1));
    
    X_(1:2:2*(n+1)-1) = X;
    X_(2:2:2*(n+1)) = X;
    
    X_ = X_';
    
    Y_ = zeros(1, 2*(n+1));
    
    Y_(1:2:2*(n+1)) = Y;
    Y_(2:2:2*(n+1)) = Y;
    
    Q = zeros(2*n + 2, 2*n + 2);
    
    %Step 2
    Q(:, 1) = Y_;
    Q(2:2:2*(n+1), 2) = Z;
    
    Q(3:2:2*(n+1)-1, 2) = (Q(3:2:2*(n+1)-1, 1) - Q(2:2:2*(n+1)-2, 1))...
                        ./ (X_(3:2:2*(n+1)-1) - X_(2:2:2*(n+1)-2));
                 
    for i = 3 : 2*n+2
        for j = 3 : i
            Q(i, j) = (Q(i, j-1) - Q(i-1, j-1))...
                     / (X_(i) - X_(i-j+1));
        end
    end
    %Step 3
    sum = 0;
    
    syms x_;
    
    for k = 2 : 2*n+2
        prod = 1;
        
        for k2 = 1 : k-1
            prod = prod * (x_ - X_(k2));
        end
        
        sum = sum + Q(k, k) * prod;
    end
    
    H2n_1 = Q(1, 1) + sum;
    dH2n_1 = diff(H2n_1, x_);
end

function [y, z] = MetHermiteDD(X, Y, Z, x)
    [H2n_1, dH2n_1] = ObtinePolinomHermiteDD(X, Y, Z);

    y = double(subs(H2n_1, x));
    z = double(subs(dH2n_1, x));
end

% function [y] = SplineL(X, Y, x)
%     n = length(X) - 1;
%     
%     a = zeros(1, n);
%     b = zeros(1, n);
%     
%     for j = 1:n
%         a(j) = Y(j);
%         b(j) = (Y(j+1) - Y(j))...
%                 /(X(j+1) - X(j));
%     end
%     
%     for j = 1:n
%         if X(j) <= x && x <= X(j+1)
%             y = a(j) + b(j)*(x - X(j));
%             return;
%         end
%     end
% end
%4)e)
function [y] = SplineL(X, Y, x)
    n = length(X) - 1;
    
    a = zeros(1, n);
    b = zeros(1, n);
    
    for j = 1:n
        a(j) = Y(j);
        b(j) = (Y(j+1) - Y(j))...
                /(X(j+1) - X(j));
    end
    
    y = zeros(1, length(x));
    
    for j = 1:n
        indices = find(X(j) <= x & x <= X(j+1));
        y(indices) = a(j) + b(j) * (x(indices) - X(j));
    end
end