%% 10/10*
%Ex.2.
f = @(x)sin(x);
fprim = @(x)cos(x);

N = 3;
A = -pi/2;
B = pi/2;
xgrafic = linspace(A,B,100);

subplot(1, 3, 1)
plot(xgrafic, f(xgrafic),  'r');
hold on;
%diviziunea echidistanta cu N puncte 
X = linspace(A,B,N);
Y = f(X);
Z = fprim(X);
plot(X,Y,'o');
[y, z] = MetHermiteDD(X,Y,Z,xgrafic);
plot(xgrafic, y); %reprezentarea polinomului Hermite 

subplot(1, 3, 2)
plot(xgrafic, fprim(xgrafic),  'r');
hold on;
plot(X, Z, '.');
plot (xgrafic, z); %reprezentarea derivatei polinomului Hermite 

%reprezentarea grafica a erorii
subplot(1, 3, 3)
plot(xgrafic, abs(f(xgrafic) - y));
hold on
plot(xgrafic, abs(fprim(xgrafic) - z));

%%
%Ex.4. b)
f = @(x)sin(x);
fprim = @(x)cos(x);

N = [3 4 6 10];
A = -pi/2;
B = pi/2;

xgrafic = linspace(A,B,100);

for i = 1:length(N)
    figure(i)
    subplot(1, 3, 1)
    plot(xgrafic, f(xgrafic),  'r'); %grafic f
    hold on;
    X = linspace(A,B,N(i));
    Y = f(X);
    plot(X,Y,'o'); %reprezentare puncte de interpolare 
    
    %reprezentare vector S
    [y, z] = SplineL(X,Y,xgrafic);
    plot(xgrafic, y);
    
    subplot(1, 3, 2)
    plot(xgrafic, fprim(xgrafic),  'r');
    hold on;
    plot(xgrafic, z, '.');
    
    subplot(1, 3, 3)
    plot(xgrafic, abs(f(xgrafic) - y));
end
%%

%Polinomul Hermite cu diferente divizate, conform algoritmului din Curs#9
%apelata in Ex.2.
function [y, z] = MetHermiteDD(X, Y, Z, x)
    n = length(X) - 1;
    xbar = zeros(2*n+2);
    Q = zeros(2*n+2, 2*n+2);
    
    for i = 1:n+1
        xbar(2*i - 1) = X(i);
        xbar(2*i) = X(i);
    end
    
    for i = 1:n + 1
        Q(2*i - 1,1) = Y(i);
        Q(2*i,1) = Y(i);
        Q(i*2,2) = Z(i); 
    end
    
    for i = 2:n+1
        Q(i*2-1, 2) = (Q(i*2-1,1) - Q(i*2-2,1))/(xbar(i*2-1) - xbar(i*2-2));
    end
    
    for i = 3:2*n+2
        for j = 3:i
            Q(i,j) = (Q(i,j-1) - Q(i-1,j-1))/(xbar(i) - xbar(i-j+1));
        end
    end
    
    for i = 1:length(x)
        S = Q(1,1);
        Sprim = 0;
        for k = 2:2*n+2
            p = 1;
            s2 = 0;
            for j = 1:k-1
                p2 = 1;
                for q = 1:k-1
                    if q ~= j
                        p2 = p2 * (x(i) - xbar(q));
                    end
                end
                p = p * (x(i) - xbar(j));
                s2 = s2 + p2;
            end
            S = S + Q(k,k)*p;
            Sprim = Sprim + Q(k,k) * s2;
        end
        y(i) = S;
        z(i) = Sprim;
    end
end

%Ex.4 a) - metoda de interpolare spline liniara 
function [y, z] = SplineL (X, Y, x)
    n = length(X) - 1;
    a = zeros(n);
    b = zeros(n);
    for j = 1:n
        a(j) = Y(j);
        b(j) = (Y(j+1) - Y(j)) / (X(j+1) - X(j));
    end
    
    for i = 1:length(x)
        for j = 1:n
            if  x(i) >= X(j) && x(i) <= X(j+1)
                S = a(j) + b(j)*(x(i)-X(j));
                Sprim = b(j);
                break;
            end
        end
        y(i) = S;
        z(i) = Sprim;
    end
end