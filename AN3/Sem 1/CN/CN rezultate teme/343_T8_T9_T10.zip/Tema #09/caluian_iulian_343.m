% 1. -
% 2. 10
% 3. -
% 4. 6

% Total: 16/40 i.e. ~5/10*
%% Exercitiul 2
syms f(x)
f(x) = 3*x*(exp(x)) - exp(2*x);
df = diff(f,x);

xi = [1 , 1.05];
yi = [double(f(xi(1))), double(f(xi(2)))];
zi = [double(df(xi(1))), double(df(xi(2)))];
[ry,rz] = MetHermiteDD(xi, yi, zi, 1.03);
ry
rz

%b 


%% EX4
%

x = [-pi/2, 0 , pi/2];
y = [-1, 0 , 1];
vx = SplineL(x,y,-pi/4); %% ar trebui sa fie -0.5 (calculat pe hartie)
vx
%b
xi = linspace(-pi/2,pi/2, 100);
fxi = sin(xi);

l2 = linspace(-pi/2,pi/2, 3);
fy2 = sin(l2);
si2 = xi;
for i= 1:100
    si2(i) = SplineL(l2,fy2,xi(i));
end


l4 = linspace(-pi/2,pi/2, 5);
fy4 = sin(l4);

si4 = xi;
for i= 1:100
    si4(i) = SplineL(l4,fy4,xi(i));
end


l10 = linspace(-pi/2,pi/2, 11);
fy10 = sin(l10);
%si10 = xi
% for i= 1:100
%     si10(i) = SplineL(l10,fy10,xi(i));
% end
si10 = SplineL(l10,fy10,xi);


plot(xi,fxi);
hold on;
plot(xi,si2);
plot(xi,si4);
plot(xi,si10);
%%


function [y, z] = MetHermiteDD(X, Y, Z, x)
vectSize = size(X);
siz = max(vectSize(1),vectSize(2));
q = zeros(siz,siz);
q(1:2:(2*siz),1) = Y;
q(2:2:(2*siz),1) = Y;
q(2:2:(2*siz),2) = Z;
xi = zeros(1,siz*2);
xi (1, 1:2:(siz*2)) = X;
xi (2, 1:2:(siz*2)) = X;
for i = 3 :2:(2*siz)
    q(i,2) =  (q(i,1) - q(i-1,1)) / (xi(i) - xi(i-1));
end
for j = 3:(2*siz)
    for i = j:(2*siz)
        q(i,j) =  (q(i,j-1) - q(i-1,j-1)) / (xi(i) - xi(i-j+1));
    end
end
syms h2n1(x)
h2n1(x) = x*0 + q(1,1);
syms faux(x)

for k = 2:(2*siz)
    faux(x) = 1+ 0*x;
    for j = 1:(k-1)
        faux(x) = faux(x) * (x - xi(j));
    end 
    h2n1(x) =  h2n1(x) + q(k,k)*faux(x);
end
h2n1(x)

y = coeffs(h2n1);
df = diff(h2n1);
z = coeffs(df);
end

function y = SplineL(X,Y,x)
    %%return in punctul y
  
    vectSize = size(X);
    siz = max(vectSize(1),vectSize(2));

    vectSize = size(x);
    sizX = max(vectSize(1),vectSize(2));
    
    y = x;
    for j = 1:sizX 
          i = 1;
            while ((i<siz) && (X(i+1) < x(j)) )
                i = i+1;
            end
    
    %nu este necesa sa calculam toti ai, aj, doar pentru segmentul
    %respectiv trebuie:
        ai = Y(i);
         bi = (Y(i+1) - Y(i) ) / (X(i+1) - X(i) );
         y(j) = ai + bi*(x(j) - X(i));
    end
end

