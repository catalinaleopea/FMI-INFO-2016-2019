%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMA 9                                                                  %
% - Madalina Pietreanu, grupa 343                                         %
% - acest fisier reprezinta implementarile anumitor exercitii din tema 9  %
% - exercitiile care se rezolvau "manual" se gasesc in folderul "Papers"  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % Error using subs
% % % Expected input number 1, S, to be one of these types:
% % % 
% % % sym
% % % 
% % % Instead its type was function_handle.
% % % 
% % % Error in sym/subs (line 60)
% % % validateattributes(F, {'sym'}, {}, 'subs', 'S', 1);
% % % 
% % % Error in Madalina_Pietreanu_343 (line 23)
% % % YHermite = subs(y,x,Xgraf);



syms x y;
f = @(x) sin(x);
df = matlabFunction(diff(f(x),x));
n = 3;
fst = -pi/2;
snd = pi/2;
X = linspace(fst,snd,n+1);
Y = f(X);
Z = df(X);

Xgraf = linspace(fst,snd);
Ygraf = f(Xgraf);

[y,dy] = MetHermiteDD(X,Y,Z);
YHermite = subs(y,x,Xgraf);
figure(3);
title('Hermite');
plot(Xgraf,Ygraf,'-r');
hold on;
plot(Xgraf,YHermite,'-b');
hold off;

% derivata functiei vs. derivata polinomului Hermite
dYHermite = subs(dy,x,Xgraf);
dXgraf = df(Xgraf);
figure(4);
title('Derivata functiei vs. derivata polinomului Hermite');
plot(Xgraf,dXgraf,'-r');
hold on;
plot(Xgraf,dYHermite,'-b');
hold off;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% EXERCITIUL 4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% b)
% initializari
f = @(x) sin(x);
fst = -pi/2;
snd = pi/2;
n = [2,4,10];
max = 100;
x = linspace(fst,snd,max);
y = f(x); % pentru plotarea functiei f
S = zeros(1,max);

% fac ce imi cere cerinta pentru fiecare n in parte
for i = 1 : length(n)
    X = linspace(fst,snd,(n(i)+1));
    Y = f(X);
    
    for j = 1 : max
        S(j) = SplineL(X,Y,x(j));
    end
    
    figure(i);
    plot(x,y,'-r');
    hold on;
    scatter(X,Y,'*b');
    hold on;
    scatter(x,S,'xg');
    hold off;
end

% c)
% un mic test
% z = SplineLModif(X,Y,[x(1),x(2),x(3)]);
% z

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUNCTII %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% METODA HERMITE                                                          %
% - aceasta functie calculeaza polinomul de interpolare Hermite H cu      %
%           diferente divizate conform algoritmului prezentat in cursul 9 %
% - INPUT:  X - multimea nodurilor de interpolare, |X| = n+1              %
%           Y - multimea punctelor yi, unde yi = f(xi)                    %
% - OUTPUT: y - H(x)                                                      %
%           z - H'(x)                                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [y,z] = MetHermiteDD(X,Y,Z)

    n = length(X);
    
    % formez vectorul Xbar dubland fiecare element in parte
    % [a1 a2 ... an] => [a1 a1 a2 a2 ... an an]
    Xbar = zeros(1,2*n);
    for i = 1 : n
        Xbar(2*i-1) = X(i);
        Xbar(2*i) = X(i);
    end
    
    % fac acelasi lucru si cu Ybar, ca sa imi fie mai usor la calcule
    Ybar = zeros(1,2*n);
    for i = 1 : n
        Ybar(2*i-1) = Y(i);
        Ybar(2*i) = Y(i);
    end
    
    Q = zeros(2*n,2*n);
    
    % prima coloana
    Q(:,1) = Ybar;
    
    % a doua coloana
    for i = 1 : n
        Q(2*i,2) = Z(i);
    end
    
    % restul matricii
    for i = 2 : n
        Q(2*i-1,2) = ( Q(2*i-1,1) - Q(2*i-2,1) ) /...
            ( Xbar(2*i-1) - Xbar(2*i-2) );
    end
    
    for i = 3 : 2*n
        for j = 3 : i
            Q(i,j) = ( Q(i,j-1) - Q(i-1,j-1) ) / ( Xbar(i) - Xbar(i-j+1) );
        end
    end
    
    % determin polinomul Hermite conform algoritmului din cursul 9
    syms x
    y = Q(1,1);
    for i = 2 : 2*n
        aux = 1;
        for k = 2 : 2*n
            aux = aux * (x - Xbar(k));
        end
        y = y + Q(i,i) * aux;
    end
    
    y = matlabFunction(y, 'var', {x});
    
    % derivata polinomului Hermite
    z = matlabFunction(diff(y(x),x));

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INTERPOLAREA SPLINE LINIARA                                             %
% - aceasta functie calculeaza functia spline liniara de interpolare S(x) %
%           conform algoritmului din cursul 9                             %
% - voi presupune ca datele de intrare sunt corecte                       %
% - INPUT:  X - multimea nodurilor de interpolare, |X| = n+1, unde        %
%               a = X(1) < X(2) < ... < X(n+1) = b                        %
%           Y - multimea punctelor yi, unde yi = f(X(i)), i=1,n+1         %
%           x - valoarea pentru care vreau sa calculez S(x), x apartine   %
%               intervalului [a,b]                                        %
% - OUTPUT: y - S(x)                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function[y] = SplineL(X,Y,x)
    
    % determin n-ul
    n = length(X);
    
    % intitializari
    a = zeros(1,n);
    b = zeros(1,n);
    S = -1;
    
    % determin a-urile si b-urile conform algoritmului
    for j = 1 : n - 1
        a(j) = Y(j);
        b(j) = (Y(j+1) - Y(j)) / (X(j+1) - X(j));
    end
    
    for j = 1 : n - 2
        if X(j) <= x && x < X(j+1)
            S = a(j) + b(j) * (x-X(j));
            break;
        end
    end
    % la ultimul interval, si capatul din dreapta este inchis; tratez cazul
    % asta separat, in caz ca nu am gasit pana acum solutia
    if X(n-1) <= x && x <= X(n)
        S = a(n-1) + b(n-1)*(x-X(n-1));
    end
    
    y = S;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INTERPOLAREA SPLINE LINIARA - varianta modificata                       %
% - aceasta functie calculeaza functia spline liniara de interpolare S(x) %
%           conform algoritmului din cursul 9 si conform modificarilor    %
%           cerute de cerinta c) a exercitiului 4                         %
% - voi presupune ca datele de intrare sunt corecte                       %
% - INPUT:  X - multimea nodurilor de interpolare, |X| = n+1, unde        %
%               a = X(1) < X(2) < ... < X(n+1) = b                        %
%           Y - multimea punctelor yi, unde yi = f(X(i)), i=1,n+1         %
%           x - valoarea pentru care vreau sa calculez S(x), x apartine   %
%               intervalului [a,b]                                        %
% - OUTPUT: y - S(x)                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function[y] = SplineLModif(X,Y,x)
    
    % determin n-ul
    n = length(X);
    
    % intitializari
    a = zeros(1,n);
    b = zeros(1,n);
    y = zeros(1,length(x));
    S = -1;
    
    % determin a-urile si b-urile conform algoritmului
    for j = 1 : n - 1
        a(j) = Y(j);
        b(j) = (Y(j+1) - Y(j)) / (X(j+1) - X(j));
    end
    
    for i = 1 : length(x)
        
        for j = 1 : n - 2
            if X(j) <= x(i) && x(i) < X(j+1)
                S = a(j) + b(j) * (x(i)-X(j));
                break;
            end
        end
        
        % la ultimul interval, si capatul din dreapta este inchis; 
        % tratez cazul asta separat, in caz ca nu am gasit pana acum
        % solutia
        if X(n-1) <= x(i) && x(i) <= X(n)
            S = a(n-1) + b(n-1)*(x(i)-X(n-1));
        end
        y(i) = S;
    end
end