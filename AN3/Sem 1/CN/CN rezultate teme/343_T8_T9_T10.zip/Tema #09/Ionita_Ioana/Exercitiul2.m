f = @(x)sin(x);
fprim = @(x)cos(x);

n = 3;
a = -pi/2;
b = pi/2;
xgrafic = linspace(a, b,100);

figure(1);
plot(xgrafic, f(xgrafic),  'r');
X = linspace(a, b, n);
Y = f(X);
Z = fprim(X);
hold on;
plot(X,Y,'o');
[y, z] = MetHermiteDD(X, Y, Z, xgrafic);
hold on;
plot(xgrafic, y);
hold off;

figure(2);
plot(xgrafic, fprim(xgrafic),  'r');
hold on;
plot(X, Z, '.');
hold on;
plot (xgrafic, z);
hold off;

figure(3);
plot(xgrafic, abs(f(xgrafic) - y));
hold on
plot(xgrafic, abs(fprim(xgrafic) - z));
hold off;