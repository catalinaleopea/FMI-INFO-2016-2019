%Exercitiul 4
%subpunctul b)
f = @(x) sin(x);
a = -pi/2;
b = pi/2;
%pentru n = 2
n1 = 2;
X1 = linspace(a, b, n1+1); 
Y1 = f(X1);
figure(1);
plot(X1, Y1, 'r', 'LineWidth', 2);
hold on;
plot(X1(1), Y1(1), 'bo', 'MarkerSize', 10, 'MarkerFaceColor','green');
hold on;
plot(X1(2), Y1(2), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'green');
hold on;
plot(X1(3), Y1(3), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'green');
x1 = linspace(a, b, 100);
for i=1:100
    y1(i) = SplineL(X1, Y1, x1(i));
end
hold on;
plot(x1, y1, 'b', 'LineWidth', 2);
hold off;
%pentru n = 4
n2 = 4;
X2 = linspace(a, b, n2+1);
Y2 = f(X2);
figure(2);
plot(X2, Y2, 'r', 'LineWidth', 2);
for i=1:n2+1
    hold on;
    plot(X2(i), Y2(i), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'green');
end
x2 = linspace(a, b, 100);
for i=1:100
    y2(i) = SplineL(X2, Y2, x2(i));
end
hold on;
plot(x2, y2, 'b', 'LineWidth', 2);
hold off;
%pentru n = 10
n3 = 10;
X3 = linspace(a, b, n3+1);
Y3 = f(X3);
figure(3);
plot(X3, Y3, 'r', 'LineWidth', 2);
for i=1:n3+1
    hold on;
    plot(X3(i), Y3(i), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'green');
end
x3 = linspace(a, b, 100);
for i=1:100
    y3(i) = SplineL(X3, Y3, x3(i));
end
hold on;
plot(x3, y3, 'b', 'LineWidth', 2);
hold off;
