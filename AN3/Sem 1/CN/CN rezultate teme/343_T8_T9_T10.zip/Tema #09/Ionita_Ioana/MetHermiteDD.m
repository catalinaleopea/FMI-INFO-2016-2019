function [y, z] = MetHermiteDD(X, Y, Z,x)

n = length(X) - 1;

for i = 1:n+1
    xbar(2*i - 1) = X(i);
    xbar(2*i) = X(i);
end
    
for i = 1:n + 1
    Q(2*i - 1,1) = Y(i);
    Q(2*i,1) = Y(i);
    Q(i*2,2) = Z(i); 
end
    
for i = 2:n+1
    Q(i*2-1, 2) = (Q(i*2-1,1) - Q(i*2-2,1))/(xbar(i*2-1) - xbar(i*2-2));
end
    
for i = 3:2*n+2
    for j = 3:i
        Q(i,j) = (Q(i,j-1) - Q(i-1,j-1))/(xbar(i) - xbar(i-j+1));
    end
end
    
for i = 1:length(x)
    S = Q(1,1);
    Sprim = 0;
    for k = 2:2*n+2
        p = 1;
        s2 = 0;
        for j = 1:k-1
            p2 = 1;
            for q = 1:k-1
                if q ~= j
                    p2 = p2 * (x(i) - xbar(q));
                end
            end
            p = p * (x(i) - xbar(j));
            s2 = s2 + p2;
        end
        S = S + Q(k,k)*p;
        Sprim = Sprim + Q(k,k) * s2;
    end
    y(i) = S;
    z(i) = Sprim;
end
end