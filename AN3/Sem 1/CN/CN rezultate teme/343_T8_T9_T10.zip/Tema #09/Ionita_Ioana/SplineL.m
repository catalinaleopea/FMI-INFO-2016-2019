function [ y ] = SplineL( X, Y, x )

n = length(X);
a = zeros(n);
b = zeros(n);
m = length(x);
for j = 1:n-1
    a(j) = Y(j);
    b(j) = (Y(j+1) - Y(j))/(X(j+1) - X(j));
end
for i = 1: m
    for j=1:n-1
        if(X(j) <= x(i) && x(i)<= X(j+1))
            y(i) = a(j) + b(j) * (x(i) - X(j));
            break;
        end
    end
end
end
