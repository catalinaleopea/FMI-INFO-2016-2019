% 9/10 -> A trebuit sa mai fac modificari ca sa pot rula! 

%% Problema 1
syms t
f = 3*t*exp(t) - exp(2*t);
df = diff(f,t);
X = [1 1.05];
Y = subs(f,t,X);
Z = subs(df,t,X);

H = MetHermiteDD(X,Y,Z,1.03);
Eroare = double(abs(H - subs(f,t,1.03)))
clear t

%% Problema 2
%b)
a = -pi/2;
b = pi/2;
Xval = a:(b-a)/99:b;
X = [a,0,b];
Y = sin(X);
Z = cos(X);

[y,z] = MetHermiteDD(X,Y,Z,Xval);

figure;
hold on;
plot(Xval,sin(Xval),'r');
plot(Xval,y,'g--');
legend('functia','MetHermiteDD','Location', 'Best');
hold off;

figure;
hold on;
plot(Xval,cos(Xval),'r');
plot(Xval,z,'g--');
legend('derivata','MetHermiteDD','Location', 'Best');
hold off;

%c)
figure;
hold on;
Ef = abs(y - sin(Xval));
plot(Xval,Ef,'g+');
Ed = abs(y - sin(Xval));
plot(Xval,Ed,'b-');
legend('Eroare functie','Eroare derivata','Location', 'Best');
hold off;

%% Problema 3
X = [-pi/2,0,pi/2];
Y = sin(X);
S = SplineL(X, Y, 'var').'

%% Problema 4
a = -pi/2;
b = pi/2;
Xval = a:(b-a)/99:b;

for n = [2,4,10]
    X = a:(b-a)/n:b;
    Y = sin(X);

    y = SplineL(X, Y, Xval);
    figure;
    hold on;
    plot(Xval,sin(Xval),'r');
    plot(X,Y,'bo');
    plot(Xval,y,'g--');
    legend('real','(X,Y)','SplineL','Location', 'Best');
    hold off;
end

%%
Functii

MetHermiteDD
function [y, z] = MetHermiteDD(X, Y, Z, xvalue)

N = size(X,2);
xTilda = 1:2*N;
for i = 1:N
    xTilda(2*i-1) = X(i);
    xTilda(2*i) = X(i);
end
yTilda = 1:2*N;
for i = 1:N
    yTilda(2*i-1) = Y(i);
    yTilda(2*i) = Y(i);
end

Q = ones(2*N,2*N);

Q(:,1,:) = yTilda.';
for i = 1:N
    Q(2*i,2) = Z(i);
end
for i = 2:N
    Q(2*i-1,2) = (Q(2*i-1,1)-Q(2*i-2,1))/(xTilda(2*i-1)-xTilda(2*i-2));
end

for i = 3:2*N
    for j = 3:i
        Q(i,j) = (Q(i,j-1) - Q(i-1,j-1))/(xTilda(i)-xTilda(i-j+1));
    end
end

syms x
y = Q(1,1);
for k = 2:2*N
    produs = 1;
    for i = 1:k-1
        produs = produs .* (x - xTilda(i));
    end
    y = y + Q(k,k) .* produs;
end
z = diff(y);
y = subs(y,x,xvalue);
z = subs(z,x,xvalue);

clear x
end
% SplineL

function y = SplineL(X, Y, xvalue)
N = size(X,2)-1;

A = 1:N;
B = 1:N;

for j = 1:N
    A(j) = Y(j);
    B(j) = (Y(j+1)-Y(j))/(X(j+1)-X(j));
end

syms S x
S = sym('S',[1,N]);

for j = 1:N
    S(j) = A(j) + B(j) * (x - X(j));
end

if strcmp(xvalue,'var')
    y = S;
    return
end

if(isvector(xvalue))
    y = 1:size(xvalue,2);
    
    for i = 1:N
        Xj = find(xvalue >= X(i) & xvalue <= X(i+1));
        y(Xj) = subs(S(i),x,xvalue(Xj));
    end
else
    for i = 1:N
        if xvalue >= X(i) && xvalue <= X(i+1)
            y = subs(S(i),x,xvalue);
            break;
        end
    end
end

clear S x
end
