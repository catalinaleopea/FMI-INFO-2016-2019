% =========================================================================
% Fisier SCRIPT
% -------------------------------------------------------------------------
% Tema 9
% -------------------------------------------------------------------------
% Author: Naomi Alexandra Halip, 2018
% =========================================================================
% 1. 10*
% 2. 10
% 3. 10
% 4. 9*

% Total 39/40 i.e. ~10/10
%%
% Ex. 2.
f = @(x) sin(x);
n = 3;
a = -pi/2;
b = pi/2;

figure(1);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'-b'); % trasarea graficului functiei f
xlim([-2 2]);
ylim([-2 2]);
hold on

X = linspace(a,b,n+1); % generarea nodurilor de interpolare
X(1) = a;
X(n+1) = b;
Y = f(X); % valorile functiei f in nodurile de interpolare
plot(X,Y,'--r'); % reprezentarea grafica a perechilor de forma (Xi,Yi), i=1:n+1
hold on

syms x
df = matlabFunction(diff(f(x))); % derivata functiei f
Z = df(X); % valorile derivatei functiei f in nodurile de interpolare

[H, Hd] = MetHermiteDD(X,Y,Z,x); % calculul polinomului Herimite si al derivatei acestuia
fplot(H,[a,b],'--g'); % reprezentarea grafica a polinomului Hermite
legend('functia f(x)=sin(x)','perechile (Xi,Yi), i=1:n+1','Polinoml Pn obtinut prin MetHermiteDD');

figure(2);
fplot(df,[a b],'-b'); % plotez graficul derivatei functiei f
xlim([-2 2]);
ylim([-2 2]);
hold on
fplot(Hd,[a,b],'--g'); % reprezentarea grafica a derivatei polinomului Hermite
legend('derivata functiei f(x)=sin(x)','Derivata polinomului Pn obtinut prin MetHermiteDD');

% Eroarea E = abs(f-Pn);
figure(3);
E = abs(f-H); % calculul erorii
% xlim([-2 2]);
% ylim([-2 2]);
hold on
fplot(E,'--r'); % reprezentarea grafica a erorii
legend('Eroarea E=|f-Pn|');
%%

%%
% Ex. 4
% b)
f = @(x) sin(x);
n = 2;
a = -pi/2;
b = pi/2;

X = linspace(a,b,n+1); % generarea nodurilor de interpolare
X(1) = a;
X(n+1) = b;
Y = f(X); % valorile functiei f in nodurile de interpolare 

figure(4);
z = linspace(a,b,100); % discretizare interval 
t = f(z);
plot(z,t,'-b'); % trasarea graficului functiei f
xlim([-2 2]);
ylim([-2 2]);
hold on

plot(X,Y,'-r'); % reprezentarea grafica a perechilor de forma (Xi,Yi), i=1:n+1
hold on

% valorile functiei spline liniara calculata in 100 de noduri
for i=1:100
    S(i) = SplineL(X,Y,z(i));
end
plot(z,S,'--g'); % reprezentarea grafica a functiei spline liniara calculata in 100 de noduri
legend('Functia f(x)=sin(x)','perechile (Xi,Yi), i=1:n+1','Valoarea functiei spline liniara');

% test Spline liniar cu vectori
figure(5);
Sv = SplineLVec(X,Y,z); % valorile functiei spline liniara calculata in 100 de noduri
% folosind metoda Spline liniara pentru vectori
xlim([-2 2]);
ylim([-2 2]);
hold on
plot(z,Sv,'-m'); % reprezentarea grafica a functiei spline liniara folosind metoda SplineLVec
plot(z,S,'--b'); % reprezentarea grafica a functiei spline liniara folosind metoda SplineL
legend('Valoarea functiei spline liniara folosind vectori','Valoarea functiei spline liniara');
%%

%%
% Ex. 2.
% Am rezolvat exercitiul construind procedura MetHermiteDD, conform
% algoritmului din Cursul#9, pagina 2
% -------------------------------------------------------------------------
% Date de intrare:
% 'X' = matrice reprezantand nodurile de interpolare
% 'Y' = matrice reprezentand valorile functiei f in nodurile de interpolare
% 'Z' = matrice reprezentand valorile functiei f' in nodurile de
% interpolare
% -------------------------------------------------------------------------
% Date de iesire:
% 'y' = polinomul Hermite obtinut
% 'z' = derivata polinomului Hermite
% -------------------------------------------------------------------------
function [y, z] = MetHermiteDD(X,Y,Z,x)
    n1 = size(X);
    n = n1(2) - 1;
    xb = zeros(2*n+2,1);
    yb = zeros(2*n+2,1);
    for i=1:n+1 
        xb(2*i-1) =X(i);
        xb(2*i) =X(i);
        
        yb(2*i-1) =Y(i);
        yb(2*i) =Y(i);
    end
    for i=1:2*n+2 
        Q(i,1) =yb(i);
    end
    for i=1:n+1 
        Q(2*i,2) =Z(i);
    end
    for i=2:n+1 
        Q(2*i-1,2) =(Q(2*i-1,1) -Q(2*i-2,1))/(xb(2*i-1) - xb(2*i-2));
    end
    for i=3:2*n+2
        for j=3:i
             Q(i,j) =(Q(i,j-1) -Q(i-1,j-1))/(xb(i) - xb(i-j+1));
        end
    end
    y = Q(1,1) +Sum(Q,n,x,xb);
    z = diff(Q(1,1) +Sum(Q,n,x,xb));
end
%%

%%
% Ex. 4.
% a)
% Am rezolvat exercitiul construind procedura SplineL, conform
% algoritmului din Cursul#9, pagina 3
% -------------------------------------------------------------------------
% Date de intrare:
% 'X' = matrice reprezantand nodurile de interpolare
% 'Y' = matrice reprezentand valorile functiei f in nodurile de interpolare
% 'x' = variabila scalara, x apartine intervalului [a,b]
% -------------------------------------------------------------------------
% Date de iesire:
% 'y' = valoarea functiei spline liniara
% -------------------------------------------------------------------------
function [y] = SplineL(X,Y,x)
    n1 = size(X);
    n = n1(2) - 1;
    for j=1:n
        A(j) = Y(j);
        B(j) = (Y(j+1) -Y(j))/(X(j+1) -X(j));
    end
    for j = 1:n
        if ((x >= X(j)) && (x <= X(j+1)))
            S = A(j) +B(j)*(x -X(j));
            break;
        end
    end
    y = S;
end
%%

%%
% Ex. 4.
% c)
% Am rezolvat exercitiul construind procedura SplineL, conform
% algoritmului din Cursul#9, pagina 3, pe care l-am adatptat la vectori
% -------------------------------------------------------------------------
% Date de intrare:
% 'X' = matrice reprezantand nodurile de interpolare
% 'Y' = matrice reprezentand valorile functiei f in nodurile de interpolare
% 'x' = vector, x(i) apartine intervalului [a,b]
% -------------------------------------------------------------------------
% Date de iesire:
% 'y' = vector, reprezentand valoarea functiei spline liniara
% -------------------------------------------------------------------------
function [y] = SplineLVec(X,Y,x)
    n1 = size(x);
    n1 = n1(2);
    for i=1:n1
        n2 = size(X);
        n = n2(2) - 1;
        for j=1:n
            A(j) = Y(j);
            B(j) = (Y(j+1) -Y(j))/(X(j+1) -X(j));
        end
        for j = 1:n
            if ((x(i) >= X(j)) && (x(i) <= X(j+1)))
                S = A(j) +B(j)*(x(i) -X(j));
                break;
            end
        end
        y(i) = S;
    end
end
%%

%%
% Pentru functia MetHermiteDD
function [s] = Sum(Q,n,x,xb)
    s = 0;
    for k=2:2*n+2
        s = s+Q(k,k)*Prod(k,x,xb);
    end
end
%%

%%
% Pentru functia MetHermiteDD
function [p] = Prod(k,x,xb)
    p = 1;
    for i=1:k-1
        p = p*(x-xb(i));
    end
end
%%