function [detectii, scoruriDetectii, imageIdx] = ruleazaDetectorFacial(parametri)
% 'detectii' = matrice Nx4, unde 
%           N este numarul de detectii  
%           detectii(i,:) = [x_min, y_min, x_max, y_max]
% 'scoruriDetectii' = matrice Nx1. scoruriDetectii(i) este scorul detectiei i
% 'imageIdx' = tablou de celule Nx1. imageIdx{i} este imaginea in care apare detectia i
%               (nu punem intregul path, ci doar numele imaginii: 'albert.jpg')

% Aceasta functie returneaza toate detectiile ( = ferestre) pentru toate imaginile din parametri.numeDirectorExempleTest
% Directorul cu numele parametri.numeDirectorExempleTest contine imagini ce
% pot sau nu contine fete. Aceasta functie ar trebui sa detecteze fete atat pe setul de
% date MIT+CMU dar si pentru alte imagini (imaginile realizate cu voi la curs+laborator).
% Functia 'suprimeazaNonMaximele' suprimeaza detectii care se suprapun (protocolul de evaluare considera o detectie duplicata ca fiind falsa)
% Suprimarea non-maximelor se realizeaza pe pentru fiecare imagine.

% Functia voastra ar trebui sa calculeze pentru fiecare imagine
% descriptorul HOG asociat. Apoi glisati o fereastra de dimeniune paremtri.dimensiuneFereastra x  paremtri.dimensiuneFereastra (implicit 36x36)
% si folositi clasificatorul liniar (w,b) invatat poentru a obtine un scor. Daca acest scor este deasupra unui prag (threshold) pastrati detectia
% iar apoi procesati toate detectiile prin suprimarea non maximelor.
% pentru detectarea fetelor de diverse marimi folosit un detector multiscale

    imgFiles = dir( fullfile( parametri.numeDirectorExempleTest, '*.jpg' ));
    %initializare variabile de returnat
    detectii = zeros(0,4);
    scoruriDetectii = zeros(0,1);
    imageIdx = cell(0,1);
    currentImg_imageIdx = cell(0, 1);
    for i = 1:length(imgFiles) 
        fprintf('Rulam detectorul facial pe imaginea %s\n', imgFiles(i).name)
        img = imread(fullfile( parametri.numeDirectorExempleTest, imgFiles(i).name ));    
        if(size(img,3) > 1)
            img = rgb2gray(img);
        end
        origImg = img;    
        %completati codul functiei in continuare astfel incat sa asignati un scor ferestrelor in imagine la diferite scale
        %puneti toate ferestrele in matricea currentImg_detectii (de dimensiune nrFerestre x 4 coloane - pentru cele 4 coordonate)
        %puneti scorurile fiecarei ferestre in vectorul currentImg_scoruriDetectii (vector coloana)
        contor = 1;
        currentImg_detectii = zeros(0, 4);
        currentImg_scoruriDetectii = zeros(0, 0);
        for scale = [0.1:0.1:1 1.2:0.2:2]
            img = imresize(origImg, scale);
            
            vl_img = vl_hog(single(img), parametri.dimensiuneCelulaHOG);
            [l, c, ~] = size(vl_img);
            
            k = parametri.dimensiuneFereastra / parametri.dimensiuneCelulaHOG;
            
            steps = (l-k+1) * (c-k+1);
            
            currentImg_detectii = [currentImg_detectii; zeros(steps, 4)];
            currentImg_scoruriDetectii = [currentImg_scoruriDetectii; zeros(steps, 1)];
            currentImg_imageIdx = [currentImg_imageIdx; cell(steps, 1)];
            
            for n = 1:(l-k+1)
                for m = 1:(c-k+1)
                    fereastra = vl_img(n:n+k-1, m:m+k-1, :);
                    currentImg_detectii(contor, :) = [m, n, m+k-1, n+k-1] * parametri.dimensiuneCelulaHOG ./ scale;
                    fereastra = reshape(fereastra, [1, numel(fereastra)]);
                    currentImg_scoruriDetectii(contor) = fereastra*parametri.w + parametri.b;
                    currentImg_imageIdx{contor, 1} = imgFiles(i).name;
                    contor = contor + 1;
                    fprintf("scale = %d, n = %d, m = %d\n", scale, n, m);                
                end
            end
        end


        %aplica nms
        ndx = find(currentImg_scoruriDetectii>parametri.threshold);
        currentImg_detectii = currentImg_detectii(ndx,:);
        currentImg_scoruriDetectii = currentImg_scoruriDetectii(ndx);
        currentImg_imageIdx = currentImg_imageIdx(ndx);
        %suprimeaza non-maximele  
        if size(currentImg_detectii,1)>0
           [is_maximum] = eliminaNonMaximele(currentImg_detectii, currentImg_scoruriDetectii, size(origImg));
            currentImg_scoruriDetectii = currentImg_scoruriDetectii(is_maximum);
            currentImg_detectii = currentImg_detectii(is_maximum,:);
            currentImg_imageIdx = currentImg_imageIdx(is_maximum);
        end    
        detectii = [detectii; currentImg_detectii];
        scoruriDetectii = [scoruriDetectii; currentImg_scoruriDetectii];
        imageIdx = [imageIdx; currentImg_imageIdx];
%        toc
    end
end




